require "./spec_helper"
require "../src/lavinmq/launcher"
require "../src/lavinmq/clustering/client"
require "../src/lavinmq/clustering/etcd_coordinator"
require "../src/lavinmq/proxy_protocol"
require "mqtt-protocol"

# Create a custom slow clustering server for testing
class SlowClusteringServer < LavinMQ::Clustering::Server
  # Override files_with_hash to add delays during sync to simulate slow network
  def files_with_hash(caps : Hash(String, Int64)? = nil, & : Tuple(String, Bytes) -> Nil)
    super(caps) do |tuple|
      sleep 0.1.seconds
      yield tuple
    end
  end

  # Override close to avoid checksums.sha1 file write issues in tests
  def close
    @listeners.each &.close
    @lock.synchronize do
      @followers.each &.close
      @followers.clear
    end
    Fiber.yield # required for follower/listener fibers to actually finish
    # Skip checksums.store to avoid file write errors in tests
  end
end

describe "extract_conn_info during full_sync with syncing_followers", tags: %w[etcd slow] do
  add_etcd_around_each

  it "should handle PROXY protocol from syncing followers during full_sync" do
    leader_config = LavinMQ::Config.instance.dup
    FileUtils.mkdir_p(leader_config.data_dir)
    slow_replicator = SlowClusteringServer.new(leader_config, NullCoordinator.new, 0)
    leader_tcp_server = TCPServer.new("localhost", 0)
    spawn(slow_replicator.listen(leader_tcp_server), name: "slow leader clustering")

    begin
      with_amqp_server(replicator: slow_replicator) do |leader_s|
        leader_s.@config.clustering = true
        with_channel(leader_s) do |ch|
          q = ch.queue("test_queue")
          20.times { |i| q.publish_confirm "message #{i}" }
        end

        follower_data_dir = File.tempname
        Dir.mkdir follower_data_dir

        begin
          follower_config = leader_config.dup.tap &.data_dir = follower_data_dir
          follower_config.metrics_http_port = -1
          follower_client = LavinMQ::Clustering::Client.new(follower_config, 2, slow_replicator.password, proxy: false)

          spawn(name: "slow follower sync") do
            follower_client.follow("localhost", leader_tcp_server.local_address.port)
          end

          sleep 0.5.seconds # Give time for sync to start but not complete

          server_port = amqp_port(leader_s)

          # Ensure we have a syncing follower
          slow_replicator.syncing_followers.size.should be > 0

          client_socket = TCPSocket.new("localhost", server_port)

          begin
            # Since we're connecting from 127.0.0.1 (same as follower), this should work
            proxy_header = "PROXY TCP4 192.168.1.100 127.0.0.1 54321 #{server_port}\r\n"
            client_socket.write(proxy_header.to_slice)
            client_socket.write("AMQP\u0000\u0000\t\u0001".to_slice)
            client_socket.flush

            sleep 0.1.seconds

            buffer = Bytes.new(128)
            client_socket.read_timeout = 0.5.seconds
            bytes_read = client_socket.read(buffer)

            # Verify we got a proper AMQP Connection.Start response
            response_str = String.new(buffer[0, bytes_read])
            response_str.should contain("LavinMQ")
          ensure
            client_socket.close rescue nil
          end
        ensure
          follower_client.try &.close
          FileUtils.rm_rf follower_data_dir if follower_data_dir
        end
      end
    ensure
      slow_replicator.try &.close
    end
  end

  it "should reject PROXY protocol when no followers are syncing or synced" do
    with_amqp_server do |server|
      server.@config.clustering = true

      server_port = amqp_port(server)
      client_socket = TCPSocket.new("localhost", server_port)

      begin
        proxy_header = "PROXY TCP4 192.168.1.100 127.0.0.1 54321 #{server_port}\r\n"
        client_socket.write(proxy_header.to_slice)

        amqp_header = "AMQP\u0000\u0000\t\u0001"
        client_socket.write(amqp_header.to_slice)
        client_socket.flush

        buffer = Bytes.new(8)
        client_socket.read_timeout = 0.5.seconds
        client_socket.read(buffer)

        buffer.should eq LavinMQ::AMQP::PROTOCOL_START_0_9_1.to_slice
      ensure
        client_socket.close rescue nil
      end
    end
  end

  it "should handle PROXY protocol after follower has fully synced" do
    with_clustering do |cluster|
      with_amqp_server(replicator: cluster.replicator) do |leader_s|
        leader_s.@config.clustering = true
        with_channel(leader_s) do |ch|
          q = ch.queue("test_queue")
          q.publish_confirm "test message"
        end

        wait_for { cluster.replicator.followers.first?.try &.lag_in_bytes == 0 }

        server_port = amqp_port(leader_s)
        client_socket = TCPSocket.new("localhost", server_port)

        begin
          # Get the actual follower's remote address for PROXY header
          follower_remote_addr = cluster.replicator.followers.first.remote_address

          proxy_header = "PROXY TCP4 #{follower_remote_addr.address} 127.0.0.1 #{follower_remote_addr.port} #{server_port}\r\n"
          client_socket.write(proxy_header.to_slice)
          client_socket.write("AMQP\u0000\u0000\t\u0001".to_slice)
          client_socket.flush

          buffer = Bytes.new(128)
          begin
            client_socket.read_timeout = 0.5.seconds
            bytes_read = client_socket.read(buffer)

            # Verify we got a proper AMQP Connection.Start response
            response_str = String.new(buffer[0, bytes_read])
            response_str.should contain("LavinMQ")
          end
        ensure
          client_socket.close rescue nil
        end

        cluster.stop
      end
    end
  end

  it "refuses the default user over MQTT when a synced follower forwards a loopback client" do
    with_clustering do |cluster|
      with_amqp_server(replicator: cluster.replicator) do |leader_s|
        leader_s.@config.clustering = true
        leader_s.@config.default_user_only_loopback = true
        mqtt_tcp = TCPServer.new("localhost", 0)
        leader_s.mqtt_server.bind_tcp(mqtt_tcp)
        spawn(name: "mqtt listener") { leader_s.mqtt_server.listen }
        Fiber.yield

        wait_for { cluster.replicator.followers.first?.try &.lag_in_bytes == 0 }

        mqtt_port = mqtt_tcp.local_address.port
        client_socket = TCPSocket.new("localhost", mqtt_port)
        client_socket.read_timeout = 1.second

        begin
          # The follower forwards a client that connected on the follower's own loopback
          client_socket.write "PROXY TCP4 127.0.0.1 127.0.0.1 54321 #{mqtt_port}\r\n".to_slice
          io = MQTT::Protocol::IO.new(client_socket)
          MQTT::Protocol::Connect.new("c1", false, 30u16, "guest", "guest".to_slice, nil).to_io(io)
          connack = MQTT::Protocol::Packet.from_io(io).should be_a(MQTT::Protocol::Connack)
          connack.return_code.should eq MQTT::Protocol::Connack::ReturnCode::NotAuthorized
        ensure
          client_socket.close rescue nil
        end

        cluster.stop
      end
    end
  end
end
