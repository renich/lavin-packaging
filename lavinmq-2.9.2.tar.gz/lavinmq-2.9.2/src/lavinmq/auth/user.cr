require "./base_user"
require "./password"
require "./../sortable_json"
require "./../tag"

module LavinMQ
  module Auth
    class User < BaseUser
      include SortableJSON
      Log = LavinMQ::Log.for "user"
      getter name : String
      getter permissions : Hash(String, Permissions) = Hash(String, Permissions).new
      property tags : Array(Tag)
      getter password
      property plain_text_password

      @password : Password? = nil
      @plain_text_password : String?
      @tags = Array(Tag).new
      @permission_revision = Atomic(UInt32).new(0u32)

      def initialize(pull : JSON::PullParser)
        loc = pull.location
        name = hash = hash_algo = nil
        pull.read_object do |key|
          case key
          when "name"
            name = pull.read_string
          when "password_hash"
            hash = read_password_hash(pull)
          when "hashing_algorithm"
            hash_algo = pull.read_string_or_null
          when "permissions"
            parse_permissions(pull)
          when "tags"
            @tags = Tag.parse_list(pull.read_string)
          else nil
          end
        end
        raise JSON::ParseException.new("Missing json attribute: name", *loc) if name.nil?
        raise JSON::ParseException.new("Missing json attribute: password_hash", *loc) if hash.nil?
        @name = name
        if hash.empty?
          @password = nil
        else
          @password = parse_password(hash, hash_algo || "MD5", loc)
        end
      end

      def self.create(name : String, password : String, hash_algorithm : String, tags : Array(Tag))
        pwd = hash_password(password, hash_algorithm)
        self.new(name, pwd, tags)
      end

      def self.hash_password(password, hash_algorithm)
        case hash_algorithm
        when /bcrypt$/i then Password::BcryptPassword.create(password, cost: 4)
        when /sha256$/i then Password::SHA256Password.create(password)
        when /sha512$/i then Password::SHA512Password.create(password)
        when /md5$/i    then Password::MD5Password.create(password)
        else                 raise UnknownHashAlgoritm.new(hash_algorithm)
        end
      end

      private def read_password_hash(pull : JSON::PullParser) : String
        hash = pull.read_string_or_null
        if hash.nil?
          Log.warn { "Possibly malformed JSON: 'password_hash' was null" }
          return ""
        end
        hash
      end

      private def parse_password(hash, hash_algorithm, loc = nil)
        return nil unless hash_algorithm
        case hash_algorithm
        when /bcrypt$/i then Password::BcryptPassword.new(hash)
        when /sha256$/i then Password::SHA256Password.new(hash)
        when /sha512$/i then Password::SHA512Password.new(hash)
        when /md5$/i    then Password::MD5Password.new(hash)
        else
          if loc
            raise JSON::ParseException.new("Unsupported hash algorithm", *loc)
          else
            raise UnknownHashAlgoritm.new(hash_algorithm)
          end
        end
      end

      def self.create_hidden_user(name)
        password = Random::Secure.urlsafe_base64(32)
        password_hash = hash_password(password, "sha256")
        user = self.new(name, password_hash, [Tag::Administrator])
        user.plain_text_password = password
        user
      end

      def initialize(@name, password_hash, hash_algorithm, @tags)
        update_password_hash(password_hash, hash_algorithm)
      end

      def initialize(@name, @password, @tags)
      end

      def hidden? : Bool
        Auth::UserStore.hidden?(@name)
      end

      def update_password_hash(password_hash, hash_algorithm)
        if password_hash.empty?
          @password = nil
          return
        end
        @password = parse_password(password_hash, hash_algorithm || "MD5")
      end

      def update_password(password, hash_algorithm = "sha256")
        return if @password.try &.verify(password)
        @password = self.class.hash_password(password, hash_algorithm)
      end

      def user_details
        {
          name:              @name,
          password_hash:     @password || "",
          hashing_algorithm: @password.try &.hash_algorithm,
          tags:              @tags.map(&.to_s.downcase).join(","),
        }
      end

      def permissions_details
        @permissions.map { |k, p| permissions_details(k, p) }
      end

      private def parse_permissions(pull)
        pull.read_object do |vhost|
          config = read = write = /^$/
          pull.read_object do |ikey|
            case ikey
            when "config" then config = Regex.from_json(pull)
            when "read"   then read = Regex.from_json(pull)
            when "write"  then write = Regex.from_json(pull)
            else               nil
            end
          end
          @permissions[vhost] = {config: config, read: read, write: write}
        end
      end

      class UnknownHashAlgoritm < ArgumentError; end
    end
  end
end
