require "../controller"
require "../../sortable_json"

module LavinMQ
  module HTTP
    class VHostLimitsController < Controller
      private def register_routes
        get "/api/vhost-limits" do |context, _params|
          arr = vhosts(user(context)).compact_map { |v| VHostLimitsView.new(v).self_if_limited }
          page(context, arr)
        end

        get "/api/vhost-limits/:vhost" do |context, params|
          with_vhost(context, params) do |vhost|
            refuse_unless_management(context, user(context), vhost)
            [VHostLimitsView.new(vhost).self_if_limited].compact.to_json(context.response.output)
          end
        end

        put "/api/vhost-limits/:vhost/:type" do |context, params|
          u = user(context)
          refuse_unless_administrator(context, u)
          context.response.status_code = 400
          with_vhost(context, params) do |vhost|
            if body = context.request.body
              json = JSON.parse(body)
              if value = json["value"]?.try &.as_i?
                value = nil if value < 0
                case params["type"]
                when "max-connections"
                  vhost.max_connections = value
                  context.response.status_code = 204
                when "max-queues"
                  vhost.max_queues = value
                  context.response.status_code = 204
                end
              end
            end
          end
          context
        end

        delete "/api/vhost-limits/:vhost/:type" do |context, params|
          context.response.status_code = 400
          refuse_unless_administrator(context, user(context))
          with_vhost(context, params) do |vhost|
            case params["type"]
            when "max-connections"
              context.response.status_code = 204
              vhost.max_connections = nil
            when "max-queues"
              context.response.status_code = 204
              vhost.max_queues = nil
            end
          end
          context
        end
      end

      struct VHostLimitsView
        include SortableJSON

        def initialize(@vhost : VHost)
        end

        def self_if_limited : VHostLimitsView?
          self if @vhost.max_connections || @vhost.max_queues
        end

        def details_tuple
          value = NamedTuple.new
          if max = @vhost.max_connections
            value = value.merge({"max-connections": max})
          end
          if max = @vhost.max_queues
            value = value.merge({"max-queues": max})
          end
          {
            vhost: @vhost.name,
            value: value,
          }
        end

        def search_match?(value : String) : Bool
          @vhost.name.includes? value
        end

        def search_match?(value : Regex) : Bool
          value === @vhost.name
        end
      end
    end
  end
end
