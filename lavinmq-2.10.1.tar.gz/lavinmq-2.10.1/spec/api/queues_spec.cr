require "socket"
require "socket/tcp_socket"
require "../spec_helper"
require "compress/deflate"

describe LavinMQ::HTTP::QueuesController do
  describe "GET /api/queues" do
    it "should return all queues" do
      with_http_server do |http, s|
        s.vhosts["/"].declare_queue("q0", false, false)
        response = http.get("/api/queues")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        body.as_a.empty?.should be_false
        keys = ["name", "durable", "exclusive", "auto_delete", "arguments", "consumers", "vhost",
                "messages", "ready", "unacked", "policy", "exclusive_consumer_tag", "state",
                "effective_policy_definition"]
        body.as_a.each { |v| keys.each { |k| v.as_h.keys.should contain(k) } }
      end
    end

    it "should only return queues in the given state" do
      with_http_server do |http, s|
        vhost = s.vhosts["/"]
        vhost.declare_queue("q_running", false, false)
        vhost.declare_queue("q_paused", false, false)
        vhost.queue("q_paused").pause!
        response = http.get("/api/queues?state=paused")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        body.as_a.map(&.["name"]).should eq ["q_paused"]
      end
    end

    it "should filter on multiple states" do
      with_http_server do |http, s|
        vhost = s.vhosts["/"]
        vhost.declare_queue("q_running", false, false)
        vhost.declare_queue("q_paused", false, false)
        vhost.queue("q_paused").pause!
        vhost.declare_queue("q_closed", true, false)
        vhost.queue("q_closed").close
        response = http.get("/api/queues?state=paused,closed")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        body.as_a.map(&.["name"].as_s).sort!.should eq ["q_closed", "q_paused"]
      end
    end

    it "should return 400 for an invalid state" do
      with_http_server do |http, _|
        response = http.get("/api/queues?state=foo")
        response.status_code.should eq 400
      end
    end

    it "should apply the state filter on top of a name filter, not instead of it" do
      with_http_server do |http, s|
        vhost = s.vhosts["/"]
        vhost.declare_queue("orders_paused", false, false)
        vhost.declare_queue("orders_running", false, false)
        vhost.declare_queue("events_paused", false, false)
        vhost.queue("orders_paused").pause!
        vhost.queue("events_paused").pause!

        response = http.get("/api/queues?state=paused&name=orders")
        response.status_code.should eq 200
        JSON.parse(response.body).as_a.map(&.["name"]).should eq ["orders_paused"]
      end
    end

    it "should apply the state filter on top of a regex name filter" do
      with_http_server do |http, s|
        vhost = s.vhosts["/"]
        vhost.declare_queue("q_paused_1", false, false)
        vhost.declare_queue("q_paused_2", false, false)
        vhost.declare_queue("other_paused", false, false)
        ["q_paused_1", "q_paused_2", "other_paused"].each { |n| vhost.queue(n).pause! }

        response = http.get("/api/queues?state=paused&name=^q_&use_regex=true")
        response.status_code.should eq 200
        JSON.parse(response.body).as_a.map(&.["name"].as_s).sort!.should eq ["q_paused_1", "q_paused_2"]
      end
    end

    it "should keep total_count unfiltered when filtering on state" do
      with_http_server do |http, s|
        vhost = s.vhosts["/"]
        vhost.declare_queue("q_running", false, false)
        vhost.declare_queue("q_paused", false, false)
        vhost.queue("q_paused").pause!
        response = http.get("/api/queues?page=1&state=paused")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        body["total_count"].should eq 2
        body["filtered_count"].should eq 1
        body["items"].as_a.map(&.["name"]).should eq ["q_paused"]
      end
    end
  end
  describe "GET /api/queues/vhost" do
    it "should return all queues for a vhost" do
      with_http_server do |http, s|
        s.vhosts["/"].declare_queue("q0", false, false)
        response = http.get("/api/queues/%2f")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        body.as_a.empty?.should be_false
      end
    end

    it "should only return queues in the given state for a vhost" do
      with_http_server do |http, s|
        vhost = s.vhosts["/"]
        vhost.declare_queue("q_running", false, false)
        vhost.declare_queue("q_closed", true, false)
        vhost.queue("q_closed").close
        response = http.get("/api/queues/%2f?state=closed")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        body.as_a.map(&.["name"]).should eq ["q_closed"]
      end
    end
  end
  describe "GET /api/queues/vhost/name" do
    it "should return queue" do
      with_http_server do |http, s|
        s.vhosts["/"].declare_queue("q0", false, false)
        response = http.get("/api/queues/%2f/q0")
        response.status_code.should eq 200
      end
    end

    it "should return 404 if queue does not exist" do
      with_http_server do |http, _|
        response = http.get("/api/queues/%2f/404")
        response.status_code.should eq 404
      end
    end

    it "should return message stats" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          q = ch.queue("stats_q")
          3.times { q.publish "m1" }
        end

        msgs = Channel(Int32).new
        with_channel(s) do |ch|
          q = ch.queue("stats_q")
          1.times { q.get }

          ch.prefetch 1
          q.subscribe(no_ack: false) do |msg|
            msgs.send 1
            msg.ack
          end
        end
        msgs.receive

        msgs = Channel(Int32).new
        with_channel(s) do |ch|
          q = ch.queue("stats_q")

          ch.prefetch 1
          q.subscribe(no_ack: true) do
            msgs.send 1
          end
        end
        msgs.receive

        body = %({ "count": 1, "ack_mode": "get", "encoding": "auto" })
        http.post("/api/queues/%2f/stats_q/get", body: body)

        response = http.get("/api/queues/%2f/stats_q")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        body["message_stats"]["publish_details"]["rate"].nil?.should be_false
        body["message_stats"]["get"].should eq 1
        body["message_stats"]["deliver"].should eq 1
        body["message_stats"]["get_no_ack"].should eq 1
        body["message_stats"]["deliver_no_ack"].should eq 1
        body["message_stats"]["deliver_get"].should eq 4
      end
    end

    it "writes message_stats only once" do
      with_http_server do |http, s|
        s.vhosts["/"].declare_queue("stats_q", false, false)
        response = http.get("/api/queues/%2f/stats_q")
        response.body.scan(/"message_stats"/).size.should eq 1
      end
    end

    it "should return no persistent message count" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          q = ch.queue("stats_q", auto_delete: false, durable: false, exclusive: false)
          q.publish "m1"
        end
        response = http.get("/api/queues/%2f/stats_q")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        body["messages"].should eq 1
        body["messages_persistent"].should eq 0
      end
    end

    it "should return persistent message count" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          q = ch.queue("stats_q", auto_delete: false, durable: true, exclusive: false)
          q.publish "m1"
        end
        response = http.get("/api/queues/%2f/stats_q")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        body["messages"].should eq 1
        body["messages_persistent"].should eq 1
      end
    end
  end

  describe "GET /api/queues/vhost/name/unacked" do
    describe "subscribe" do
      it "should return unacked messages" do
        with_http_server do |http, s|
          with_channel(s) do |ch|
            q = ch.queue("unacked_q")
            2.times { q.publish "m1" }
            q.subscribe(no_ack: false) { }

            wait_for { s.vhosts["/"].queue("unacked_q").unacked_count == 2 }
            s.vhosts["/"].queue("unacked_q").basic_get_unacked_size.should eq 0
            response = http.get("/api/queues/%2f/unacked_q/unacked?page=1&page_size=100")
            response.status_code.should eq 200
            body = JSON.parse(response.body)
            body["items"].size.should eq 2
          end
        end
      end

      it "should not return if acked" do
        with_http_server do |http, s|
          with_channel(s) do |ch|
            q = ch.queue("unacked_q")
            2.times { q.publish "m1" }

            q.subscribe(no_ack: false) do |msg|
              msg.ack
            end
            wait_for { s.vhosts["/"].queue("unacked_q").unacked_count == 0 }

            response = http.get("/api/queues/%2f/unacked_q/unacked?page=1&page_size=100")
            response.status_code.should eq 200
            body = JSON.parse(response.body)
            body["items"].size.should eq 0
          end
        end
      end

      it "should not return if rejected" do
        with_http_server do |http, s|
          with_channel(s) do |ch|
            q = ch.queue("unacked_q")
            2.times { q.publish "m1" }

            q.subscribe(no_ack: false) do |msg|
              msg.reject
            end
            wait_for { s.vhosts["/"].queue("unacked_q").unacked_count == 0 }

            response = http.get("/api/queues/%2f/unacked_q/unacked?page=1&page_size=100")
            response.status_code.should eq 200
            body = JSON.parse(response.body)
            body["items"].size.should eq 0
          end
        end
      end
    end

    describe "basic get" do
      it "should return unacked messages" do
        with_http_server do |http, s|
          with_channel(s) do |ch|
            q = ch.queue("unacked_q")
            q.publish "m1"

            q.get(no_ack: false)
            wait_for { s.vhosts["/"].queue("unacked_q").basic_get_unacked_size == 1 }
            response = http.get("/api/queues/%2f/unacked_q/unacked?page=1&page_size=100")
            response.status_code.should eq 200
            body = JSON.parse(response.body)
            body["items"].size.should eq 1
          end
        end
      end

      it "should not return if acked" do
        with_http_server do |http, s|
          with_channel(s) do |ch|
            q = ch.queue("unacked_q")
            q.publish "m1"
            ch.prefetch(1)
            if msg = q.get(no_ack: false)
              wait_for { s.vhosts["/"].queue("unacked_q").unacked_count == 1 }
              msg.ack
            end
            wait_for { s.vhosts["/"].queue("unacked_q").unacked_count == 0 }
            response = http.get("/api/queues/%2f/unacked_q/unacked?page=1&page_size=100")
            response.status_code.should eq 200
            body = JSON.parse(response.body)
            body["items"].size.should eq 0
          end
        end
      end

      it "should not return if rejected" do
        with_http_server do |http, s|
          with_channel(s) do |ch|
            q = ch.queue("unacked_q")
            q.publish "m1"

            ch.prefetch(1)
            if msg = q.get(no_ack: false)
              wait_for { s.vhosts["/"].queue("unacked_q").unacked_count == 1 }
              msg.reject
            end
            wait_for { s.vhosts["/"].queue("unacked_q").unacked_count == 0 }
            response = http.get("/api/queues/%2f/unacked_q/unacked?page=1&page_size=100")
            response.status_code.should eq 200
            body = JSON.parse(response.body)
            body["items"].size.should eq 0
          end
        end
      end

      it "should be removed from unacked when channel closes" do
        with_http_server do |http, s|
          with_channel(s) do |ch|
            q = ch.queue("unacked_q")
            q.publish "m1"

            ch.prefetch(1)
            q.get(no_ack: false)
            wait_for { s.vhosts["/"].queue("unacked_q").unacked_count == 1 }
          end
          wait_for { s.vhosts["/"].queue("unacked_q").unacked_count == 0 }
          response = http.get("/api/queues/%2f/unacked_q/unacked?page=1&page_size=100")
          response.status_code.should eq 200
          body = JSON.parse(response.body)
          body["items"].size.should eq 0
        end
      end
    end
  end

  describe "GET /api/queues/vhost/name/bindings" do
    it "should return queue bindings" do
      with_http_server do |http, s|
        s.vhosts["/"].declare_queue("q0", false, false)
        s.vhosts["/"].bind_queue("q0", "amq.direct", "foo")
        response = http.get("/api/queues/%2f/q0/bindings?page=1&page_size=100")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        body["items"].as_a.size.should eq 2
      end
    end
  end
  describe "PUT /api/queues/vhost/name" do
    it "should create queue" do
      with_http_server do |http, _|
        body = {
          "durable"     => false,
          "auto_delete" => true,
          "arguments"   => {
            "max-length" => 10,
          },
        }
        response = http.put("/api/queues/%2f/putqueue", body: body.to_json)
        response.status_code.should eq 201
        response = http.get("/api/queues/%2f/putqueue")
        response.status_code.should eq 200
        json = JSON.parse(response.body)
        json["name"].should eq "putqueue"
        body.each do |key, value|
          json[key].should eq value
        end
      end
    end

    it "should not require any body (1)" do
      with_http_server do |http, _|
        response = http.put("/api/queues/%2f/okq")
        response.status_code.should eq 201
      end
    end

    it "should not require any body (2)" do
      with_http_server do |http, _|
        # Use raw socket to make a request without body and content-length
        addr = http.addr
        TCPSocket.open addr.address, addr.port do |io|
          io.write "PUT /api/queues/%2f/okq2 HTTP/1.1\r\n".to_slice
          http.test_headers.serialize(io)
          io.write "\r\n".to_slice
          io.flush
          response = HTTP::Client::Response.from_io?(io, ignore_body: false, decompress: false)
          response = response.should_not be_nil
          response.status_code.should eq 201
        end
      end
    end

    it "should require durable to be the same when overwriting" do
      with_http_server do |http, _|
        body = <<-JSON
          {
            "durable": true
          }
          JSON
        response = http.put("/api/queues/%2f/q1d", body: body)
        response.status_code.should eq 201
        body = <<-JSON
          {
            "durable": false
          }
          JSON
        response = http.put("/api/queues/%2f/q1d", body: body)
        response.status_code.should eq 400
      end
    end

    it "should not be possible to declare amq. prefixed queues" do
      with_http_server do |http, _|
        response = http.put("/api/queues/%2f/amq.test", body: %({}))
        response.status_code.should eq 400
      end
    end

    it "should respond with 400 for PreconditionFailed errors" do
      with_http_server do |http, _|
        # supplying 'x-dead-letter-routing-key' is only valid if
        # 'x-dead-letter-exchange' is also in the request
        # so this request generates a Error::PreconditionFailed
        body = <<-JSON
          {
            "arguments": {"x-dead-letter-routing-key": "value"}
          }
          JSON
        response = http.put("/api/queues/%2f/precond-failed", body: body)
        response.status_code.should eq 400
      end
    end

    it "should require config access to declare" do
      with_http_server do |http, _|
        hdrs = HTTP::Headers{"Authorization" => "Basic dGVzdF9wZXJtOnB3"}
        response = http.put("/api/queues/%2f/test_perm", headers: hdrs, body: %({}))
        response.status_code.should eq 401
      end
    end
  end
  describe "DELETE /api/queues/vhost/name" do
    it "should delete queue" do
      with_http_server do |http, s|
        s.vhosts["/"].declare_queue("delq", false, false)
        response = http.delete("/api/queues/%2f/delq")
        response.status_code.should eq 204
      end
    end

    it "should not delete queue if it has messasge when query param if-unused is set" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          q = ch.queue("q3", auto_delete: false, durable: true, exclusive: false)
          q.publish "m1"
          sleep 0.05.milliseconds
          body = <<-JSON
            {
              "count": 1,
              "ack_mode": "reject_requeue_true",
              "encoding": "auto"
            }
            JSON
          response = http.post("/api/queues/%2f/q3/get", body: body)
          response.status_code.should eq 200
          body = JSON.parse(response.body)
          body.as_a.empty?.should be_false
          keys = ["payload_bytes", "redelivered", "exchange", "routing_key", "message_count",
                  "properties", "payload", "payload_encoding"]
          body.as_a.each { |v| keys.each { |k| v.as_h.keys.should contain(k) } }
          s.vhosts["/"].queue("q3").message_count.should be > 0
        end
      end
    end
  end
  describe "POST /api/queues/vhost/name/get" do
    it "should get plain text messages" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          q = ch.queue("q4")
          q4 = s.vhosts["/"].queue("q4")
          q.publish "m1"
          wait_for { q4.message_count == 1 }
          body = %({ "count": 1, "ack_mode": "get", "encoding": "auto" })
          response = http.post("/api/queues/%2f/q4/get", body: body)
          response.status_code.should eq 200
          body = JSON.parse(response.body)
          body[0]["payload"].should eq "m1"
          q4.empty?.should be_true
        end
      end
    end

    it "should get encoded messages" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          q = ch.queue("q4")
          q4 = s.vhosts["/"].queue("q4")
          mem_io = IO::Memory.new
          Compress::Deflate::Writer.open(mem_io, Compress::Deflate::BEST_SPEED) { |deflate| deflate.print("m1") }
          encoded_msg = mem_io.to_s
          q.publish encoded_msg, props: AMQP::Client::Properties.new(content_encoding: "deflate")
          wait_for { q4.message_count == 1 }
          body = %({ "count": 1, "ack_mode": "get", "encoding": "auto" })
          response = http.post("/api/queues/%2f/q4/get", body: body)
          response.status_code.should eq 200
          body = JSON.parse(response.body)
          body[0]["payload"].should eq Base64.urlsafe_encode(encoded_msg)
          body[0]["payload_encoding"].should eq "base64"
          q4.empty?.should be_true
        end
      end
    end

    it "should reject on error while getting messages" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          q = ch.queue("q4")
          q4 = s.vhosts["/"].queue("q4")
          message_count = 100
          message_count.times { q.publish "m1" * 100000 }
          wait_for { q4.message_count == message_count }
          body = %({ "count": #{message_count}, "ack_mode": "get", "encoding": "json" })
          client = HTTP::Client.new(URI.parse http.test_uri(""))

          # Pipe the response into an IO.pipe we never drain. The pipe fills, the
          # client stops reading, kernel TCP buffers fill, and the server blocks
          # mid-response with messages still unacked. Closing the client then
          # forces the write error that the controller is expected to rescue.
          pipe_r, pipe_w = IO.pipe

          spawn do
            client.post("/api/queues/%2f/q4/get", body: body, headers: http.test_headers) do |response|
              IO.copy(response.body_io, pipe_w)
            end
          rescue # Ignore errors from closing the client
          ensure
            pipe_w.close
          end

          loop do
            if q4.unacked_count > 0
              # Simulate an error by closing the client while there are unacked messages
              client.close
              break
            elsif q4.message_count == 0
              fail("All messages already acked, failed to test scenario")
              break
            end
            Fiber.yield
          end

          # All unacked messages should be requeued
          wait_for { q4.unacked_count == 0 }
          pipe_r.close
        end
      end
    end

    it "should not double-decrement unacked_count when an ack fails mid-batch" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          q = ch.queue("q4")
          q4 = s.vhosts["/"].queue("q4").as(LavinMQ::AMQP::Queue)
          3.times { q.publish_confirm "m1" }
          wait_for { q4.message_count == 3 }

          # Let the first ack of the batch succeed and the next one fail. The
          # failing ack has already decremented unacked_count, so the recovery
          # path must only requeue the messages it hasn't finalized yet.
          q4.@msg_store.raise_on_delete_after = 1

          body = %({ "count": 3, "ack_mode": "get", "encoding": "auto" })
          begin
            http.post("/api/queues/%2f/q4/get", body: body)
          rescue # the endpoint re-raises the injected failure
          end
          q4.@msg_store.raise_on_delete_after = nil

          q4.unacked_count.should eq 0
          http.get("/api/overview").status_code.should eq 200
        end
      end
    end

    it "should handle count > message_count" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          q = ch.queue("q5", auto_delete: false, durable: true, exclusive: false)
          q.publish "m1"
          sleep 0.05.milliseconds
          body = <<-JSON
            {
              "count": 2,
              "ack_mode": "get",
              "encoding": "auto"
            }
            JSON
          response = http.post("/api/queues/%2f/q5/get", body: body)
          response.status_code.should eq 200
        end
      end
    end

    it "should handle empty q" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          ch.queue("q6")
          body = <<-JSON
            {
              "count": 1,
              "ack_mode": "get",
              "encoding": "auto"
            }
            JSON
          response = http.post("/api/queues/%2f/q6/get", body: body)
          response.status_code.should eq 200
          body = JSON.parse(response.body)
          body.as_a.should be_empty
        end
      end
    end

    it "should handle base64 encoding" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          q = ch.queue("q7")
          q.publish "m1"
          sleep 0.05.milliseconds
          body = <<-JSON
            {
              "count": 1,
              "ack_mode": "get",
              "encoding": "base64"
            }
            JSON
          response = http.post("/api/queues/%2f/q7/get", body: body)
          response.status_code.should eq 200
          body = JSON.parse(response.body)
          Base64.decode_string(body[0]["payload"].as_s).should eq "m1"
        end
      end
    end

    it "should not allow get and requeue" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          q = ch.queue("q8")
          q.publish "m1"
          sleep 0.05.milliseconds
          body = <<-JSON
            {
              "count": 1,
              "ack_mode": "get",
              "requeue": true,
              "encoding": "base64"
            }
            JSON
          response = http.post("/api/queues/%2f/q8/get", body: body)
          response.status_code.should eq 400
          body = JSON.parse(response.body)
          body["reason"].should eq "Cannot requeue message on get"
        end
      end
    end
  end

  describe "PUT /api/queues/vhost/name/pause" do
    it "should pause the queue" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          ch.queue("confqueue")
          response = http.put("/api/queues/%2f/confqueue/pause")
          response.status_code.should eq 204
          response = http.get("/api/queues/%2f/confqueue")
          response.status_code.should eq 200
          body = JSON.parse(response.body)
          body["state"].should eq "paused"
        end
      end
    end
  end

  describe "PUT /api/queues/vhost/name/resume" do
    it "should resume the queue" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          ch.queue("confqueue")

          q = s.vhosts["/"].queue("confqueue")
          q.pause!

          response = http.get("/api/queues/%2f/confqueue")
          response.status_code.should eq 200
          body = JSON.parse(response.body)
          body["state"].should eq "paused"

          response = http.put("/api/queues/%2f/confqueue/resume")
          response.status_code.should eq 204

          response = http.get("/api/queues/%2f/confqueue")
          response.status_code.should eq 200
          body = JSON.parse(response.body)
          body["state"].should eq "running"
        end
      end
    end
  end

  describe "GET /api/queues/vhost/name effective_arguments" do
    it "should include x-max-age in effective_arguments for streams" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          args = {"x-queue-type": "stream", "x-max-age": "1h"}
          ch.queue("stream-with-max-age", args: AMQP::Client::Arguments.new(args))

          response = http.get("/api/queues/%2f/stream-with-max-age")
          response.status_code.should eq 200
          body = JSON.parse(response.body)
          body["effective_arguments"].as_a.should contain("x-max-age")
          body["effective_arguments"].as_a.should contain("x-queue-type")
        end
      end
    end
  end

  describe "PUT /api/queues/vhost/name/restart" do
    it "should restart a queue" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          queue_name = "restart_queue"
          ch.queue(queue_name)

          q = s.vhosts["/"].queue(queue_name)
          q.close

          response = http.get("/api/queues/%2f/#{queue_name}")
          response.status_code.should eq 200
          body = JSON.parse(response.body)
          body["state"].should eq "closed"

          response = http.put("/api/queues/%2f/#{queue_name}/restart")
          response.status_code.should eq 204

          response = http.get("/api/queues/%2f/#{queue_name}")
          response.status_code.should eq 200
          body = JSON.parse(response.body)
          body["state"].should eq "running"
        end
      end
    end

    it "should not restart if queue is still running" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          queue_name = "restart_queue"
          ch.queue(queue_name)

          s.vhosts["/"].queue(queue_name)
          response = http.put("/api/queues/%2f/#{queue_name}/restart")
          response.status_code.should eq 400

          response = http.get("/api/queues/%2f/#{queue_name}")
          response.status_code.should eq 200
          body = JSON.parse(response.body)
          body["state"].should eq "running"
        end
      end
    end
  end
end
