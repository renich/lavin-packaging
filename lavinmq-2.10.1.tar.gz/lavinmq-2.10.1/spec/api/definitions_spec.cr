require "../spec_helper"
require "../../src/lavinmq/definitions"

private def import_defs(s, defs)
  tmpfile = File.tempname("lavinmq-defs", ".json")
  File.write(tmpfile, defs.to_json)
  LavinMQ::GlobalDefinitions.import_from_file(tmpfile, s)
ensure
  File.delete?(tmpfile) if tmpfile
end

private def ctx(username)
  LavinMQ::MQTT::PermissionService::Context.new(username, "dev")
end

describe LavinMQ::GlobalDefinitions do
  [false, true].each do |skip_existing|
    it "keeps all active groups after a failed import save with skip_existing=#{skip_existing}" do
      defs = {"mqtt_permissions" => [
        {"name" => "default", "vhost" => "/", "members" => ["*"],
         "rules" => [{"identifier" => "public", "pattern" => "public/#", "read" => true, "write" => true}]},
        {"name" => "sensors", "vhost" => "/", "members" => ["alice"],
         "rules" => [{"identifier" => "s", "pattern" => "sensors/#", "read" => true, "write" => true}]},
      ]}
      with_http_server do |http, s|
        vhost = s.vhosts["/"]
        service = vhost.mqtt_permission_service
        original = service.to_json
        path = File.join(vhost.data_dir, "mqtt_permissions.json")
        on_disk = File.read(path)
        Dir.mkdir("#{path}.tmp")
        if skip_existing
          expect_raises(LavinMQ::MQTT::PermissionService::SaveError) { import_defs(s, defs) }
        else
          http.post("/api/definitions", body: defs.to_json).status_code.should eq 500
        end
        service.to_json.should eq original
        service["sensors"]?.should be_nil
        service.can_write?(ctx("guest"), "anything").should be_true
        File.read(path).should eq on_disk

        Dir.delete("#{path}.tmp")
        if skip_existing
          import_defs(s, defs)
        else
          http.post("/api/definitions", body: defs.to_json).status_code.should eq 200
        end
        reloaded = LavinMQ::MQTT::PermissionService.new("/", vhost.data_dir, nil)
        [service, reloaded].each do |permissions|
          # skip_existing keeps the existing default group, without it the
          # narrowed default group from the file replaces it.
          permissions.can_write?(ctx("guest"), "anything").should eq skip_existing
          permissions.can_write?(ctx("guest"), "public/1").should be_true
          permissions.can_write?(ctx("alice"), "sensors/1").should be_true
        end
      end
    end

    it "adds groups next to the default group of an existing vhost with skip_existing=#{skip_existing}" do
      defs = {"mqtt_permissions" => [
        {"name" => "default", "vhost" => "/", "members" => ["*"],
         "rules" => [{"identifier" => "public", "pattern" => "public/#", "read" => true, "write" => true}]},
        {"name" => "sensors", "vhost" => "iot", "members" => ["alice"],
         "rules" => [{"identifier" => "s", "pattern" => "sensors/#", "read" => true, "write" => true}]},
        {"name" => "sensors", "vhost" => "/", "members" => ["alice"],
         "rules" => [{"identifier" => "s", "pattern" => "sensors/#", "read" => true, "write" => true}]},
      ]}
      with_amqp_server do |s|
        s.vhosts.create("iot")
        LavinMQ::GlobalDefinitions.new(s).import(JSON.parse(defs.to_json), skip_existing: skip_existing)

        service = s.vhosts["/"].mqtt_permission_service
        service.can_write?(ctx("guest"), "public/1").should be_true
        service.can_write?(ctx("guest"), "private/1").should eq skip_existing
        service.can_write?(ctx("alice"), "sensors/1").should be_true

        other = s.vhosts["iot"].mqtt_permission_service
        other["default"]?.should_not be_nil
        other.can_write?(ctx("alice"), "sensors/1").should be_true
        other.can_write?(ctx("guest"), "sensors/1").should be_true
      end
    end
  end

  describe ".import_from_file" do
    it "does not overwrite existing users" do
      defs = {
        "users" => [
          {"name" => "guest", "password_hash" => "$2a$04$PuoK2zgHy/NHRU3CRUCidOKaSTwFkv97Sm.zTspKZRWJkn6l37YOe",
           "hashing_algorithm" => "Bcrypt", "tags" => "administrator"},
        ],
      }
      tmpfile = File.tempname("lavinmq-defs", ".json")
      File.write(tmpfile, defs.to_json)
      begin
        with_amqp_server do |s|
          original_hash = s.users["guest"].user_details["password_hash"]
          LavinMQ::GlobalDefinitions.import_from_file(tmpfile, s)
          s.users["guest"].user_details["password_hash"].should eq original_hash
        end
      ensure
        File.delete?(tmpfile)
      end
    end

    it "does not overwrite existing permissions" do
      defs = {
        "permissions" => [
          {"user" => "guest", "vhost" => "/", "configure" => "^new$", "read" => "^new$", "write" => "^new$"},
        ],
      }
      tmpfile = File.tempname("lavinmq-defs", ".json")
      File.write(tmpfile, defs.to_json)
      begin
        with_amqp_server do |s|
          original_config = s.users["guest"].permissions["/"][:config]
          LavinMQ::GlobalDefinitions.import_from_file(tmpfile, s)
          s.users["guest"].permissions["/"][:config].should eq original_config
        end
      ensure
        File.delete?(tmpfile)
      end
    end

    it "skips default vhost and user when load_definitions is configured" do
      defs = {
        "users" => [
          {"name" => "admin", "password_hash" => "$2a$04$g5IMwYwvgDLACYdAQxCpCulKuK/Ym2I56Tz6T9Wi9DGdKQG.DE8Gi",
           "hashing_algorithm" => "Bcrypt", "tags" => "administrator"},
        ],
        "vhosts" => [
          {"name" => "production"},
        ],
        "permissions" => [
          {"user" => "admin", "vhost" => "production", "configure" => ".*", "read" => ".*", "write" => ".*"},
        ],
      }
      tmpfile = File.tempname("lavinmq-defs", ".json")
      File.write(tmpfile, defs.to_json)
      begin
        config = LavinMQ::Config.new
        config.load_definitions = tmpfile
        with_amqp_server(config: config) do |s|
          LavinMQ::GlobalDefinitions.import_from_file(tmpfile, s)
          s.vhosts["/"]?.should be_nil
          s.users["guest"]?.should be_nil
          s.vhosts["production"]?.should_not be_nil
          s.users["admin"]?.should_not be_nil
        end
      ensure
        File.delete?(tmpfile)
        LavinMQ::Config.instance.load_definitions = ""
      end
    end

    it "imports definitions from a JSON file" do
      defs = {
        "queues" => [
          {"name" => "load_def_q1", "vhost" => "/", "durable" => true, "auto_delete" => false, "arguments" => {} of String => String},
        ],
      }
      tmpfile = File.tempname("lavinmq-defs", ".json")
      File.write(tmpfile, defs.to_json)
      begin
        with_amqp_server do |s|
          LavinMQ::GlobalDefinitions.import_from_file(tmpfile, s)
          s.vhosts["/"].queue_exists?("load_def_q1").should be_true
        end
      ensure
        File.delete?(tmpfile)
      end
    end

    it "imports bindings with the mqtt exchange as source" do
      defs = {
        "queues" => [
          {"name" => "mqtt.sub", "vhost" => "/", "durable" => true, "auto_delete" => false,
           "arguments" => {"x-queue-type" => "mqtt"}},
        ],
        "bindings" => [
          {"source" => "mqtt.default", "vhost" => "/", "destination" => "mqtt.sub",
           "destination_type" => "queue", "routing_key" => "a/b", "arguments" => {} of String => String},
        ],
      }
      tmpfile = File.tempname("lavinmq-defs", ".json")
      File.write(tmpfile, defs.to_json)
      begin
        with_amqp_server do |s|
          # Nothing has created an MQTT broker at this point, just like in
          # Launcher#start where definitions are loaded before MQTT::Server
          LavinMQ::GlobalDefinitions.import_from_file(tmpfile, s)
          exchange = s.vhosts["/"].mqtt_exchange
          exchange.bindings_details.map(&.binding_key.routing_key).should eq ["a/b"]
        end
      ensure
        File.delete?(tmpfile)
      end
    end

    it "raises if definitions file not found" do
      with_amqp_server do |s|
        expect_raises(File::NotFoundError) do
          LavinMQ::GlobalDefinitions.import_from_file("/tmp/nonexistent_#{rand(100000)}.json", s)
        end
      end
    end

    it "preserves admin permissions from definitions file on fresh boot" do
      defs = {
        "users" => [
          {"name" => "myadmin", "password_hash" => "+pHuxkR9fCyrrwXjOD4BP4XbzO3l8LJr8YkThMgJ0yVHFRE+",
           "hashing_algorithm" => "rabbit_password_hashing_sha256", "tags" => "administrator"},
        ],
        "vhosts"      => [{"name" => "restricted_vh"}],
        "permissions" => [
          {"user" => "myadmin", "vhost" => "restricted_vh",
           "configure" => "^only$", "read" => "^only$", "write" => "^only$"},
        ],
      }
      tmpfile = File.tempname("lavinmq-defs", ".json")
      File.write(tmpfile, defs.to_json)
      begin
        with_amqp_server do |s|
          LavinMQ::GlobalDefinitions.import_from_file(tmpfile, s)
          perms = s.users["myadmin"].permissions["restricted_vh"]
          perms[:config].should eq(/^only$/)
          perms[:read].should eq(/^only$/)
          perms[:write].should eq(/^only$/)
        end
      ensure
        File.delete?(tmpfile)
      end
    end

    it "skips permissions for unknown users without crashing" do
      defs = {
        "permissions" => [
          {"user" => "ghost", "vhost" => "/", "configure" => ".*", "read" => ".*", "write" => ".*"},
        ],
      }
      tmpfile = File.tempname("lavinmq-defs", ".json")
      File.write(tmpfile, defs.to_json)
      begin
        with_amqp_server do |s|
          LavinMQ::GlobalDefinitions.import_from_file(tmpfile, s)
          s.users["ghost"]?.should be_nil
        end
      ensure
        File.delete?(tmpfile)
      end
    end

    it "raises on invalid regex in permissions" do
      defs = {
        "users" => [
          {"name" => "regexuser", "password_hash" => "+pHuxkR9fCyrrwXjOD4BP4XbzO3l8LJr8YkThMgJ0yVHFRE+",
           "hashing_algorithm" => "rabbit_password_hashing_sha256", "tags" => "administrator"},
        ],
        "permissions" => [
          {"user" => "regexuser", "vhost" => "/", "configure" => "[", "read" => ".*", "write" => ".*"},
        ],
      }
      tmpfile = File.tempname("lavinmq-defs", ".json")
      File.write(tmpfile, defs.to_json)
      begin
        with_amqp_server do |s|
          expect_raises(ArgumentError, /Invalid regex in configure permission/) do
            LavinMQ::GlobalDefinitions.import_from_file(tmpfile, s)
          end
        end
      ensure
        File.delete?(tmpfile)
      end
    end

    it "raises on an invalid topic filter in a permission group" do
      defs = {
        "mqtt_permissions" => [
          {"name"    => "bad",
           "members" => [] of String,
           "rules"   => [{"identifier" => "bad", "pattern" => "secret/#/temp", "read" => true, "write" => false}]},
        ],
      }
      tmpfile = File.tempname("lavinmq-defs", ".json")
      File.write(tmpfile, defs.to_json)
      begin
        with_amqp_server do |s|
          expect_raises(ArgumentError, /Invalid MQTT topic filter/) do
            LavinMQ::GlobalDefinitions.import_from_file(tmpfile, s)
          end
        end
      ensure
        File.delete?(tmpfile)
      end
    end

    it "raises on invalid JSON" do
      tmpfile = File.tempname("lavinmq-defs", ".json")
      File.write(tmpfile, "not valid json")
      begin
        with_amqp_server do |s|
          expect_raises(JSON::ParseException) do
            LavinMQ::GlobalDefinitions.import_from_file(tmpfile, s)
          end
        end
      ensure
        File.delete?(tmpfile)
      end
    end
  end
end

describe LavinMQ::HTTP::Server do
  describe "POST /api/definitions" do
    it "should refuse non-administrator users" do
      with_http_server do |http, s|
        s.users.delete("guest")
        s.users.create("policymaker_user", "guest", [LavinMQ::Tag::PolicyMaker], save: false)
        headers = HTTP::Headers{"Authorization" => "Basic cG9saWN5bWFrZXJfdXNlcjpndWVzdA=="}
        body = %({ "vhosts":[{ "name":"test" }] })
        response = http.post("/api/definitions", headers: headers, body: body)
        response.status_code.should eq 403
        body = JSON.parse(response.body)
        body["reason"].should eq "Access refused"
      end
    end

    it "imports users" do
      with_http_server do |http, s|
        body = <<-JSON
          {
            "users":[{
              "name":"sha256",
              "password_hash":"nEeL9j6VAMtdsehezoLxjI655S4vkTWs1/EJcsjVY7o",
              "hashing_algorithm":"rabbit_password_hashing_sha256","tags":[]
            },
            {
              "name":"sha512",
              "password_hash":"wiwLjmFjJauaeABIerBxpPx2548gydUaqj9wpxyeio7+gmye+/KuGaLeAqrV1Tx1pk6bwYGR0gHMx+whOqxD6Q",
              "hashing_algorithm":"rabbit_password_hashing_sha512","tags":[]
            },
            {
              "name":"bcrypt",
              "password_hash":"$2a$04$g5IMwYwvgDLACYdAQxCpCulKuK/Ym2I56Tz6T9Wi9DGdKQG.DE8Gi",
              "hashing_algorithm":"Bcrypt","tags":[]
            },
            {
              "name":"md5",
              "password_hash":"VBxXlgu5l5QmVdFOO5YH+Q==",
              "hashing_algorithm":"rabbit_password_hashing_md5","tags":[]
            }]
          }
          JSON
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 200
        {"sha256", "sha512", "bcrypt", "md5"}.each do |name|
          u = s.users[name]?
          next unless u
          u.should be_a(LavinMQ::Auth::BaseUser)
          ok = u.not_nil!.password.not_nil!.verify "hej"
          {u.name, ok}.should(eq({u.name, true}))
        end
      end
    end

    it "returns 400 when importing a user with an unsupported hashing_algorithm" do
      with_http_server do |http, s|
        body = %({"users":[{"name":"bogus","password_hash":"abc","hashing_algorithm":"bogus","tags":[]}]})
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 400
        s.users["bogus"]?.should be_nil
      end
    end

    it "imports passwordless user (password_hash empty string)" do
      with_http_server do |http, s|
        body = %({"users":[{"name":"nopass","password_hash":"","hashing_algorithm":null,"tags":""}]})
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 200
        s.users["nopass"]?.should_not be_nil
        s.users["nopass"].password.should be_nil
      end
    end

    it "imports passwordless user (password_hash null)" do
      with_http_server do |http, s|
        body = %({"users":[{"name":"nopass","password_hash":null,"hashing_algorithm":null,"tags":""}]})
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 200
        s.users["nopass"]?.should_not be_nil
        s.users["nopass"].password.should be_nil
      end
    end

    it "imports user with valid MD5 hash and null hashing_algorithm" do
      with_http_server do |http, s|
        body = %({"users":[{"name":"legacy","password_hash":"VBxXlgu5l5QmVdFOO5YH+Q==","hashing_algorithm":null,"tags":""}]})
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 200
        u = s.users["legacy"]?
        u.should_not be_nil
        u.not_nil!.password.should_not be_nil
        u.not_nil!.password.not_nil!.verify("hej").should be_true
      end
    end

    it "round-trips passwordless user through export and import" do
      with_http_server do |http, s|
        http.put("/api/users/nopass", body: %({"password_hash": ""}))
        export = http.get("/api/definitions")
        export.status_code.should eq 200

        s.users.delete("nopass")
        s.users["nopass"]?.should be_nil

        response = http.post("/api/definitions", body: export.body)
        response.status_code.should eq 200
        s.users["nopass"]?.should_not be_nil
        s.users["nopass"].password.should be_nil
      end
    end

    it "returns 400 when importing a user with missing password_hash" do
      with_http_server do |http, _|
        body = %({"users":[{"name":"nopass","hashing_algorithm":null,"tags":""}]})
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 400
      end
    end

    it "returns 400 when importing a user with non-string password_hash" do
      with_http_server do |http, _|
        body = %({"users":[{"name":"badtype","password_hash":123,"hashing_algorithm":null,"tags":""}]})
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 400
      end
    end

    it "returns 400 when importing a user with non-string hashing_algorithm" do
      with_http_server do |http, _|
        body = %({"users":[{"name":"badtype","password_hash":"","hashing_algorithm":42,"tags":""}]})
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 400
      end
    end

    it "imports vhosts" do
      with_http_server do |http, s|
        s.vhosts.delete("def")
        body = %({ "vhosts":[{ "name":"def" }] })
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 200
        vhost = s.vhosts["def"]?
        vhost.should be_a(LavinMQ::VHost)
      end
    end

    it "imports permission groups for a vhost created by the same definitions" do
      with_http_server do |http, s|
        body = <<-JSON
          {
            "vhosts": [{ "name": "iot" }],
            "mqtt_permissions": [{
              "name": "devices", "vhost": "iot", "members": ["*"],
              "rules": [{ "identifier": "all", "pattern": "#", "read": true, "write": true }]
            }]
          }
          JSON
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 200
        service = s.vhosts["iot"].mqtt_permission_service
        service["devices"]?.should_not be_nil
      end
    end

    describe "mqtt_permissions for a vhost the definitions create" do
      it "gives the vhost only the groups from the file" do
        defs = {
          "vhosts"           => [{"name" => "iot"}],
          "mqtt_permissions" => [
            {"name" => "sensors", "vhost" => "iot", "members" => ["alice"],
             "rules" => [{"identifier" => "s", "pattern" => "sensors/#", "read" => true, "write" => true}]},
          ],
        }
        with_amqp_server do |s|
          import_defs(s, defs)
          vhost = s.vhosts["iot"]
          service = vhost.mqtt_permission_service
          service["default"]?.should be_nil
          service.can_write?(ctx("alice"), "sensors/1").should be_true
          service.can_write?(ctx("guest"), "sensors/1").should be_false
          path = File.join(vhost.data_dir, "mqtt_permissions.json")
          JSON.parse(File.read(path)).as_a.map(&.["name"]).should eq ["sensors"]
        end
      end

      it "applies a narrowed default group from the file" do
        defs = {
          "vhosts"           => [{"name" => "iot"}],
          "mqtt_permissions" => [
            {"name" => "default", "vhost" => "iot", "members" => ["*"],
             "rules" => [{"identifier" => "public", "pattern" => "public/#", "read" => true, "write" => true}]},
          ],
        }
        with_amqp_server do |s|
          import_defs(s, defs)
          service = s.vhosts["iot"].mqtt_permission_service
          service.can_write?(ctx("guest"), "public/x").should be_true
          service.can_write?(ctx("guest"), "private/x").should be_false
        end
      end

      it "keeps a vhost without groups locked down" do
        with_http_server do |http, s|
          s.vhosts.create("iot").mqtt_permission_service.delete("default")
          body = http.get("/api/definitions").body
          JSON.parse(body)["mqtt_permissions"].as_a.none? { |g| g["vhost"] == "iot" }.should be_true
          s.vhosts.delete("iot")

          http.post("/api/definitions", body: body).status_code.should eq 200

          service = s.vhosts["iot"].mqtt_permission_service
          service.size.should eq 0
          service.can_write?(ctx("guest"), "anything").should be_false
          restart_server(s)
          s.vhosts["iot"].mqtt_permission_service.can_write?(ctx("guest"), "anything").should be_false
        end
      end

      it "gives the vhost the default group when the file has no mqtt_permissions" do
        with_amqp_server do |s|
          import_defs(s, {"vhosts" => [{"name" => "iot"}]})
          service = s.vhosts["iot"].mqtt_permission_service
          service["default"]?.should_not be_nil
          service.can_write?(ctx("guest"), "anything").should be_true
        end
      end

      it "keeps the groups of a configured vhost and adds only new names" do
        defs = {"mqtt_permissions" => [
          {"name" => "sensors", "vhost" => "/", "members" => ["alice"],
           "rules" => [{"identifier" => "s", "pattern" => "sensors/#", "read" => true, "write" => true}]},
          {"name" => "default", "vhost" => "/", "members" => ["*"],
           "rules" => [{"identifier" => "none", "pattern" => "nothing", "read" => false, "write" => false}]},
        ]}
        with_amqp_server do |s|
          service = s.vhosts["/"].mqtt_permission_service
          service.put(LavinMQ::MQTT::PermissionGroup.new("mine", "/", ["bob"],
            [LavinMQ::MQTT::PermissionGroup::Rule.new("m", "mine/#", read: true, write: true)]))
          import_defs(s, defs)
          service["mine"]?.should_not be_nil
          service["sensors"]?.should_not be_nil
          service.can_write?(ctx("guest"), "anything").should be_true
        end
      end
    end

    # https://github.com/cloudamqp/lavinmq/issues/276
    context "if default user has been replaced" do
      it "imports with new default user" do
        with_http_server do |http, s|
          s.users.delete("guest")
          s.users.create("other_name", "guest", [LavinMQ::Tag::Administrator], save: false) # Will be the new default_user
          headers = HTTP::Headers{"Content-Type"  => "application/json",
                                  "Authorization" => "Basic b3RoZXJfbmFtZTpndWVzdA=="} # other_name:guest
          body = %({ "vhosts":[{ "name":"new" }] })
          response = http.post("/api/definitions", body: body, headers: headers)
          response.status_code.should eq 200
          s.vhosts["new"]?.should be_a(LavinMQ::VHost)
        end
      end
    end

    it "imports queues" do
      with_http_server do |http, s|
        body = %({ "queues": [{ "name": "import_q1", "vhost": "/", "durable": true, "auto_delete": false, "arguments": {} }] })
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 200
        s.vhosts["/"].queue_exists?("import_q1").should be_true
      end
    end

    it "imports exchanges" do
      with_http_server do |http, s|
        body = %({ "exchanges": [{ "name": "import_x1", "type": "direct", "vhost": "/", "durable": true, "internal": false, "auto_delete": false, "arguments": {} }] })
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 200
        s.vhosts["/"].exchange_exists?("import_x1").should be_true
      end
    end

    it "imports bindings" do
      with_http_server do |http, s|
        s.vhosts["/"].declare_exchange("import_x1", "topic", false, true)
        s.vhosts["/"].declare_exchange("import_x2", "fanout", false, true)
        s.vhosts["/"].declare_queue("import_q1", false, true)
        body = <<-JSON
          { "bindings": [
            {
              "source": "import_x1",
              "vhost": "/",
              "destination": "import_x2",
              "destination_type": "exchange",
              "routing_key": "r.k2",
              "arguments": {}
            },
            {
              "source": "import_x1",
              "vhost": "/",
              "destination": "import_q1",
              "destination_type": "queue",
              "routing_key": "rk",
              "arguments": {}
            }
          ]}
          JSON
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 200
        ex = s.vhosts["/"].exchange("import_x1")
        qs = Set(LavinMQ::AMQP::Queue).new
        es = Set(LavinMQ::Exchange).new
        ex.find_queues("r.k2", nil, qs, es)
        res = Set(LavinMQ::Exchange).new
        res << s.vhosts["/"].exchange("import_x1")
        res << s.vhosts["/"].exchange("import_x2")
        es.should eq res
        qs = Set(LavinMQ::AMQP::Queue).new
        es = Set(LavinMQ::Exchange).new
        ex.find_queues("rk", nil, qs, es)
        res = Set(LavinMQ::AMQP::Queue).new
        res << s.vhosts["/"].queue("import_q1")
        qs.should eq res
      end
    end

    it "imports permissions" do
      with_http_server do |http, s|
        s.users.create("u1", "")
        body = <<-JSON
          { "permissions": [
            {
              "user": "u1",
              "vhost": "/",
              "configure": "c",
              "write": "w",
              "read": "r"
            }
          ]}
          JSON
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 200
        s.users["u1"].permissions["/"][:write].should eq(/w/)
      end
    end

    it "imports policies" do
      with_http_server do |http, s|
        body = <<-JSON
          { "policies": [
            {
              "name": "import_p1",
              "vhost": "/",
              "apply-to": "queues",
              "priority": 1,
              "pattern": "^.*",
              "definition": {
                "x-max-length": 10
              }
            }
          ]}
          JSON
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 200
        s.vhosts["/"].policies.has_key?("import_p1").should be_true
      end
    end

    it "imports parameters" do
      with_http_server do |http, s|
        body = <<-JSON
          { "parameters": [
            {
              "name": "import_shovel_param",
              "component": "shovel",
              "vhost": "/",
              "value": {
                "src-uri": "#{s.amqp_server.url}",
                "src-queue": "shovel_will_declare_q1",
                "dest-uri": "#{s.amqp_server.url}",
                "dest-queue": "shovel_will_declare_q1"
              }
            }
          ]}
          JSON
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 200
        # Because we run shovels in a new Fiber we have to make sure the shovel is not started
        # after this spec has finished
        sleep 0.1.seconds # Start the shovel
        wait_for do
          shovels = s.vhosts["/"].shovels.not_nil!
          shovels.values.all? &.running?
        end
        s.vhosts["/"].parameters.any? { |_, p| p.parameter_name == "import_shovel_param" }
          .should be_true
      end
    end

    it "applies no parameters when one entry is malformed (issue #2073)" do
      with_http_server do |http, s|
        # A valid shovel followed by an operator_policy with priority > 127, which
        # overflows Int8 and raises while parsing. Entries are validated up front,
        # so a malformed entry makes the whole import a clean no-op: the shovel
        # before it is neither applied in memory nor written to disk.
        body = <<-JSON
          { "parameters": [
            {
              "name": "regression_shovel_2073",
              "component": "shovel",
              "vhost": "/",
              "value": {
                "src-uri": "#{s.amqp_server.url}",
                "src-queue": "regression_q_2073",
                "dest-uri": "#{s.amqp_server.url}",
                "dest-queue": "regression_q_2073"
              }
            },
            {
              "name": "regression_op_2073",
              "component": "operator_policy",
              "vhost": "/",
              "value": {
                "pattern": "^.*",
                "apply-to": "queues",
                "priority": 999,
                "definition": { "max-length": 10 }
              }
            }
          ]}
          JSON
        response = http.post("/api/definitions", body: body)
        response.status_code.should_not eq 200
        vhost = s.vhosts["/"]
        vhost.parameters.any? { |_, p| p.parameter_name == "regression_shovel_2073" }.should be_false
        params_file = File.join(vhost.data_dir, "parameters.json")
        File.read(params_file).should_not contain("regression_shovel_2073") if File.exists?(params_file)
      end
    end

    it "applies no policies when one entry is malformed (issue #2073)" do
      with_http_server do |http, s|
        # A valid policy followed by one with priority > 127, which overflows Int8
        # while parsing. The whole import is a clean no-op: the first policy is
        # neither applied in memory nor written to disk.
        body = <<-JSON
          { "policies": [
            {
              "name": "regression_policy_2073",
              "vhost": "/",
              "pattern": "^.*",
              "apply-to": "queues",
              "priority": 1,
              "definition": { "max-length": 10 }
            },
            {
              "name": "regression_bad_policy_2073",
              "vhost": "/",
              "pattern": "^.*",
              "apply-to": "queues",
              "priority": 999,
              "definition": { "max-length": 10 }
            }
          ]}
          JSON
        response = http.post("/api/definitions", body: body)
        response.status_code.should_not eq 200
        vhost = s.vhosts["/"]
        vhost.policies.has_key?("regression_policy_2073").should be_false
        policies_file = File.join(vhost.data_dir, "policies.json")
        File.read(policies_file).should_not contain("regression_policy_2073") if File.exists?(policies_file)
      end
    end

    it "applies no permission groups when one entry is malformed" do
      with_http_server do |http, s|
        # A valid group followed by one with an invalid topic filter pattern.
        # Groups are parsed and validated up front, so a malformed later entry
        # makes the whole import a clean no-op: the earlier group is neither
        # applied in memory nor written to disk.
        body = <<-JSON
          { "mqtt_permissions": [
            {
              "name": "regression_group_ok",
              "members": ["*"],
              "rules": [{ "identifier": "ok", "pattern": "a/#", "read": true, "write": true }]
            },
            {
              "name": "regression_group_bad",
              "members": ["*"],
              "rules": [{ "identifier": "bad", "pattern": "secret/#/temp", "read": true, "write": false }]
            }
          ]}
          JSON
        response = http.post("/api/definitions", body: body)
        response.status_code.should_not eq 200
        s.vhosts["/"].mqtt_permission_service["regression_group_ok"]?.should be_nil
        groups_file = File.join(s.vhosts["/"].data_dir, "mqtt_permissions.json")
        File.read(groups_file).should_not contain("regression_group_ok") if File.exists?(groups_file)
      end
    end

    it "imports global parameters" do
      with_http_server do |http, s|
        body = <<-JSON
          { "global_parameters": [
            {
              "name": "global_p1",
              "value": {}
            }
          ]}
          JSON
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 200
        s.parameters.any? { |_, p| p.parameter_name == "global_p1" }.should be_true
      end
    end

    it "should handle request with empty body" do
      with_http_server do |http, _|
        response = http.post("/api/definitions", body: "")
        response.status_code.should eq 200
      end
    end

    it "should handle unexpected input" do
      with_http_server do |http, _|
        response = http.post("/api/definitions", body: "\"{}\"")
        response.status_code.should eq 400
      end
    end

    it "should handle invalid JSON" do
      with_http_server do |http, _|
        response = http.post("/api/definitions", body: "a")
        response.status_code.should eq 400
        body = JSON.parse(response.body)
        body["reason"].as_s.should eq("Malformed JSON")
      end
    end

    it "should return sensible error for invalid password hash" do
      with_http_server do |http, _|
        body = <<-JSON
          {
            "users": [{
              "name": "testuser",
              "password_hash": "invalid_hash",
              "tags": "administrator"
            }]
          }
          JSON
        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 400
        error_body = JSON.parse(response.body)
        error_body["error"].as_s.should eq "bad_request"
        # Should have a sensible error message, not just "Negative count: -10"
        reason = error_body["reason"].as_s
        reason.should_not contain("Negative count")
        reason.should contain("Invalid password hash")
      end
    end
  end

  describe "GET /api/definitions" do
    it "should refuse non-administrator users" do
      with_http_server do |http, s|
        s.users.delete("guest")
        s.users.create("management_user", "guest", [LavinMQ::Tag::Management], save: false)
        headers = HTTP::Headers{"Authorization" => "Basic bWFuYWdlbWVudF91c2VyOmd1ZXN0"}
        response = http.get("/api/definitions", headers: headers)
        response.status_code.should eq 403
        body = JSON.parse(response.body)
        body["reason"].should eq "Access refused"
      end
    end

    it "exports users" do
      with_http_server do |http, _|
        response = http.get("/api/definitions")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        body["users"].as_a.empty?.should be_false
        keys = ["name", "password_hash", "hashing_algorithm"]
        bad_keys = ["permissions"]
        body["users"].as_a.each { |v| keys.each { |k| v.as_h.keys.should contain(k) } }
        body["users"].as_a.each { |v| bad_keys.each { |k| v.as_h.keys.should_not contain(k) } }
      end
    end

    it "exports vhosts" do
      with_http_server do |http, _|
        response = http.get("/api/definitions")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        body["vhosts"].as_a.empty?.should be_false
        keys = ["name"]
        body["vhosts"].as_a.each { |v| keys.each { |k| v.as_h.keys.should contain(k) } }
      end
    end

    it "exports queues" do
      with_http_server do |http, s|
        s.vhosts["/"].declare_queue("export_q1", false, false)
        response = http.get("/api/definitions")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        body["queues"].as_a.empty?.should be_false
        keys = ["name", "vhost", "auto_delete", "durable", "arguments"]
        body["queues"].as_a.each { |v| keys.each { |k| v.as_h.keys.should contain(k) } }
      end
    end

    it "exports durable mqtt sessions but not transient ones" do
      with_http_server do |http, s|
        mqtt_args = LavinMQ::AMQP::Table.new({"x-queue-type" => "mqtt"})
        s.vhosts["/"].declare_queue("mqtt.durable", true, false, mqtt_args)
        s.vhosts["/"].declare_queue("mqtt.transient", false, true, mqtt_args)
        s.vhosts["/"].session("mqtt.durable").durable?.should be_true
        s.vhosts["/"].session("mqtt.transient").durable?.should be_false

        response = http.get("/api/definitions")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        queues = body["queues"].as_a
        durable = queues.find { |v| v["name"] == "mqtt.durable" }
        durable.should_not be_nil
        durable.not_nil!["arguments"]["x-queue-type"].should eq "mqtt"
        queues.find { |v| v["name"] == "mqtt.transient" }.should be_nil
      end
    end

    it "re-imports an exported durable mqtt session as a session" do
      with_http_server do |http, s|
        mqtt_args = LavinMQ::AMQP::Table.new({"x-queue-type" => "mqtt"})
        s.vhosts["/"].declare_queue("mqtt.roundtrip", true, false, mqtt_args)
        body = http.get("/api/definitions").body
        s.vhosts["/"].delete_queue("mqtt.roundtrip")
        s.vhosts["/"].session?("mqtt.roundtrip").should be_nil

        response = http.post("/api/definitions", body: body)
        response.status_code.should eq 200
        s.vhosts["/"].session?("mqtt.roundtrip").should_not be_nil
        s.vhosts["/"].queue?("mqtt.roundtrip").should be_nil
      end
    end

    it "exports exchanges" do
      with_http_server do |http, s|
        s.vhosts["/"].declare_exchange("export_e1", "topic", false, false)
        response = http.get("/api/definitions")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        keys = ["name", "vhost", "auto_delete", "durable", "arguments", "type", "internal"]
        body["exchanges"].as_a.empty?.should be_false
        body["exchanges"].as_a.each { |v| keys.each { |k| v.as_h.keys.should contain(k) } }
      end
    end

    it "exports bindings" do
      with_http_server do |http, s|
        s.vhosts["/"].declare_exchange("export_x1", "direct", false, true)
        s.vhosts["/"].declare_queue("export_q1", false, true)
        s.vhosts["/"].bind_queue("export_q1", "export_x1", "", AMQ::Protocol::Table.new)
        response = http.get("/api/definitions")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        keys = ["source", "vhost", "destination", "destination_type", "routing_key", "arguments"]
        body["bindings"].as_a.empty?.should be_false
        body["bindings"].as_a.each { |v| keys.each { |k| v.as_h.keys.should contain(k) } }
      end
    end

    it "exports permissions" do
      with_http_server do |http, _|
        response = http.get("/api/definitions")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        keys = ["user", "vhost", "configure", "read", "write"]
        body["permissions"].as_a.empty?.should be_false
        body["permissions"].as_a.each { |v| keys.each { |k| v.as_h.keys.should contain(k) } }
      end
    end

    it "exports and imports permission groups" do
      with_http_server do |http, s|
        rule = LavinMQ::MQTT::PermissionGroup::Rule.new("sensors", "sensors/#", read: true, write: false)
        group = LavinMQ::MQTT::PermissionGroup.new("testers", "/", ["alice"], [rule])
        s.vhosts["/"].mqtt_permission_service.put(group)

        response = http.get("/api/definitions")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        body["mqtt_permissions"].as_a.empty?.should be_false
        exported = body["mqtt_permissions"].as_a.find { |g| g["name"] == "testers" }
        exported.should_not be_nil
        exported.not_nil!["members"].as_a.map(&.as_s).should contain("alice")

        s.vhosts["/"].mqtt_permission_service.delete("testers")
        s.vhosts["/"].mqtt_permission_service["testers"]?.should be_nil

        response = http.post("/api/definitions", body: body.to_json)
        response.status_code.should eq 200
        s.vhosts["/"].mqtt_permission_service["testers"]?.not_nil!.members.should contain("alice")
      end
    end

    it "exports policies" do
      with_http_server do |http, s|
        d = {"x-max-lenght" => JSON::Any.new(10_i64)}
        s.vhosts["/"].add_policy("export_p1", "^.*", "queues", d, -1_i8)
        response = http.get("/api/definitions")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        keys = ["name", "vhost", "pattern", "apply-to", "definition", "priority"]
        body["policies"].as_a.empty?.should be_false
        body["policies"].as_a.each { |v| keys.each { |k| v.as_h.keys.should contain(k) } }
      end
    end

    it "exports global parameters" do
      with_http_server do |http, s|
        d = JSON::Any.new({"dummy" => JSON::Any.new(10_i64)})
        p = LavinMQ::Parameter.new("c1", "p11", d)
        s.add_parameter(p)
        response = http.get("/api/definitions")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        keys = ["name", "component", "value"]
        body["global_parameters"].as_a.empty?.should be_false
        body["global_parameters"].as_a.each { |v| keys.each { |k| v.as_h.keys.should contain(k) } }
      end
    end

    it "exports vhost parameters" do
      with_http_server do |http, s|
        d = JSON::Any.new({"dummy" => JSON::Any.new(10_i64)})
        p = LavinMQ::Parameter.new("c1", "p11", d)
        s.vhosts["/"].add_parameter(p)
        response = http.get("/api/definitions")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        keys = ["name", "component", "value"]
        body["parameters"].as_a.empty?.should be_false
        body["parameters"].as_a.each { |v| keys.each { |k| v.as_h.keys.should contain(k) } }
      end
    end
  end
  describe "GET /api/definitions/vhost" do
    it "exports queues" do
      with_http_server do |http, s|
        s.vhosts["/"].declare_queue("export_q2", false, false)
        response = http.get("/api/definitions/%2f")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        body["queues"].as_a.empty?.should be_false
        keys = ["name", "vhost", "auto_delete", "durable", "arguments"]
        body["queues"].as_a.each { |v| keys.each { |k| v.as_h.keys.should contain(k) } }
      end
    end

    it "does not export exclusive queues" do
      with_http_server do |http, s|
        # Declare exclusive queue with amqp client
        with_channel(s) do |ch|
          ch.queue("", exclusive: true)
          response = http.get("/api/definitions/%2f")
          response.status_code.should eq 200
          body = JSON.parse(response.body)
          body["queues"].as_a.empty?.should be_true
        end
      end
    end

    it "exports exchanges" do
      with_http_server do |http, s|
        s.vhosts["/"].declare_exchange("export_e2", "topic", false, false)
        response = http.get("/api/definitions/%2f")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        keys = ["name", "vhost", "auto_delete", "durable", "arguments", "type", "internal"]
        body["exchanges"].as_a.empty?.should be_false
        body["exchanges"].as_a.each { |v| keys.each { |k| v.as_h.keys.should contain(k) } }
      end
    end

    it "exports bindings" do
      with_http_server do |http, s|
        s.vhosts["/"].declare_exchange("export_x1", "direct", false, true)
        s.vhosts["/"].declare_queue("export_q1", false, true)
        s.vhosts["/"].bind_queue("export_q1", "export_x1", "", AMQ::Protocol::Table.new)
        response = http.get("/api/definitions/%2f")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        keys = ["source", "vhost", "destination", "destination_type", "routing_key", "arguments"]
        body["bindings"].as_a.empty?.should be_false
        body["bindings"].as_a.each { |v| keys.each { |k| v.as_h.keys.should contain(k) } }
      end
    end

    it "exports policies" do
      with_http_server do |http, s|
        d = {"x-max-lenght" => JSON::Any.new(10_i64)}
        s.vhosts["/"].add_policy("export_p2", "^.*", "queues", d, -1_i8)
        response = http.get("/api/definitions/%2f")
        response.status_code.should eq 200
        body = JSON.parse(response.body)
        keys = ["name", "vhost", "pattern", "apply-to", "definition", "priority"]
        body["policies"].as_a.empty?.should be_false
        body["policies"].as_a.each { |v| keys.each { |k| v.as_h.keys.should contain(k) } }
      end
    end
    describe "user tags and vhost access" do
      it "should refuse management user even with vhost permissions" do
        with_http_server do |http, s|
          s.users.delete("guest")
          s.users.create("other_name", "guest", [LavinMQ::Tag::Management], save: false)
          s.vhosts.create("new")
          s.users.add_permission("other_name", "new", /.*/, /.*/, /.*/)
          headers = HTTP::Headers{"Authorization" => "Basic b3RoZXJfbmFtZTpndWVzdA=="}
          response = http.get("/api/definitions/new", headers: headers)
          response.status_code.should eq 403
          body = JSON.parse(response.body)
          body["reason"].should eq "Access refused"
        end
      end

      it "should refuse vhost access" do
        with_http_server do |http, s|
          s.users.delete("guest")
          s.users.create("other_name", "guest", [LavinMQ::Tag::Management], save: false) # Will be the new default_user
          s.vhosts.create("new")
          headers = HTTP::Headers{"Authorization" => "Basic b3RoZXJfbmFtZTpndWVzdA=="}
          response = http.get("/api/definitions/new", headers: headers)
          response.status_code.should eq 403
          body = JSON.parse(response.body)
          body["reason"].should eq "Access refused"
        end
      end
    end
  end
  describe "POST /api/definitions/vhost" do
    it "imports queues" do
      with_http_server do |http, s|
        body = %({ "queues": [{ "name": "import_q1", "vhost": "/", "durable": true, "auto_delete": false, "arguments": {} }] })
        response = http.post("/api/definitions/%2f", body: body)
        response.status_code.should eq 200
        s.vhosts["/"].queue_exists?("import_q1").should be_true
      end
    end

    it "imports exchanges" do
      with_http_server do |http, s|
        body = %({ "exchanges": [{ "name": "import_x1", "type": "direct", "vhost": "/", "durable": true, "internal": false, "auto_delete": false, "arguments": {} }] })
        response = http.post("/api/definitions/%2f", body: body)
        response.status_code.should eq 200
        s.vhosts["/"].exchange_exists?("import_x1").should be_true
      end
    end

    it "imports bindings" do
      with_http_server do |http, s|
        s.vhosts["/"].declare_exchange("import_x1", "direct", false, true)
        s.vhosts["/"].declare_exchange("import_x2", "fanout", false, true)
        s.vhosts["/"].declare_queue("import_q1", false, true)
        body = <<-JSON
          { "bindings": [
            {
              "source": "import_x1",
              "vhost": "/",
              "destination": "import_x2",
              "destination_type": "exchange",
              "routing_key": "r.k2",
              "arguments": {}
            },
            {
              "source": "import_x1",
              "vhost": "/",
              "destination": "import_q1",
              "destination_type": "queue",
              "routing_key": "rk",
              "arguments": {}
            }
          ]}
          JSON
        response = http.post("/api/definitions/%2f", body: body)
        response.status_code.should eq 200
        ex = s.vhosts["/"].exchange("import_x1")
        qs = Set(LavinMQ::AMQP::Queue).new
        es = Set(LavinMQ::Exchange).new
        ex.find_queues("r.k2", nil, qs, es)
        res = Set(LavinMQ::Exchange).new
        res << s.vhosts["/"].exchange("import_x1")
        res << s.vhosts["/"].exchange("import_x2")
        es.should eq res
        qs = Set(LavinMQ::AMQP::Queue).new
        es = Set(LavinMQ::Exchange).new
        ex.find_queues("rk", nil, qs, es)
        res = Set(LavinMQ::AMQP::Queue).new
        res << s.vhosts["/"].queue("import_q1")
        qs.should eq res
      end
    end

    it "imports policies" do
      with_http_server do |http, s|
        body = <<-JSON
          { "policies": [
            {
              "name": "import_p1",
              "vhost": "/",
              "apply-to": "queues",
              "priority": 1,
              "pattern": "^.*",
              "definition": {
                "x-max-length": 10
              }
            }
          ]}
          JSON
        response = http.post("/api/definitions/%2f", body: body)
        response.status_code.should eq 200
        s.vhosts["/"].policies.has_key?("import_p1").should be_true
      end
    end

    it "should handle request with empty body" do
      with_http_server do |http, _|
        response = http.post("/api/definitions/%2f", body: "")
        response.status_code.should eq 200
      end
    end

    it "should handle unexpected input" do
      with_http_server do |http, _|
        response = http.post("/api/definitions/%2f", body: "\"{}\"")
        response.status_code.should eq 400
      end
    end

    it "should handle invalid JSON" do
      with_http_server do |http, _|
        response = http.post("/api/definitions/%2f", body: "a")
        response.status_code.should eq 400
        body = JSON.parse(response.body)
        body["reason"].as_s.should eq("Malformed JSON")
      end
    end
    describe "user tags and vhost access" do
      it "should refuse policymaker user even with vhost permissions" do
        with_http_server do |http, s|
          s.users.delete("guest")
          s.users.create("other_name", "guest", [LavinMQ::Tag::PolicyMaker], save: false)
          s.vhosts.create("new")
          s.users.add_permission("other_name", "new", /.*/, /.*/, /.*/)
          headers = HTTP::Headers{"Authorization" => "Basic b3RoZXJfbmFtZTpndWVzdA=="}
          body = %({ "queues": [{ "name": "import_q1", "vhost": "new", "durable": true, "auto_delete": false, "arguments": {} }] })
          response = http.post("/api/definitions/new", headers: headers, body: body)
          response.status_code.should eq 403
          body = JSON.parse(response.body)
          body["reason"].should eq "Access refused"
        end
      end

      it "should refuse vhost access" do
        with_http_server do |http, s|
          s.users.delete("guest")
          s.users.create("other_name", "guest", [LavinMQ::Tag::Management], save: false) # Will be the new default_user
          s.vhosts.create("new")
          headers = HTTP::Headers{"Authorization" => "Basic b3RoZXJfbmFtZTpndWVzdA=="}
          body = %({ "queues": [{ "name": "import_q1", "vhost": "new", "durable": true, "auto_delete": false, "arguments": {} }] })
          response = http.post("/api/definitions/new", headers: headers, body: body)
          response.status_code.should eq 403
          body = JSON.parse(response.body)
          body["reason"].should eq "Access refused"
        end
      end

      it "should refuse user tag access" do
        with_http_server do |http, s|
          s.users.delete("guest")
          s.users.create("other_name", "guest", [LavinMQ::Tag::Management], save: false) # Will be the new default_user
          s.vhosts.create("new")
          s.users.add_permission("other_name", "new", /.*/, /.*/, /.*/)
          headers = HTTP::Headers{"Authorization" => "Basic b3RoZXJfbmFtZTpndWVzdA=="}
          body = %({ "queues": [{ "name": "import_q1", "vhost": "new", "durable": true, "auto_delete": false, "arguments": {} }] })
          response = http.post("/api/definitions/new", headers: headers, body: body)
          response.status_code.should eq 403
          body = JSON.parse(response.body)
          body["reason"].should eq "Access refused"
        end
      end
    end
  end

  describe "POST /api/definitions/upload" do
    it "should refuse non-administrator users" do
      with_http_server do |http, s|
        s.users.delete("guest")
        s.users.create("management_user", "guest", [LavinMQ::Tag::Management], save: false)
        headers = HTTP::Headers{
          "Authorization" => "Basic bWFuYWdlbWVudF91c2VyOmd1ZXN0",
          "Content-Type"  => "application/json",
        }
        body = %({ "vhosts":[{ "name":"test" }] })
        response = http.post("/api/definitions/upload", headers: headers, body: body)
        response.status_code.should eq 403
        body = JSON.parse(response.body)
        body["reason"].should eq "Access refused"
      end
    end

    it "imports definitions from uploaded file (no Referer)" do
      with_http_server do |http, s|
        file_content = %({ "vhosts":[{ "name":"uploaded_vhost" }] }) # sanity check
        io = IO::Memory.new
        builder = HTTP::FormData::Builder.new(io)
        builder.file("file", IO::Memory.new(file_content))
        builder.finish

        headers = {"Content-Type" => builder.content_type}
        body = io.to_s

        response = http.post("/api/definitions/upload", headers: headers, body: body)
        response.status_code.should eq 200
        s.vhosts["uploaded_vhost"]?.should_not be_nil
        s.vhosts["uploaded_vhost"].should be_a(LavinMQ::VHost)
      end
    end

    it "imports definitions from uploaded file" do
      with_http_server do |http, s|
        file_content = %({ "vhosts":[{ "name":"uploaded_vhost" }] }) # sanity check
        io = IO::Memory.new
        builder = HTTP::FormData::Builder.new(io)
        builder.file("file", IO::Memory.new(file_content))
        builder.finish

        headers = {"Content-Type" => builder.content_type, "Referer" => "/foo"}
        body = io.to_s

        response = http.post("/api/definitions/upload", headers: headers, body: body)
        response.status_code.should eq 302
        response.headers["Location"].should eq "/foo"
        s.vhosts["uploaded_vhost"]?.should_not be_nil
        s.vhosts["uploaded_vhost"].should be_a(LavinMQ::VHost)
      end
    end

    it "imports definitions from json body" do
      with_http_server do |http, s|
        body = {vhosts: [{name: "uploaded_vhost"}]}.to_json
        headers = {"Content-Type" => "application/json"}
        response = http.post("/api/definitions/upload", headers: headers, body: body)
        response.status_code.should eq 200
        s.vhosts["uploaded_vhost"]?.should_not be_nil
        s.vhosts["uploaded_vhost"].should be_a(LavinMQ::VHost)
      end
    end
  end

  it "should update existing user on import" do
    with_http_server do |http, s|
      name = "bcryptuser"
      body = <<-JSON
        {
          "users":[{
            "name":"#{name}",
            "password_hash":"$2a$04$g5IMwYwvgDLACYdAQxCpCulKuK/Ym2I56Tz6T9Wi9DGdKQG.DE8Gi",
            "hashing_algorithm":"Bcrypt","tags":[]
          }]
        }
        JSON

      response = http.post("/api/definitions", body: body)
      response.status_code.should eq 200

      u = s.users[name]
      u.should be_a(LavinMQ::Auth::BaseUser)
      ok = u.not_nil!.password.not_nil!.verify "hej"
      {u.name, ok}.should eq({name, true})

      update_body = <<-JSON
        {
          "users":[{
            "name":"#{name}",
            "password_hash":"$2a$04$PuoK2zgHy/NHRU3CRUCidOKaSTwFkv97Sm.zTspKZRWJkn6l37YOe",
            "hashing_algorithm":"Bcrypt","tags":[]
          }]
        }
        JSON
      response = http.post("/api/definitions", body: update_body)
      response.status_code.should eq 200

      u = s.users[name]
      u.should be_a(LavinMQ::Auth::BaseUser)
      ok = u.not_nil!.password.not_nil!.verify "test"
      {u.name, ok}.should eq({name, true})
    end
  end

  it "shouldn't ruin internal state of delayed exchange (issue #698)" do
    with_http_server do |http, s|
      vhost = s.vhosts["/"]
      args = {"x-delayed-message", false, false, false, LavinMQ::AMQP::Table.new({"x-delayed-type": "direct"})}
      vhost.declare_exchange "test", *args
      http.get("/api/definitions")
      vhost.exchange("test").match?(*args).should be_true
    end
  end

  it "should be able to import delayed exchanges created in LavinMQ (issue #743)" do
    with_http_server do |http, s|
      body = <<-JSON
        {
          "type": "direct",
          "durable": true,
          "internal": false,
          "auto_delete": false,
          "delayed": true
        }
        JSON
      http.put("/api/exchanges/%2f/test-delayed", body: body)
      response = http.get("/api/definitions")
      body = JSON.parse(response.body)
      http.delete("/api/exchanges/%2f/test-delayed")
      LavinMQ::GlobalDefinitions.new(s).import(body)
      response = http.get("/api/exchanges/%2f/test-delayed")
      response.status_code.should eq 200
    end
  end
end
