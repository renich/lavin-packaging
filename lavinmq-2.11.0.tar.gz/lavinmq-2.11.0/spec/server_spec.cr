require "./spec_helper"
require "benchmark"
require "log/spec"

describe LavinMQ::Server do
  it "closes idempotently" do
    server = LavinMQ::Server.new(LavinMQ::Config.instance)
    server.close
    server.close
    server.closed?.should be_true
  end

  it "replaces server stores on restart" do
    server = LavinMQ::Server.new(LavinMQ::Config.instance)
    users = server.users
    vhosts = server.vhosts
    parameters = server.parameters
    authenticator = server.authenticator

    begin
      restart_server(server)

      server.users.same?(users).should be_false
      server.vhosts.same?(vhosts).should be_false
      server.parameters.same?(parameters).should be_false
      server.authenticator.same?(authenticator).should be_false
      server.vhosts["/"]?.should_not be_nil
      server.users["guest"]?.should_not be_nil
    ensure
      server.close unless server.closed?
    end
  end

  it "removes the log exchange channel when closed" do
    config = LavinMQ::Config.instance
    config.log_exchange = true
    server = LavinMQ::Server.new(config)

    begin
      server.start_log_exchange
      log_channel = server.@log_exchange_channel.not_nil!("log exchange channel not started")
      ::Log::InMemoryBackend.instance.channels.includes?(log_channel).should be_true

      server.close

      ::Log::InMemoryBackend.instance.channels.includes?(log_channel).should be_false
      log_channel.closed?.should be_true
    ensure
      server.close unless server.closed?
      config.log_exchange = false
    end
  end

  it "logs kTLS=off for TLS connections without kernel offload" do
    with_amqp_server(tls: true) do |s|
      uri = URI.parse(s.amqp_server.url)
      Log.capture("lmq.server", :info) do |logs|
        client_ctx = OpenSSL::SSL::Context::Client.new
        client_ctx.verify_mode = OpenSSL::SSL::VerifyMode::NONE
        conn = AMQP::Client.new(host: uri.hostname.not_nil!("URI has no host"), port: uri.port.not_nil!("URI has no port"), tls: client_ctx).connect
        conn.close
        logs.check(:info, /connected with .* kTLS=off/)
      end
    end
  end

  it "doesn't hold the TCP read buffer of idle TLS connections" do
    with_amqp_server(tls: true) do |s|
      with_channel(s, tls: true, verify_mode: OpenSSL::SSL::VerifyMode::NONE) do |ch|
        ch.queue # a roundtrip, so the connection is idle afterwards
        client = s.connections.first.as(LavinMQ::AMQP::Client)
        tcp = client.@socket.as(OpenSSL::SSL::Socket).@bio.to_reference.io.as(TCPSocket)
        tcp.buffer_pool.should_not be_nil
        wait_for { tcp.@in_buffer.null? }
      end
    end
  end

  it "accepts connections" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        x = ch.exchange("amq.topic", "topic", auto_delete: false, durable: true, internal: true, passive: true)
        q = ch.queue
        q.bind(x.name, "#")
        pmsg = "test message"
        x.publish pmsg, q.name
        msg = q.get(no_ack: true).should_not be_nil
        msg.body_io.to_s.should eq("test message")
      end
    end
  end

  it "can delete queue" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("del_q")
        q.publish "m1"
        q.delete
      end
      with_channel(s) do |ch|
        pmsg = "m2"
        q = ch.queue("del_q")
        q.publish pmsg
        msg = q.get.should_not be_nil
        msg.body_io.to_s.should eq("m2")
      end
    end
  end

  it "can reject message" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        q.publish "m1"
        m1 = q.get(no_ack: false)
        m1.try(&.reject)
        m1 = q.get(no_ack: false)
        m1.should be_nil
      end
    end
  end

  it "can reject and requeue message" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        q.publish "m1"
        m1 = q.get(no_ack: false)
        m1.try(&.reject(requeue: true))
        m1 = q.get(no_ack: false).should_not be_nil
        m1.body_io.to_s.should eq("m1")
        m1.redelivered.should be_true
      end
    end
  end

  it "can reject while consuming" do
    with_amqp_server do |s|
      done = ::Channel(Nil).new(1)
      data = Bytes.new(1000)
      spawn do
        with_channel(s) do |ch|
          q = ch.queue("reject")
          200.times do
            q.publish data
          end
        end
      end
      spawn do
        with_channel(s) do |ch|
          ch.prefetch 10
          q = ch.queue("reject")
          q.subscribe(no_ack: false, block: true) do |msg|
            msg.reject(requeue: false)
            done.send nil
          end
        rescue AMQP::Client::Connection::ClosedException
        end
      end
      timeout = false
      200.times do
        select
        when done.receive
        when timeout 1.seconds
          timeout = true
        end
      end
      timeout.should be_false
      with_channel(s) do |ch|
        ch.queue_declare("reject", passive: true)[:message_count].should eq 0
      end
    end
  end

  it "rejects all unacked msgs when disconnecting" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        pmsg = "m1"
        q = ch.queue("q5", auto_delete: false, durable: true, exclusive: false)
        q.publish pmsg
        q.get(no_ack: false)
      end
      with_channel(s) do |ch|
        q = ch.queue("q5", auto_delete: false, durable: true, exclusive: false)
        m1 = q.get(no_ack: true).should_not be_nil
        m1.body_io.to_s.should eq("m1")
      end
    end
  end

  it "can delete exchange" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        x = ch.exchange("test_delete_exchange", "topic", durable: true)
        x.delete
        expect_raises(AMQP::Client::Channel::ClosedException) do
          ch.exchange("test_delete_exchange", "topic", durable: true, passive: true)
        end
      end
    end
  end

  it "can delete internal exchange" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        x = ch.exchange("test_delete_exchange", "topic", durable: true, internal: true)
        x.delete
      end
    end
  end

  it "can auto delete exchange" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        ch.confirm_select
        code = Channel(UInt16).new
        ch.on_close do |c, _reply|
          code.send c
        end
        x = ch.exchange("test_ad_exchange", "topic", durable: false, auto_delete: true)
        q = ch.queue
        q.bind(x.name, "")
        q.unbind(x.name, "")
        x.publish("m1", q.name)
        code.receive.should eq 404
        sleep 10.milliseconds
        ch.closed?.should be_true
      end
    end
  end

  it "can purge a queue" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        4.times { q.publish "" }
        q.purge[:message_count].should eq 4
      end
    end
  end

  it "supports publisher confirms" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        q.publish_confirm("m1").should be_true
      end
    end
  end

  it "supports mandatory publish flag" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        pmsg = "m1"
        ch1 = Channel(Tuple(UInt16, String)).new
        ch.on_return do |msg|
          ch1.send({msg.reply_code, msg.reply_text})
        end
        ch.basic_publish(pmsg, "amq.direct", "none", mandatory: true)
        reply_code, reply_text = ch1.receive
        reply_code.should eq 312
        reply_text.should eq "NO_ROUTE"
      end
    end
  end

  it "can handle messages going to no queue" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        ch.basic_publish_confirm("m1", "amq.direct", "none").should be_true
        ch.basic_publish_confirm("m2", "amq.direct", "none").should be_true
      end
    end
  end

  it "expires messages" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        q.publish_confirm "expired", props: AMQP::Client::Properties.new(expiration: "0")
        msg = q.get(no_ack: true)
        msg.should be_nil
      end
    end
  end

  it "expires multiple messages" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        q.publish_confirm "expired", props: AMQP::Client::Properties.new(expiration: "1")
        sleep 10.milliseconds
        q.publish_confirm "expired", props: AMQP::Client::Properties.new(expiration: "1")
        sleep 10.milliseconds
        msg = q.get(no_ack: true)
        msg.should be_nil
      end
    end
  end

  it "expires messages with message TTL on queue declaration" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q, dlq = create_ttl_and_dl_queues(ch)
        ttl_msg = "queue dlx"
        q.publish_confirm ttl_msg
        msg = wait_for { dlq.get(no_ack: true) }
        msg.body_io.to_s.should eq(ttl_msg)
        s.vhosts["/"].queue(q.name).empty?.should be_true
        q.publish_confirm ttl_msg
        msg = wait_for { dlq.get(no_ack: true) }
        msg.body_io.to_s.should eq(ttl_msg)
      end
    end
  end

  it "expires messages with TTL on requeue" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q, dlq = create_ttl_and_dl_queues(ch, queue_ttl: 500)
        r_msg = "requeue msg"
        q.publish_confirm r_msg
        msg = q.get(no_ack: false).should_not be_nil
        msg.reject(requeue: true)
        msg = wait_for { dlq.get(no_ack: true) }
        msg.body_io.to_s.should eq(r_msg)
        s.vhosts["/"].queue(q.name).empty?.should be_true
      end
    end
  end

  it "can publish and consume messages larger than 128kb" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        lmsg = "a" * 5_00_000
        q = ch.queue "lmsg_q"
        q.publish_confirm lmsg
        q.subscribe(no_ack: true) do |msg|
          msg.should_not be_nil
          msg.body_io.to_s.should eq(lmsg)
        end
      end
    end
  end

  it "does not requeue messages on consumer close" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue "msg_q"
        q.publish_confirm "no requeue"
        done = Channel(Nil).new
        tag = q.subscribe(no_ack: false) { |_| done.send nil }
        done.receive
        q.unsubscribe(tag)
        s.vhosts["/"].queue("msg_q").empty?.should be_true
      end
    end
  end

  it "dead-letter expired messages" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        dlq = ch.queue
        ch.queue("exp")
        hdrs = AMQP::Client::Arguments.new
        hdrs["x-dead-letter-exchange"] = ""
        hdrs["x-dead-letter-routing-key"] = dlq.name
        x = ch.exchange("", "direct", passive: true)
        x.publish_confirm "dead letter", "exp", props: AMQP::Client::Properties.new(expiration: "0", headers: hdrs)
        msg = wait_for { dlq.get(no_ack: true) }
        msg.body_io.to_s.should eq("dead letter")
      end
    end
  end

  it "dead-letter expired messages to non existing exchange" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        args = AMQP::Client::Arguments.new
        args["x-max-length"] = 1
        args["x-dead-letter-exchange"] = "not_found"
        q = ch.queue "", durable: false, exclusive: true, args: args
        q.publish_confirm "1"
        q.publish_confirm "2"
        q.publish_confirm "3"
        msg = q.get(no_ack: true).should_not be_nil
        msg.body_io.to_s.should eq "3"
      end
    end
  end

  it "dead-letter preserves headers" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        dlq = ch.queue
        ch.queue("exp")
        hdrs = AMQP::Client::Arguments.new
        hdrs["custom1"] = "v1"
        hdrs["custom2"] = "v2"
        hdrs["x-dead-letter-exchange"] = ""
        hdrs["x-dead-letter-routing-key"] = dlq.name
        x = ch.exchange("", "direct", passive: true)
        x.publish_confirm "dead letter", "exp", props: AMQP::Client::Properties.new(expiration: "0", headers: hdrs)
        msg = wait_for { dlq.get(no_ack: true) }
        headers = msg.properties.headers.should_not be_nil
        headers.has_key?("custom1").should be_true
        headers.has_key?("custom2").should be_true
        headers["custom1"].should eq "v1"
        headers["custom2"].should eq "v2"
      end
    end
  end

  it "can publish to queues with max-length 0 if there's consumers" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        args = AMQP::Client::Arguments.new
        args["x-max-length"] = 0
        q = ch.queue "", durable: false, exclusive: true, args: args
        mch = Channel(AMQP::Client::DeliverMessage).new(2)
        q.subscribe(no_ack: true) do |msg|
          mch.send msg
        end
        q.publish "1"
        q.publish "2"
        2.times do
          select
          when msg = mch.receive?
            msg.should_not be_nil
          when timeout 2.seconds
            raise "timeout"
          end
        end
      end
    end
  end

  it "should still drop_overflow even with slow consumers" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        args = AMQP::Client::Arguments.new
        args["x-max-length"] = 2
        q = ch.queue "", durable: false, exclusive: true, args: args
        mch = Channel(AMQP::Client::DeliverMessage).new(10)
        ack = Channel(Nil).new
        ch.prefetch 1
        q.subscribe(no_ack: false) do |msg|
          mch.send msg
          ack.receive
          msg.ack
        end
        q.publish_confirm "0"
        mch.receive.body_io.to_s.should eq "0"
        1.upto(9) do |i|
          q.publish_confirm i.to_s
        end
        wait_for { s.vhosts["/"].queue(q.name).message_count == 2 }
        ack.send nil
        mch.receive.body_io.to_s.should eq "8"
        ack.send nil
        mch.receive.body_io.to_s.should eq "9"
        ack.send nil
      end
    end
  end

  it "msgs publish to queue w/o consumers with max-length 0 will be dropped" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        args = AMQP::Client::Arguments.new
        args["x-max-length"] = 0
        q = ch.queue "", durable: false, exclusive: true, args: args
        q.publish_confirm "1"
        q.publish_confirm "2"
        q.get.should be_nil
        q.get.should be_nil
      end
    end
  end

  it "handle immediate flag" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        pmsg = "m1"
        reply_code = 0
        reply_msg = nil
        ch.on_return do |msg|
          reply_code = msg.reply_code
          reply_msg = msg.reply_text
        end
        ch.basic_publish(pmsg, "amq.topic", "rk", mandatory: false, immediate: true)
        wait_for { reply_code == 313 }
        reply_code.should eq 313
      end
    end
  end

  it "can cancel consumers" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("", auto_delete: false, durable: true, exclusive: false)
        q.publish "m1"
        msgs = [] of AMQP::Client::DeliverMessage
        tag = q.subscribe { |msg| msgs << msg }
        q.unsubscribe(tag)
        sleep 10.milliseconds
        ch.has_subscriber?(tag).should be_false
      end
    end
  end

  it "supports header exchange all" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        hdrs = AMQP::Client::Arguments.new
        hdrs["x-match"] = "all"
        hdrs["org"] = "84codes"
        hdrs["user"] = "test"
        x = ch.exchange("asdasdasd", "headers", passive: false)
        q.bind(x.name, "", args: hdrs)
        hdrs.delete("x-match")
        x.publish_confirm "m1", q.name, props: AMQP::Client::Properties.new(headers: hdrs)
        hdrs["user"] = "hest"
        x.publish_confirm "m2", q.name, props: AMQP::Client::Properties.new(headers: hdrs)
        q.get.should_not be_nil
        q.get.should be_nil
      end
    end
  end

  it "supports header exchange any" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        hdrs = AMQP::Client::Arguments.new
        hdrs["x-match"] = "any"
        hdrs["org"] = "84codes"
        hdrs["user"] = "test"
        x = ch.exchange("hx1", "headers", passive: false)
        q.bind(x.name, "", args: hdrs)
        hdrs.delete("x-match")
        x.publish "m1", q.name, props: AMQP::Client::Properties.new(headers: hdrs)
        hdrs["user"] = "hest"
        x.publish "m2", q.name, props: AMQP::Client::Properties.new(headers: hdrs)
        msgs = Channel(AMQP::Client::DeliverMessage).new(2)
        q.subscribe { |msg| msgs.send msg }
        spawn { sleep 5.seconds; msgs.close }
        2.times { msgs.receive?.should_not be_nil }
      end
    end
  end

  it "validates header exchange x-match" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        hdrs = AMQP::Client::Arguments.new
        hdrs["x-match"] = "fail"
        expect_raises(AMQP::Client::Channel::ClosedException, "PRECONDITION_FAILED") do
          ch.exchange("hx1", "headers", passive: false, args: hdrs)
        end
      end
    end
  end

  it "validates header exchange binding with x-match" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        hdrs = AMQP::Client::Arguments.new
        hdrs["x-match"] = 123
        q = ch.queue
        expect_raises(AMQP::Client::Channel::ClosedException, "PRECONDITION_FAILED") do
          q.bind("amq.headers", "", args: hdrs)
        end
      end
    end
  end

  it "should persist exchange-exchange binding" do
    with_amqp_server do |s|
      hdrs = AMQP::Client::Arguments.new
      hdrs["org"] = "84codes"
      hdrs["user"] = "test"
      with_channel(s) do |ch|
        topic_x = ch.exchange("topic_exchange", "topic", passive: false)
        headers_x = ch.exchange("headers_exchange", "headers", passive: false)
        topic_x.bind(exchange: headers_x.name, routing_key: "", args: hdrs)
      end
      restart_server(s)
      with_channel(s) do |ch|
        q = ch.queue
        q.bind("topic_exchange", "#")

        ch.basic_publish_confirm "m1", "headers_exchange", "test", props: AMQP::Client::Properties.new(headers: hdrs)

        hdrs["user"] = "hest"
        ch.basic_publish_confirm "m2", "headers_exchange", "test", props: AMQP::Client::Properties.new(headers: hdrs)

        q.get.should_not be_nil
        q.get.should be_nil
      end
    end
  end

  it "splits frames into max frame sizes" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        2.times do
          msg_size = (2**17 + 1)
          pmsg1 = "m" * msg_size
          sha1 = Digest::SHA1.digest pmsg1
          q = ch.queue
          q.purge
          q.publish_confirm pmsg1
          msg = q.get(no_ack: true).should_not be_nil
          msg.body_io.size.should eq msg_size
          Digest::SHA1.digest(msg.body_io).should eq sha1
        end
      end
    end
  end

  it "can receive and deliver multiple large messages" do
    pmsg = "a" * 150_000
    with_amqp_server do |s|
      with_channel(s) do |ch|
        2.times do
          q = ch.queue
          q.publish pmsg
          msg = q.get.should_not be_nil
          msg.body_io.to_s.should eq pmsg
        end
      end
    end
  end

  it "acking an invalid delivery tag should close the channel" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        cch = Channel(Tuple(UInt16, String)).new
        ch.on_close do |code, text|
          cch.send({code, text})
        end
        ch.basic_ack(999_u64)
        c, _ = cch.receive
        c.should eq 406
      end
    end
  end

  it "acking tag 0 with multiple=true should not close the channel" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        ch.basic_ack(0, multiple: true)
        sleep 10.milliseconds
        ch.basic_ack(0, multiple: true)
      end
    end
  end

  it "can bind exchanges to exchanges" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        x1 = ch.exchange("x1", "direct")
        x2 = ch.exchange("x2", "direct")
        x2.bind(x1.name, "e2e")
        q = ch.queue("e2e", auto_delete: true, durable: false, exclusive: false)
        q.bind(x2.name, "e2e")
        pmsg = "test message"
        x1.publish_confirm pmsg, "e2e"
        Fiber.yield
        msg = q.get(no_ack: true).should_not be_nil
        msg.body_io.to_s.should eq("test message")
      end
    end
  end

  it "supports x-max-length drop-head" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        args = AMQP::Client::Arguments.new
        args["x-max-length"] = 1_i64
        q = ch.queue("", args: args)
        q.publish_confirm "m1"
        q.publish_confirm "m2"
        msgs = [] of AMQP::Client::DeliverMessage
        q.subscribe { |msg| msgs << msg }
        wait_for { msgs.size >= 1 }
        msgs.size.should eq 1
      end
    end
  end

  it "supports x-max-length reject-publish" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        args = AMQP::Client::Arguments.new
        args["x-max-length"] = 1_i64
        args["x-overflow"] = "reject-publish"
        q1 = ch.queue("test1", durable: true, args: args)
        q2 = ch.queue("test2", durable: true)
        x1 = ch.exchange("x345", "topic")
        q1.bind(x1.name, "rk")
        q2.bind(x1.name, "rk")
        x1.publish_confirm("m1", "rk").should be_true
        x1.publish_confirm("m2", "rk").should be_false
        q1.publish_confirm("m3").should be_false
        q2.publish_confirm("m4").should be_true
        msgs = [] of AMQP::Client::DeliverMessage
        q1.subscribe { |msg| msgs << msg }
        wait_for { msgs.size == 1 }
        msgs.size.should eq 1
      end
    end
  end

  it "drop overflow when max-length is applied" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("mlq")
        q.publish_confirm("m1").should be_true
        q.publish_confirm("m2").should be_true
        definitions = {"max-length" => JSON::Any.new(1_i64)} of String => JSON::Any
        s.vhosts["/"].add_policy("test", "^mlq$", "queues", definitions, 10_i8)
        sleep 10.milliseconds
        s.vhosts["/"].queue("mlq").message_count.should eq 1
      end
    end
  end

  it "disallows creating queues starting with amq." do
    expect_raises(AMQP::Client::Channel::ClosedException, /REFUSED/) do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.queue("amq.test")
        end
      end
    end
  end

  it "disallows deleting exchanges named amq.*" do
    with_amqp_server do |s|
      expect_raises(AMQP::Client::Channel::ClosedException, /REFUSED/) do
        with_channel(s) do |ch|
          ch.exchange("amq.topic", "topic", passive: true).delete
        end
      end
      with_channel(s) do |ch|
        ch.exchange("amq.topic", "topic", passive: true).should_not be_nil
      end
    end
  end

  it "disallows creating new exchanges named amq.*" do
    expect_raises(AMQP::Client::Channel::ClosedException, /REFUSED/) do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.exchange("amq.topic2", "topic")
        end
      end
    end
  end

  it "only allow one consumer when exclusive consumers flag is set" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("exlusive_consumer", auto_delete: true)
        q.subscribe(exclusive: true) { }

        expect_raises(AMQP::Client::Channel::ClosedException, /ACCESS_REFUSED/) do
          with_channel(s) do |ch2|
            q2 = ch2.queue("exlusive_consumer", passive: true)
            q2.subscribe { }
          end
        end
      end
      with_channel(s) do |ch|
        q = ch.queue("exlusive_consumer", auto_delete: true)
        q.subscribe { }
      end
    end
  end

  it "refuses an exclusive consumer when the queue already has consumers" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("exclusive_consumer_after_shared", auto_delete: true)
        q.subscribe { }

        expect_raises(AMQP::Client::Channel::ClosedException, /ACCESS_REFUSED/) do
          with_channel(s) do |ch2|
            q2 = ch2.queue("exclusive_consumer_after_shared", passive: true)
            q2.subscribe(exclusive: true) { }
          end
        end

        # The refused exclusive consumer must not lock out further consumers
        with_channel(s) do |ch3|
          ch3.queue("exclusive_consumer_after_shared", passive: true).subscribe { }
        end
      end
    end
  end

  it "only allow one connection access an exlusive queues" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        ch.queue("exlusive_queue", durable: true, exclusive: true)
        expect_raises(AMQP::Client::Channel::ClosedException, /RESOURCE_LOCKED/) do
          with_channel(s) do |ch2|
            ch2.queue("exlusive_queue", passive: true)
          end
        end
      end
    end
  end

  it "it does persists transient msgs between restarts" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        ch.confirm_select
        q = ch.queue("durable_queue", durable: true)
        1000.times do |i|
          delivery_mode = i % 2 == 0 ? 2_u8 : 0_u8
          props = AMQP::Client::Properties.new(delivery_mode: delivery_mode)
          q.publish(i.to_s, props: props)
        end
        ch.wait_for_confirms
      end
      restart_server(s)
      with_channel(s) do |ch|
        q = ch.queue("durable_queue", durable: true)
        deleted_msgs = q.delete
        deleted_msgs[:message_count].should eq 1000
      end
    end
  end

  it "it does remeber acked msgs between restarts" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        ch.confirm_select
        q = ch.queue("q")
        1000.times do
          q.publish("a")
        end
        ch.wait_for_confirms
        q.message_count.should eq 1000
        q.subscribe(no_ack: false, tag: "c", block: true) do |msg|
          msg.ack
          q.unsubscribe("c") if msg.delivery_tag == 1000
        end
        q.message_count.should eq 0
      end
      restart_server(s)
      with_channel(s) do |ch|
        q = ch.queue("q")
        q.message_count.should eq 0
      end
    end
  end

  it "supports max-length" do
    with_amqp_server do |s|
      definitions = {"max-length" => JSON::Any.new(1_i64)}
      s.vhosts["/"].add_policy("ml", "^.*$", "queues", definitions, 10_i8)
      with_channel(s) do |ch|
        q = ch.queue
        q.publish_confirm("m1").should be_true
        q.publish_confirm("m2").should be_true
        msgs = [] of AMQP::Client::DeliverMessage
        q.subscribe { |msg| msgs << msg }
        wait_for { msgs.size == 1 }
        msgs.size.should eq 1
      end
    end
  end

  it "supports alternate-exchange" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        args = AMQP::Client::Arguments.new
        args["alternate-exchange"] = "ae"
        x1 = ch.exchange("x1", "topic", args: args)
        ae = ch.exchange("ae", "topic")
        q = ch.queue
        q.bind(ae.name, "*")
        x1.publish("m1", "rk")
        msg = q.get(no_ack: true).should_not be_nil
        msg.body_io.to_s.should eq("m1")
      end
    end
  end

  it "supports x-alternate-exchange" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        args = AMQP::Client::Arguments.new
        args["x-alternate-exchange"] = "ae"
        x1 = ch.exchange("x1", "topic", args: args)
        ae = ch.exchange("ae", "topic")
        q = ch.queue
        q.bind(ae.name, "*")
        x1.publish("m1", "rk")
        msg = q.get(no_ack: true).should_not be_nil
        msg.body_io.to_s.should eq("m1")
      end
    end
  end

  it "supports expires" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        args = AMQP::Client::Arguments.new
        args["x-expires"] = 1
        ch.queue("test", args: args)
        sleep 5.milliseconds
        Fiber.yield
        s.vhosts["/"].queue_exists?("test").should be_false
      end
    end
  end

  it "does not expire queue when consumer are still there" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        args = AMQP::Client::Arguments.new
        args["x-expires"] = 50
        q = ch.queue("test", args: args)
        q.subscribe(no_ack: true) { |_| }
        sleep 50.milliseconds
        Fiber.yield
        s.vhosts["/"].queue_exists?("test").should be_true
      end
    end
  end

  it "should deliver to all matching queues" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q1 = ch.queue
        q2 = ch.queue
        x1 = ch.exchange("x122", "topic")
        q1.bind(x1.name, "rk")
        q2.bind(x1.name, "rk")
        x1.publish("m1", "rk")
        sleep 50.milliseconds
        msg_q1 = q1.get(no_ack: true).should_not be_nil
        msg_q2 = q2.get(no_ack: true).should_not be_nil
        msg_q1.body_io.to_s.should eq("m1")
        msg_q2.body_io.to_s.should eq("m1")
      end
    end
  end

  it "supports auto ack consumers" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        q.publish "m1"
        msgs = [] of AMQP::Client::DeliverMessage
        q.subscribe(no_ack: true) { |msg| msgs << msg }
        wait_for { msgs.size == 1 }
        msgs.size.should eq 1
      end
    end
  end

  it "allows any Int64 message timestamp" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        props = AMQP::Client::Properties.new(timestamp: Int64::MAX)
        q.publish "m1", props: props
        msg = q.get(no_ack: true).should_not be_nil
        msg.body_io.to_s.should eq "m1"
        msg.properties.timestamp_raw.should eq Int64::MAX
      end
    end
  end

  it "sets correct message timestamp" do
    LavinMQ::Config.instance.set_timestamp = true
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        t = Time.utc.to_unix
        q.publish "m1"
        msg = nil
        q.subscribe(no_ack: true) { |m| msg = m }
        wait_for { msg }
        delivered = msg.should_not be_nil
        timestamp = delivered.properties.timestamp.should_not be_nil
        timestamp.to_unix.should be_close(t, 1)
      end
      LavinMQ::Config.instance.set_timestamp = false
    end
  end

  it "supports recover requeue" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("recover", exclusive: true)
        5.times { q.publish "" }
        delivered = 0
        tag = q.subscribe(no_ack: false) { |_m| delivered += 1 }
        sleep 50.milliseconds
        q.unsubscribe(tag)
        sleep 50.milliseconds
        ch.basic_recover(requeue: true)
        sleep 50.milliseconds
        q.delete[:message_count].should eq 5
      end
    end
  end

  it "supports recover redeliver" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        q.publish "m1"
        msgs = Channel(AMQP::Client::DeliverMessage).new
        q.subscribe(no_ack: false) { |m| msgs.send m }
        msgs.receive
        ch.basic_recover(requeue: true)
        msgs.receive.redelivered.should be_true
      end
    end
  end

  it "basic_recover requeues messages for cancelled consumers" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("q")
        q.publish "m1"
        msgs = Channel(AMQP::Client::DeliverMessage).new
        tag = q.subscribe(no_ack: false) { |m| msgs.send m }
        msgs.receive.body_io.to_s.should eq "m1"
        q.unsubscribe(tag)
        ch.basic_recover(requeue: true)
        select
        when m = msgs.receive
          m.should be_nil
        when timeout 100.milliseconds
        end
        ch.queue_declare(q.name, passive: true)[:message_count].should eq 1
      end
    end
  end

  it "supports recover for basic get" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        q.publish_confirm "m1"
        q.publish_confirm "m2"
        msg = q.get(no_ack: false).should_not be_nil
        msg.body_io.to_s.should eq "m1"
        ch.basic_recover(requeue: true)
        msg = q.get(no_ack: false).should_not be_nil
        msg.body_io.to_s.should eq "m1"
      end
    end
  end

  it "recover(requeue=false) for basic get actually requeues" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        q.publish_confirm "m1"
        q.publish_confirm "m2"
        msg = q.get(no_ack: false).should_not be_nil
        msg.body_io.to_s.should eq "m1"
        ch.basic_recover(requeue: false)
        msg = q.get(no_ack: false).should_not be_nil
        msg.body_io.to_s.should eq "m1"
      end
    end
  end

  it "supports delivery-limit" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        args = AMQP::Client::Arguments.new
        args["x-delivery-limit"] = 1
        q = ch.queue("delivery_limit", args: args)
        q.publish "m1"
        msg = q.get(no_ack: false).should_not be_nil
        headers = msg.properties.headers.should_not be_nil
        headers.has_key?("x-delivery-count").should be_false # x-delivery-count is not set on first delivery
        msg.reject(requeue: true)
        msg = q.get(no_ack: false).should_not be_nil
        headers = msg.properties.headers.should_not be_nil
        headers["x-delivery-count"].as(Int32).should eq 1
        msg.reject(requeue: true)
        Fiber.yield
        s.vhosts["/"].queue("delivery_limit").empty?.should be_true
      end
    end
  end

  it "supports sends nack if all queues reject" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        args = AMQP::Client::Arguments.new
        args["x-max-length"] = 0_i64
        args["x-overflow"] = "reject-publish"
        q = ch.queue("", args: args)
        q.publish_confirm("m1").should be_false
      end
    end
  end

  it "nacks but doesn't return a mandatory publish that a full queue rejects" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        returned = Channel(String).new
        ch.on_return { |msg| returned.send msg.routing_key }
        args = AMQP::Client::Arguments.new
        args["x-max-length"] = 0_i64
        args["x-overflow"] = "reject-publish"
        q = ch.queue("", args: args)
        ch.basic_publish_confirm("m1", "", q.name, mandatory: true).should be_false
        ch.basic_publish_confirm("m2", "", "unroutable", mandatory: true).should be_true
        returned.receive.should eq "unroutable"
      end
    end
  end

  it "doesn't return a mandatory publish that a full queue rejects without confirms" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        returned = Channel(String).new
        ch.on_return { |msg| returned.send msg.routing_key }
        args = AMQP::Client::Arguments.new
        args["x-max-length"] = 0_i64
        args["x-overflow"] = "reject-publish"
        q = ch.queue("", args: args)
        ch.basic_publish("m1", "", q.name, mandatory: true)
        ch.basic_publish("m2", "", "unroutable", mandatory: true)
        returned.receive.should eq "unroutable"
      end
    end
  end

  it "binding to empty queue name binds last queue" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        ch.queue_bind("", "amq.direct", "foo")
        ch.basic_publish_confirm("bar", "amq.direct", "foo")
        msg = q.get.should_not be_nil
        msg.body_io.to_s.should eq "bar"
      end
    end
  end

  it "refuses binding to amq.default" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        expect_raises(AMQP::Client::Channel::ClosedException, "ACCESS_REFUSED") do
          q.bind("", "foo")
        end
      end
    end
  end

  it "refuses unbinding from amq.default" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        expect_raises(AMQP::Client::Channel::ClosedException, "ACCESS_REFUSED") do
          q.unbind("", q.name)
        end
      end
    end
  end

  it "requeues unacked msg from basic_ack on disconnect" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("ba", durable: true)
        q.publish "m1"
        msg = ch.basic_get(q.name, no_ack: false)
        msg.should_not be_nil
      end
      with_channel(s) do |ch|
        q = ch.queue("ba", durable: true)
        msg = ch.basic_get(q.name, no_ack: true)
        msg.should_not be_nil
      end
    end
  end

  it "will close channel on unknown delivery tag" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        ch.basic_ack(1)
        sleep 0.1.seconds
        expect_raises(AMQP::Client::Channel::ClosedException, /PRECONDITION_FAILED - unknown delivery tag 1/) do
          ch.basic_ack(1)
        end
      end
    end
  end

  it "will close channel on double ack" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("")
        q.publish "1"
        q.publish "2"
        q.publish "3"
        msg1 = ch.basic_get(q.name, no_ack: false).should_not be_nil
        msg2 = ch.basic_get(q.name, no_ack: false).should_not be_nil
        _msg3 = ch.basic_get(q.name, no_ack: false)
        msg2.ack
        msg2.ack # this will trigger the error
        sleep 0.1.seconds
        expect_raises(AMQP::Client::Channel::ClosedException, /PRECONDITION_FAILED - unknown delivery tag 2/) do
          msg1.ack
        end
      end
    end
  end

  it "will close channel on double ack with multiple" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("")
        q.publish "1"
        q.publish "2"
        q.publish "3"
        _msg1 = ch.basic_get(q.name, no_ack: false)
        msg2 = ch.basic_get(q.name, no_ack: false).should_not be_nil
        msg3 = ch.basic_get(q.name, no_ack: false).should_not be_nil
        msg2.ack
        msg2.ack(multiple: true) # this should tigger a precondition fail
        sleep 0.1.seconds
        expect_raises(AMQP::Client::Channel::ClosedException, /PRECONDITION_FAILED - unknown delivery tag 2/) do
          msg3.ack
        end
      end
    end
  end

  it "will requeue messages that can't be delivered" do
    with_amqp_server do |s|
      qname = "requeue-failed-delivery"
      count = 0
      with_channel(s) do |ch|
        ch.@connection.@io.as(TCPSocket).linger = 0
        q = ch.queue(qname)
        q.subscribe(no_ack: false) do |_msg|
          count += 1
        end
        q.publish "1"
        ch.@connection.@io.as(TCPSocket).close
        sleep 50.milliseconds
        count.should eq 0

        Fiber.yield
        s.vhosts["/"].queue(qname).message_count.should eq 1
        s.vhosts["/"].queue(qname).unacked_count.should eq 0
      end
    end
  end

  it "will limit message size" do
    LavinMQ::Config.instance.max_message_size = 128
    with_amqp_server do |s|
      with_channel(s) do |ch|
        expect_raises(AMQP::Client::Channel::ClosedException, /message size/) do
          ch.basic_publish_confirm("a" * 129, "amq.direct", "none")
        end
      end
    end
  ensure
    LavinMQ::Config.instance.max_message_size = 128 * 1024**2
  end

  it "should measure time it takes to collect metrics in stats_loop" do
    stats_interval = LavinMQ::Config.instance.stats_interval
    LavinMQ::Config.instance.stats_interval = 100
    with_amqp_server do |s|
      should_eventually(be_true, 1.seconds) { s.stats_collection_duration_seconds_total > Time::Span.zero }
      s.stats_rates_collection_duration_seconds.should_not eq Time::Span.zero
      s.stats_system_collection_duration_seconds.should_not eq Time::Span.zero
    end
  ensure
    LavinMQ::Config.instance.stats_interval = stats_interval if stats_interval
  end

  it "should requeue messages correctly on channel close" do
    with_amqp_server do |s|
      qname = "requeue-on-close"
      with_channel(s) do |ch|
        q = ch.queue(qname)

        10.times { q.publish_confirm "" }

        q.get(no_ack: true)
        q.get(no_ack: false)
        q.get(no_ack: false)

        count = 0
        q.subscribe(no_ack: false) do |_msg|
          count += 1
        end
        wait_for { count == 7 }
      end
      with_channel(s) do |ch|
        q = ch.queue(qname)
        q.message_count.should eq 9
      end
    end
  end

  it "supports single active consumer" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        ch.prefetch 1
        q = ch.queue("sac", args: AMQ::Protocol::Table.new({"x-single-active-consumer": true}))
        begin
          msgs = Channel(Tuple(String, AMQP::Client::DeliverMessage)).new
          q.subscribe(no_ack: false, tag: "1") do |msg|
            msgs.send({"1", msg})
          end
          q.subscribe(no_ack: false, tag: "2") do |msg|
            msgs.send({"2", msg})
          end
          4.times { q.publish "" }
          2.times do
            tag, msg = msgs.receive
            tag.should eq "1"
            msg.ack
          end
          tag, msg = msgs.receive
          tag.should eq "1"
          q.unsubscribe "1"
          msg.ack
          tag, msg = msgs.receive
          tag.should eq "2"
          msg.ack
        ensure
          q.delete
        end
      end
    end
  end

  it "can publish large messages to multiple queues" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q1 = ch.queue
        q2 = ch.queue
        q1.bind("amq.fanout", "")
        q2.bind("amq.fanout", "")
        2.times do |i|
          ch.basic_publish_confirm(i.to_s * 200_000, "amq.fanout", "")
        end
        2.times do |i|
          if msg = q1.get
            msg.body_io.to_s.should eq i.to_s * 200_000
          else
            msg.should_not be_nil
          end
          if msg = q2.get
            msg.body_io.to_s.should eq i.to_s * 200_000
          else
            msg.should_not be_nil
          end
        end
      end
    end
  end

  it "can publish small messages to multiple queues" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q1 = ch.queue
        q2 = ch.queue
        q1.bind("amq.fanout", "")
        q2.bind("amq.fanout", "")
        2.times do |i|
          ch.basic_publish_confirm(i.to_s * 200, "amq.fanout", "")
        end
        2.times do |i|
          if msg = q1.get
            msg.body_io.to_s.should eq i.to_s * 200
          else
            msg.should_not be_nil
          end
          if msg = q2.get
            msg.body_io.to_s.should eq i.to_s * 200
          else
            msg.should_not be_nil
          end
        end
      end
    end
  end

  it "supports consumer timeouts", tags: "slow" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("", exclusive: true, args: AMQP::Client::Arguments.new({"x-consumer-timeout": 100}))
        q.publish_confirm("a")
        expect_raises(AMQP::Client::Channel::ClosedException, /PRECONDITION/) do
          q.subscribe(no_ack: false, tag: "c", block: true) { }
        end
      end
    end
  end

  it "restarts fast even with large messages", tags: "slow" do
    with_amqp_server do |s|
      data = Bytes.new 128 * 1024**2
      with_channel(s) do |ch|
        q = ch.queue("large-messages")
        10.times do
          q.publish_confirm(data)
        end
      end
      restart_time = Benchmark.realtime do
        restart_memory = Benchmark.memory do
          restart_server(s)
        end
        restart_memory.should be < 1 * 1024**2
      end
      restart_time.should be < 3.seconds # Some CI environments are slow
      with_channel(s) do |ch|
        ch.prefetch 1
        q = ch.queue("large-messages")
        done = Channel(Nil).new
        q.subscribe(no_ack: false) do |msg|
          msg.body_io.bytesize.should eq 128 * 1024**2
          msg.ack
          done.send nil
        end
        10.times { done.receive }
      end
    end
  end

  it "can handle non valid protocol starts" do
    LavinMQ::Config.instance.clustering = true
    with_amqp_server do |s|
      t = TCPSocket.new("localhost", amqp_port(s))
      t.print "HTTP"
      buf = Bytes.new 8
      t.read(buf)
      buf.should eq Bytes['A'.ord, 'M'.ord, 'Q'.ord, 'P'.ord, 0, 0, 9, 1]
    end
  end
end

# Fails to accept with *errno* *failures* times, then returns *client* once
private class FailingListener
  include Socket::Server
  getter? closed = false

  def initialize(@failures : Int32, @client : IO, @errno = Errno::EMFILE)
  end

  def accept? : IO?
    return if @closed
    if @failures > 0
      @failures -= 1
      raise Socket::Error.from_os_error("accept", @errno)
    end
    client, @client = @client, nil
    client
  end

  def accept : IO
    accept? || raise IO::Error.new("Closed")
  end

  def close
    @closed = true
  end
end

describe LavinMQ::AcceptLoop do
  it "accepts the next connection when the one being accepted failed" do
    # Network errors that accept(2) passes on from the connection
    errors = [Errno::ECONNABORTED]
    {% if flag?(:linux) %}
      errors << Errno.new(112) << Errno.new(64) # EHOSTDOWN, ENONET
    {% end %}
    errors.each do |errno|
      client, server_side = UNIXSocket.pair
      listener = FailingListener.new(failures: 1, client: server_side, errno: errno)
      accepted = nil
      LavinMQ::AcceptLoop.each(listener, "Spec listener") do |socket|
        accepted = socket
        listener.close
      end
      accepted.should be server_side
    ensure
      client.try &.close
      server_side.try &.close
    end
  end

  it "keeps accepting after an error that isn't listed" do
    client, server_side = UNIXSocket.pair
    listener = FailingListener.new(failures: 2, client: server_side, errno: Errno::ECONNRESET)
    accepted = nil
    started = Time.instant
    LavinMQ::AcceptLoop.each(listener, "Spec listener") do |socket|
      accepted = socket
      listener.close
    end
    accepted.should be server_side
    # 10 and 20ms, as it's not known to pass right away
    (Time.instant - started).should be >= 30.milliseconds
  ensure
    client.try &.close
    server_side.try &.close
  end
end

describe "Running out of file descriptors" do
  it "keeps accepting AMQP connections" do
    with_amqp_server do |s|
      address = s.amqp_server.@listeners.select(TCPServer).first.local_address
      rejected = Socket.tcp(address.family)
      without_free_file_descriptors do
        rejected.connect(address)
        sleep 100.milliseconds # the listener fails to accept it
      end
      # Linux accepts this one later, macOS drops it when accept fails
      rejected.close
      client = TCPSocket.new(address.address, address.port)
      client.read_timeout = 5.seconds
      client.write "AMQP\u0000\u0000\u0009\u0001".to_slice
      client.read_byte.should eq 1 # the method frame with the server's Connection.Start
    ensure
      rejected.try &.close
      client.try &.close
    end
  end

  it "pauses the HTTP listener before accepting again" do
    client, server_side = UNIXSocket.pair
    listener = FailingListener.new(failures: 4, client: server_side)
    http = HTTP::Server.new(&.response.print("ok"))
    http.bind(listener)
    started = Time.instant
    spawn { http.listen }
    client << "GET / HTTP/1.1\r\nHost: spec\r\n\r\n"
    client.flush
    HTTP::Client::Response.from_io(client).body.should eq "ok"
    # 10, 20, 40 and 80ms, instead of trying again right away
    (Time.instant - started).should be >= 140.milliseconds
  ensure
    http.try &.close
    client.try &.close
  end
end
