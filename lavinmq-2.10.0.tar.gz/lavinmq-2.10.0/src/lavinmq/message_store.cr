require "./mfile"
require "./segment_position"
require "./rate_limiter"
require "log"
require "file_utils"
require "./clustering/server"
require "./bool_channel"
require "./message_store/requeued_store"

module LavinMQ
  # Message store
  # This handles writing msgs to segments on disk
  # Keeping a list of deleted messages in memory and on disk
  # You can shift through the message store, but not requeue msgs
  # That has to be handled at another layer
  # Writes messages to segments on disk
  # Messages are refered to as SegmentPositions
  # Deleted messages are written to acks.#{segment}
  class MessageStore
    PURGE_YIELD_INTERVAL = 16_384
    Log                  = LavinMQ::Log.for "message_store"
    @segments = Hash(UInt32, MFile).new
    @deleted = Hash(UInt32, Array(UInt32)).new
    @segment_msg_count = Hash(UInt32, UInt32).new(0u32)
    @requeued : RequeuedStore = PublishOrderedRequeuedStore.new
    @closed = false
    getter closed
    getter bytesize = 0u64
    getter size = 0u32
    getter empty = BoolChannel.new(true)

    def initialize(@msg_dir : String, replicator : Clustering::Replicator?, durable : Bool = true, metadata : ::Log::Metadata = ::Log::Metadata.empty)
      @log = Logger.new(Log, metadata)
      @durable = durable
      # Non-durable queues unlink their files at creation, so they cannot be
      # replicated by reading from disk. Skip replication entirely for them.
      @replicator = durable ? replicator : nil
      @acks = Hash(UInt32, MFile).new { |acks, seg| acks[seg] = open_ack_file(seg) }
      load_segments_from_disk
      load_acks_from_disk
      @wfile_id = @segments.last_key
      @wfile = @segments.last_value
      @rfile_id = @segments.first_key
      @rfile = @segments.first_value
      unless @closed
        load_stats_from_segments
        prune_orphaned_acks
        delete_unused_segments
      end
      @empty.set empty? unless @closed
    end

    def push(msg) : SegmentPosition
      raise ClosedError.new if @closed
      sp = write_to_disk(msg)
      was_empty = @size.zero?
      @bytesize += sp.bytesize
      @size += 1
      @empty.set false if was_empty
      sp
    end

    def requeue(sp : SegmentPosition)
      raise ClosedError.new if @closed
      was_empty = @size.zero?
      @requeued.insert(sp)
      @bytesize += sp.bytesize
      @size += 1
      @empty.set false if was_empty
    end

    def first? : Envelope? # ameba:disable Metrics/CyclomaticComplexity
      raise ClosedError.new if @closed
      if sp = @requeued.first?
        seg = @segments[sp.segment]
        begin
          msg = BytesMessage.from_bytes(seg.to_slice + sp.position)
          return Envelope.new(sp, msg, redelivered: true)
        rescue ex
          raise Error.new(seg, cause: ex)
        end
      end

      loop do
        seg = @rfile_id
        rfile = @rfile
        pos = rfile.pos.to_u32
        if pos == rfile.size # EOF?
          select_next_read_segment && next
          return if @size.zero?
          raise IO::EOFError.new("EOF but @size=#{@size}")
        end
        if deleted?(seg, pos)
          BytesMessage.skip(rfile)
          next
        end
        msg = BytesMessage.from_bytes(rfile.to_slice + pos)
        raise IndexError.new("Message at segment #{seg} pos #{pos} has zero timestamp") if msg.timestamp.zero?
        sp = SegmentPosition.make(seg, pos, msg)
        return Envelope.new(sp, msg, redelivered: false)
      rescue ex : IndexError
        @log.warn(exception: ex) { "Msg file size does not match expected value, moving on to next segment" }
        select_next_read_segment && next
        return if @size.zero?
        raise Error.new(@rfile, cause: ex)
      rescue ex
        @log.error(exception: ex) { "first? failed: #{state_snapshot}" }
        raise Error.new(@rfile, cause: ex)
      end
    end

    def shift?(consumer = nil) : Envelope? # ameba:disable Metrics/CyclomaticComplexity
      raise ClosedError.new if @closed
      if sp = @requeued.shift?
        begin
          segment = @segments[sp.segment]
          msg = BytesMessage.from_bytes(segment.to_slice + sp.position)
          @bytesize -= sp.bytesize
          @size -= 1
          @empty.set true if @size.zero?
          return Envelope.new(sp, msg, redelivered: true)
        rescue ex
          # sp has already been removed from @requeued; drop its accounting too
          # so @size/@bytesize don't leak when the segment is gone or the
          # payload can't be parsed. Without this, future shift? calls can hit
          # EOF with @size > 0 because the requeued entry can never be re-read.
          @bytesize -= sp.bytesize
          @size -= 1
          @empty.set true if @size.zero?
          raise Error.new(@segments[sp.segment]? || @rfile, cause: ex)
        end
      end

      loop do
        rfile = @rfile
        seg = @rfile_id
        pos = rfile.pos.to_u32
        if pos == rfile.size # EOF?
          select_next_read_segment && next
          return if @size.zero?
          raise IO::EOFError.new("EOF but @size=#{@size}")
        end
        if deleted?(seg, pos)
          BytesMessage.skip(rfile)
          next
        end
        msg = BytesMessage.from_bytes(rfile.to_slice + pos)
        raise IndexError.new("Message at segment #{seg} pos #{pos} has zero timestamp") if msg.timestamp.zero?
        sp = SegmentPosition.make(seg, pos, msg)
        rfile.seek(sp.bytesize, IO::Seek::Current)
        @bytesize -= sp.bytesize
        @size -= 1
        @empty.set true if @size.zero?
        return Envelope.new(sp, msg, redelivered: false)
      rescue ex : IndexError
        @log.warn(exception: ex) { "Msg file size does not match expected value, moving on to next segment" }
        select_next_read_segment && next
        return if @size.zero?
        raise Error.new(@rfile, cause: ex)
      rescue ex
        @log.error(exception: ex) { "shift? failed: #{state_snapshot}" }
        raise Error.new(@rfile, cause: ex)
      end
    end

    def [](sp : SegmentPosition) : BytesMessage
      raise ClosedError.new if @closed
      segment = @segments[sp.segment]
      begin
        BytesMessage.from_bytes(segment.to_slice + sp.position)
      rescue ex
        raise Error.new(segment, cause: ex)
      end
    end

    # Like `#[]`, but the returned message owns all its memory: the record is
    # copied out of the segment's mmap, so the message stays valid after the
    # segment is deleted and unmapped. For messages that outlive the caller's
    # @msg_store_lock hold, e.g. dead-lettering (see AMQP::Queue#expire_msg).
    def copy(sp : SegmentPosition) : BytesMessage
      raise ClosedError.new if @closed
      segment = @segments[sp.segment]
      begin
        BytesMessage.from_bytes(segment.to_slice(sp.position.to_i64, sp.bytesize.to_i64).dup)
      rescue ex
        raise Error.new(segment, cause: ex)
      end
    end

    def delete(sp) : Nil
      raise ClosedError.new if @closed
      afile = @acks[sp.segment]
      begin
        ack_offset = afile.size.to_i64
        afile.write_bytes sp.position
        @replicator.try &.append_value(afile.path, sp.position, ack_offset)

        # if all msgs in a segment are deleted then delete the segment
        return if sp.segment == @wfile_id # don't try to delete a segment we still write to
        ack_count = afile.size // sizeof(UInt32)
        msg_count = @segment_msg_count[sp.segment]
        if ack_count == msg_count
          @log.debug { "Deleting segment #{sp.segment} (delete sp): #{state_snapshot}" }
          select_next_read_segment if sp.segment == @rfile_id
          if a = @acks.delete(sp.segment)
            delete_file(a)
          end
          if seg = @segments.delete(sp.segment)
            delete_file(seg, including_meta: true)
          end
          @segment_msg_count.delete(sp.segment)
          @deleted.delete(sp.segment)
        end
      rescue ex
        raise Error.new(afile, cause: ex)
      end
    end

    # Deletes all "ready" messages (not unacked)
    def purge(max_count : Int = UInt32::MAX) : UInt32
      raise ClosedError.new if @closed
      count = 0u32
      while count < max_count && (env = shift?)
        delete(env.segment_position)
        count += 1
        break if count >= max_count
        Fiber.yield if (count % PURGE_YIELD_INTERVAL).zero?
      end
      count
    end

    def purge_all
      # Drain @requeued, acking each entry so it doesn't come back after a restart
      while sp = @requeued.shift?
        @size -= 1
        @bytesize -= sp.bytesize
        delete(sp) if @segments.has_key?(sp.segment)
      end

      # Delete all segments except the current rfile and wfile
      @segments.reject! do |seg_id, file|
        next false if seg_id == @rfile_id || seg_id == @wfile_id

        delete_file(file, including_meta: true)
        # Only decrement @size for unread segments. Read segments don't
        # contribute to @size: their msgs are either acked, in-flight, or
        # were drained from @requeued above.
        if (msg_count = @segment_msg_count.delete(seg_id)) && seg_id > @rfile_id
          # msg_count is every msg ever written to the segment, acked ones
          # included, while @size only counts the ready ones. Never take off
          # more than @size holds: which msgs are ready is the subclass's to
          # decide, and a purge must not underflow the counter here, outside
          # the rescue below.
          acked = @acks[seg_id]?.try { |f| (f.size // sizeof(UInt32)).to_u32 } || 0u32
          ready = acked < msg_count ? msg_count - acked : 0u32
          @size -= Math.min(ready, @size)
        end
        if afile = @acks.delete(seg_id)
          delete_file(afile)
        end
        @deleted.delete(seg_id)
        true
      end

      # Purge @rfile and @wfile. Swallow any inconsistency between @size and the
      # on-disk segments — purge_all's postcondition is an empty store, so we
      # force the counters to zero below regardless of how the loop exits.
      begin
        while env = shift?
          delete(env.segment_position)
        end
      rescue ex : IO::EOFError | Error
        @log.warn(exception: ex) { "purge_all: store state out of sync with segments, resetting counters" }
      end

      @bytesize = 0_u64
      @size = 0_u32
      @empty.set true
    end

    def delete
      @closed = true
      @empty.close
      @segments.reject! { |_, f| delete_file(f, including_meta: true); true }
      @acks.reject! { |_, f| delete_file(f); true }
      FileUtils.rm_rf @msg_dir
    end

    private def delete_file(file : MFile, including_meta = false)
      file.delete(raise_on_missing: false)
      if replicator = @replicator
        replicator.delete_file(meta_file_name(file)) if including_meta
        replicator.delete_file(file.path)
      end
      File.delete?(meta_file_name(file)) if including_meta
      file.close
    end

    def empty?
      @size.zero?
    end

    def close : Nil
      return if @closed
      @closed = true
      @empty.close
      if replicator = @replicator
        @segments.each_value do |segment|
          replicator.register_file segment.path
          segment.close
        end
        @acks.each_value do |ackfile|
          replicator.register_file ackfile.path
          ackfile.close
        end
      else
        @segments.each_value &.close
        @acks.each_value &.close
      end
    end

    def avg_bytesize : UInt32
      return 0u32 if @size.zero?
      (@bytesize / @size).to_u32
    end

    private def state_snapshot : String
      String.build do |io|
        io << "store_closed=" << @closed
        io << " rfile_id=" << @rfile_id
        io << " rfile=" << @rfile.path << "(closed=" << @rfile.closed? << " pos=" << @rfile.pos << " size=" << @rfile.size << ")"
        io << " wfile_id=" << @wfile_id
        io << " segments=" << @segments.keys
        io << " size=" << @size
      end
    end

    private def select_next_read_segment : MFile?
      @rfile.dontneed unless @rfile.closed?
      prev_id = @rfile_id
      # Expect @segments to be ordered
      if id = @segments.each_key.find { |sid| sid > @rfile_id }
        rfile = @segments[id]
        rfile.advise(MFile::Advice::Sequential)
        @rfile_id = id
        @rfile = rfile
        @log.debug { "select_next_read_segment: #{prev_id} -> #{id}, segments=#{@segments.keys}" }
        rfile
      else
        @log.debug { "select_next_read_segment: no segment > #{prev_id}, segments=#{@segments.keys}, rfile_closed=#{@rfile.closed?}" }
        nil
      end
    end

    private def write_to_disk(msg) : SegmentPosition
      wfile = @wfile
      if wfile.capacity < wfile.size + msg.bytesize
        wfile = open_new_segment(msg.bytesize)
      end
      wfile_id = @wfile_id
      sp = SegmentPosition.make(wfile_id, wfile.size.to_u32, msg)
      wfile.write_bytes msg
      @replicator.try &.append(wfile.path, sp.position, wfile.size - sp.position)
      @segment_msg_count[wfile_id] += 1
      sp
    end

    private def open_new_segment(next_msg_size = 0) : MFile
      unless @wfile_id.zero?
        write_metadata_file(@wfile_id, @wfile)
        @wfile.truncate(@wfile.size)
      end
      @wfile.dontneed unless @wfile == @rfile
      next_id = @wfile_id + 1
      path = File.join(@msg_dir, "msgs.#{next_id.to_s.rjust(10, '0')}")
      capacity = Math.max(Config.instance.segment_size, next_msg_size + 4)
      wfile = MFile.new(path, capacity)
      wfile.write_bytes Schema::VERSION
      wfile.pos = 4
      @replicator.try &.register_file wfile
      @replicator.try &.append_value path, Schema::VERSION, 0i64
      @wfile_id = next_id
      @wfile = @segments[next_id] = wfile
      delete_unused_segments
      @wfile.delete unless @durable # mark as deleted if non-durable
      wfile
    end

    private def write_metadata_file(seg : UInt32, wfile : MFile)
      metafile = meta_file_name(wfile)
      @log.debug { "Write message segment meta file #{metafile}" }
      File.open(metafile, "w") do |f|
        f.buffer_size = 4096
        write_metadata(f, seg)
        @replicator.try &.register_file(f)
      end
      @replicator.try &.replace_file metafile
    end

    private def write_metadata(io, seg)
      io.write_bytes @segment_msg_count[seg]
    end

    private def open_ack_file(id) : MFile
      path = File.join(@msg_dir, "acks.#{id.to_s.rjust(10, '0')}")
      capacity = Config.instance.segment_size // BytesMessage::MIN_BYTESIZE * 4 + 4
      mfile = MFile.new(path, capacity, writeonly: true)
      mfile.delete unless @durable # mark as deleted if non-durable
      @replicator.try &.register_file mfile
      mfile
    end

    private def load_acks_from_disk : Nil
      count = 0u32
      Dir.each_child(@msg_dir) do |f|
        if f.starts_with?("tmp.acks.")
          stale = File.join(@msg_dir, f)
          @log.debug { "Deleting stale ack rewrite tempfile: #{stale}" }
          File.delete?(stale)
          next
        end
        next unless f.starts_with?("acks.")
        seg = f[5, 10].to_u32
        path = File.join(@msg_dir, f)

        # The ack file is orphaned if there is no corresponding msg file
        msgs_path = File.join(@msg_dir, "msgs.#{seg.to_s.rjust(10, '0')}")
        unless File.exists?(msgs_path)
          @log.warn { "Deleting orphaned ack file: #{path}" }
          File.delete(path)
          @replicator.try &.delete_file(path)
          next
        end

        # We must replicate the files even if the store is closed
        if @closed
          @replicator.try &.register_file path
        else
          acked = Array(UInt32).new
          File.open(path, "a+") do |file|
            loop do
              pos = UInt32.from_io(file, IO::ByteFormat::SystemEndian)
              if pos.zero? # pos 0 doesn't exists (first valid is 4), must be a sparse file
                file.truncate(file.pos - 4)
                break
              end
              acked << pos
            rescue IO::EOFError
              break
            end
            @replicator.try &.register_file(file)
          end
          @acks[seg] = open_ack_file(seg)
          @deleted[seg] = acked.sort! unless acked.empty?
        end
        count += 1
        Fiber.yield
      end
      @log.debug { "Loaded #{count} ack files" }
    rescue File::NotFoundError
      # msg_dir does not exist, nothing to load
    end

    private def load_segments_from_disk : Nil
      ids = Array(UInt32).new
      Dir.each_child(@msg_dir) do |f|
        if f.starts_with?("msgs.") && f.size == 15
          ids << f[5, 10].to_u32
        end
      end
      ids.sort!
      was_empty = ids.empty?
      ids << 1_u32 if was_empty
      last_idx = ids.size - 1
      ids.each_with_index do |seg, idx|
        filename = "msgs.#{seg.to_s.rjust(10, '0')}"
        path = File.join(@msg_dir, filename)
        file = if idx == last_idx
                 # expand the last segment
                 MFile.new(path, Config.instance.segment_size)
               else
                 MFile.new(path)
               end
        @replicator.try &.register_file file
        file.delete unless @durable # mark files for non-durable queues for deletion

        if was_empty
          file.write_bytes Schema::VERSION
          @replicator.try &.append_value path, Schema::VERSION, 0i64
        else
          begin
            SchemaVersion.verify(file, :message)
          rescue IO::EOFError
            # delete empty file, it will be recreated if it's needed
            @log.warn { "Empty file at #{path}, deleting it" }
            delete_file(file, including_meta: true)
            if idx == 0 # Recreate the file if it's the first segment because we need at least one segment to exist
              file = MFile.new(path, Config.instance.segment_size)
              file.write_bytes Schema::VERSION
              @replicator.try &.append_value path, Schema::VERSION, 0i64
            else
              @segments.delete seg
              next
            end
          rescue ex
            @log.error { "Could not initialize segment #{seg}, closing message store: #{ex.message}" }
            @segments[seg] = file
            # Register remaining segments by path so the replicator knows about
            # all files on disk even though we won't load them due to the abort.
            if replicator = @replicator
              ids[(idx + 1)..].each do |remaining_seg|
                replicator.register_file File.join(@msg_dir, "msgs.#{remaining_seg.to_s.rjust(10, '0')}")
              end
            end
            close
            break
          end
        end
        file.pos = 4
        @segments[seg] = file
        Fiber.yield
      end
    end

    # Populate bytesize, size and segment_msg_count
    private def load_stats_from_segments : Nil
      counter = 0
      is_long_queue = @segments.size > 255
      if is_long_queue
        @log.info { "Loading #{@segments.size} segments" }
      else
        @log.debug { "Loading #{@segments.size} segments" }
      end
      log_limiter = RateLimiter.new(2.seconds)
      @segments.each do |seg, mfile|
        begin
          read_metadata_file(seg, mfile)
        rescue File::NotFoundError | MetadataError
          produce_metadata(seg, mfile)
          break if @closed
          write_metadata_file(seg, mfile) unless seg == @segments.last_key # this segment is not full yet
        end

        counter &+= 1
        if is_long_queue
          log_limiter.do { @log.info { "Loaded #{counter}/#{@segments.size} segments, #{@size} messages" } }
        else
          @log.debug { "Loaded #{counter}/#{@segments.size} segments, #{@size} messages" } if counter % 128 == 0
        end
      end
      @log.info { "Loaded #{counter} segments, #{@size} messages" }
    end

    private def read_metadata_file(seg, mfile)
      metafile = meta_file_name(mfile)
      count = File.open(metafile) do |file|
        msg_count = file.read_bytes(UInt32)
        @replicator.try &.register_file(file)
        read_extra_metadata_fields(file, seg)
        msg_count
      end
      @segment_msg_count[seg] = count
      bytesize = mfile.size - 4
      if deleted = @deleted[seg]?
        deleted.each do |pos|
          mfile.pos = pos
          bs = BytesMessage.skip(mfile)
          # don't allow underflow
          bytesize = bs < bytesize ? bytesize - bs : 0
          count -= 1 if count > 0
        rescue ex
          @log.error { "Error reading metadata file #{metafile}, pos: #{pos}, seg: #{seg}, count: #{count}, bytesize: #{bytesize}" }
          raise ex
        end
      end
      mfile.pos = 4
      mfile.dontneed
      @bytesize += bytesize
      @size += count
      @log.debug { "Reading count from #{metafile}: #{count}" }
    rescue ex : File::NotFoundError
      raise ex
    rescue ex
      @log.error(exception: ex) { "Metadata file #{metafile} is incorrect" }
      raise MetadataError.new("Metadata file #{metafile} is incorrect", cause: ex)
    end

    private def read_extra_metadata_fields(file : File, seg : UInt32)
      # Used in subclasses of MessageStore to read additional metadata fields
    end

    # Removes ack positions referencing data past the reconstructed segment size.
    # Such orphaned acks can survive an unclean shutdown when kernel page-cache
    # flushes the acks file but not the corresponding msgs file, and would
    # otherwise cause shift? to skip over brand-new messages as if acked.
    private def prune_orphaned_acks : Nil
      # Snapshot keys — prune_orphaned_acks_for_segment mutates @deleted.
      @deleted.keys.each do |seg|
        next unless positions = @deleted[seg]?
        next unless mfile = @segments[seg]?
        prune_orphaned_acks_for_segment(seg, mfile, positions)
      end
    end

    private def prune_orphaned_acks_for_segment(seg : UInt32, mfile : MFile, positions : Array(UInt32)) : Nil
      data_end = mfile.size.to_u32
      valid = positions.select { |p| p < data_end }
      orphan_count = positions.size - valid.size
      return if orphan_count.zero?

      @log.warn do
        "Msgs/acks files for segment #{seg} are out of sync (possibly because of " \
        "an unclean shutdown). Removing #{orphan_count} orphaned ack position(s)."
      end

      if valid.empty?
        @deleted.delete(seg)
      else
        @deleted[seg] = valid
      end

      rewrite_ack_file(seg, valid)
    end

    private def rewrite_ack_file(seg : UInt32, positions : Array(UInt32)) : Nil
      return unless @durable

      basename = "acks.#{seg.to_s.rjust(10, '0')}"
      final_path = File.join(@msg_dir, basename)
      tmp_path = File.join(@msg_dir, "tmp.#{basename}")

      File.open(tmp_path, "w") do |f|
        positions.each { |p| f.write_bytes(p, IO::ByteFormat::SystemEndian) }
        f.fsync
      end

      # Unmap the old file before renaming so mmap stops pinning the old inode.
      if old = @acks.delete(seg)
        old.close(truncate_to_size: false)
      end

      File.rename(tmp_path, final_path)

      # Ship the rewritten (short) file to followers before reopening, so
      # ReplaceAction captures the post-rename file size rather than the
      # capacity-sized file produced by open_ack_file's ftruncate.
      @replicator.try &.replace_file(final_path)
      @acks[seg] = open_ack_file(seg)
    end

    private def produce_metadata(seg, mfile)
      count = 0u32
      mfile.pos = 4
      loop do
        pos = mfile.pos
        ts = IO::ByteFormat::SystemEndian.decode(Int64, mfile.to_slice(pos, 8))
        break mfile.resize(pos) if ts.zero? # This means that the rest of the file is zero, so resize it
        bytesize = BytesMessage.skip(mfile)
        count += 1
        next if deleted?(seg, pos)
        @bytesize += bytesize
        @size += 1
      rescue IO::EOFError
        break
      rescue ex : OverflowError | AMQ::Protocol::Error::FrameDecode
        @log.error { "Could not initialize segment, closing message store: Failed to read segment #{seg} at pos #{mfile.pos}. #{ex}" }
        close
        return count
      end
      mfile.pos = 4
      mfile.dontneed
      Fiber.yield
      @segment_msg_count[seg] = count
      @log.debug { "Manually counted #{count} msgs from #{mfile.path}" }
    end

    private def delete_unused_segments : Nil
      current_seg = @segments.last_key
      @segments.reject! do |seg, mfile|
        next if seg == current_seg # don't the delete the segment still being written to

        if (acks = @acks[seg]?) && @segment_msg_count[seg] <= (acks.size // sizeof(UInt32))
          @log.debug { "Deleting unused segment #{seg}: #{state_snapshot}" }
          select_next_read_segment if seg == @rfile_id
          @segment_msg_count.delete seg
          @deleted.delete seg
          if ack = @acks.delete(seg)
            delete_file(ack)
          end
          delete_file(mfile, including_meta: true)
          true
        else
          false
        end
      end
    end

    private def deleted?(seg, pos) : Bool
      if del = @deleted[seg]?
        del.bsearch { |dpos| dpos >= pos } == pos
      else
        false
      end
    end

    private def meta_file_name(mfile : MFile) : String
      meta_file_name(mfile.path)
    end

    private def meta_file_name(path : String) : String
      # We assume the path ends with "msgs.<10 chars>"
      raw = path.to_slice

      # This is basically the same as using sub("msgs.", "meta.") but with #sub
      # the first occurrence of "msgs." would be replaced, not the last one.
      # This also requires only one allocation.
      String.build(path.size) do |io|
        io.write raw[0, raw.size - 15]
        io.write "meta.".to_slice
        io.write raw[-10..]
      end
    end

    class ClosedError < ::Channel::ClosedError; end

    class MetadataError < Exception; end

    class Error < Exception
      def initialize(mfile : MFile, cause = nil)
        super("path=#{mfile.path} pos=#{mfile.pos} size=#{mfile.size}", cause: cause)
      end
    end
  end
end
