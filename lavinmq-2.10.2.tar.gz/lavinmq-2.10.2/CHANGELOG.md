# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.10.2] - 2026-10-07

### Fixed

- Memory growth with clustering enabled when vhosts are repeatedly created and deleted: files of a deleted vhost stayed in the replication index, and followers kept them on disk with an open file descriptor each [#2335](https://github.com/cloudamqp/lavinmq/pull/2335)
- A vhost deleted on a cluster could reappear with its queues, messages, exchanges and policies if the vhost was created again under the same name after a failover: followers kept the deleted vhost's files on disk [#2335](https://github.com/cloudamqp/lavinmq/pull/2335)

## [2.10.1] - 2026-10-05

This patch release works around a Linux kernel bug that stalled queue churn on affected kernels, and fixes messages above `x-max-priority` that could not be acked, stream segments with an incomplete trailing record that prevented startup, and streams that `max-length` retention could empty on rollover. It reduces stream memory usage during replays, resends unacked MQTT QoS 1 publishes under their original packet IDs, keeps a locked-down MQTT definitions import locked down, and fixes several queue policy, HTTP API, management UI and logging issues.

### Added

- A startup warning when the data directory's block device has a read ahead above 1 MiB, as a large read ahead stalls publishers at segment rollover [#2337](https://github.com/cloudamqp/lavinmq/pull/2337)

### Changed

- The MQTT `default` permission group is saved to `mqtt_permissions.json` when a vhost is created instead of when it closes. A definitions import no longer removes the `default` group from an existing vhost, and a vhost created by an import that has an `mqtt_permissions` key gets only the groups listed for it, so an exported vhost without groups stays locked down. `lavinmqctl definitions export` includes the `default` group for a vhost without `mqtt_permissions.json` [#2330](https://github.com/cloudamqp/lavinmq/pull/2330)
- `max_inflight_messages` must be at least `1`; `0` is now rejected at startup and on config reload instead of leaving every MQTT session accepting publishes it can never deliver [#2233](https://github.com/cloudamqp/lavinmq/pull/2233)
- Stream `max-length` and `max-length-bytes` retention only drops a segment if the stream still meets the limit without it, so a stream now keeps at least the limit (up to one extra segment) instead of possibly being emptied on segment rollover. `max-age` segments are dropped when they expire, also on streams that receive no new messages [#2250](https://github.com/cloudamqp/lavinmq/pull/2250)
- TLS handshake failures and invalid TLS configuration are logged with an error message instead of a stack trace. A failed TLS configuration reload logs the error and keeps the previous configuration [#1762](https://github.com/cloudamqp/lavinmq/pull/1762)

### Fixed

- Severe queue-churn stalls on affected Linux kernels, observed on arm64: segment memory is released in 1 MiB chunks to avoid a kernel TLB flush bug that caused repeated page faults [#2288](https://github.com/cloudamqp/lavinmq/pull/2288)
- Messages published with a priority above the queue's `x-max-priority` could not be acked, rejected, requeued or purged, leaving the queue inconsistent even after a restart. Store lookups now clamp the priority to the queue's maximum, matching how the messages are stored [#2293](https://github.com/cloudamqp/lavinmq/pull/2293)
- An incomplete trailing record in a stream segment could prevent broker startup when segment metadata was rebuilt. Recovery now drops the incomplete record and replicates the shortened segment to followers [#2286](https://github.com/cloudamqp/lavinmq/pull/2286)
- Unacknowledged MQTT QoS 1 publishes are resent under the packet IDs the client already holds, with `dup` set, instead of being assigned new ones [MQTT-4.4.0-1]. The IDs are remembered in-process, so a session resumed after a broker restart is still redelivered under fresh IDs [#2233](https://github.com/cloudamqp/lavinmq/pull/2233)
- Stream queue memory usage while consuming: segments are released from memory as soon as no consumer is reading them, instead of by a sweep every 60 seconds, which could grow to hundreds of MB during a fast replay [#2250](https://github.com/cloudamqp/lavinmq/pull/2250)
- Repeated queue policy updates spawned duplicate expiration and limit-enforcement workers. Updates are now coalesced, and overflow and delivery-limit enforcement run independently so a failure in one cannot skip the other [#2291](https://github.com/cloudamqp/lavinmq/pull/2291)
- HTTP routes with percent-encoded unreserved characters, such as `/api/nodes/gc%5Fstats`, now match the intended endpoint. Encoded slashes remain part of parameter values, including vhost names [#2277](https://github.com/cloudamqp/lavinmq/pull/2277)
- Sorting boolean columns through the HTTP API returned an error, including sorting the connections list by TLS in the management UI [#2248](https://github.com/cloudamqp/lavinmq/pull/2248)
- Management UI tooltips were clipped or misplaced near viewport edges and inside scrollable containers [#2235](https://github.com/cloudamqp/lavinmq/pull/2235)

## [2.10.0] - 2026-09-25

This release adds MQTT topic permissions, negative `x-stream-offset` values to read the last N stream messages, a `state` filter on the queue list endpoints and an API endpoint to close a single channel. It adds Prometheus metrics for per-queue deliveries and inter-node replication. Shovels get reworked HTTP destinations and error handling, with classified delivery outcomes, a `dest-timeout` setting and an `aborted` state. It also fixes purged messages that came back after a restart, a stream consumer that could starve other fibers during a fast replay, and an AMQP reply text over 255 bytes that broke the frame it travelled in.

### Added

- Negative `x-stream-offset` values to consume the last N stream messages [#1941](https://github.com/cloudamqp/lavinmq/pull/1941)
- Tab navigation on queue detail pages in the management UI [#2006](https://github.com/cloudamqp/lavinmq/pull/2006)
- `client_id_validation` MQTT config option to require the client ID to match the authenticated username [#2038](https://github.com/cloudamqp/lavinmq/pull/2038)
- `tls_prefer_server_ciphers` config option that makes the server's cipher order decide the negotiated cipher [#2204](https://github.com/cloudamqp/lavinmq/pull/2204)
- API endpoint and management UI action to close a single channel [#2212](https://github.com/cloudamqp/lavinmq/pull/2212)
- `state` query parameter on `GET /api/queues` and `GET /api/queues/:vhost` to filter queues by state, e.g. `?state=closed` or `?state=paused,closed` [#2234](https://github.com/cloudamqp/lavinmq/pull/2234)
- Per-queue delivered and acked totals in Prometheus metrics [#1837](https://github.com/cloudamqp/lavinmq/pull/1837)
- Inter-node replication byte metrics in Prometheus [#2051](https://github.com/cloudamqp/lavinmq/pull/2051)
- Shovel `dest-timeout` setting for HTTP destinations, editable in the management UI, and runtime delivery outcome counters in the shovel API [#2128](https://github.com/cloudamqp/lavinmq/pull/2128)
- MQTT topic permissions: per-user, per-topic-filter authorization managed via `/api/mqtt/permission-groups`. Every vhost gets a `default` group that allows all topics, delete it to lock the vhost down [#2126](https://github.com/cloudamqp/lavinmq/pull/2126)

### Changed

- Shovel deliveries are classified into outcomes: a `2xx` HTTP response acks the message, `408`, `429`, `5xx` and transport failures requeue it with backoff, statuses that describe the message itself dead-letter it, and repeated unusable-destination outcomes stop the shovel in a new `aborted` state that is resumed via the API or the management UI. A dead-lettered message is dropped if the source queue has no dead-letter exchange [#2128](https://github.com/cloudamqp/lavinmq/pull/2128)
- Overview page card design updates in the management UI [#2145](https://github.com/cloudamqp/lavinmq/pull/2145) [#2174](https://github.com/cloudamqp/lavinmq/pull/2174)
- The management UI version is advertised via the `LavinMQ-Version` response header instead of being injected at build time [#2123](https://github.com/cloudamqp/lavinmq/pull/2123)

### Fixed

- An AMQP `reply_text` longer than 255 bytes broke the frame after the header was written and dropped the connection. A passive declare of a missing queue with a long name reaches it, as do the `X-Reason` headers on `DELETE /api/channels/:name` and `DELETE /api/connections/:name`. The text is now truncated on a codepoint boundary [#2263](https://github.com/cloudamqp/lavinmq/pull/2263)
- Boolean values in an `[sni:...]` config section were parsed case-sensitively, so `TRUE` read as false for 8 keys, including `tls_verify_peer` where it silently disabled mTLS [#2264](https://github.com/cloudamqp/lavinmq/pull/2264)
- A shovel kept reporting the `error` it had stopped with after it recovered or was resumed [#2264](https://github.com/cloudamqp/lavinmq/pull/2264)
- Purged messages that had been requeued came back after a restart, because `purge_all` dropped them from memory without writing an ack record. The queue size counter could also underflow [#2247](https://github.com/cloudamqp/lavinmq/pull/2247)
- A stream consumer replaying from an old offset yielded to other fibers only every 32768 messages, so a fast replay of large messages could starve publishers, other consumers and GC [#2227](https://github.com/cloudamqp/lavinmq/issues/2227)

## [2.10.0-rc.2] - 2026-09-24

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.10.0-rc.2> for changes in this pre-release

## [2.10.0-rc.1] - 2026-09-18

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.10.0-rc.1> for changes in this pre-release

## [2.9.3] - 2026-09-09

This patch release fixes MQTT persistent sessions losing their subscriptions on restart, a segfault when dead-lettering races a purge or queue delete, and slow restarts with many delayed messages. It enforces the vhost `max-connections` and `max-queues` limits for MQTT, stops PROXY protocol connections from counting as loopback for the default user, and corrects several message statistics, stream policy, API and management UI issues.

### Fixed

- MQTT persistent sessions lost their subscriptions on restart: the MQTT exchange was created after the definitions were loaded, and its bindings were never written to the definitions file [#2159](https://github.com/cloudamqp/lavinmq/pull/2159)
- Segfault (use after munmap) when dead-lettering a message raced a purge or a queue delete on the source queue [#2184](https://github.com/cloudamqp/lavinmq/pull/2184)
- O(N²) insert in the delayed message store made broker restarts hang and publishing to a large delayed exchange queue progressively slower; replaced with a min-heap [#2175](https://github.com/cloudamqp/lavinmq/pull/2175)
- Per-vhost `message_stats` no longer over-counts published messages by the fan-out factor; cumulative message counters are read from the vhost's own counters instead of summing per-queue [#2092](https://github.com/cloudamqp/lavinmq/issues/2092)
- Prometheus and HTTP API counters (`global_messages_*`, churn `*_total`, `/api/overview`, `/api/nodes`) no longer decrease when a queue or vhost is deleted, which previously made `rate()`/`increase()` fabricate spikes [#2093](https://github.com/cloudamqp/lavinmq/issues/2093)
- `return_unroutable` was only counted per channel and always reported 0 in per-vhost `message_stats`, `/api/overview` and Prometheus; it is now aggregated to the vhost and exposed as `lavinmq_global_messages_unroutable_returned_total` [#2203](https://github.com/cloudamqp/lavinmq/pull/2203)
- The vhost `max-connections` limit is now enforced for MQTT connections [#2222](https://github.com/cloudamqp/lavinmq/pull/2222)
- MQTT sessions now respect the vhost `max-queues` limit; a SUBSCRIBE that would create a session beyond the cap is answered with failure return codes instead of exceeding the limit [#2223](https://github.com/cloudamqp/lavinmq/pull/2223)
- A connection with a PROXY protocol header never counts as loopback for `default_user_only_loopback`, including through a cluster follower. The default user can only connect directly on the broker host [#2224](https://github.com/cloudamqp/lavinmq/pull/2224)
- A stream queue that got `max-age` only from a policy ignored policy edits that increased `max-age` until restart [#2152](https://github.com/cloudamqp/lavinmq/pull/2152)
- The broker failed to start when `users.json` contained an unknown key, for example after a downgrade [b9f03d90](https://github.com/cloudamqp/lavinmq/commit/b9f03d90)
- HTTP shovels could not be created through the API, config validation demanded a destination queue or exchange that an HTTP destination has no use for [#2215](https://github.com/cloudamqp/lavinmq/pull/2215)
- `GET` and `DELETE /api/vhosts/:vhost` return 404 instead of 403 for a non-existent vhost when the user is an administrator [#2147](https://github.com/cloudamqp/lavinmq/pull/2147)
- MQTT connections were missing `host`, `port`, `peer_host` and `peer_port` in `lavinmqctl list_connections`, the management UI and `/api/connections` [#2138](https://github.com/cloudamqp/lavinmq/pull/2138)
- MQTT 3.1 connections were reported as `MQTT 3.1.1` in connection details [#2139](https://github.com/cloudamqp/lavinmq/pull/2139)
- Management UI: a failed API request no longer resets form values or reloads the table; the error is shown and the form keeps its input [#2214](https://github.com/cloudamqp/lavinmq/pull/2214)
- Management UI: the vhost page no longer raises an error when the limits request fails on page load [#2225](https://github.com/cloudamqp/lavinmq/pull/2225)
- Management UI: table links overlapped other elements because of a stray `z-index` [#2135](https://github.com/cloudamqp/lavinmq/pull/2135)

### Changed

- CC and BCC headers are removed from dead-lettered messages when `x-dead-letter-routing-key` is set, instead of being preserved, matching RabbitMQ [#1993](https://github.com/cloudamqp/lavinmq/pull/1993)
- Deprecated config options are handled the same way for INI and CLI options, with a warning at startup [#2059](https://github.com/cloudamqp/lavinmq/pull/2059)
- MQTT sessions are decoupled from AMQP queues as part of separating protocol-specific queue/session handling [#1920](https://github.com/cloudamqp/lavinmq/pull/1920)
- Follower full sync logs progress as compared/total files [#2169](https://github.com/cloudamqp/lavinmq/pull/2169)
- Use mqtt-protocol 0.3.1 [#2157](https://github.com/cloudamqp/lavinmq/pull/2157)
- No RPM packages are built for Fedora 42, which is end of life [9d686861](https://github.com/cloudamqp/lavinmq/commit/9d686861)

## [2.9.2] - 2026-08-11

This patch release makes clustering full sync faster and more robust by pre-calculating and persisting follower checksums, fixes wrong checksums for files appended to mid-content, clears stale follower file handles before resync, and fixes an unacked message count underflow in the HTTP API. LavinMQ is now built with Crystal 1.21.

### Fixed

- Persist follower checksums incrementally during full sync, so an interrupted follower doesn't rehash all files on reconnect [#1834](https://github.com/cloudamqp/lavinmq/pull/1834)
- Pre-calculate follower checksums before connecting to the leader, shortening the time the leader's full-sync lock is held [#2164](https://github.com/cloudamqp/lavinmq/pull/2164)
- Reuse cached checksums in the capped full sync pass [#2165](https://github.com/cloudamqp/lavinmq/pull/2165)
- Fix wrong checksums for files appended to mid-content [#2167](https://github.com/cloudamqp/lavinmq/pull/2167)
- Clear stale clustering follower file handles before resync [#2161](https://github.com/cloudamqp/lavinmq/pull/2161)
- Stop the follower log fiber when streaming stops [#2166](https://github.com/cloudamqp/lavinmq/pull/2166)
- Don't double-decrement the unacked message count when an HTTP API basic get partially fails [#2168](https://github.com/cloudamqp/lavinmq/pull/2168)

### Changed

- Build with Crystal 1.21 [#2170](https://github.com/cloudamqp/lavinmq/pull/2170)
- Use amq-protocol 1.3.1 [#2154](https://github.com/cloudamqp/lavinmq/pull/2154)

## [2.9.1] - 2026-07-01

This patch release fixes OAuth2/OIDC management UI login for stricter identity providers, adds authorization checks to the shovel management endpoints, and resolves a stream consumer-offset overflow, clustered startup bind failures and several connection-handling issues.

### Fixed

- Management UI OAuth2 login now works with identity providers that require a specific scope (e.g. Entra ID), via the new `mgmt_scopes` config option [#2127](https://github.com/cloudamqp/lavinmq/pull/2127)
- Accept JWKS keys that omit the `alg` parameter when fetching keys for OAuth/OIDC [#2124](https://github.com/cloudamqp/lavinmq/pull/2124)
- Document that OAuth/OIDC JWTs must include a `kid` header matching a JWKS key [#2107](https://github.com/cloudamqp/lavinmq/pull/2107)
- Enforce policymaker role checks on the shovel management endpoints [#2133](https://github.com/cloudamqp/lavinmq/pull/2133)
- Apply SNI certificate changes on config reload [#2129](https://github.com/cloudamqp/lavinmq/pull/2129)
- Stream `cleanup_consumer_offsets` overflow when the `consumer_offsets` file is near full [#1995](https://github.com/cloudamqp/lavinmq/pull/1995)
- Clustered localhost listener bind failures during startup [#2114](https://github.com/cloudamqp/lavinmq/pull/2114)
- Heartbeat frames on non-zero channels now close the connection with `UNEXPECTED_FRAME` [#1999](https://github.com/cloudamqp/lavinmq/pull/1999)
- Normalize IPv4-mapped peer addresses in connection metadata, logs and API fields [#2122](https://github.com/cloudamqp/lavinmq/pull/2122)

## [2.9.0] - 2026-06-25

This release makes local publish confirms wait until messages are flushed to disk with `syncfs` (with a `--no-sync` opt-out), reworks clustered durability so confirms and durable definition changes are acknowledged only once every in-sync replica holds the data, and adds OAuth2/OIDC SSO login to the management UI. It also adds PROXY protocol trusted sources, `load_definitions`, per-queue-type policy `apply-to` targets and a configurable control socket, alongside a wide range of bugfixes and performance optimizations across the broker.

### Added

- OAuth2/OIDC SSO login to the management UI [#1768](https://github.com/cloudamqp/lavinmq/pull/1768)
- `proxy_protocol_trusted_sources` config option supporting individual IPs and CIDR notation [#1601](https://github.com/cloudamqp/lavinmq/pull/1601)
- Startup warning when PROXY protocol is enabled without `proxy_protocol_trusted_sources` configured [#1601](https://github.com/cloudamqp/lavinmq/pull/1601)
- `load_definitions` config option [#1828](https://github.com/cloudamqp/lavinmq/pull/1828)
- Per-queue-type policy `apply-to` targets (`classic_queues`, `quorum_queues`, `streams`) for RabbitMQ definitions compatibility [#2015](https://github.com/cloudamqp/lavinmq/pull/2015)
- Bindings count in overview, CLI status and Prometheus metrics [#2018](https://github.com/cloudamqp/lavinmq/pull/2018)
- Per-vhost message stats and labeled channel metrics in `/metrics/detailed` [#1926](https://github.com/cloudamqp/lavinmq/pull/1926)
- `--no-sync` option to disable syncfs on publish confirm [#1987](https://github.com/cloudamqp/lavinmq/pull/1987)
- `control_unix_path` config option to make the lavinmqctl control socket path configurable [#2029](https://github.com/cloudamqp/lavinmq/pull/2029)
- User tag classes to control management UI element visibility [#1892](https://github.com/cloudamqp/lavinmq/pull/1892)

### Changed

- A publish is confirmed once every in-sync follower has the data; local syncfs is only used as a fallback when there are no in-sync followers (or the node is standalone). When a follower disconnects mid-confirm, the confirm is held until the follower's removal from the etcd ISR is committed, so a leader crash right after the confirm can't elect a replica that lacks the data [#2002](https://github.com/cloudamqp/lavinmq/pull/2002)
- Durable definition changes (queue/exchange declares, deletes, bindings) are likewise acknowledged only once every in-sync follower has acked them - or a non-acking follower's removal from the etcd ISR is committed - so a leader crash right after a Declare-Ok can't elect a replica that lacks the acknowledged definition [#2002](https://github.com/cloudamqp/lavinmq/pull/2002)
- Followers ack replicated data incrementally as it's written, so a single large action (big message or file sync) keeps a healthy follower in the replica set instead of being evicted on the leader's ack deadline [#2002](https://github.com/cloudamqp/lavinmq/pull/2002)
- Send publish confirms only after messages are flushed to disk with `syncfs` [#1891](https://github.com/cloudamqp/lavinmq/pull/1891)
- Eliminate heap allocations in the message publish/deliver hot path [#2045](https://github.com/cloudamqp/lavinmq/pull/2045)
- Zero-allocation MQTT subscription-tree matching [#2090](https://github.com/cloudamqp/lavinmq/pull/2090)
- Use Crystal's native kTLS support [#1937](https://github.com/cloudamqp/lavinmq/pull/1937)
- Fiber-free synchronous replication [a011ec99](https://github.com/cloudamqp/lavinmq/commit/a011ec993089408d23c3b76e0cb008e2cda4b39a)
- On-demand deliver_loop fibers for AMQP consumers [#1722](https://github.com/cloudamqp/lavinmq/pull/1722)
- Idle fiber management for queue message expiration [#1614](https://github.com/cloudamqp/lavinmq/pull/1614)
- Replace periodic GC.collect with on-demand GC [#2016](https://github.com/cloudamqp/lavinmq/pull/2016)
- Batch persistence during definitions import [#2014](https://github.com/cloudamqp/lavinmq/pull/2014)
- `tcp_proxy_protocol` now accepts boolean values (`true`/`false`/`yes`/`no`); legacy `1`/`2` are treated as enabled, `0` disables. Protocol version is auto-detected [#1601](https://github.com/cloudamqp/lavinmq/pull/1601)

### Deprecated

- `clustering_max_unsynced_actions` is now a no-op (still accepted to avoid breaking existing configs); the follower ack buffer is a fixed size and how far a follower may lag is governed by the leader's ack deadline [#2002](https://github.com/cloudamqp/lavinmq/pull/2002)

### Removed

- `unix_proxy_protocol` config option; Unix sockets always auto-detect PROXY protocol headers [#1601](https://github.com/cloudamqp/lavinmq/pull/1601)

### Fixed

- Print clean error messages on boot failures instead of stacktraces [aba7361b](https://github.com/cloudamqp/lavinmq/commit/aba7361b8a434f1ab2776ec0fbb393c73e94861d)
- Group `lavinmqctl` help output by command category [#1830](https://github.com/cloudamqp/lavinmq/pull/1830)
- Use `amq.default` in UI related operations [#1913](https://github.com/cloudamqp/lavinmq/pull/1913)
- New action bar for tables with row counter and column selector [#1900](https://github.com/cloudamqp/lavinmq/pull/1900)
- Bake static assets as string literals to reduce compile memory [#1944](https://github.com/cloudamqp/lavinmq/pull/1944)
- Bump amq-protocol to 1.2.0 [#1996](https://github.com/cloudamqp/lavinmq/pull/1996)
- Update amqp-client to 1.3.3, lz4 and systemd 3.0.1 dependencies [cd2f4c58](https://github.com/cloudamqp/lavinmq/commit/cd2f4c586dd55aae15d6223181c178a8e1025e71)
- `GET /api/queues/:vhost/:name` no longer emits the `message_stats` field twice [#2031](https://github.com/cloudamqp/lavinmq/pull/2031)
- `GET /api/channels` and `GET /api/connections` no longer include the per-metric rate-history `log` arrays in every list row, matching `GET /api/queues`. The logs are only needed by the per-object detail pages, so they are now returned solely by `GET /api/channels/:name` and `GET /api/connections/:name`, greatly reducing list response size and latency on large deployments [#2025](https://github.com/cloudamqp/lavinmq/pull/2025)
- Discard settlement frames (`ack`/`nack`/`reject`) for an already-closed channel instead of closing the connection with `CHANNEL_ERROR` [f421d6e3](https://github.com/cloudamqp/lavinmq/commit/f421d6e3e8359a686453b45a33b423b5ea129a32)
- Treat a publish to a concurrently-closed queue as dropped instead of raising, which previously surfaced as an HTTP publish `500` [93f88429](https://github.com/cloudamqp/lavinmq/commit/93f88429be1d9b3692d2d945c14964f0622a0db9)
- Stop federation and shovel links before tearing down vhosts on shutdown, and keep the embedded amqp-client's routine connection-teardown logging (already reported via the `lmq.*` federation/shovel layers) out of the broker log [2b213d3c](https://github.com/cloudamqp/lavinmq/commit/2b213d3cbce52a1782dcec6143cc41e55cd816d3)
- Reply with `Basic.GetEmpty` instead of erroring when a `basic_get` races a concurrent queue delete [9fbf4dc4](https://github.com/cloudamqp/lavinmq/commit/9fbf4dc472e76bcf773e637d35d49f02906ae15f)
- Serialize store saves (vhosts, parameters, users) so concurrent create/delete (under churn) don't race on the shared `.tmp` file and fail the rename [f2316d0d](https://github.com/cloudamqp/lavinmq/commit/f2316d0d947d5ef8261153a991c20d1b26a04b3a)
- Don't crash the MQTT brokers on a vhost `Closed` event for a vhost that was never registered (e.g. one whose create didn't finish) [fcf592c4](https://github.com/cloudamqp/lavinmq/commit/fcf592c44614d23f0823d72d6c553e62da557550)
- Serialize per-resource policy application and run stream `drop_overflow` under the message-store lock, fixing a segfault when policies were applied to a queue concurrently (e.g. under policy churn) with publishing/consuming [7f4b8399](https://github.com/cloudamqp/lavinmq/commit/7f4b8399e1890e85a2404575397e2bb9831c3db2)
- Race between stream queue delete and `drop_overflow` [#1939](https://github.com/cloudamqp/lavinmq/pull/1939)
- Stream queue crash when delivery-limit policy is applied [d3667f99](https://github.com/cloudamqp/lavinmq/commit/d3667f995b2cb6deb2a4f03909111765f5dd93bf)
- Handle empty trailing stream segment on load [4efe79c4](https://github.com/cloudamqp/lavinmq/commit/4efe79c4e4031a0352e69a8c71d9246e988966bd)
- Serialize stream consumer-offset access under the message-store lock for MT safety [#1973](https://github.com/cloudamqp/lavinmq/pull/1973)
- Skip `delete_message` after queue close [#1961](https://github.com/cloudamqp/lavinmq/pull/1961)
- `MessageStore` size leaks in `purge_all` and requeued `shift?` [#1957](https://github.com/cloudamqp/lavinmq/pull/1957)
- Handle reject-publish overflow in HTTP publish and multi-queue routes [#1958](https://github.com/cloudamqp/lavinmq/pull/1958)
- Keep closing AMQP channels until close-ok [#1980](https://github.com/cloudamqp/lavinmq/pull/1980)
- MQTT max inflight message flow control [#1935](https://github.com/cloudamqp/lavinmq/pull/1935)
- Exit if etcd lease expires while waiting to be in sync [#1969](https://github.com/cloudamqp/lavinmq/pull/1969)
- Wait lease TTL + 2 seconds before retrying etcd lease grant [57d898cd](https://github.com/cloudamqp/lavinmq/commit/57d898cd2802f3b05f16aa71bc19c87d4f75280b)
- Delete empty queue directories on followers during streaming [#2005](https://github.com/cloudamqp/lavinmq/pull/2005)
- Broker start failure for passwordless users with `null` hashing_algorithm [#1898](https://github.com/cloudamqp/lavinmq/pull/1898)
- Anchor server uptime and CPU counters to OS process lifetime [#2012](https://github.com/cloudamqp/lavinmq/pull/2012)
- Use `:vhost` named parameter for `DELETE` vhost-limits route [#1994](https://github.com/cloudamqp/lavinmq/pull/1994)
- OpenAPI docs fixes [#2004](https://github.com/cloudamqp/lavinmq/pull/2004)
- Log `kTLS=off` instead of `kTLS=` when offload is inactive [#2019](https://github.com/cloudamqp/lavinmq/pull/2019)
- MQTT packet ID overflow in lavinmqperf [#1997](https://github.com/cloudamqp/lavinmq/pull/1997)
- `-q` flag collision between QoS and quiet in mqttperf [#1951](https://github.com/cloudamqp/lavinmq/pull/1951)
- Smooth pacing in lavinmqperf AMQP throughput [85711b32](https://github.com/cloudamqp/lavinmq/commit/85711b3290335c367908b0896c4e200bf1ba71f4)
- Federation upstream-set deletion and per-entry overrides [#2089](https://github.com/cloudamqp/lavinmq/pull/2089)
- Lost exchange-federation bindings created during link startup [#2037](https://github.com/cloudamqp/lavinmq/pull/2037)
- Federation exchange link leaking a dead observer when the upstream is deleted during startup [#2105](https://github.com/cloudamqp/lavinmq/pull/2105)
- Remove a dead follower inline in `each_follower` to stop "Follower disconnected" log spam [#2103](https://github.com/cloudamqp/lavinmq/pull/2103)
- Use `f_frsize` for disk size reporting on Linux, fixing inflated `disk_total`/`disk_free` on virtiofs and NFS [#2055](https://github.com/cloudamqp/lavinmq/pull/2055)
- Sub-second `stats_interval` produced `NaN`/`Inf` rates that broke stats-endpoint JSON [#2024](https://github.com/cloudamqp/lavinmq/pull/2024)
- Guard against an empty destination in the Move messages UI [#2042](https://github.com/cloudamqp/lavinmq/pull/2042)
- Skip config parsing for exact `--version`/build-info requests so a deprecated config file no longer warns on version output [#2115](https://github.com/cloudamqp/lavinmq/pull/2115)

## [2.9.0-rc.2] - 2026-06-22

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.9.0-rc.2> for changes in this pre-release

## [2.9.0-rc.1] - 2026-06-11

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.9.0-rc.1> for changes in this pre-release

## [2.8.1] - 2026-05-18

### Changed

- Build deb packages for Ubuntu 26.04, RPM for Fedora 44, drop support for Fedora 41 [#1934](https://github.com/cloudamqp/lavinmq/pull/1934)

### Fixed

- Clear consumer flags on queue close to unblock restart [#1904](https://github.com/cloudamqp/lavinmq/pull/1904)
- Advance `@rfile` in `delete_unused_segments` to prevent `Closed mfile` crash [#1910](https://github.com/cloudamqp/lavinmq/pull/1910)
- Missing vhost-limits OpenAPI schema [#1915](https://github.com/cloudamqp/lavinmq/pull/1915)
- Slow shutdown with many autodelete queues [#1922](https://github.com/cloudamqp/lavinmq/pull/1922)
- Install libssl-dev for Ubuntu 26.04 builds [#1936](https://github.com/cloudamqp/lavinmq/pull/1936)
- Double message read in `reject(requeue=true)` [#1921](https://github.com/cloudamqp/lavinmq/pull/1921)

## [2.7.3] - 2026-05-08

### Fixed

- Advance `@rfile` in `delete_unused_segments` to prevent `Closed mfile` crash [#1910](https://github.com/cloudamqp/lavinmq/pull/1910)
- Clear consumer flags on queue close to unblock restart [#1904](https://github.com/cloudamqp/lavinmq/pull/1904)

## [2.8.0] - 2026-05-06

This release adds Prometheus metrics for mfiles, vhost-level data rate aggregation across all protocols, a RateLimiter with reduced clustering sync log verbosity, sorting on bindings tables, and several management UI improvements. It also fixes a 404 on `/metrics/detailed` for follower nodes and prevents queue closure caused by orphaned ack positions after unclean shutdown.

### Added

- RateLimiter and reduced clustering sync log verbosity [#1807](https://github.com/cloudamqp/lavinmq/pull/1807)
- Prometheus metrics for mfiles [#1627](https://github.com/cloudamqp/lavinmq/pull/1627)
- Aggregate data rates at vhost level for all protocols [#1699](https://github.com/cloudamqp/lavinmq/pull/1699)
- Sorting on bindings tables [#1823](https://github.com/cloudamqp/lavinmq/pull/1823)
- Log "Deleting vhost" message when vhost deletion starts [#1886](https://github.com/cloudamqp/lavinmq/pull/1886)

### Changed

- Use policymaker role consistently for global-parameters endpoints [#1695](https://github.com/cloudamqp/lavinmq/pull/1695)
- Store baked static assets in read-only memory [#1742](https://github.com/cloudamqp/lavinmq/pull/1742)
- Align exchange type error message with RabbitMQ [#1811](https://github.com/cloudamqp/lavinmq/pull/1811)
- Optimize all SVG assets using SVGO [#1769](https://github.com/cloudamqp/lavinmq/pull/1769)
- Refactor menu to not need the active class (no JavaScript) [#1709](https://github.com/cloudamqp/lavinmq/pull/1709)
- Show only `I` as feature for internal queue [#1857](https://github.com/cloudamqp/lavinmq/pull/1857)
- Styling updates for tables [#1848](https://github.com/cloudamqp/lavinmq/pull/1848)
- Use `segment_position.bytesize` in consumer deliver loop [#1786](https://github.com/cloudamqp/lavinmq/pull/1786)
- Remove no longer needed media queries [#1873](https://github.com/cloudamqp/lavinmq/pull/1873)

### Fixed

- Prune orphaned ack positions on startup to prevent queue closure after unclean shutdown [#1866](https://github.com/cloudamqp/lavinmq/pull/1866)
- Deprecated `--guest-only-loopback` flag silently ignored [#1824](https://github.com/cloudamqp/lavinmq/pull/1824)
- CSP hash for login page inline theme script [#1876](https://github.com/cloudamqp/lavinmq/pull/1876)
- 404 on `/metrics/detailed` for follower nodes [#1859](https://github.com/cloudamqp/lavinmq/pull/1859)
- Sorting by columns with nil values [#1840](https://github.com/cloudamqp/lavinmq/pull/1840)

## [2.8.0-rc.1] - 2026-04-29

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.8.0-rc.1> for changes in this pre-release

## [2.7.2] - 2026-04-28

### Fixed

- Exclusive queue references leak on auto-delete [#1887](https://github.com/cloudamqp/lavinmq/pull/1887)

## [2.8.0-beta.1] - 2026-04-24

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.8.0-beta.1> for changes in this pre-release

## [2.7.1] - 2026-04-24

### Fixed

- User permission check to source and destinations vhosts when creating shovels [#1867](https://github.com/cloudamqp/lavinmq/pull/1867)
- Replicate the .queue file [#1869](https://github.com/cloudamqp/lavinmq/pull/1869)
- Clean up empty dirs on follower after full sync [#1870](https://github.com/cloudamqp/lavinmq/pull/1870)
- Recognize IPv4-mapped IPv6 loopback addresses. Fixes default user loopback check. [#1871](https://github.com/cloudamqp/lavinmq/pull/1871)

## [2.7.0] - 2026-04-16

This release introduces OAuth2/OIDC authentication, kernel TLS offloading, a rewritten configuration system, Jump consistent hash exchange algorithm, and the ability to restart closed queues. It also brings enhanced TLS capabilities including SNI and mTLS support, improved stream performance, improved clustering and federation management, and many bug fixes.

### Added

- OAuth2/OpenID Connect authentication support with JWT token validation (RS256), JWKS, scope-to-permission mapping, and token refresh via UpdateSecret [#1632](https://github.com/cloudamqp/lavinmq/pull/1632)
- Jump consistent hash algorithm for Consistent Hash Exchange [#1604](https://github.com/cloudamqp/lavinmq/pull/1604)
- kTLS (kernel TLS) support for OpenSSL servers, offloading TLS encryption to the kernel for improved performance [61bdb124](https://github.com/cloudamqp/lavinmq/commit/61bdb124)
- Restart closed queues via API/UI/lavinmqctl [#1345](https://github.com/cloudamqp/lavinmq/pull/1345)
- TLS keylog file (SSLKEYLOGFILE) support [#1531](https://github.com/cloudamqp/lavinmq/pull/1531)
- TLS SNI and mTLS support [#1516](https://github.com/cloudamqp/lavinmq/pull/1516)
- Shell command hooks for cluster leader transitions [#1491](https://github.com/cloudamqp/lavinmq/pull/1491)
- Cache checksums on followers for faster failover [#1554](https://github.com/cloudamqp/lavinmq/pull/1554)
- `--pidfile` CLI option [#1570](https://github.com/cloudamqp/lavinmq/pull/1570)
- Connection duration logged on disconnect [#1662](https://github.com/cloudamqp/lavinmq/pull/1662)
- Collapsible sidebar menu in the management UI [#1553](https://github.com/cloudamqp/lavinmq/pull/1553)
- Support for mqtts in `lavinmqperf` [#1702](https://github.com/cloudamqp/lavinmq/pull/1702)

### Changed

- Configuration system rewritten with annotations and macros; clear precedence: CLI args > environment variables > INI file [#917](https://github.com/cloudamqp/lavinmq/pull/917)
- Deprecated duplicate INI options in section-specific locations; these now forward to `[main]` with a deprecation warning [#1636](https://github.com/cloudamqp/lavinmq/pull/1636)
- HTTP API permissions aligned with RabbitMQ: admin access required for definitions endpoints [#1687](https://github.com/cloudamqp/lavinmq/pull/1687)
- Prometheus metrics grouped per metric with `# TYPE` and `# HELP` annotations [#1598](https://github.com/cloudamqp/lavinmq/pull/1598)
- Server-side authentication validation for management UI views [#1641](https://github.com/cloudamqp/lavinmq/pull/1641)
- Vhost selection disabled in vhost-specific management UI views [#1575](https://github.com/cloudamqp/lavinmq/pull/1575)
- Convert queued message graph to stacked line graph [#1565](https://github.com/cloudamqp/lavinmq/pull/1565)
- Stream: Store offset only for first message per segment [#1479](https://github.com/cloudamqp/lavinmq/pull/1479)
- Use parallel execution context for clustering followers [#1544](https://github.com/cloudamqp/lavinmq/pull/1544)
- Graceful shutdown for StandaloneRunner [#1577](https://github.com/cloudamqp/lavinmq/pull/1577)
- MQTT performance improved by flushing socket per packet instead of per write [#1651](https://github.com/cloudamqp/lavinmq/pull/1651)
- Crystal 1.19 compatibility [#1620](https://github.com/cloudamqp/lavinmq/pull/1620)
- `lavinmqctl --help` touchups [#1755](https://github.com/cloudamqp/lavinmq/pull/1755)

### Fixed

- Dead letter cycle detection [#1723](https://github.com/cloudamqp/lavinmq/pull/1723)
- MQTT subscribe permission check logic [#1836](https://github.com/cloudamqp/lavinmq/pull/1836)
- MQTT sessions no longer deleted or cleared if a new client has already taken over the session [#1665](https://github.com/cloudamqp/lavinmq/pull/1665)
- Honor `yield_each_delivered_bytes` setting for MQTT [#1783](https://github.com/cloudamqp/lavinmq/pull/1783)
- Replicate files in closed message stores [#1794](https://github.com/cloudamqp/lavinmq/pull/1794)
- Replication shouldn't break if mfiles are closed [#1792](https://github.com/cloudamqp/lavinmq/pull/1792)
- Only allow one follower to do bulk sync at a time [#1720](https://github.com/cloudamqp/lavinmq/pull/1720), [#1780](https://github.com/cloudamqp/lavinmq/pull/1780)
- Add `Sync::Shared` lock for `@files` and `@checksums` in `Clustering::Server` [#1753](https://github.com/cloudamqp/lavinmq/pull/1753)
- Don't delete metadata files during full sync [#1814](https://github.com/cloudamqp/lavinmq/pull/1814)
- Persist `segment_last_ts` to prevent message loss on restart in streams with max-age [#1760](https://github.com/cloudamqp/lavinmq/pull/1760)
- Reset position when crossing segment boundary in `find_offset_in_segments` [#1772](https://github.com/cloudamqp/lavinmq/pull/1772)
- Gracefully close message store on corrupt segments [#1710](https://github.com/cloudamqp/lavinmq/pull/1710)
- Don't expire messages before server is fully started [#1714](https://github.com/cloudamqp/lavinmq/pull/1714)
- Delayed message store crash on corrupt segment data [#1694](https://github.com/cloudamqp/lavinmq/pull/1694)
- Missing `x-stream-offset` header in StreamReader responses [#1774](https://github.com/cloudamqp/lavinmq/pull/1774)
- Return frame error for corrupt frames with invalid frame end [#1813](https://github.com/cloudamqp/lavinmq/pull/1813)
- Allow any timestamp in AMQP messages [#1705](https://github.com/cloudamqp/lavinmq/pull/1705)
- Return 400 for invalid binding routing key [#1734](https://github.com/cloudamqp/lavinmq/pull/1734)
- Use `openssl dgst` instead of `sha256sum` in Makefile for macOS portability [#1818](https://github.com/cloudamqp/lavinmq/pull/1818)
- Consumer starvation in lavinmqperf throughput mode [#1712](https://github.com/cloudamqp/lavinmq/pull/1712)
- Print usage on unexpected arguments in lavinmqperf [#1796](https://github.com/cloudamqp/lavinmq/pull/1796)
- Prefetch button icons in CSS [#1556](https://github.com/cloudamqp/lavinmq/pull/1556)
- UI: Chart color consistency [#1756](https://github.com/cloudamqp/lavinmq/pull/1756)
- UI: Tooltip sizing [#1700](https://github.com/cloudamqp/lavinmq/pull/1700)
- UI: Tooltip z-index to appear above menus [#1729](https://github.com/cloudamqp/lavinmq/pull/1729)
- UI: Collapse whitespace in client capabilities display [#1733](https://github.com/cloudamqp/lavinmq/pull/1733)
- UI: Empty cells in connection details for consistent rendering [#1732](https://github.com/cloudamqp/lavinmq/pull/1732)
- UI: Rename "Routing key" to "Binding key" in binding view [#1748](https://github.com/cloudamqp/lavinmq/pull/1748)
- UI: Overlapping sources in logs [#1790](https://github.com/cloudamqp/lavinmq/pull/1790)
- UI: Invalid JSON warning on empty binding arguments [#1749](https://github.com/cloudamqp/lavinmq/pull/1749)

## [2.6.11] - 2026-04-15

### Fixed

- Return frame error for corrupt frames with invalid frame end [#1813](https://github.com/cloudamqp/lavinmq/pull/1813)
- Fix MQTT subscribe permission check logic [#1836](https://github.com/cloudamqp/lavinmq/pull/1836)

## [2.7.0-rc.3] - 2026-04-14

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.7.0-rc.3> for changes in this pre-release

## [2.7.0-rc.2] - 2026-03-24

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.7.0-rc.2> for changes in this pre-release

## [2.6.10] - 2026-03-09

### Fixed

- Only allow one follower to do bulk sync at a time [#1720](https://github.com/cloudamqp/lavinmq/pull/1720), [#1780](https://github.com/cloudamqp/lavinmq/pull/1780)
- Replication shouldn't break if mfiles are closed [#1792](https://github.com/cloudamqp/lavinmq/pull/1792)
- Replicate files in closed message stores [#1794](https://github.com/cloudamqp/lavinmq/pull/1794)

## [2.6.9] - 2026-03-03

### Fixed

- Persist `segment_last_ts` to prevent message loss on restart with max-age [#1760](https://github.com/cloudamqp/lavinmq/pull/1760)
- Don't expire messages before server is fully started [#1714](https://github.com/cloudamqp/lavinmq/pull/1714)
- Return 400 for invalid binding routing key [#1734](https://github.com/cloudamqp/lavinmq/pull/1734)
- Fix invalid JSON warning on empty binding arguments [#1749](https://github.com/cloudamqp/lavinmq/pull/1749)
- Dead letter cycle detection [#1723](https://github.com/cloudamqp/lavinmq/pull/1723)
- Prevent consumer starvation in lavinmqperf throughput [#1712](https://github.com/cloudamqp/lavinmq/pull/1712)
- Gracefully close message store on corrupt segments [#1710](https://github.com/cloudamqp/lavinmq/pull/1710)
- Allow any timestamp in AMQP messages [#1705](https://github.com/cloudamqp/lavinmq/pull/1705)
- Fix delayed message store crash on corrupt segment data [#1694](https://github.com/cloudamqp/lavinmq/pull/1694)
- Don't delete/clear MQTT session if new client exists [#1665](https://github.com/cloudamqp/lavinmq/pull/1665)

## [2.7.0-rc.1] - 2026-02-11

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.7.0-rc.1> for changes in this pre-release

## [2.6.8] - 2026-02-10

### Fixed

- Align definitions API permisssion with RabbitMQ [#1686](https://github.com/cloudamqp/lavinmq/pull/1686)

## [2.6.7] - 2026-02-06

### Fixed

- Fixed version numbering

## [2.6.6] - 2026-02-06

### Fixed

- Better validation of shovel config [#1670](https://github.com/cloudamqp/lavinmq/pull/1670)
- Refactor vhost access control in HTTP API [#1669](https://github.com/cloudamqp/lavinmq/pull/1669)

## [2.6.5] - 2026-01-28

### Fixed

- Add Sec-WebSockets-Protocol to websocket responses [#1621](https://github.com/cloudamqp/lavinmq/pull/1621), [#1637](https://github.com/cloudamqp/lavinmq/pull/1637)
- Resume expiration after consuming non-expiring msg [#1606](https://github.com/cloudamqp/lavinmq/pull/1606), [#1649](https://github.com/cloudamqp/lavinmq/pull/1649)

## [2.6.4] - 2026-01-23

### Fixed

- Apply stream max-length and max-length-bytes from policy [#1631](https://github.com/cloudamqp/lavinmq/pull/1631)

## [2.6.3] - 2026-01-16

### Fixed

- Fixed a bug in delayed exchange index build [#1619](https://github.com/cloudamqp/lavinmq/pull/1619)

## [2.6.2] - 2026-01-15

### Added

- Add shovel and federation management commands to lavinmqctl [#1277](https://github.com/cloudamqp/lavinmq/pull/1277)

### Changed

- BoolChannel: Don't spawn fiber [#1603](https://github.com/cloudamqp/lavinmq/pull/1603)
- Reduce etcd lease keepalive renewal interval to 1/3rd of TTL [#1573](https://github.com/cloudamqp/lavinmq/pull/1573)

### Fixed

- delay exchange message ordering [#1600](https://github.com/cloudamqp/lavinmq/pull/1600)
- Removing too many bindings in Consistent hash exchange on unbind [#1594](https://github.com/cloudamqp/lavinmq/pull/1594)
- Federation refactor/improvements [#1492](https://github.com/cloudamqp/lavinmq/pull/1492)
- Bugfix and refactor dead lettering [#1552](https://github.com/cloudamqp/lavinmq/pull/1552)
- BCC remove on delivery [#1557](https://github.com/cloudamqp/lavinmq/pull/1557)
- Topic exchange # wildcard now matches zero segments [#1608](https://github.com/cloudamqp/lavinmq/pull/1608)

## [2.7.0-alpha.1] - 2025-12-07

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.7.0-alpha.1> for changes in this pre-release

## [2.6.1] - 2025-12-07

### Fixed

- lavinmqperf - correctly summarize throughput numbers [#1536](https://github.com/cloudamqp/lavinmq/pull/1536)

## [2.6.0] - 2025-12-05

This release introduces Geographic Information System (GIS) filtering for streams, enhanced performance testing capabilities, as well as many other improvements and bugfixes.

### Added

- GIS filtering for streams [#1397](https://github.com/cloudamqp/lavinmq/pull/1397)
- SystemD memory pressure monitoring support [#1484](https://github.com/cloudamqp/lavinmq/pull/1484)
- Latency measurement support in `lavinmqperf amqp throughput --measure-latency` [#1474](https://github.com/cloudamqp/lavinmq/pull/1474)
- Queue pattern support in `lavinmqperf amqp throughput` [#1471](https://github.com/cloudamqp/lavinmq/pull/1471)
- ASCII art logo on boot [#1482](https://github.com/cloudamqp/lavinmq/pull/1482)
- UI improvements [#1470](https://github.com/cloudamqp/lavinmq/pull/1470), [#1454](https://github.com/cloudamqp/lavinmq/pull/1454), [#1463](https://github.com/cloudamqp/lavinmq/pull/1463)

### Changed

- Better default config - Enable amqps/mqtts/https by default if tls_cert/key is supplied [#1487](https://github.com/cloudamqp/lavinmq/pull/1487)
- New name format for queues for delayed messages: `amq.delayed-<exchange name>` [#1461](https://github.com/cloudamqp/lavinmq/pull/1461)

### Fixed

- Regression in authorization for /metrics [#1521](https://github.com/cloudamqp/lavinmq/pull/1521)
- Handle updated permissions while users are connected [#1526](https://github.com/cloudamqp/lavinmq/pull/1526)
- Race condition when closing auto-delete queues [#1529](https://github.com/cloudamqp/lavinmq/pull/1529)
- Handle "lease not found" etcd error without infinite retry [#1519](https://github.com/cloudamqp/lavinmq/pull/1519)
- OpenAPI schema for bcrypt hashing_algorithm name [#1498](https://github.com/cloudamqp/lavinmq/pull/1498)
- Overridden effective arguments not marked as active in UI [#1489](https://github.com/cloudamqp/lavinmq/pull/1489)
- Vhosts with exchange to exchange bindings generated in v2.4.x could not be start [#1495](https://github.com/cloudamqp/lavinmq/pull/1495)
- Sensible error message if trying to import definitions via the HTTP API with an invalid password_has field for users [#1496](https://github.com/cloudamqp/lavinmq/pull/1496)

### Removed

- Don't save backups when failing over to new leader [#1508](https://github.com/cloudamqp/lavinmq/pull/1508)

## [2.6.0-rc.4] - 2025-12-02

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.6.0-rc.4> for changes in this pre-release

## [2.6.0-rc.3] - 2025-12-01

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.6.0-rc.3> for changes in this pre-release

## [2.5.5] - 2025-11-26

### Fixed

- Don't raise when truncating deleted MFile [#1500](https://github.com/cloudamqp/lavinmq/pull/1500)
- Abort on IO::Error in delivery_loop [#f87491ec29bc0cf31b9fe5db4d3f2d3d8cce85c6](https://github.com/cloudamqp/lavinmq/commit/f87491ec29bc0cf31b9fe5db4d3f2d3d8cce85c6)

## [2.6.0-rc.2] - 2025-11-22

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.6.0-rc.2> for changes in this pre-release

## [2.5.4] - 2025-11-22

### Fixed

- Vhosts with exchange to exchange bindings generated in v2.4.x could not be start [#1495](https://github.com/cloudamqp/lavinmq/pull/1495)

## [2.6.0-rc.1] - 2025-11-19

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.6.0-rc.1> for changes in this pre-release

## [2.5.3] - 2025-11-19

### Fixed

- Improved packet size accounting in MQTT [#1477](https://github.com/cloudamqp/lavinmq/pull/1477)
- Improved frame size accounting in AMQP [#1485](https://github.com/cloudamqp/lavinmq/pull/1485)
- Replicate `limits.json` [#1466](https://github.com/cloudamqp/lavinmq/pull/1466)

## [2.5.2] - 2025-11-12

### Fixed

- Prevent MFile leakage in clustering when follower disconnects [#1450](https://github.com/cloudamqp/lavinmq/pull/1450)
- Don't keep FDs open for MFiles [#1428](https://github.com/cloudamqp/lavinmq/pull/1428)
- Signal empty after purge all in Priority queue message store [#1442](https://github.com/cloudamqp/lavinmq/pull/1442)
- Only render exchange info once [#1447](https://github.com/cloudamqp/lavinmq/pull/1447)
- Add tooltips to exchange features [#1448](https://github.com/cloudamqp/lavinmq/pull/1448)
- Remove NoopServer from Clustering::Server [#1457](https://github.com/cloudamqp/lavinmq/pull/1457)
- GUI: Navigate between exchanges [#1454](https://github.com/cloudamqp/lavinmq/pull/1454)

## [2.5.1] - 2025-11-05

### Fixed

- Boolean queue arguments validated as invalid if set to false [#1429](https://github.com/cloudamqp/lavinmq/pull/1429)
- Use the correct path for meta files in streams [#1438](https://github.com/cloudamqp/lavinmq/pull/1438)
- Remove meta files when segments are removed in streams [#1435](https://github.com/cloudamqp/lavinmq/pull/1435)
- Consumers would get stuck trying to consume from priority queues [#1440](https://github.com/cloudamqp/lavinmq/pull/1440)

## [2.5.0] - 2025-11-04

This release brings significant improvements across multiple areas of LavinMQ. Key focus areas include major clustering and replication enhancements for better reliability and performance, a new light mode UI theme alongside numerous user interface improvements, substantial performance optimizations including faster boot times and improved memory management, and enhanced tooling with expanded MQTT support. The release also includes important bug fixes.

### Added

- MQTT client now uses permissions to authorize write operations on publish and read/write operations on subscribe [#1275](https://github.com/cloudamqp/lavinmq/pull/1275)
- Human friendly exchange type names in controller and exchanges.js [#1238](https://github.com/cloudamqp/lavinmq/pull/1238)
- Icons added to sidebar navigation and divided sidebar into groups [#1268](https://github.com/cloudamqp/lavinmq/pull/1268)
- Table filter: search as you type functionality [#1274](https://github.com/cloudamqp/lavinmq/pull/1274)
- Read messages from stream [#1236](https://github.com/cloudamqp/lavinmq/pull/1236)
- Support Basic Auth and HTTPS for etcd endpoints [#1212](https://github.com/cloudamqp/lavinmq/pull/1212)
- Add checksum verification for JavaScript dependencies [#1257](https://github.com/cloudamqp/lavinmq/pull/1257)
- Boot time is greatly improved by storing the message count in a file alongside the message segment [#1163](https://github.com/cloudamqp/lavinmq/pull/1163)
- Way faster initial replication follower synchronization by caching file checksums [#1088](https://github.com/cloudamqp/lavinmq/pull/1088)
- Added Light mode for the UI [46b00e4c](https://github.com/cloudamqp/lavinmq/commit/46b00e4c)
- Shovels can now be paused and resumed [#1103](https://github.com/cloudamqp/lavinmq/pull/1103) & [#1151](https://github.com/cloudamqp/lavinmq/pull/1151)
- Ability to limit the number of consumers per channel [#1106](https://github.com/cloudamqp/lavinmq/pull/1106)
- `lavinmqperf` now supports MQTT [#983](https://github.com/cloudamqp/lavinmq/pull/983)
- `lavinmqperf` All clients are now waited for to be connected before publishing/consuming [#1120](https://github.com/cloudamqp/lavinmq/pull/1120)
- The `/api/queues` endpoint now exposes `messages_ready` and `messages_unacknowledged` [#1121](https://github.com/cloudamqp/lavinmq/pull/1121)
- Alpine Linux compatibility and a corresponding Dockerfile (packaging/alpine/Dockerfile) [#1115](https://github.com/cloudamqp/lavinmq/pull/1115)
- The container image now includes an SBOM and provenance information [#54a3cc21](https://github.com/cloudamqp/lavinmq/commit/54a3cc21)
- Support for MQTT 3.1.0 clients
- Added --durable, --arguments and --no-wait parameters to `lavinmqperf queue-count` [#6b8b8c91](https://github.com/cloudamqp/lavinmq/commit/6b8b8c91)
- Persist shovel pause state across broker restarts [#1151](https://github.com/cloudamqp/lavinmq/pull/1151)

### Changed

- Crystal 1.18.0 compatibility [#1356](https://github.com/cloudamqp/lavinmq/pull/1356), [#1360](https://github.com/cloudamqp/lavinmq/pull/1360)
- Sticky header on logs page [#1333](https://github.com/cloudamqp/lavinmq/pull/1333)
- Less scary logging if cleaning up upstream resources fails [#1379](https://github.com/cloudamqp/lavinmq/pull/1379)
- Use paused instead of .paused as filename for paused queues [#1209](https://github.com/cloudamqp/lavinmq/pull/1209)
- Use eventListener consistently across JS [#1220](https://github.com/cloudamqp/lavinmq/pull/1220)
- Prometheus metrics can nowbe served on a different port to allow unauthenticated requests for metrics [#1217](https://github.com/cloudamqp/lavinmq/pull/1217)
- Followers no longer forward requests to the unauthenticated `/metrics` to leader and instead show their own metrics [#1217](https://github.com/cloudamqp/lavinmq/pull/1217)
- Rename message segment meta files to `meta.SEGMENT` [#1343](https://github.com/cloudamqp/lavinmq/pull/1343)
- Switch from slash to chevron right in title bar breadcrumbs [#1334](https://github.com/cloudamqp/lavinmq/pull/1334)
- Priority message store refactored to use one message store per priority, big performance/memory gain [#1156](https://github.com/cloudamqp/lavinmq/pull/1156)
- Refactored clustering and replication to improve reliability and performance [#1164](https://github.com/cloudamqp/lavinmq/pull/1164)
- Improved consumer fairness and performance for AMQP [#1173](https://github.com/cloudamqp/lavinmq/pull/1173)
- Socket write buffer is now flushed only when required, big performance gain [#29ab3436](https://github.com/cloudamqp/lavinmq/commit/29ab3436)
- `MFile`s are no longer included in coredumps [#1128](https://github.com/cloudamqp/lavinmq/pull/1128)
- Federation now respects `max-hops` [#1130](https://github.com/cloudamqp/lavinmq/pull/1130)
- UI: The user form in the UI now has a password visibility toggle and a password generation button [#1150](https://github.com/cloudamqp/lavinmq/pull/1150)
- Prometheus CPU system/user time metrics are now ever-increasing counters [#0509b547](https://github.com/cloudamqp/lavinmq/commit/0509b547)
- Channel mode display improved to be more descriptive [#1188](https://github.com/cloudamqp/lavinmq/pull/1188)
- Crystal 1.17.0 is now required [#4b0fa247](https://github.com/cloudamqp/lavinmq/commit/4b0fa247)
- Improved queue and exchange features display with tooltips and styling [#3fb458ec](https://github.com/cloudamqp/lavinmq/commit/3fb458ec)
- UI: Removed fixed table layout for details table for better responsiveness [#eff8575b](https://github.com/cloudamqp/lavinmq/commit/eff8575b)
- Add builds for Debian 13 & Fedora 43. Remove builds for Fedora 40 [#1410](https://github.com/cloudamqp/lavinmq/pull/1410)

### Fixed

- Fixed a bug where LavinMQ could end up in an infinte loop in a priority queue [#1420](https://github.com/cloudamqp/lavinmq/pull/1420)
- Remove meta files after priority queue store migration [#1421](https://github.com/cloudamqp/lavinmq/pull/1421)
- Show all channels for a specific vhost in the GUI [#1413](https://github.com/cloudamqp/lavinmq/pull/1413)
- Don't log 'NaN' during follower sync if bps is 0 [#1418](https://github.com/cloudamqp/lavinmq/pull/1418)
- Fixed a flaky spec [#1383](https://github.com/cloudamqp/lavinmq/pull/1383)
- Reset segment pos before producing metadata [#1417](https://github.com/cloudamqp/lavinmq/pull/1417)
- Remove leftover apostrophe after refactoring [#1415](https://github.com/cloudamqp/lavinmq/pull/1415)
- Don't crash when reading metadata [#1416](https://github.com/cloudamqp/lavinmq/pull/1416)
- Fix x-max-age not showing as effective argument for stream queues in UI [#1389](https://github.com/cloudamqp/lavinmq/pull/1389)
- Add x-hash-on to effective_arguments for Consistent Hash Exchange [#1405](https://github.com/cloudamqp/lavinmq/pull/1405)
- Bugfix: mismatch between ids in view and script [#1409](https://github.com/cloudamqp/lavinmq/pull/1409)
- Exchange view will auto refresh data [#1399](https://github.com/cloudamqp/lavinmq/pull/1399)
- Handle AMQPLAIN authentication without required keys [035b8fdf](https://github.com/cloudamqp/lavinmq/commit/035b8fdf)
- Respect --pmessages/--cmessages also for multiple publishers/consumers in lavinmqperf [03604792](https://github.com/cloudamqp/lavinmq/commit/03604792)
- Only include livereload.js if flag livereloadjs is set [#1411](https://github.com/cloudamqp/lavinmq/pull/1411)
- Stream Basic Get responses over HTTP API [c1b8ec3](https://github.com/cloudamqp/lavinmq/commit/c1b8ec39c4d2d91cf80ad9bf0eb6f9805fd51a0b)
- Fixed a bug where stream consumers sometimes did not flush messages to socket [#1385](https://github.com/cloudamqp/lavinmq/pull/1385)
- Log Info instead of Warning on passive declare [#1384](https://github.com/cloudamqp/lavinmq/pull/1384)
- Log which user is being denied permission [#1392](https://github.com/cloudamqp/lavinmq/pull/1392)
- UI sorting bugs [#1374](https://github.com/cloudamqp/lavinmq/pull/1374)
- Don't delete shovel with DeleteAfter::QueueLength when pausing it [#1376](https://github.com/cloudamqp/lavinmq/pull/1376)
- Federations: Use correct variable to prevent channel error and reconnect [#1378](https://github.com/cloudamqp/lavinmq/pull/1378)
- Right-aligned columns display in UI tables [97f093e](https://github.com/cloudamqp/lavinmq/commit/da51e805f14c18d1e63f78e191871582ab94166c)
- Close metrics_server on clustering client close [#1367](https://github.com/cloudamqp/lavinmq/pull/1367) & [#1380](https://github.com/cloudamqp/lavinmq/pull/1380)
- Replicate meta files in clustering [#1365](https://github.com/cloudamqp/lavinmq/pull/1365)
- Use the right counters for lavinmq_global_messages_delivered_total [#1358](https://github.com/cloudamqp/lavinmq/pull/1358)
- `list_connections`: don't fail on missing key [#1226](https://github.com/cloudamqp/lavinmq/pull/1226)
- Fixed bug where proxying from a follower that is performing full sync does not work [#1283](https://github.com/cloudamqp/lavinmq/pull/1283)
- Fix condition if follower should be written to ISR [#1341](https://github.com/cloudamqp/lavinmq/pull/1341)
- Manage shovels on streams in the GUI [#1337](https://github.com/cloudamqp/lavinmq/pull/1337)
- API endpoint should accept empty/no body [#1338](https://github.com/cloudamqp/lavinmq/pull/1338)
- Don't double requeue messages on delivery failure [#1344](https://github.com/cloudamqp/lavinmq/pull/1344)
- Topic exchange doesn't route messages properly [#1300](https://github.com/cloudamqp/lavinmq/pull/1300)
- Specs should fail on closed queues [#1339](https://github.com/cloudamqp/lavinmq/pull/1339)
- Fix for sidebar icons light and dark mode [#1329](https://github.com/cloudamqp/lavinmq/pull/1329)
- Don't allow deletion of default (amq.x / mqtt.x) exchanges [#1321](https://github.com/cloudamqp/lavinmq/pull/1321)
- Allow deleting internal exchange via HTTP [#1319](https://github.com/cloudamqp/lavinmq/pull/1319)
- Make sure unused segments are properly deleted [#1297](https://github.com/cloudamqp/lavinmq/pull/1297)
- Don't return empty messages from first? and shift? [#1298](https://github.com/cloudamqp/lavinmq/pull/1298)
- Fix segfault in purge_all [#1289](https://github.com/cloudamqp/lavinmq/pull/1289)
- Always decode path params [#1273](https://github.com/cloudamqp/lavinmq/pull/1273)
- Move initialization of some BoolChannel to prevent leaks [#1263](https://github.com/cloudamqp/lavinmq/pull/1263)
- Fix some UI bugs in shovels: handle src and dest as arrays, properly display src-exchange, properly show paused/resume state [#1265](https://github.com/cloudamqp/lavinmq/pull/1265)
- Fixed a raise condition in `MFile#close` [816bfb3](https://github.com/cloudamqp/lavinmq/commit/816bfb3c254f0340acf7a52172c170bb0d7a1556)
- Reject unacked messages on error when getting messages via HTTP [#1349](https://github.com/cloudamqp/lavinmq/pull/1349)
- Added missing documentation [#1304](https://github.com/cloudamqp/lavinmq/pull/1304) & [#1306](https://github.com/cloudamqp/lavinmq/pull/1306)
- Fixed a bug where reconnecting a MQTT client with unacked messages was being blocked [#1102](https://github.com/cloudamqp/lavinmq/pull/1102)
- Refactoring and performance improvments of header exchanges [#1112](https://github.com/cloudamqp/lavinmq/pull/1112)
- Delete orphan acks files on start and shutdown [#1175](https://github.com/cloudamqp/lavinmq/pull/1175)
- A file descriptor leak in MQTT's `RetainStore` has been fixed [#be4e5032](https://github.com/cloudamqp/lavinmq/commit/be4e5032)
- The `consumer_offset` file is now closed and deleted when the message store is closed or deleted [#a3b746cb](https://github.com/cloudamqp/lavinmq/commit/a3b746cb)
- The shovel API no longer returns a 422 error when resuming a running shovel [#1157](https://github.com/cloudamqp/lavinmq/pull/1157)
- The user not found error is no longer logged twice [#1109](https://github.com/cloudamqp/lavinmq/pull/1109)
- Metrics - `deliver_no_ack` & `get_no_ack` added, and fixed a bug regarding `deliver`. [#1146](https://github.com/cloudamqp/lavinmq/pull/1146), [#1119](https://github.com/cloudamqp/lavinmq/pull/1119), [#1099](https://github.com/cloudamqp/lavinmq/pull/1099)
- lavinmqctl now validates access to the unix socket [#1181](https://github.com/cloudamqp/lavinmq/pull/1181)
- Verification of the default password hash on launch [#1078](https://github.com/cloudamqp/lavinmq/pull/1078)
- UI: The unbind button in the bindings listing in the queue view has been fixed [#1145](https://github.com/cloudamqp/lavinmq/pull/1145)
- UI: The behavior of the multi-control popup has been improved [#1144](https://github.com/cloudamqp/lavinmq/pull/1144)
- Fixed dead letter loop detection to prevent infinite loops [#1244](https://github.com/cloudamqp/lavinmq/pull/1244)
- Fixed pagination bounds check to prevent out-of-bounds pages [#1207](https://github.com/cloudamqp/lavinmq/pull/1207)
- Fixed bug where x-cache-ttl was reset when expiring messages with delayed exchange [#24f74bd7](https://github.com/cloudamqp/lavinmq/commit/24f74bd7)
- Validate input for operator policies [#1199](https://github.com/cloudamqp/lavinmq/pull/1199)
- Fixed unsafe shared body buffer in MQTT publish [#de730e77](https://github.com/cloudamqp/lavinmq/commit/de730e77)
- Fixed bug where messages larger than 64kB couldn't be published [#cd77b3f0](https://github.com/cloudamqp/lavinmq/commit/cd77b3f0)

## [2.5.0-rc.7] - 2025-11-03

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.5.0-rc.7> for changes in this pre-release

## [2.5.0-rc.6] - 2025-10-30

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.5.0-rc.6> for changes in this pre-release

## [2.5.0-rc.5] - 2025-10-30

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.5.0-rc.5> for changes in this pre-release

## [2.5.0-rc.4] - 2025-10-27

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.5.0-rc.4> for changes in this pre-release

## [2.4.5] - 2025-10-22

### Fixed

- Crystal 1.18.x compatibility [#1361](https://github.com/cloudamqp/lavinmq/pull/1361), [#1359](https://github.com/cloudamqp/lavinmq/pull/1359), [#1373](https://github.com/cloudamqp/lavinmq/pull/1373)

## [2.5.0-rc.3] - 2025-10-21

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.5.0-rc.3> for changes in this pre-release

## [2.5.0-rc.2] - 2025-10-14

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.5.0-rc.2> for changes in this pre-release

## [2.4.4] - 2025-09-16

### Fixed

- Memory leak in StreamConsumer [#1266](https://github.com/cloudamqp/lavinmq/pull/1266)
- Fixed some UI bugs [#1269](https://github.com/cloudamqp/lavinmq/pull/1269)
- Prevent delayed exchanges to bind to its internal delayed queue [#1270](https://github.com/cloudamqp/lavinmq/pull/1270)

## [2.4.3] - 2025-09-11

### Fixed

- Broken javascript dependency [#1247](https://github.com/cloudamqp/lavinmq/pull/1247)
- Queue `unacked_bytesize` return `unacked_count` [#1250](https://github.com/cloudamqp/lavinmq/pull/1250)
- Fix bug where only one consumer got notified about new messages in a stream [#1253](https://github.com/cloudamqp/lavinmq/pull/1253)
- Fix bug where a stream consumer's deliver loop could loop for infinity [#1254](https://github.com/cloudamqp/lavinmq/pull/1254)

## [2.4.2] - 2025-09-10

### Fixed

- Memory leak in `MQTT::Consumer` [#1242](https://github.com/cloudamqp/lavinmq/pull/1242)

## [2.5.0-rc.1] - 2025-08-12

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.5.0-rc.1> for changes in this pre-release

## [2.4.1] - 2025-07-21

### Fixed

- MQTT 3.1 client support
- Allow publishing of MQTT messages larger than 64KiB

## [2.4.0] - 2025-06-11

### Added

- Streams - Filtering on any header [#1053](https://github.com/cloudamqp/lavinmq/pull/1053)
- Show active arguments on queues & exchanges [#1072](https://github.com/cloudamqp/lavinmq/pull/1072)
- Install instructions for Archlinux [#1001](https://github.com/cloudamqp/lavinmq/pull/1001)

### Changed

- Parts of LavinMQ is now multi threaded, many structures are now thread safe
- Requires Crystal 1.16 and `-Dpreview_mt -Dexecution_context` to run
- Purgeing a queue without unacked messages is now instant [#1083](https://github.com/cloudamqp/lavinmq/pull/1083)
- Run etcd lease keepalive in a separate thread
- `lavinmqperf throughput` is multithreaded
- Drop global ACL caches and keep one write cache only per Client
- Remove ws.html and ws-mqtt.html

### Fixed

- Allow requeuing of MQTT messages when delivery fails [#1081](https://github.com/cloudamqp/lavinmq/pull/1081)
- Fixed routing_key or exchange with length 255 causing an ArithmeticOverflow [#1094](https://github.com/cloudamqp/lavinmq/pull/1094)
- Append to x-received-from instead of replacing [#1084](https://github.com/cloudamqp/lavinmq/pull/1084)
- Don't allow invalid binding arguments to ConsitentHashExchange [#1089](https://github.com/cloudamqp/lavinmq/pull/1089)
- Drop msg on requeue if above delivery_limit [#996](https://github.com/cloudamqp/lavinmq/pull/996)
- Fixed clustering leader election timing issue [#1138](https://github.com/cloudamqp/lavinmq/pull/1138)

## [2.3.0] - 2025-04-17

### Added

- MQTT websocket support [#1007](https://github.com/cloudamqp/lavinmq/pull/1007)
- Ability to change channel prefetch in UI/API [#1033](https://github.com/cloudamqp/lavinmq/pull/1033)
- Add Prometheus metrics for `global_message_*` counters [#1010](https://github.com/cloudamqp/lavinmq/pull/1010)
- Add filtering for bindings on exchange [#1032](https://github.com/cloudamqp/lavinmq/pull/1032)
- Make it possible to filter on connection_name and user from /connections [#1031](https://github.com/cloudamqp/lavinmq/pull/1031)
- Log total startup time [#1056](https://github.com/cloudamqp/lavinmq/pull/1056)

### Fixed

- Multiple nodes could generate and set clustering secret, causing the leader to use another secret than the followers. [#998](https://github.com/cloudamqp/lavinmq/pull/998)
- A policy with delivery-limit is now properly applied to a queue if the value is lower than the existing argument. [#1000](https://github.com/cloudamqp/lavinmq/pull/1000)
- Fix cluster ID and advertised URI collision handling, preventing confusing behavior when multiple nodes have the same identity [#1023](https://github.com/cloudamqp/lavinmq/pull/1023)
- Close MQTT client socket and exit deliver loop on errors [#1043](https://github.com/cloudamqp/lavinmq/pull/1043)
- Don't federate internal exchanges [#1058](https://github.com/cloudamqp/lavinmq/pull/1058)
- Stop existing federation links when applying a new policy [#1059](https://github.com/cloudamqp/lavinmq/pull/1059)

### Changed

- Cleaner CLI output with separators [#1018](https://github.com/cloudamqp/lavinmq/pull/1018)
- Default limit of 128 items in deduplication cache [#1019](https://github.com/cloudamqp/lavinmq/pull/1019)
- Messages in stream queues now support multiple filter values [#1022](https://github.com/cloudamqp/lavinmq/pull/1022)
- Filtering on stream queues now requires all filters on a consumer to match [#1022](https://github.com/cloudamqp/lavinmq/pull/1022)
- Make it possible to filter on connection_name and user from /connections [#1031](https://github.com/cloudamqp/lavinmq/pull/1031)
- Add BasicAuth section to HTTP API docs [#1030](https://github.com/cloudamqp/lavinmq/pull/1030)
- Command line arguments for mqtt_bind [#992](https://github.com/cloudamqp/lavinmq/pull/992)
- Show MQTT client keepalive in management UI [#989](https://github.com/cloudamqp/lavinmq/pull/989)
- Count MQTT messages in vhosts message stats [#988](https://github.com/cloudamqp/lavinmq/pull/988)
- Build RPM packages for Fedora 42 [391f79be](https://github.com/cloudamqp/lavinmq/commit/391f79be)
- README overhaul with improved structure and visual elements [#1052](https://github.com/cloudamqp/lavinmq/pull/1052)
- Don't build lavinmqperf with MT

## [2.2.0] - 2025-03-13

### Added

- Implemented support for MQTT 3.1.1. [#766](https://github.com/cloudamqp/lavinmq/pull/766)
- Introduced message deduplication on exchanges and queues. [#854](https://github.com/cloudamqp/lavinmq/pull/854)
- Added filtering capabilities for streams. [#893](https://github.com/cloudamqp/lavinmq/pull/893)
- Added garbage collection (GC) metrics to Prometheus endpoints. [#954](https://github.com/cloudamqp/lavinmq/pull/954)
- Incorporated message rates into the exchanges view. [#929](https://github.com/cloudamqp/lavinmq/pull/929)
- Displayed disk space usage in the `/queues` endpoint. [#930](https://github.com/cloudamqp/lavinmq/pull/930)
- Introduced configurability for `default_user` and `default_password`. These can now be set in the configuration file, as command-line arguments, or as environment variables. [#919](https://github.com/cloudamqp/lavinmq/pull/919)
- Added the `/api/auth/hash_password` endpoint and the `lavinmqctl hash_password` command to facilitate password hash generation. [#919](https://github.com/cloudamqp/lavinmq/pull/919)
- Enhanced `lavinmqperf` with a new queue-count test scenario. [#955](https://github.com/cloudamqp/lavinmq/pull/955)
- Added tooltips for the details table to improve user experience. [#925](https://github.com/cloudamqp/lavinmq/pull/925)

### Changed

- Ensured that `channel_max` negotiation is respected, treating a value of 0 as unlimited.
- Implemented logging and re-raising of errors if loading unexpectedly fails. [#933](https://github.com/cloudamqp/lavinmq/pull/933)
- Included priority settings in the journald log format. [#950](https://github.com/cloudamqp/lavinmq/pull/950)
- Deprecated `guest_only_loopback` in favor of `default_user_only_loopback`; `guest_only_loopback` will be removed in the next major release. [#919](https://github.com/cloudamqp/lavinmq/pull/919)

### Fixed

- Queues now expire `TTL` milliseconds after the last consumer disconnects. [#924](https://github.com/cloudamqp/lavinmq/pull/924)
- Prevented LavinMQ from freezing when closing consumers and channels. [#947](https://github.com/cloudamqp/lavinmq/pull/947)
- `x-delivery-count` is now excluded from the initial delivery of a message; the count accurately reflects the number of delivery attempts prior to the current delivery. [#977](https://github.com/cloudamqp/lavinmq/pull/977)
- Resolved an issue where follower nodes unnecessarily resynchronized identical files during full syncs due to mismatched hash calculations. [#963](https://github.com/cloudamqp/lavinmq/pull/963)
- Validated that the `expiration` parameter is a non-negative number when publishing via the HTTP API. [#969](https://github.com/cloudamqp/lavinmq/pull/969)
- Implemented handling for missing files during follower synchronization. [#968](https://github.com/cloudamqp/lavinmq/pull/968)

## [2.2.0-rc.1] - 2025-02-21

See [v2.2.0-rc.1 Release Notes](https://github.com/cloudamqp/lavinmq/releases/tag/v2.2.0-rc.1) for changes in this pre-release

## [2.1.0] - 2025-01-16

### Changed

- New UI for management interface [#821](https://github.com/cloudamqp/lavinmq/pull/821)
- Use sent/received bytes instead of messages to trigger when other tasks can run [#863](https://github.com/cloudamqp/lavinmq/pull/863)
- Spread out stream queues GC-loop over time [#876](https://github.com/cloudamqp/lavinmq/pull/876)
- Don't unmap files on USR2 or when last consumer disconnects [#876](https://github.com/cloudamqp/lavinmq/pull/876)
- Unmap files when they are no longer in use [#876](https://github.com/cloudamqp/lavinmq/pull/876)
- Store non-durable queues in a separate dir that is removed on startup and shutdown [#900](https://github.com/cloudamqp/lavinmq/pull/900)

### Fixed

- Queues will no longer be closed if file size is incorrect. Fixes [#669](https://github.com/cloudamqp/lavinmq/issues/669)
- Dont redeclare exchange in java client test [#860](https://github.com/cloudamqp/lavinmq/pull/860)
- Removed duplicate metric rss_bytes [#881](https://github.com/cloudamqp/lavinmq/pull/881)
- Release leadership on graceful shutdown [#871](https://github.com/cloudamqp/lavinmq/pull/871)
- Rescue more exceptions while reading msg store on startup [#865](https://github.com/cloudamqp/lavinmq/pull/865)
- Crystal 1.15 support [#905](https://github.com/cloudamqp/lavinmq/pull/905)
- lavinmqctl now handles pagination of large result sets [#904](https://github.com/cloudamqp/lavinmq/pull/904)
- Make clustering more reliable [#879](https://github.com/cloudamqp/lavinmq/pull/879), [#909](https://github.com/cloudamqp/lavinmq/pull/909), [#906](https://github.com/cloudamqp/lavinmq/pull/906)
- Strip newlines from logs [#896](https://github.com/cloudamqp/lavinmq/pull/896)

### Added

- Added some logging for followers [#885](https://github.com/cloudamqp/lavinmq/pull/885)

## [2.0.2] - 2024-11-25

### Fixed

- Don't raise FileNotFound when deleting already deleted file [#849](https://github.com/cloudamqp/lavinmq/pull/849)
- Increase default etcd lease TTL to 10s and run keepalive earlier [#847](https://github.com/cloudamqp/lavinmq/pull/847)
- Don't remove consumers from queue before all data is sent to client. It may cause a segmentation fault because a unmapped message segment is accessed. [#850](https://github.com/cloudamqp/lavinmq/pull/850)

### Changed

- Exit with status 1 if lost leadership so that LavinMQ is restarted by systemd [#846](https://github.com/cloudamqp/lavinmq/pull/846)

## [2.0.1] - 2024-11-13

### Fixed

- etcd lease will no longer expire during slow startup [#834](https://github.com/cloudamqp/lavinmq/pull/834)
- Leader node is no longer unresponsive while sending file_list/files to new followers [#838](https://github.com/cloudamqp/lavinmq/pull/838)
- Leader node now waits for all data to be acked to all followers before shutting down on graceful shutdown [#835](https://github.com/cloudamqp/lavinmq/pull/835)
- Improve broker initiated client disconnects [#816](https://github.com/cloudamqp/lavinmq/pull/816)
- Fixed sorting on unacked messages [#836](https://github.com/cloudamqp/lavinmq/pull/836)

### Changed

- Remove the 'reset vhost' feature [#822](https://github.com/cloudamqp/lavinmq/pull/822)
- Build with latest crystal version [#841](https://github.com/cloudamqp/lavinmq/pull/841)
- Added metadata when logging connection handshake [#826](https://github.com/cloudamqp/lavinmq/pull/826)

### Added

- Added some indexing for streams, greatly increasing performance when looking up by offset or timestamp [#817](https://github.com/cloudamqp/lavinmq/pull/817)
- Added buildstep for 'make rpm' [#840](https://github.com/cloudamqp/lavinmq/pull/840)

## [2.0.0] - 2024-10-31

With the release of 2.0.0 we introduce High Availablility for LavinMQ in the form of clustering. With clustering, LavinMQ replicates data between nodes with our own replication protocol, and uses etcd for leader election. See [this post](https://lavinmq.com/blog/lavinmq-high-availability) in the LavinMQ blog or the [readme](https://github.com/cloudamqp/lavinmq?tab=readme-ov-file#clustering) for more information about clustering.

### Added

- Full HA clustering support, uses etcd for leader election and metadata, and a replication protocol between nodes.
- Added cluster_status to lavinmqctl [#787](https://github.com/cloudamqp/lavinmq/pull/787)
- Added deliver_get to message_stats [#793](https://github.com/cloudamqp/lavinmq/pull/793)
- Added a configurable default consumer prefetch value for all consumers. Defaults to 65535. [#813](https://github.com/cloudamqp/lavinmq/pull/813)
- Output format (text/json) can now be selected when running lavinmqctl cmds [#790](https://github.com/cloudamqp/lavinmq/pull/790)
- Clustering clients will now listen on the UNIX sockets if configured
- Clustering server will accept PROXY protocol V2 headers from followers

### Fixed

- Shovels' batching of acks caused a lot of unacked messages in source broker [#777](https://github.com/cloudamqp/lavinmq/pull/777)
- Shovel AMQP source didn't reconnect on network failures (partially fixed in prev release) [#758](https://github.com/cloudamqp/lavinmq/pull/758)
- Running lavinmqctl commands on a follower node now displays an error and exits with code 2 [#785](https://github.com/cloudamqp/lavinmq/pull/785)
- Federation queue links now reconnects if the upstream disconnects [#788](https://github.com/cloudamqp/lavinmq/pull/788)
- Proxying from followers is now more resilient [#812](https://github.com/cloudamqp/lavinmq/pull/812)
- Sorting on consumer count at channels page
- Log if user tries to declare a queue with an unknown queue type [#792](https://github.com/cloudamqp/lavinmq/pull/792)
- Force close AMQP connections if a protocol error occurs
- Remove min_isr setting [#789](https://github.com/cloudamqp/lavinmq/pull/789)
- Wait for followers to synchronize on shutdown of leader
- Make proxied UNIX sockets in followers RW for all
- SystemD notify ready in cluster mode when lader is found
- Etcd actions are retried, etcd can now be restarted without issues
- Clustering secret is monitored if not available yet when becoming a replication follower

### Changed

- Updated RabbitMQ HTTP API Go client test to use a patch-file for LavinMQ compatibility [#778](https://github.com/cloudamqp/lavinmq/pull/778)
- Renames clustering_max_lag -> clustering_max_unsynced_actions to clarify that it is measured in number of actions [#810](https://github.com/cloudamqp/lavinmq/pull/810)
- Renames lag -> lag_in_bytes to clarify that lag is measured in bytes [#810](https://github.com/cloudamqp/lavinmq/pull/810)
- Suggests etcd 3.4.0 as min version [#815](https://github.com/cloudamqp/lavinmq/pull/815)
- Changed logging to provide more information about which queue is being handled [#809](https://github.com/cloudamqp/lavinmq/pull/809)
- Publishing messages are now handled fully by exchanges [#786](https://github.com/cloudamqp/lavinmq/pull/786)
- Logging is now handled more uniformly throghout LavinMQ [#800](https://github.com/cloudamqp/lavinmq/pull/800)
- Don't log handled exceptions as error with backtrace [#776](https://github.com/cloudamqp/lavinmq/pull/776)
- Don't dynamically fetch active etcd endpoints

## [2.0.0-rc.5] - 2024-10-28

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.0.0-rc.5> for changes in this pre-release

## [1.3.1] - 2024-08-29

### Fixed

- Don't shovel messages after initial queue length [#734](https://github.com/cloudamqp/lavinmq/pull/734)
  - Shovels that were set up to stop after the initial queue length will now stop. For high ingress queues a race condition could trigger these shovels to send more messages than the initial queue length.
- Memory leak in Crystal's Hash implementation fixed [#14862](https://github.com/crystal-lang/crystal/pull/14862)
  - This release is using Crystal `1.13.2`
- Bindings are now sorted properly in the web interface [#726](https://github.com/cloudamqp/lavinmq/pull/726)
- Shovel AMQP source didn't reconnect on network failures [#758](https://github.com/cloudamqp/lavinmq/pull/758)
  - Update `amqp-client.cr` to get a necessary fix for reconnecting shovel sources
- Dead-lettering loop when publishing to a delayed exchange's internal queue was fixed [#748](https://github.com/cloudamqp/lavinmq/pull/748)
- Exchange federation tried to bind to the upstream's default exchange [#749](https://github.com/cloudamqp/lavinmq/pull/749)
- Shovel ack all unacked messages on stop [#755](https://github.com/cloudamqp/lavinmq/pull/755)
- Prevent a queue that is overflowing from consuming too many resources [#725](https://github.com/cloudamqp/lavinmq/pull/725)

## [2.0.0-rc.4] - 2024-08-21

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.0.0-rc.4> for changes in this pre-release

## [1.3.0] - 2024-07-17

### Removed

- Removed old replication in anticipation of coming clustering.

### Changed

- Build with Crystal 1.13.1
- Deb packages now includes all debug symbols, for useful stacktraces
- Replaced HTTP router with an internal one. Now LavinMQ uses 0 external libraries.
- Specs are more reliable when a new server is started for each spec
- LavinMQ never sets TLS ciphers by it self, custom ciphers have to be configured via the config

### Fixed

- HTTP API: Regression where an (empty) body was required to PUT a new vhost
- lavinmqctl didn't recognize 201/204 response codes from set_permissions, set_user_tags and add_vhost
- Queues will no longer be closed if file size is incorrect. Fixes [#669](https://github.com/cloudamqp/lavinmq/issues/669)
- Improved logging
- Won't choke on empty message files on boot [#685](https://github.com/cloudamqp/lavinmq/issues/685)
- Won't choke on somewhat too large message files on boot [#671](https://github.com/cloudamqp/lavinmq/issues/671)

### Added

- Can view which messages are unacked in each queue (HTTP and UI) [#712](https://github.com/cloudamqp/lavinmq/pull/712)
- Tags and descriptions on VHosts
- Can pass an array of URLs to Shovel

## [2.0.0-rc.3] - 2024-07-12

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.0.0-rc.3> for changes in this pre-release

## [2.0.0-rc.2] - 2024-07-05

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.0.0-rc.2> for changes in this pre-release

## [2.0.0-rc.1] - 2024-06-25

See <https://github.com/cloudamqp/lavinmq/releases/tag/v2.0.0-rc.1> for changes in this pre-release

## [1.2.14] - 2024-06-15

### Fixed

- Exporting definitions broke delayed exchanges [#699](https://github.com/cloudamqp/lavinmq/pull/699)
- lavinmqctl: escape symbols in parameters (eg. can now create vhosts with / in the name) [#699](https://github.com/cloudamqp/lavinmq/pull/696)

## [1.2.13] - 2024-06-14

### Fixed

- Some prometheus metrics typing was mixed up, counter where it should be gauge
- Unmap memory mapped files on finalize, could cause segfaults in replication when files already deleted tried to be replicated
- Bug fix where followers who were synchronizing could miss some updates

### Changed

- Auto reconnect `lavinmqperf throughput` on disconnect
- Render HTTP API docs using Stoplight Elements

### Added

- HTTP API: /api/connections/:user, lists connections by a specific user

## [1.2.12] - 2024-05-24

### Changed

- Follower lag is now based on bytes written to action queue instead of socket [#652](https://github.com/cloudamqp/lavinmq/pull/652)
- Change how delayed exchanges are exported with definitions [#663](https://github.com/cloudamqp/lavinmq/pull/663)
- Force 4096 bytes frame_max for WebSocket connections [#681](https://github.com/cloudamqp/lavinmq/pull/681)

### Fixed

- Federated queues now only transfers messages if there is a consumer on the downstream queue [#637](https://github.com/cloudamqp/lavinmq/pull/637)
- Handle proxied WebSocket connections [#680](https://github.com/cloudamqp/lavinmq/pull/680)

## [1.2.11] - 2024-04-26

### Fixed

- Empty ack files created for all segments [#658](https://github.com/cloudamqp/lavinmq/pull/658)
- UI: Set proper width (colspan) for pagination cell [#662](https://github.com/cloudamqp/lavinmq/pull/662)
- Provide better information about connections LavinMQ initiates [#613](https://github.com/cloudamqp/lavinmq/pull/613)
- Bugfix: Make sure shovels reconnect after destination disconnects [#667](https://github.com/cloudamqp/lavinmq/pull/667)

### Changed

- LavinMQ now waits for any followers to be in sync before shutting down [#645](https://github.com/cloudamqp/lavinmq/pull/645)
- UI: Creating queues and exchanges in the UI now defaults to durable [#656](https://github.com/cloudamqp/lavinmq/pull/656)
- Rename config.ini -> lavinmq.ini [#664](https://github.com/cloudamqp/lavinmq/pull/664)

### Added

- Replication lag is now exported in metrics [#646](https://github.com/cloudamqp/lavinmq/pull/646)

## [1.2.10] - 2024-03-25

### Fixed

- Don't use shovel name as consumer tag [#634](https://github.com/cloudamqp/lavinmq/pull/634)
- Keep the same vhost selected when creating queues [#629](https://github.com/cloudamqp/lavinmq/pull/629)
- Make sure name of Queues, Exchanges & Vhosts is not longer than 255 characters [#631](https://github.com/cloudamqp/lavinmq/pull/631)
- Add nilguard for matching x-delayed-type argument [#639](https://github.com/cloudamqp/lavinmq/pull/639)

### Changed

- Use system assigned ports in specs [#640](https://github.com/cloudamqp/lavinmq/pull/640)
- Let MFile raise ClosedError instead of IO::Error [#642](https://github.com/cloudamqp/lavinmq/pull/642)

### Added

- Improved logging during definitions loading [#621](https://github.com/cloudamqp/lavinmq/pull/621)

## [1.2.9] - 2024-02-05

### Fixed

- LavinMQ now calls Systemd.notify_ready when started as follower [#626](https://github.com/cloudamqp/lavinmq/pull/626)

## [1.2.8] - 2024-01-10

### Fixed

- A bug causing faulty definition frames for delayed exchanges, preventing LavinMQ from starting [#620](https://github.com/cloudamqp/lavinmq/pull/620)
- Better table views for Queues, where the name isn't cut of
- Persist table sorting between page loads
- Don't include permissions in users array in definitions json export, as that was incompatible with other brokers
- Don't mmap a segment file to just verify the schema version (uses pread instead)

### Changed

- Build binaries and container images using Crystal 1.11.0
- Don't allow clients open an already open channel
- Use DirectDispatcher for logging and add more logging to startup procedure [#619](https://github.com/cloudamqp/lavinmq/pull/619)

### Added

- Support for Consumer timeouts, default none.

## [1.2.7] - 2023-12-12

- Version 1.2.6 may not include the bumped version of lavinmq, so instead use version 1.2.7

## [1.2.6] - 2023-12-12

### Fixed

- Don't update user's password hash if given password is the same as current [#586](https://github.com/cloudamqp/lavinmq/pull/586)
- Remove old segments in the background for stream queues [#608](https://github.com/cloudamqp/lavinmq/pull/608)

### Changed

- New amq-protocol.cr version 1.1.12
- Add package build for Debian 12 (bookworm) [#597](https://github.com/cloudamqp/lavinmq/pull/597)
- Do not update permissions if they are the same [#609](https://github.com/cloudamqp/lavinmq/pull/609)
- Do not update password hash if given current password [#586](https://github.com/cloudamqp/lavinmq/pull/586)

### Added

- Add playwright for frontend specs [#560](https://github.com/cloudamqp/lavinmq/pull/560)

## [1.2.5] - 2023-11-06

### Added

- Consumer arguments support for shovels [#578](https://github.com/cloudamqp/lavinmq/pull/578)

### Fixed

- A bug in delay exchanges caused messages to be routed to x-dead-letter-exchange instead of bound queues. It also ruined any dead lettering headers.
- A bug that prevented headers exchange to match on table in message headers.
- Purging a queue with a lot of messages blocked LavinMQ from other operations.
- Message timestamps not being updated when dead lettered breaking TTL.

### Changed

- Definitions uploads can now be JSON body [#580](https://github.com/cloudamqp/lavinmq/pull/580)

## [1.2.4] - 2023-09-26

### Fixed

- A bug in amq-protocol caused corrupt headers when a message was dead-lettered multiple times [amq-protocol/#14](https://github.com/cloudamqp/amq-protocol.cr/pull/14)

## [1.2.3] - 2023-09-12

### Fixed

- A bug in amq-protocol caused lost headers when dead-lettering [amq-protocol/#12](https://github.com/cloudamqp/amq-protocol.cr/pull/12)
- Block creation of queues and users when disk is close to full to prevent disk from becoming full [#567](https://github.com/cloudamqp/lavinmq/pull/567)
- Compacting definitions during runtime to avoid the definitions file to grow endlessly when churning bindings/queues (#571)
- Only store bind/unbind defintions if not already added, decreases definitions file growth
- Unmap segments in stream queues regularly
- Unmap segments when all consumers from a queue has disconnected

## [1.2.2] - 2023-08-22

### Added

- Make it possible to declare temp queues in lavinmqperf connection-count

### Fixed

- Delete fully ACK'd segments when opening new segments [#565](https://github.com/cloudamqp/lavinmq/pull/565)
- Don't send internal error messages to clients
- Remove queues from ACL cache on deletion
- Use federated queue's name if queue name is empty [#562](https://github.com/cloudamqp/lavinmq/pull/562)

### Changed

- Refactoring
- Use amq-protocol v1.1.8, refactor header handling
- Optimize SegmentPosition creation

## [1.2.1] - 2023-08-09

### Fixed

- Aggressively unmapping message store segments could result in seg faults when consumers are slow.

## [1.2.0] - 2023-08-08

### Added

- Stream queues, queues that can be consumed multiple times, messages (segments) are only deleted by a retention policy

### Fixed

- Queue message segments where opened with the wrong permissions to be able to be truncated if needed

## [1.1.7] - 2023-08-05

### Fixed

- Acked messages reappeared after server reboot, ack files were accidently truncated
- Deliver msgs to consumer even if queue ttl is 0
- Allow multiple formats (array, string etc) of tags in definitions.json
- Acking delivery tag 0 (with multiple=true) when channel as no unacked messages will not result in an error

### Added

- Signal USR2 will unmap all mmap:ed files (in addition to force a memory garbace collection)
- Building packages for enterprise linux 9 (EL9, redhat 9, centos stream 9, rocky linux 9 etc)

### Changed

- Removed "Message size snapshot", UI and API, which has been non functioning for a long time
- Crystal 1.9.2

## [1.1.6] - 2023-07-20

### Added

- Replication support, followers can connect and stream data from a leader in real time, enabling hot-standby use-cases
- Config variables for free_disk_min and free_disk_warn
- Support for adding custom properties in `lavinmqperf throughput --properties '{"headers": {"a": 1}}'`
- Support for random bodies in `lavinmqperf --random-bodies`

### Changed

- Temporary message files (per channel) are not truncated on publish, so performance for transactions are up 10x, and publishing messages larger than frame_max too
- Modifying defintions (declaring/deleting queues/exchanges etc) is now synchrous and thread safe.
- Message segments aren't ftruncated until server is cloded, as it's a slow operation
- SEGV signal always generate coredumps now (no custom signal handler for SEGV)
- Boehm GC upgraded to version 8.2.4 (from 8.2.2)

### Fixed

- Messages larger than frame_max, routed to multiple queues, were only written to the first queue, and corrupted the others
- Message segments are aggressively unmapped to decrease memory usage
- Exclusive queues are no longer included in definitions export
- UI error handling simplified

## [1.1.5] - 2023-06-23

### Fixed

- Prevent memory leaks from consumer fibers which are waiting for empty queues etc.

## [1.1.4] - 2023-06-22

### Changed

- fsync on transaction commit, but not on publish confirm

### Fixed

- Don't allow creating policies with wrongly typed defintions
- Javascript bugs in the UI
- Allow importing definitions where entities lacks the vhost property
- Export vhost parameters when exporting a single vhost
- Redirect to login page when cookie expires in UI

### Added

- Single Active Consumer queue support
- Exponential backoff for shovel reconnects
- Consumer churn rate metrics
- Quicker boot time after crash
- UI view for consumers

## [1.1.3] - 2023-05-22

### Added

- Added churn_rates to /api/overview call [#517](https://github.com/cloudamqp/lavinmq/pull/517)

### Changed

- Improve RAM usage by only spawning queue_expiration loop when it's needed [#512](https://github.com/cloudamqp/lavinmq/pull/512)
- Better handling of JSON arguments in UI [#513](https://github.com/cloudamqp/lavinmq/pull/513)
- Load debug symbols by default

### Fixed

- Fixed some specs

## [1.1.2] - 2023-04-27

### Fixed

- Seg fault issues with Crystal 1.8.0 and LLVM 12, so this version just rebuild of 1.1.1 using crystal 1.8.1 and LLVM 15

## [1.1.1] - 2023-04-26

### Fixed

- Segmentation fault bug with Crystal 1.8 for exchange to exchange binding listing in API
- Consistent login handling in UI (use cookie, not basic auth)
- Shovel/federation clients now support negotiating frame_max with upstream server

### Changed

- Remove signal handler for SEGV (segmentation fault) in release mode so that a coredump is generated
- Don't include stat history when listing exchanges
- UI table refactoring so that multiple tables can have pagination for instance
- UI keeps trying to load data while server is offline
- Paused queues will no longer resume on restart, instead they will stay paused untill manually resumed [#511](https://github.com/cloudamqp/lavinmq/pull/511)

### Added

- `lavinmqctl definitions <datadir>` to generate definitions json from an existing data dir for emergency recovery

## [1.1.0] - 2023-04-15

### Added

- Only mmap message store files on-demand, decreasing memory usage for arbitrary long queues to 0
- CSP rules in the UI, forbids inline js etc.
- Support `?columns=` query for all API endpoints
- The HTTP API now supports cookie authentication, in addition to basic auth

### Changed

- Precompress static assets (inflate on-demand if client don't accept deflate)
- Don't include historic message stats when listing queues via the API
- New favicon (that works both in dark and light mode)
- Return 403 rather than 401 for access refused in /api (401 only if unauthenticated)
- Cleaning up JS in UI

### Fixed

- Error message in UI when lacking access to Logs/Vhosts/Users/shovels/federation
- Autocomplete queues/vhosts is now correct in the UI (selecting only from the vhost in question)
- Deliveries of messages larger than socket_buffer_size (16KB) on x86_64 fixed in Crystal 1.8.0 due to faulty LibC bindings
- Increased responsiveness in cases with very fast consumers
- UI: Consumers listing on Queue page
- UI: Users with vhost access can also list all connections/channels/consumers in that vhost

## [1.0.1] - 2023-04-06

### Fixed

- Require `administrator` tag to show logs in UI/API
- VHost dropdown menu is now sorted by name

### Changed

- Optimized images in UI (replace jpg/png with webp, svg and css gradients)
- Calculate etags for static resources at compile time
- Use weak etags so that responses can be compressed without dropping the etag
- no-cache for views and static resources, the browser will still cache them, but query the browser if there are newer versions
- Use the hash part of the URL as arguments to /queue and other views, so that the browser reuse the same cached HTML

## [1.0.0] - 2023-03-31

### Added

- Log exchange [#473](https://github.com/cloudamqp/lavinmq/pull/473)

### Fixed

- A lot of management UI fixes
- Disable proxy buffering of /api/livelog

## [1.0.0-beta.13] - 2023-03-30

### Changed

- Use /tmp/lavinmqctl.sock as unix socket path for lavinmqctl on all platforms
- Make HTTP unix sockets world writeable, authentication is done on the protocol level
- Keep debug symbols in debian packages, no separate dbgsym package required

### Fixed

- JS error when checking authentication
- Optimized basic auth check

## [1.0.0-beta.12] - 2023-03-22

### Fixed

- Add lavinmq user when installing Debian/Ubuntu deb packages

## [1.0.0-beta.11] - 2023-03-18

### Changed

- Each queue now has its own message store, simplifying a lot of code (net -1500 LOC), but sacrificing fanout performance and persistent exchange support (to be replaced with stream queues). Single queue performance is better (as only one write is needed per message) and no message GC is needed, disk space usage is better.
- Backup data dir before migration (remember to delete when successful)
- pcre2 as regex engine

### Fixed

- No flash of layout when not logged in to the UI
- Delete temporary messages on transaction rollback

## [1.0.0-beta.10] - 2023-03-10

### Added

- Log view in the UI, uses SSE to live stream any logs from the server

### Changed

- Use relative links in the UI, so that the mgmt interface can be mapped at any path
- HTML views are now templated using ECR
- Own implementation of embedding UI assets in executable

### Fixed

- Fixed potential message store corruption bug, if client disconnected while publishing (and body frame split over multiple TCP packets)
- Include libsystemd-pthread in container image so that lavinmqperf works again
- Builds are reproducible

## [1.0.0-beta.9] - 2023-02-22

### Changed

- Side menu in manager is now more responsive to smaller browser windows [#437](https://github.com/cloudamqp/lavinmq/pull/437)
- Updated Chart.js version form v2.9.4 to v4.0.1 [#426](https://github.com/cloudamqp/lavinmq/pull/426)
- Build lavinmqperf with multi threading
- `lavinmqperf connection-count` now uses multiple fibers to take use of multi threading
- Charts are updated faster with recent information
- UI updates for a better responsive experience [#463](https://github.com/cloudamqp/lavinmq/pull/463)

### Fixed

- Property tag shortcuts for JSON Payload fixed [#441](https://github.com/cloudamqp/lavinmq/pull/441)
- Warn if vm.max_map_count is low on boot
- Restore priority queues correctly [#436](https://github.com/cloudamqp/lavinmq/pull/436)
- Increased multi threading compability
- Can re-decalre a delayed-message exchange without failing [#450](https://github.com/cloudamqp/lavinmq/pull/450)

## [1.0.0-beta.8] - 2022-11-29

### Added

- Upload definitions to a specific vhost only
- Building RPM packages (for Fedora 37 currently, please request others if needed)
- Build DEB debuginfo/debugsource packages
- Include debug symbols in the container image binaries
- `install`/`uninstall` targets in `Makefile`

### Changed

- Allow administrators to change user's tags without also updating password
- Doesn't try to send publish confirms before publish (so messaged being delivered might still be unconfirmed)
- Understandable error message from lavinmqctl if lavinmq isn't running
- Lint openapi spec before building API docs

### Fixed

- Messages published in a transaction now gets their timestamp at the time of commit
- Impersonator tag now works as it should (allow messages to have another `user_id` property than the user publishing it)
- Unacked messages are only stored on the Channel level now, no double booking in the Queue, ~17% performance increase
- Close client socket as soon as Connection#CloseOk has been read
- Close channel if a new publish starts before another publish has finished
- Prevent double ack in a transaction
- Precondition error if trying to TxCommit/Rollback when TxSelect hasn't been issued
- Don't requeue uncommited ack:ed messages in Tx on BasicRecover

## [1.0.0-beta.7] - 2022-11-21

### Added

- Include the message timestamp and the TTL in the queue index for faster handling of expired message when the Queue has a message TTL
- Migrating index files to the new queue index format
- New RoughTime methods for faster time lookups
- Transaction support in lavinmqperf
- Spec stage/layer in `Dockerfile`: `docker build --target spec .`

### Fixed

- Queue/exchange arguments has priority over policies, but lowest value wins in case of numeric property
- Removed the use of StringPool for short strings, no performance impact and lower memory usage
- Proper error message if listing in UI includes error items
- Correct handling of zero TTL messages (expire on requeue)
- 6% publish rate increase due to caching of segment id (1.6M msgs/s locally)
- Include ca-certificates in container image so that lavinmqperf can connect to AMQPS servers with valid certs
- Unacked basic_get messages werent accounted for, which in rare cases could lead to message loss (unacked for a long time and then requeued)

### Changed

- Always fsync on transaction commit (if the transaction included persistent messages)
- Build container image and debian packages with crystal 1.6.2
- lavinmqctl list_connections connection_properties emulates the rabbitmqctl output format
- Command line arguments overrides config file settings
- lavinmqperf queue-churn uses random queue names for parallel runs

## [1.0.0-beta.6] - 2022-11-10

### Fixed

- Improved user handling ([#400](https://github.com/cloudamqp/lavinmq/pull/400))
- BasicRecover w/ requeue should return all unacked messages to the queues ([#398](https://github.com/cloudamqp/lavinmq/pull/398))
- Don't include basic_get messages when limiting global prefetch

### Added

- Support for AMQP transactions ([#403](https://github.com/cloudamqp/lavinmq/pull/403))
- support for set_permissions to lavinmqctl ([#397](https://github.com/cloudamqp/lavinmq/pull/397))
- Let consumers pull messages from queues ([#391](https://github.com/cloudamqp/lavinmq/pull/391)

### Changed

- Keep same Logger for server restarts ([#399](https://github.com/cloudamqp/lavinmq/pull/399))

## [1.0.0-beta.5] - 2022-11-02

### Changed

- Removed first/last timestamp from Queue view, as it as poorly implemented ([#392](https://github.com/cloudamqp/lavinmq/pull/392))

### Fixed

- Selects the selected vhost as default when creating queue ([#394](https://github.com/cloudamqp/lavinmq/pull/394))
- Add number of persistent messages in queue response ([#390](https://github.com/cloudamqp/lavinmq/pull/390))

## [1.0.0-beta.4] - 2022-10-18

### Changed

- Allow "policy maker"-user to export/import vhost definitions ([#379](https://github.com/cloudamqp/lavinmq/pull/379))

### Fixed

- Ensure Http tag does not give management access ([#381](https://github.com/cloudamqp/lavinmq/pull/381))
- If the server crashed, the index files could in many cases be corrupted and result in message loss ([#384](https://github.com/cloudamqp/lavinmq/pull/384))

## [1.0.0-beta.3] - 2022-09-06

Measure and log time it takes to collect metrics in stats_loop ([#371](https://github.com/cloudamqp/lavinmq/pull/371))

### Added

- Queue size metric details to present expensive queue metrics calculation ([#362](https://github.com/cloudamqp/lavinmq/pull/362))
- Support for vhost limits (max-queues and max-connections)
- Support for configuring max_message_size (default 128MB)
- The amount of ready and unacknowledged messages are shown in the nodes details ([#368](https://github.com/cloudamqp/lavinmq/pull/368))

## [1.0.0-beta.2] - 2022-06-30

### Fixed

- Fix endless loop over `expire_queue` on expired queues that still had consumers ([#363](https://github.com/cloudamqp/lavinmq/pull/363) and [#364](https://github.com/cloudamqp/lavinmq/pull/364))

## [1.0.0-beta.1] - 2022-05-17

### Added

- Queue multi action UI, purge or delete multiple queues ([#330](https://github.com/cloudamqp/lavinmq/pull/330))
- Shovel error feedback, ability to see why a shovel failed without consulting the logs ([#328](https://github.com/cloudamqp/lavinmq/pull/328))
- Can pass queue and consumer arguments in lavinmqperf
- Shovel configuration error feedback ([#328](https://github.com/cloudamqp/lavinmq/pull/328))
- Can reset vhosts ([#321](https://github.com/cloudamqp/lavinmq/pull/321))
- `lavinmqperf connection-count` for benchmarking many connections
- Read cgroup max memory, both for cgroup v1 and v2
- Show message rates per vhost (#355)
- Kubernetes example file (./extras/kubernetes.yaml)

### Fixed

- Fix potential corruption by race condition between multiple consumers
- Stop Queue if unrecoverable read error (i.e. corruption) ([#318](https://github.com/cloudamqp/lavinmq/pull/318))
- Handle both ackmode and ack_mode as param to "Get messages" ([#347](https://github.com/cloudamqp/lavinmq/pull/347))
- Number of messages was never used when puring from UI ([#337](https://github.com/cloudamqp/lavinmq/pull/337))
- Use the statically linked gc libary, which gives fewer GC pauses ([#337](https://github.com/cloudamqp/lavinmq/pull/337))
- Report which protocol each listener uses in /api/overview (#348)
- Limit API result sets, truncate instead of corrupt output (#343)
- Truncate spare index files on queue index restore for decreased memory usage on recovery

### Changed

- Renamed to LavinMQ
- Limit number of consumers listed on Queue page, improve load time if there's lots of consumers ([#327](https://github.com/cloudamqp/lavinmq/pull/327))
- Count consumers more efficiently ([#346](https://github.com/cloudamqp/lavinmq/pull/346))
- Stop building deb packages for Ubuntu 18.04
- New logging framework (#332)
- Improved websocket example page (./static/ws.html)
- Base container on crystal 1.4.1 and ubuntu 22.04 (openssl 3.0)

## [1.0.0-alpha.34] - 2022-01-19

### Added

- Option do configure tcp keepalive via config file
- Allow or block guest user using loopback address. ([#305](https://github.com/cloudamqp/lavinmq/pull/305))
- Reject and requeue is now default option when getting messages in UI. ([#307](https://github.com/cloudamqp/lavinmq/pull/307))
- Show hostname in header ([#308](https://github.com/cloudamqp/lavinmq/pull/308))
- Prometheus metrics
- Make it possible to reque Get messages last with the HTTP API
- Show server hostname in UI
- Displaying timestamp of first and last message in each Queue (HTTP API/UI)
- Option to set max count of how many messages to purge
- lavinmqperf throughput have a max uncofirmed messages option
- lavinmqperf throughput can multi ack X number of messages
- lavinmqperf consumer-churn command
- lavinmqctl status command

### Removed

- Remove SystemD socket activation/seamless restart ([#303](https://github.com/cloudamqp/lavinmq/pull/303))

### Fixed

- GC collect every 10s and unmap GC memory as soon as possible
- No 2GB limit of MFiles (segments/queue indicies)
- Messages are requeued correctly if delivery fails
- Can log to file using log_file config option
- Fix print build info on startup, log prefix on each line

### Changed

- Faster JSON generation for queues
- Build with Crystal 1.3.1
- Allow Get/Reject messages from paused queues in the HTTP API
- Use /var/lib/lavinmq as default path for data in containers
- libsystemd is no longer a dependency
- Faster ready messages bytesize counting

## [1.0.0-alpha.33] - 2021-10-28

### Fixed

- Fix stuck deliver_loop by yielding once in a while

## [1.0.0-alpha.32] - 2021-10-27

### Added

- On `USR1` print segments referenced by each queue
- Log to file, via config option `log_file`
- New option `--build-info` to print build information (Crystal, LLVM version etc)
- New option `--no-data-dir-lock` to stop lock file being created
- Added `lavinmqctl` and `lavinmqperf` binaries to Docker images
- Packages and images built with Crystal 1.2.1 and LLVM 10
- Keep debug symbols in Docker builds

### Fixed

- MFile (mmap) unmap pointer bug
- VHost definition import failed if default user was renamed
- Definitions export bug if compiled with LLVM 11
- Memory reporting on BSD/Mac, value was kbyte but handled as byte
- Assertions against acking wrong messages
- Handle IO::Error exceptions in read_loop

### Changed

- Unix domain socket default location changed to `/dev/shm/lavinmq-http.sock` on Linux
- Don't log if client EOF on connect, such as healthchecks

## [1.0.0-alpha.31] - 2021-06-28

### Fixed

- When starting, make sure to only load queues once even if the defintions.amqp includes creating/deleting the same queue multiple times
- Speed up logging by only looking at ENV once
- StartLimitIntervalSec was in the wrong SystemD service file section
- Catch and only log IO::Errors in accept loop (could happen if client disconnected very soon after TCP was established)

### Changed

- Log backtrace if unhandled exception occurs
- Only log if a publish confirm can't be delivered to client, don't raise

## [1.0.0-alpha.30] - 2021-04-25

### Fixed

- Restore PROXY protocol v2 functionality
- Correct header names for Received/Sent bytes in Connections listing

## [1.0.0-alpha.29] - 2021-04-23

### Fixed

- Build script fixes
- Charts rendered correctly

## [1.0.0-alpha.28] - 2021-04-23

### Added

- FreeBSD compatibility
- Crystal 1.0.0 compatibility
- Publisher confirm count to Overview chart
- Support for PROXY protocol v2, including SSL information

### Changed

- Delayed message exchange bug fix
- Trigger explicit GC of message segments on purge and delete queue

## [1.0.0-alpha.27] - 2021-03-09

### Added

- WebSocket support, for use with <https://github.com/cloudamqp/amqp-client.js>

### Changed

- Compress HTTP responses
- Faster restoring of queue indexes on boot

### Fixed

- Reply with FlowOk when getting Flow from channel
- Consitent clean up of dropped connections
- Mark vhost as dirty on boot to run at least one GC
- x-frame-options now applied correctly

## [1.0.0-alpha.26] - 2021-02-19

### Fixes

- Confirms are sent before messages are delivered to consumers
- Federation links connection recovery improved
- Null padded index files are truncated on restore
- File descriptors are always closed when files are deleted

### Changes

- Lower default segment size to 8MB
- Include client provided connection name (if any) in log statements

## [1.0.0-alpha.25] - 2021-01-30

### Fixed

- Deleted queues could reappear after a crash
- Never send frames to closed channels
- Checking RSS on OS X could fail when FD limit was reached
- Escaping connection name in UI to prevent XSS

### Changed

- Crystal 0.36.0 compability
- Don't open a temp write for every channel, only when needed

## [1.0.0-alpha.24] - 2021-01-26

### Added

- Support for consumer priority
- Display the timestamp of the first & last message in a Queue, reveals consumer lag

### Changed

- Index files are memory-mapped which makes them much faster
- Default git branch is renamed to main
- Default to 8MB segment size on non-Linux machines (that doesn't support hole punching)
- Default to 300s heartbeat timeout

### Fixed

- Consumer accounting wasn't right when client disconnected
- Some stats could overflow, fixed by making the counter UInt64

## [1.0.0-alpha.23] - 2021-01-22

### Fixed

- Federation: improvements to how messages are acked
- Segment positions must be in order for GC to work
- Show queue arguments in queue list

### Changed

- Removed ability to ack with requeue from HTTP API

## [1.0.0-alpha.22] - 2021-01-20

### Fixed

- Bug where we tried to write beyond segment capacity
- Missing return when bind/unbind preconditions failed
- Restore Queue@max_length_bytes when policy changes
- Start federation links when exchange policy is applied
- Don't expire messages when the queue has been closed
- Mark vhost as dirty when deleting or purging queues

### Changed

- Overwrite user on import definitions if used already exist
- Passwords are exported in RabbitMQ compatible format
- Message properties are included in shoveled and federated messages

## [1.0.0-alpha.21] - 2021-01-18

### Fixed

- Make sure client connections are cleaned up correctly
- Bug when creating and listing users in lavinmqctl
- Kill process if segment GC loop fails unexpectedly
- SegmentPosition is requeued if not expired
- Writes to `ack` file is always flushed to disk

### Added

- Autocomplete queues and exchanges in UI
- Create and delete queues and exchanges from lavinmqctl

## [1.0.0-alpha.20] - 2021-01-11

### Fixed

- x-max-length is always respected
- Validate x-max-priority
- Better handling in UI on server errors
- Remember table sorting option until session ends + correct sorting on page refresh
- Refresh last used time on queue when policy with expire applies to it
- Improved rendering of charts

### Changed

- Allow all printable ASCII characters in entity (queue and exchnage) names.

### Added

- Webhook shovel
- Autofill of update policy form when click on policy name in the queue, exchange or policies views.

## [1.0.0-alpha.19] - 2020-12-01

### Fixed

- Improved rendering of charts

### Changed

- Allow all printable ASCII characters in entity (queue and exchange) names.

## [1.0.0-alpha.18] - 2020-12-01

### Fixed

- Keep unacked messages sorted, as the merge sort in segment GC expects

## [1.0.0-alpha.17] - 2020-11-20

### Fixed

- Requeued messages wasn't always inserted back in correct order into the Ready queue
- Report correct disk usage for mmap:ed files
- Force close AMQP connections on shutdown after 10s timeout

### Changed

- Arguments given on command line overrides config file settings

## [1.0.0-alpha.16] - 2020-11-17

### Fixed

- Bug where messages larger than frame_max didn't get published properly

## [1.0.0-alpha.15] - 2020-11-17

### Fixed

- Message rate stats count messages in and out, not messages routed
- Charts now shows all the data it got, not limited

### Changed

- Debug symbols for ARM builds
- Only perform segment GC if messages has been consumed/deleted
- Copy message bodies (that fit in a single frame) to RAM before writing to msg store so that slow clients don't block
- frame_max lowered to 128kb

## [1.0.0-alpha.14] - 2020-11-11

### Fixed

- Write default definitions to disk immediately on start, don't wait for compaction
- Decreased memory usage when queues are long (~25%) and ~10% higher throughput performance
- Don't do unnecessary async msync syscalls

### Changed

- UI improvements
- Prefetch global now accounts for all consumers on the channel
- Improved HTTP API compatibility

### Added

- A lot more commands added to lavinmqctl

## [1.0.0-alpha.13] - 2020-10-30

### Fixed

- Messages that can't be delivered to client is properly requeued now
- Support for uploading definitions via the HTTP API (earlier only UI)
- Fixed a counter could overflow when there was more than 2GB of messages in the queues
- Many API calls are more robust when it's fed erroneous input data

### Changed

- Consistent HTTP status responses
- Smarter segment GC where we iterate the existing ready/unack queues instead of creating a new array
- Increase systemd max start time to 5min
- Optimize two cases in topic exchanges

### Added

- Building and distributing ARM64 debian and AMD64 RPM packages (via packagecloud.io)
- HTTP API documentation
- Log level is updated on SIGUP if changed in config

## [1.0.0-alpha.12] - 2020-10-25

### Added

- tcp_proxy_protocol config for if PROXY protocol is used on TCP connections

### Fixed

- Optimize publish of persisted messages when when publish confirm isn't enabled

## [1.0.0-alpha.11] - 2020-10-24

### Fixed

- Don't read message from disk on expiration unless required

## [1.0.0-alpha.10] - 2020-10-23

### Fixed

- Lower IOPS usage when messages are expired and all data doesn't fit in disk cache
- Churn metrics correctly reported from closed connections/channels

### Changed

- UI: Display more connection properties such as max_frame, TLS version and cipher
- UI: Nicer charts
- UI: Default sort order is now descending

### Added

- Releases are published on Docker hub: <https://hub.docker.com/repository/docker/cloudamqp/lavinmq>

## [1.0.0-alpha.9] - 2020-10-20

### Fixed

- Bug where segment files could be truncated at boot

### Changed

- Default segment size is now 1 GB (up from 32 MB)
- Report size of deleted segments without holes
- Truncate segments after last message (not hole punching)
- Looks for a config file at /etc/lavinmq
- Uses ENV["StateDirectory"] as data dir if set

### Added

- Support for systemd socket activation, both of the HTTP and AMQP sockets

## [1.0.0-alpha.8] - 2020-10-14

### Fixed

- All frames are counted as heartbeats, but we also make sure to send heartbeats if we only receive traffic
- Regression where only the first exchange to exchange binding was respected

### Added

- UI: Show exchange arguments

## [1.0.0-alpha.7] - 2020-10-13

### Fixed

- Send heartbeats at heartbeat timeout / 2
- UI: Always base64 bodies if not valid utf8
- HTTP API: Message stats on vhost
- HTTP API: More stat properites at /api/nodes
- HTTP API: Allow publishing msgs without body

## [1.0.0-alpha.6] - 2020-10-13

### Fixed

- GC collection doesn't close mmap:ings

## [1.0.0-alpha.5] - 2020-10-12

### Fixed

- Don't delete segments that might have references to it
- Write lock around segment rotation
- Don't double base64 encode message bodies in UI
- Allow PUT to queues without body

## [1.0.0-alpha.4] - 2020-10-12

### Fixed

- When allowing TLS 1.0 and 1.1, add SECLEVEL=1 to ciphers list (required in ubuntu/debian)
- Corrent page aligment when hole punching segment files

### Changed

- Don't strip debug symbols in debian/ubuntu package

## [1.0.0-alpha.3] - 2020-10-11

### Fixed

- Considerably faster garbage collection of segments and hole punching

### Changed

### Added

- tls_min_version configuration option, default is 1.2, but 1.0, 1.1 and 1.3 is are also allowed options
- tls_ciphers configuration option that sets enabled TLS ciphers (config and cmd line)
- Log IP when TLS connection fails
- Limit syscalls server is allowed to call, in systemd service file

- Don't log HTTP error when client disconnects

## [1.0.0-alpha.2] - 2020-10-08

### Fixed

- Routing of binding keys with multiple wildcards fixed

## [1.0.0-alpha.1] - 2020-10-07

### Fixed

- Memory usage monitoring is now showing current RSS, not max RSS
- Consumer cancellation doesn't requeue unacked messages
- UI: No more JSON parsing errors when the server is offline
- UI: Fix name filter pagination bug
- Support delayed exchange via policy and x-delayed-message exchange type
- Clear all user permissions to a vhost when it's deleted
- Allow exchange to exchange binding for internal exchanges
- Redeclare queue updatex expiration time correctly
- Stricter validation of queue argments
- Stricter validation of frame sizes
- Closing connections on missed heartbeat (even if the TCP connection is alive)
- Correctly requeue cancelled consumers messages on close
- Respect the not_in_use flag when deleting exchanges
- UI: Fixing the Unbind button on Exchange in the UI
- Support for Nack with delivery tag 0
- Stricter exchange and queue name validation
- Dead-letters can't loop
- Detect header/body frames that are out of order
- Don't allow binding/unbinding exclusive queues
- Use the shortest TTL of expiration header and queue message-ttl
- Validates the expiration field on publish
- Semantic comparison of headers when declaring queues/exchanges

### Changed

- On-disk file formats has changed so previous data directories are incompatible with this version
- Decreased memory usage and increased performance by reimplemented segment GC
- Only listen on localhost by default
- DEB packages are distributed via packagecloud.io
- Log less on shutdown
- Higher throughput due to revamped segment GC algorithm
- Validate x-match headers
- Don't allow declaring or deleting the default exchange
- lavinmqctl now uses a private unix socket for communication
- Make queue/exchange delete and unbind idempotent

### Added

- Support for consistent hash exchange
- Support for exchange federation
- Support for priority queues
- Ability to "pause" queues, stopping messages to be delivered to consumers
- max-length-bytes supported as queue argument and policy
- UI: Shows bytes of messages a queue hold
- UI: Show data rates and heartbeats in connections listing
- Reload TLS certificates on HUP signal
- systemctl reload lavinmq now supported in systemd (by sending HUP to main pid)
- UNIX socket support for HTTP server
- Documented how persistent exchange works in the readme
- Promethous exporter at /metrics
- Respect the CC header when dead-lettering
- Support for Decimal values in headers
- UI: Show Unroutable messages rates in Exchange graph
- UI: Churn stats
- Queue bind now substitutes empty queue and routing key values with last declared queue
- UserID header is now validate
- Better server properties sent on connection establishment

## [0.11.0] - 2020-07-01

### Changed

- Using mmap to read/write to the segment files, almost doubling the performance
- UI: format uptime, format numbers according to browser locale
- Automatically add permissions for the user creating a vhost to that vhost

### Added

- Persistent exchange support, an exchange that can republish messages to a queue
- Unroutable message count on exchanges
- perf throughput now accepts --time, --pmessages and --cmessages arguments
- perf throughput rate limiter is vastly improved and much more accurate
- robots.txt to disallow crawling of the mgmt UI

### Fixed

- The --persistent flag is actually being respected in lavinmqperf throughput
- On shutdown, force close client connections
- Can now successfully delete shovels that has connection problems

## [0.10.7] - 2020-06-19

### Fixed

- Prevent overflow exception in shovel, don't look for short queues

## [0.10.6] - 2020-06-19

### Fixed

- Fixed overflow exception in /api/nodes if uptime was more than Int32::MAX milliseconds

## [0.10.5] - 2020-06-18

### Fixed

- Crystal 0.35 compatibility
- Decrease segment position counter on queue delete

### Changed

- fsyncing on publish confirm as soon as possible (previously only every 200ms)

### Added

- robots.txt file to disallow crawling
- Possibility to cancel consumers from the UI

## [0.10.4] - 2020-06-09

### Fixed

- Only use `copy_file_range` when the glibc version supports it

### Added

- Display message rates in queues list in mgmt UI
- Config for changing endianess of on-disk data

## [0.10.3] - 2020-05-26

### Fixed

- XSS in shovel UI
- Echo incoming heartbeat if we didn't send one recently

### Changed

- Faster segment GC
- Using zero-copy syscall `copy_file_range` between temp file and segment

## [0.10.2] - 2020-05-01

### Changed

- The way to find holes in segment files to punch is much improved

## [0.10.1] - 2020-04-26

### Fixed

- Updated amq-protocol.cr, fixes skipping headers in partial GC

## [0.10.0] - 2020-04-26

### Fixed

- All settings in the file config is respected now, not just a few

### Changed

- Partial GC of segments by hole punching, disk usage is much lower now
- Lower default file read buffer to 16KB
- Removed some HTTP protection measures that aren't applicable
- If writing to the definitions.amqp file fails abort the whole application
- Periodically write to the lock file to detect lost lock

### Added

- Does now notify systemd when properly started

## [0.9.16] - 2020-04-13

### Fixed

- Keep reference to the opened .lock file until shutdown so it's not GCed
- Publish stats correct

## [0.9.15] - 2020-04-09

### Fixed

- Crystal 0.34.x compability
- Rescue error while trying to parse the PROXY protocol
- Header exchange binding without arguments matches empty message headers
- lavinmqperf throughput now declares queues smarter

### Changed

- Decreased default file buffer size to 128kb
- Increased default socket buffer size to 16kb
- Log a warning if not built in release mode
- Print out data dir on start up
- Fiber.yield only in IO.copy, it balances clients better
- Don't log warnings if msg body can't be fully read from disconnected client

### Added

- .lock file in the data dir that's locked on start so that only one instance can use it at a time
- Protection against common HTTP attacks
- Nodes page with details on node usage
- Snapcraft configuration file
- Dockerfile

## [0.9.14] - 2020-03-25

### Fixed

- 'Move messages' in the UI now uses current user's credentials for the shovel
- Don't retry shovel if it's stopped
- /api/nodes fd_limit is now correct again
- Flush segment before resetting position if message write fails

## [0.9.13] - 2020-03-24

### Fixed

- Message bodies larger than frame_max size weren't correctly written to disk
- If a segment is missing when reading metadata we stopped there, now we loop until we find a message we can read
- Ignore all errors when closing client socket
- If a body can't be read from socket, reset position on segment and continue (don't rotate segment)

### Changed

- File descriptor limit is automatically maximized on start
- Only keep one segment per queue open at any one time
- 'Lost connection' is now only reported on debug level

### Added

- In each vhost dir and each queue dir are now a file outputted with the plain text name

## [0.9.12] - 2020-03-22

### Fixed

- FD leak in queues. Segments weren't closed until all queue missed reference to it.

## [0.9.11] - 2020-03-20

### Fixed

- Bug when publishing to a queue that has reach its max-length
- Memory leak of queue lookup caches, the caches are now moved to the Channel

### Changed

- No logging of GC of segments, except in debug mode
- Message bodies smaller than a frame is written directly to disk
- Message bodies spread out over several frames to temporarily written to disk

### Added

- More stats in the /api/nodes endpoint, including CPU, diskspace, IOPS etc
- Structure the output of USR1 signal better

## [0.9.10] - 2020-03-12

### Changed

- Timestamps are only accurate to the second, giving a 10% publish speed boost
- Default value for queue_max_ack is doubled to 2M messages, decreasing number of index compactions
- Don't maintaine perfect round robin to consumers in high throughput scenarios, increasing delivery rate dramatically

## [0.9.9] - 2020-03-11

### Fixed

- Move messages between queues is now working again
- Connection view is working again
- Memory leak in queue's segment position cache fixed

### Changed

- Shovel now try to declare the source queue as passive, non-passive if that fails
- Using (faster) unchecked mutexes whenever possible

## [0.9.8] - 2020-03-09

### Fixed

- Applying TTL policy to existing queues works as expected
- Removing a policy removes its effect on existing queues
- Auto-delete queues are deleted in vhost as well when closed

### Changed

- Default to 0 heartbeat
- Use socket timeout for heartbeat sending, instead of a looping fiber
- Round message stat metrics to 1 decimal

### Added

- Report accumulated message stats in the /api/overview endpoint

## [0.9.7] - 2020-03-06

### Fixed

- Exchange to exchange bindings are restored at boot correctly

### Changed

- Rewritten garbage collection of message segments
- Rewritten mechanism for message index compaction
- Faster restore of queue message indexes
- Both transient and persistent messages are persisted between restarts

## [0.9.6] - 2020-03-02

### Added

- More reporting when on signal USR1
- Clear ShortString string pool on signal USR2

## [0.9.5] - 2020-02-27

### Fixed

- Message expiration loop didn't reset read position

## [0.9.4] - 2020-02-27

### Fixed

- Message expiration could end up in an infinite loop
- Auto-delete queues are not automatically deleted at shutdown/compaction
- Messages dropped due to queue max-length are now decreasing segment refcount
- Bsearch is used for reinserting messages into ready queue
- PUT /api/user now returns 204 for updating users (earlier 200)
- More info logging around queue index compaction

## [0.9.3] - 2020-02-25

### Fixed

- Channel#timeout is used for queue/msg expiration

### Changed

- Only ignore publish frames on closed channels
- Different log message if user is missing or password is wrong

### Added

- Signal USR1 prints various stats
- Signal USR2 forces a GC collect
- Signal HUP only reloads the config file

## [0.9.2] - 2020-02-17

### Fixed

- Changes to users (password, tags) are store to disk

### Changed

- Crystal 0.33.0
- lavinmqperf: use fibers, don't fork
- Only ack:ing persistent messages are now written to the queue index
- Mutexes around the unacked dequeue in Consumer, for thread safety

### Added

- lavinmqperf: --persistent flag for throughput tests
- lavinmqperf: queues are now bound to the exchange

## [0.9.1] - 2020-02-13

### Changed

- GC message segments periodically instead of on rotation
- Compacting queue indexes in a more efficient way
- New implementation of Shovel, based on amqp-client.cr

### Added

- gc_segments_interval configration, how often to GC message segments
- queue_max_acks configration, compact/GC queue indexes after this many acks
- Reloading configuration on SIGHUP

## [0.9.0] - 2020-01-30

### Fixed

- Crystal 0.32.x compatiblity (avoid reentrant mutexes)
- Reference couting of messages in segments for GC purposes could go negative
- Multiple dead lettering bugs
- Faster restoring of indexes by using another data type
- Make amq.default exchange clickable in the web UI
- Make it possible to unbind bindings with empty routing key in web UI
- Dead letter publishes won't cause a publish loop due to cached look up

### Added

- Queue bind with empty queue name default to last declared tmp queue
- Don't allow binding/unbinding from the default exchange
- Nicer formatting of numbers in the web UI
- Now possible to unbind binding from the exchange view in the web UI

### Changed

- More efficent amq.default exchange

## [0.8.6] - 2019-10-03

### Fixed

- Crystal 0.31.0 and multi threading compability
- Make stat counters UInt64 to avoid overflows
- Send ConfirmOk before adding consumer to queue
- Correctly report FD limit in Linux

### Changed

- Round rates in the UI to 1 decimal
- lavinmqperf throughput now forks for each connection instead of spawn
- Speed up GC of segments by using reference counting

## [0.8.5] - 2019-09-19

### Fixed

- Sorting of numbers is done correctly

### Changed

- Dont wakeup the heartbeat loop on connection cleanup, might be the cause of a Invalid memory access
- Don't fallocate/preallocate segment or index files, minimal performance gain on XFS

### Added

- Applications array with LavinMQ version added to /api/nodes response

## [0.8.4] - 2019-09-18

### Fixed

- Overview rate stats doesn't overflow anymore
- Segment size in config is respected
- Queues now closes all FDs to segments it doesn't reference

## [0.8.3] - 2019-09-16

### Fixed

- Basic::GetEmpty responses are correctly encoded
- Timestamps are correctly parsed (as seconds, not ms)

### Changed

- Logging of clients disconnected is debug level now

## [0.8.2] - 2019-07-21

### Changed

- Faster queue matching on publishing by reusing a Set
- Faster GC of unused message store segments
- Do not enable TCP_NODELAY
- Faster lavinmqproxy

## [0.8.1] - 2019-07-19

### Changed

- Restored fairness between publishers
- Use a SparseArray as channel store, for faster access times

## [0.8.0] - 2019-07-16

### Added

- Fsyncing message store and queue index if publish confirm, when idle or every 200ms

### Changed

- AMQ::Protocol::Table is now backed by an IO::Memory and only parsed on-demand

## [0.7.13] - 2019-07-07

### Changed

- Separate buffer_size configuration for files and sockets
- Fsync when writing defintions, vhosts and users

## [0.7.12] - 2019-06-28

### Added

- Make buffer_size configurable via config and increase default from 8KB to 128KB
- Pre-allocate the max size for new segments, might improve write performance (on Linux only)

## [0.7.11] - 2019-06-20

### Changed

- Revert to write lock behavior, but yield only when queue length > 10000

## [0.7.10] - 2019-06-19

### Fixed

- AMQPLAIN support in shovels is implemented correctly

### Added

ShortStrings are now added to StringPool for reduced GC pressure, the pool size is printed on HUP

### Changed

- Make setting the timestamp property optional through a config setting (set_timestamp), default to false
- Optimized topic exchange and fanout routing, giving ~5% and ~30% throughput boost respectively
- Using a Channel to communicate between Client and Vhost when publishing, removed the need for a lock

## [0.7.9] - 2019-06-10

### Fixed

- Restore ability to login with AMQPLAIN mechanism
- Making a binding via the HTTP API without a routing key threw an exception

## [0.7.8] - 2019-06-08

### Fixed

- Fix account of position in delivery loop so that we don't have to seek on disk

### Changed

- Optimize disconnection of consumers with many unacked messages

## [0.7.7] - 2019-06-07

### Fixed

- Always copy msg body to memory before writing to disk to avoid corruption if client disconnects mid-stream
- Reset position of segment when an exception is caught in delivery loop

### Changed

- chmod the unix domain socket to 777, authentication is done on the protocol level anyway

### Added

- CHANGELOG file
