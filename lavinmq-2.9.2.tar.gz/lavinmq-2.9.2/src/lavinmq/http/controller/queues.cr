require "uri"
require "../controller"
require "../binding_helpers"
require "../../unacked_message"
require "../../name_validator"

module LavinMQ
  module HTTP
    module QueueHelpers
      private def find_queue(context, params, vhost, key = "name")
        name = params[key]
        q = vhost.queue?(name)
        not_found(context, "Not Found") unless q
        q
      end

      private def find_stream(context, vhost, name)
        q = vhost.queue?(name)
        not_found(context, "Not Found") unless q
        not_found(context, "Not Found") unless q.is_a?(LavinMQ::AMQP::Stream)
        q.as(LavinMQ::AMQP::Stream)
      end
    end

    class QueuesController < Controller
      include BindingHelpers
      include QueueHelpers

      # ameba:disable Metrics/CyclomaticComplexity
      private def register_routes
        get "/api/queues" do |context, _|
          itr = vhosts(user(context)).flat_map &.queues
          page(context, itr)
        end

        get "/api/queues/:vhost" do |context, params|
          with_vhost(context, params) do |vhost|
            refuse_unless_management(context, user(context), vhost)
            page(context, vhost.queues)
          end
        end

        get "/api/queues/:vhost/:name" do |context, params|
          with_vhost(context, params) do |vhost|
            refuse_unless_management(context, user(context), vhost)
            consumer_limit = context.request.query_params["consumer_list_length"]?.try &.to_i || -1
            JSON.build(context.response) do |json|
              find_queue(context, params, vhost).to_json(json, consumer_limit)
            end
          end
        end

        get "/api/queues/:vhost/:name/unacked" do |context, params|
          with_vhost(context, params) do |vhost|
            refuse_unless_management(context, user(context), vhost)
            q = find_queue(context, params, vhost)
            unacked_messages = q.unacked_messages
            page(context, unacked_messages)
          end
        end

        put "/api/queues/:vhost/:name" do |context, params|
          with_vhost(context, params) do |vhost|
            refuse_unless_management(context, user(context), vhost)
            user = user(context)
            name = params["name"]
            name = AMQP::Queue.generate_name if name.empty?
            body = parse_body(context)
            durable = body["durable"]?.try(&.as_bool?) || false
            auto_delete = body["auto_delete"]?.try(&.as_bool?) || false
            tbl = (args = body["arguments"]?.try(&.as_h?)) ? AMQP::Table.new(args) : AMQP::Table.new
            dlx = tbl["x-dead-letter-exchange"]?.try &.as?(String)
            dlx_ok = dlx.nil? || (user.can_write?(vhost.name, dlx) && user.can_read?(vhost.name, name))
            unless user.can_config?(vhost.name, name) && dlx_ok
              access_refused(context, "User doesn't have permissions to declare queue '#{name}'")
            end
            q = vhost.queue?(name)
            if q
              unless q.match?(durable, false, auto_delete, tbl)
                bad_request(context, "Existing queue declared with other arguments arg")
              end
              context.response.status_code = 204
            elsif NameValidator.reserved_prefix?(name)
              bad_request(context, "Prefix #{NameValidator::PREFIX_LIST} forbidden, please choose another name")
            elsif name.bytesize > UInt8::MAX
              bad_request(context, "Queue name too long, can't exceed 255 characters")
            else
              vhost.declare_queue(name, durable, auto_delete, tbl)
              context.response.status_code = 201
            end
          end
        end

        put "/api/queues/:vhost/:name/pause" do |context, params|
          with_vhost(context, params) do |vhost|
            refuse_unless_management(context, user(context), vhost)
            q = find_queue(context, params, vhost)
            q.pause!
            context.response.status_code = 204
          end
        end

        put "/api/queues/:vhost/:name/resume" do |context, params|
          with_vhost(context, params) do |vhost|
            refuse_unless_management(context, user(context), vhost)
            q = find_queue(context, params, vhost)
            q.resume!
            context.response.status_code = 204
          end
        end

        put "/api/queues/:vhost/:name/restart" do |context, params|
          with_vhost(context, params) do |vhost|
            refuse_unless_management(context, user(context), vhost)
            q = find_queue(context, params, vhost)
            if q.restart!
              context.response.status_code = 204
            else
              bad_request(context, "Queue was not restarted")
            end
          end
        end

        delete "/api/queues/:vhost/:name" do |context, params|
          with_vhost(context, params) do |vhost|
            refuse_unless_management(context, user(context), vhost)
            q = find_queue(context, params, vhost)
            user = user(context)
            unless user.can_config?(q.vhost.name, q.name)
              access_refused(context, "User doesn't have permissions to delete queue '#{q.name}'")
            end
            if context.request.query_params["if-unused"]? == "true"
              bad_request(context, "Queue #{q.name} in vhost #{q.vhost.name} in use") if q.in_use?
            end
            vhost.delete_queue(q.name)
            context.response.status_code = 204
          end
        end

        get "/api/queues/:vhost/:name/bindings" do |context, params|
          with_vhost(context, params) do |vhost|
            refuse_unless_management(context, user(context), vhost)
            queue = find_queue(context, params, vhost)
            page(context, queue.bindings)
          end
        end

        delete "/api/queues/:vhost/:name/contents" do |context, params|
          with_vhost(context, params) do |vhost|
            user = user(context)
            refuse_unless_management(context, user, vhost)
            q = find_queue(context, params, vhost)
            unless user.can_read?(vhost.name, q.name)
              access_refused(context, "User doesn't have permissions to read queue '#{q.name}'")
            end
            count = context.request.query_params["count"]? || ""
            if count.empty?
              q.purge
            else
              count_i = count.to_i?
              bad_request(context, "Count must be a number") if count_i.nil?
              bad_request(context, "Count must be greater than 0") if count_i <= 0
              q.purge(count_i)
            end
            context.response.status_code = 204
          end
        end

        post "/api/queues/:vhost/:name/get" do |context, params|
          with_vhost(context, params) do |vhost|
            user = user(context)
            refuse_unless_management(context, user, vhost)
            q = find_queue(context, params, vhost)
            unless user.can_read?(q.vhost.name, q.name)
              access_refused(context, "User doesn't have permissions to read queue '#{q.name}'")
            end
            if q.state != QueueState::Running && q.state != QueueState::Paused
              forbidden(context, "Can't get from queue that is not in running state")
            end
            body = parse_body(context)
            get_count = body["count"]?.try(&.as_i) || 1
            ack_mode = (body["ack_mode"]? || body["ackmode"]?).try(&.as_s) || "get"
            encoding = body["encoding"]?.try(&.as_s) || "auto"
            truncate = body["truncate"]?.try(&.as_i)
            requeue = body["requeue"]?.try(&.as_bool) || ack_mode == "reject_requeue_true"
            ack = ack_mode == "get"
            bad_request(context, "Cannot requeue message on get") if ack && requeue
            JSON.build(context.response) do |j|
              j.array do
                sps = Array(SegmentPosition).new(get_count)
                get_count.times do
                  q.basic_get(false, true) do |env|
                    sps << env.segment_position
                    # Track vhost-level metrics for HTTP API consumption
                    event_type = ack ? EventType::ClientGet : EventType::ClientGetNoAck
                    vhost.event_tick(event_type)
                    vhost.add_send_bytes(env.message.bodysize.to_u64)
                    j.object do
                      payload_encoding = "string"
                      j.field("payload_bytes", env.message.bodysize)
                      j.field("redelivered", env.redelivered)
                      j.field("exchange", env.message.exchange_name)
                      j.field("routing_key", env.message.routing_key)
                      j.field("message_count", q.message_count)
                      j.field("properties", env.message.properties)
                      j.field("payload") do
                        j.string do |io|
                          payload_encoding = encode_body(env.message, truncate, encoding, io)
                        end
                      end
                      j.field("payload_encoding", payload_encoding)
                    end
                  end || break
                end
                # Shift each sp off before finalizing it, so `sps` only holds messages
                # that aren't finalized yet. An sp whose #ack/#reject raised halfway
                # has already been decremented, so the rescue below must not touch it.
                while sp = sps.shift?
                  if ack
                    q.ack(sp)
                  else
                    q.reject(sp, requeue)
                  end
                end
              rescue e : Exception
                # Requeue the messages that aren't finalized yet
                if unacked_sps = sps
                  unacked_sps.each do |unacked_sp|
                    q.reject(unacked_sp, true)
                  end
                end
                raise e
              end
            end
          end
        end

        post "/api/queues/:vhost/:name/stream" do |context, params|
          with_vhost(context, params) do |vhost|
            user = user(context)
            refuse_unless_management(context, user, vhost)
            q = find_stream(context, vhost, params["name"])
            unless user.can_read?(q.vhost.name, q.name)
              access_refused(context, "User doesn't have permissions to read stream '#{q.name}'")
            end
            if q.state != QueueState::Running && q.state != QueueState::Paused
              forbidden(context, "Can't read from stream that is not in running state")
            end
            body = parse_body(context)
            count = body["count"]?.try(&.as_i) || 1
            count = 0 if count < 0
            offset = body["offset"]?.try(&.as_s) || "first"
            offset = offset.to_i64 if /^\d+$/.match(offset)
            encoding = body["encoding"]?.try(&.as_s) || "auto"
            truncate = body["truncate"]?.try(&.as_i)
            reader = q.reader(offset)
            JSON.build(context.response) do |j|
              j.array do
                reader.each do |env|
                  break if count.zero?
                  payload_encoding = "string"
                  j.object do
                    j.field("payload_bytes", env.message.bodysize)
                    j.field("redelivered", env.redelivered)
                    j.field("exchange", env.message.exchange_name)
                    j.field("routing_key", env.message.routing_key)
                    j.field("message_count", q.message_count)
                    j.field("properties", env.message.properties)
                    j.field("payload") do
                      j.string do |io|
                        payload_encoding = encode_body(env.message, truncate, encoding, io)
                      end
                    end
                    j.field("payload_encoding", payload_encoding)
                  end
                  count -= 1
                end
              end
            end
          rescue e : LavinMQ::AMQP::StreamMessageStore::OffsetError
            bad_request(context, e.message)
          end
        end
      end

      private def encode_body(message, truncate, encoding, io) : String
        size = truncate ? Math.min(truncate, message.bodysize) : message.bodysize
        payload = message.body[0, size]
        if encoding == "base64" || !Unicode.valid?(payload)
          Base64.urlsafe_encode(payload, io)
          "base64"
        else
          io.write payload
          "string"
        end
      end
    end
  end
end
