require "../spec_helper"
require "string_scanner"

describe LavinMQ::HTTP::PrometheusController do
  describe "authentication" do
    it "should allow unauthenticated access to metrics on metrics port" do
      with_metrics_server do |http, _|
        response = http.get("/metrics")
        response.status_code.should eq 200
      end
    end
    it "should require authenticated access to metrics on mgmt port" do
      with_http_server do |http, _|
        response = HTTP::Client.get("http://#{http.addr}/metrics")
        response.status_code.should eq 401
      end
    end
  end
  describe "GET /metrics" do
    it "should return metrics in prometheus style" do
      with_metrics_server do |http, _|
        response = http.get("/metrics")
        response.status_code.should eq 200
        response.body.lines.any?(&.starts_with? "telemetry_scrape_duration_seconds").should be_true
      end
    end

    it "should perform sanity check on sampled metrics" do
      with_metrics_server do |http, s|
        vhost = s.vhosts.create("pmths")
        vhost.declare_queue("test1", true, false)
        vhost.delete_queue("test1")
        vhost.declare_queue("test2", true, false)
        raw = http.get("/metrics").body
        parsed_metrics = PrometheusSpecHelper.parse_prometheus(raw)
        parsed_metrics.each do |metric|
          case metric[:key]
          when "lavinmq_queues_declared_total"
            metric[:value].should eq 2
          when "lavinmq_queues"
            metric[:value].should eq 1
          end
        end
      end
    end

    it "should expose the number of bindings" do
      with_metrics_server do |http, s|
        vhost = s.vhosts.create("pmthb")
        vhost.declare_queue("bq", true, false)
        vhost.bind_queue("bq", "amq.topic", "rk1")
        vhost.bind_queue("bq", "amq.topic", "rk2")
        raw = http.get("/metrics").body
        parsed_metrics = PrometheusSpecHelper.parse_prometheus(raw)
        bindings = parsed_metrics.find { |m| m[:key] == "lavinmq_bindings" }
        bindings.should_not be_nil
        bindings.try(&.[:value].should eq 2)
      end
    end

    it "should count all delivered messages (both get and deliver)" do
      with_metrics_server do |http, s|
        with_channel(s) do |ch|
          q = ch.queue("test_deliver")
          ch.prefetch(1)

          # Get baseline
          raw = http.get("/metrics").body
          parsed_metrics = PrometheusSpecHelper.parse_prometheus(raw)
          delivered = parsed_metrics.find { |m| m[:key] == "lavinmq_global_messages_delivered_total" }
          baseline = delivered.try(&.[:value]) || 0

          # Publish 3 messages
          3.times { q.publish "test message" }

          # Deliver 1 message via get (polling consumer)
          msg = q.get(no_ack: false)
          msg.should_not be_nil
          msg.try &.ack

          # Deliver 2 messages via subscribe (push consumer)
          delivered_count = 0
          q.subscribe(no_ack: false) do |delivery|
            delivered_count += 1
            delivery.ack
          end
          wait_for { delivered_count == 2 }

          # Check metrics - should count all 3 deliveries
          raw = http.get("/metrics").body
          parsed_metrics = PrometheusSpecHelper.parse_prometheus(raw)
          delivered = parsed_metrics.find { |m| m[:key] == "lavinmq_global_messages_delivered_total" }
          delivered.should_not be_nil
          delivered.try(&.[:value].should eq(baseline + 3))
        end
      end
    end

    it "should count returned unroutable messages" do
      with_metrics_server do |http, s|
        with_channel(s) do |ch|
          returned = Channel(Nil).new
          ch.on_return { |_msg| returned.send nil }
          ch.basic_publish("m1", "amq.direct", "none", mandatory: true)
          returned.receive
        end
        raw = http.get("/metrics").body
        parsed_metrics = PrometheusSpecHelper.parse_prometheus(raw)
        metric = parsed_metrics.find { |m| m[:key] == "lavinmq_global_messages_unroutable_returned_total" }
        metric.should_not be_nil
        metric.try(&.[:value].should eq 1)
      end
    end

    it "should support specifying prefix" do
      with_metrics_server do |http, _|
        prefix = "testing"
        response = http.get("/metrics?prefix=#{prefix}")
        lines = response.body.lines
        lines.count(&.starts_with? "telemetry").should eq 2
        metric_lines = lines.reject(&.starts_with? "#")
        prefix_lines = lines.select(&.starts_with? prefix)
        prefix_lines.size.should eq metric_lines.size - 2
      end
    end

    it "should not support a prefix longer than 20" do
      with_metrics_server do |http, _|
        prefix = "abcdefghijklmnopqrstuvwxyz"
        response = http.get("/metrics?prefix=#{prefix}")
        response.status_code.should eq 400
        response.body.should match /Prefix too long/
      end
    end

    it "should include mfile count metric" do
      with_metrics_server do |http, _|
        response = http.get("/metrics")
        response.status_code.should eq 200
        parsed_metrics = PrometheusSpecHelper.parse_prometheus(response.body)
        mfile_metric = parsed_metrics.find { |m| m[:key] == "lavinmq_mfile_count" }.should_not be_nil
        mfile_metric[:value].should be >= 0
      end
    end

    it "should expose gc pause time as a histogram" do
      with_metrics_server do |http, _|
        GC.collect
        lines = http.get("/metrics").body.lines
        lines.should contain "# TYPE lavinmq_gc_pause_seconds histogram"
        value = ->(prefix : String) do
          lines.find!(&.starts_with?(prefix)).split(' ').last.to_f
        end
        count = value.call("lavinmq_gc_pause_seconds_count ")
        count.should be > 0
        value.call("lavinmq_gc_pause_seconds_sum ").should be > 0
        value.call(%(lavinmq_gc_pause_seconds_bucket{le="+Inf"} )).should eq count
        buckets = lines.select(&.starts_with?("lavinmq_gc_pause_seconds_bucket"))
          .map(&.split(' ').last.to_f)
        buckets.should eq buckets.sort
      end
    end

    it "should expose socket buffer pool stats" do
      with_metrics_server do |http, s|
        with_channel(s) do |ch|
          q = ch.queue("buffer_pool_metrics")
          q.publish_confirm "m"
          q.get.should_not be_nil
        end
        parsed_metrics = PrometheusSpecHelper.parse_prometheus(http.get("/metrics").body)
        size = LavinMQ::Config.instance.socket_buffer_size.to_s
        %w[available allocated_total reused_total released_total dropped_total].each do |key|
          metric = parsed_metrics.find do |m|
            m[:key] == "lavinmq_socket_buffer_pool_#{key}" && m[:attrs]["buffer_size"]? == size
          end
          metric.should_not be_nil, "lavinmq_socket_buffer_pool_#{key} missing"
        end
        reused = parsed_metrics.find! do |m|
          m[:key] == "lavinmq_socket_buffer_pool_reused_total" && m[:attrs]["buffer_size"]? == size
        end
        reused[:value].should be > 0
      end
    end

    it "should report uptime anchored to PROCESS_START, surviving Server re-creation" do
      uptime1 = uninitialized Time::Span
      with_metrics_server do |_, server|
        uptime1 = server.uptime
      end
      with_metrics_server do |_, server|
        server.uptime.should be > uptime1
      end
    end
  end

  describe "vhost access control" do
    it "should only return metrics for vhosts the user has access to" do
      with_http_server do |http, s|
        # Create two vhosts
        vhost1 = s.vhosts.create("vhost1")
        vhost2 = s.vhosts.create("vhost2")

        # Create two users with management tag (required for metrics access)
        s.users.create("user1", "pass1", [LavinMQ::Tag::Management])
        s.users.create("user2", "pass2", [LavinMQ::Tag::Management])

        # Give each user access only to their respective vhost
        s.users.add_permission("user1", "vhost1", /.*/, /.*/, /.*/)
        s.users.add_permission("user2", "vhost2", /.*/, /.*/, /.*/)

        # Create a queue in each vhost
        vhost1.declare_queue("queue_in_vhost1", true, false)
        vhost2.declare_queue("queue_in_vhost2", true, false)

        # user1 should only see vhost1 queue metrics
        user1_auth = "Basic #{Base64.strict_encode("user1:pass1")}"
        response = http.get("/metrics/detailed?family=queue_coarse_metrics", HTTP::Headers{"Authorization" => user1_auth})
        response.status_code.should eq 200
        parsed = PrometheusSpecHelper.parse_prometheus(response.body)

        user1_queues = parsed.select { |m| m[:key] == "lavinmq_detailed_queue_messages_ready" }
        user1_queues.size.should eq 1
        user1_queues.first[:attrs]["queue"].should eq "queue_in_vhost1"
        user1_queues.first[:attrs]["vhost"].should eq "vhost1"

        # user2 should only see vhost2 queue metrics
        user2_auth = "Basic #{Base64.strict_encode("user2:pass2")}"
        response = http.get("/metrics/detailed?family=queue_coarse_metrics", HTTP::Headers{"Authorization" => user2_auth})
        response.status_code.should eq 200
        parsed = PrometheusSpecHelper.parse_prometheus(response.body)

        user2_queues = parsed.select { |m| m[:key] == "lavinmq_detailed_queue_messages_ready" }
        user2_queues.size.should eq 1
        user2_queues.first[:attrs]["queue"].should eq "queue_in_vhost2"
        user2_queues.first[:attrs]["vhost"].should eq "vhost2"
      end
    end
  end

  describe "GET /metrics/detailed" do
    it "writes a body larger than the writer buffer completely" do
      with_metrics_server do |http, s|
        vhost = s.vhosts.create("chunked")
        200.times { |i| vhost.declare_queue("q-#{i}", false, false) }
        body = http.get("/metrics/detailed?family=queue_coarse_metrics").body
        body.bytesize.should be > LavinMQ::HTTP::PrometheusWriter::BUFFER_SIZE
        lines = body.lines
        ready = lines.select(&.starts_with?("lavinmq_detailed_queue_messages_ready{"))
        ready.count(&.includes?(%(vhost="chunked"))).should eq 200
        lines.last.should start_with "telemetry_scrape_mem"
      end
    end

    it "should support specifying families" do
      with_metrics_server do |http, _|
        response = http.get("/metrics/detailed?family=connection_churn_metrics")
        response.status_code.should eq 200
        lines = response.body.lines
        lines.any?(&.starts_with? "lavinmq_detailed_connections_opened_total").should be_true

        response = http.get("/metrics/detailed?family=family=queue_coarse_metrics")
        response.status_code.should eq 200
        lines = response.body.lines
        lines.any?(&.starts_with? "lavinmq_detailed_connections_opened_total").should be_false
      end
    end

    it "should perform sanity check on sampled metrics" do
      with_metrics_server do |http, s|
        with_channel(s) do |_|
        end
        with_channel(s) do |_|
          raw = http.get("/metrics/detailed?family=connection_churn_metrics").body
          parsed_metrics = PrometheusSpecHelper.parse_prometheus(raw)
          parsed_metrics.find! { |metric| metric[:key] == "lavinmq_detailed_connections_opened_total" }[:value].should eq 2
          parsed_metrics.find! { |metric| metric[:key] == "lavinmq_detailed_connections_closed_total" }[:value].should eq 1
        end
      end
    end

    it "should expose per-vhost message stats" do
      with_metrics_server do |http, s|
        vhost = s.vhosts.create("vms_test")
        s.users.add_permission("guest", vhost.name, /.*/, /.*/, /.*/)
        vhost.declare_queue("q1", true, false)
        vhost.declare_queue("q2", true, false)
        with_channel(s, vhost: vhost.name) do |ch|
          q = ch.queue("q1", durable: true)
          q.publish_confirm "msg-a"
          q.publish_confirm "msg-b"
          q.publish_confirm "msg-c"
          q.get(no_ack: true).should_not be_nil
        end

        raw = http.get("/metrics/detailed?family=vhost_message_stats").body
        parsed = PrometheusSpecHelper.parse_prometheus(raw)

        publishes = parsed.find! do |m|
          m[:key] == "lavinmq_detailed_vhost_messages_published_total" &&
            m[:attrs]["vhost"] == "vms_test"
        end
        publishes[:value].should eq 3

        deliveries = parsed.find! do |m|
          m[:key] == "lavinmq_detailed_vhost_messages_delivered_total" &&
            m[:attrs]["vhost"] == "vms_test"
        end
        deliveries[:value].should eq 1

        queues = parsed.find! do |m|
          m[:key] == "lavinmq_detailed_vhost_queues" &&
            m[:attrs]["vhost"] == "vms_test"
        end
        queues[:value].should eq 2
      end
    end

    it "should count mqtt sessions in detailed_vhost_queues" do
      with_metrics_server do |http, s|
        vhost = s.vhosts.create("vq_test")
        s.users.add_permission("guest", vhost.name, /.*/, /.*/, /.*/)
        vhost.declare_queue("q1", true, false)
        vhost.declare_queue("mqtt.c1", true, false, LavinMQ::AMQP::Table.new({"x-queue-type" => "mqtt"}))

        raw = http.get("/metrics/detailed?family=vhost_message_stats").body
        parsed = PrometheusSpecHelper.parse_prometheus(raw)

        queues = parsed.find! do |m|
          m[:key] == "lavinmq_detailed_vhost_queues" &&
            m[:attrs]["vhost"] == "vq_test"
        end
        queues[:value].should eq 2
      end
    end

    it "should label channel metrics with vhost and connection" do
      with_metrics_server do |http, s|
        vhost = s.vhosts.create("ch_label_test")
        s.users.add_permission("guest", vhost.name, /.*/, /.*/, /.*/)
        with_channel(s, vhost: vhost.name) do |ch|
          q = ch.queue("ch_q", durable: false, auto_delete: true)
          q.subscribe(no_ack: false) { |_| }
          wait_for { !ch.@consumers.empty? }

          raw = http.get("/metrics/detailed?family=channel_metrics").body
          lines = raw.lines.select(&.starts_with?("lavinmq_detailed_channel_consumers{"))

          lines.size.should be > 0
          relevant = lines.find(&.includes?(%(vhost="ch_label_test")))
          line = relevant.should_not be_nil
          # connection label is the server-generated "remote -> local" name; just verify it's present and non-empty
          line.should match(/connection="[^"]+"/)
          line.should match(/channel="[^"]+"/)
        end
      end
    end

    it "should group TYPE and HELP by metric name" do
      with_metrics_server do |http, s|
        vhost = s.vhosts.create("grouping_test")
        vhost.declare_queue("queue_1", true, false)
        vhost.declare_queue("queue_2", true, false)
        vhost.declare_queue("queue_3", true, false)

        raw = http.get("/metrics/detailed?family=queue_coarse_metrics").body
        lines = raw.lines

        # Count occurrences of TYPE declarations for detailed_queue_messages_ready
        type_count = lines.count(&.includes?("# TYPE lavinmq_detailed_queue_messages_ready"))
        help_count = lines.count(&.includes?("# HELP lavinmq_detailed_queue_messages_ready"))

        # Should appear exactly once, not once per queue
        type_count.should eq 1
        help_count.should eq 1

        # But values should appear for each queue (3 queues)
        value_count = lines.count(&.starts_with?("lavinmq_detailed_queue_messages_ready{"))
        value_count.should eq 3

        # Verify grouping: TYPE and HELP should immediately precede the values
        # Find TYPE line index, HELP should be next, then values should follow
        type_idx = lines.index(&.includes?("# TYPE lavinmq_detailed_queue_messages_ready")).should_not be_nil
        help_idx = lines.index(&.includes?("# HELP lavinmq_detailed_queue_messages_ready")).should_not be_nil
        first_value_idx = lines.index(&.starts_with?("lavinmq_detailed_queue_messages_ready{")).should_not be_nil

        # HELP should come right after TYPE
        help_idx.should eq(type_idx + 1)
        # First value should come right after HELP
        first_value_idx.should eq(help_idx + 1)
      end
    end

    it "should expose per-queue delivered and acked counters" do
      with_metrics_server do |http, s|
        with_channel(s) do |ch|
          q = ch.queue("test_detailed_counters")

          # Publish 2 messages
          2.times { q.publish "test message" }

          # Consume and ack both via subscribe
          delivered_count = 0
          q.subscribe(no_ack: false) do |delivery|
            delivered_count += 1
            delivery.ack
          end
          wait_for { delivered_count == 2 }

          should_eventually(eq(2)) do
            raw = http.get("/metrics/detailed?family=queue_coarse_metrics").body
            parsed = PrometheusSpecHelper.parse_prometheus(raw)
            delivered = parsed.find do |m|
              m[:key] == "lavinmq_detailed_queue_messages_delivered_total" &&
                m[:attrs]["queue"] == "test_detailed_counters" &&
                m[:attrs]["vhost"] == "/"
            end.should_not be_nil
            delivered[:value]
          end

          should_eventually(eq(2)) do
            raw = http.get("/metrics/detailed?family=queue_coarse_metrics").body
            parsed = PrometheusSpecHelper.parse_prometheus(raw)
            acked = parsed.find do |m|
              m[:key] == "lavinmq_detailed_queue_messages_acked_total" &&
                m[:attrs]["queue"] == "test_detailed_counters" &&
                m[:attrs]["vhost"] == "/"
            end.should_not be_nil
            acked[:value]
          end
        end
      end
    end
  end
end

describe "LavinMQ::HTTP::PrometheusController dead-lettered metrics" do
  it "counts messages rejected or nacked without requeue" do
    with_metrics_server do |http, s|
      with_channel(s) do |ch|
        plain, dlx = declare_dead_letter_queues(ch, {} of String => AMQ::Protocol::Field)
        plain.publish_confirm "m"
        dlx.publish_confirm "m"
        plain.get(no_ack: false).should_not(be_nil).reject(requeue: false)
        dlx.get(no_ack: false).should_not(be_nil).nack(requeue: false)

        should_eventually(eq(1)) { dead_lettered_counter(http, "rejected", "disabled") }
        should_eventually(eq(1)) { dead_lettered_counter(http, "rejected", "at_most_once") }
        dead_lettered_counter(http, "expired", "disabled").should eq 0
      end
    end
  end

  it "counts messages expired by TTL" do
    with_metrics_server do |http, s|
      with_channel(s) do |ch|
        plain, dlx = declare_dead_letter_queues(ch, {"x-message-ttl" => 1} of String => AMQ::Protocol::Field)
        plain.publish_confirm "m"
        dlx.publish_confirm "m"

        should_eventually(eq(1)) { dead_lettered_counter(http, "expired", "disabled") }
        should_eventually(eq(1)) { dead_lettered_counter(http, "expired", "at_most_once") }
      end
    end
  end

  it "counts messages dropped by max-length and max-length-bytes as maxlen" do
    with_metrics_server do |http, s|
      with_channel(s) do |ch|
        plain, _ = declare_dead_letter_queues(ch, {"x-max-length" => 1} of String => AMQ::Protocol::Field)
        _, dlx = declare_dead_letter_queues(ch, {"x-max-length-bytes" => 1} of String => AMQ::Protocol::Field, suffix: "bytes")
        3.times { plain.publish_confirm "m" }
        2.times { dlx.publish_confirm "m" }

        should_eventually(eq(2)) { dead_lettered_counter(http, "maxlen", "disabled") }
        should_eventually(eq(2)) { dead_lettered_counter(http, "maxlen", "at_most_once") }
      end
    end
  end

  it "counts messages exceeding the delivery limit" do
    with_metrics_server do |http, s|
      with_channel(s) do |ch|
        plain, dlx = declare_dead_letter_queues(ch, {"x-delivery-limit" => 1} of String => AMQ::Protocol::Field)
        {plain, dlx}.each do |q|
          q.publish_confirm "m"
          2.times { wait_for { q.get(no_ack: false) }.should_not(be_nil).reject(requeue: true) }
        end

        should_eventually(eq(1)) { dead_lettered_counter(http, "delivery_limit", "disabled") }
        should_eventually(eq(1)) { dead_lettered_counter(http, "delivery_limit", "at_most_once") }
      end
    end
  end

  it "keeps counters when queues and vhosts are deleted" do
    with_metrics_server do |http, s|
      vhost = s.vhosts.create("dl_mono")
      s.users.add_permission("guest", vhost.name, /.*/, /.*/, /.*/)
      with_channel(s, vhost: vhost.name) do |ch|
        plain, dlx = declare_dead_letter_queues(ch, {"x-max-length" => 1} of String => AMQ::Protocol::Field)
        2.times { plain.publish_confirm "m" }
        2.times { dlx.publish_confirm "m" }
      end
      should_eventually(eq(1)) { dead_lettered_counter(http, "maxlen", "disabled") }
      should_eventually(eq(1)) { dead_lettered_counter(http, "maxlen", "at_most_once") }

      vhost.delete_queue("dl_plain")
      vhost.delete_queue("dl_dlx")
      dead_lettered_counter(http, "maxlen", "disabled").should eq 1
      dead_lettered_counter(http, "maxlen", "at_most_once").should eq 1

      s.vhosts.delete("dl_mono")
      dead_lettered_counter(http, "maxlen", "disabled").should eq 1
      dead_lettered_counter(http, "maxlen", "at_most_once").should eq 1
    end
  end
end

describe "LavinMQ::HTTP::PrometheusController counter monotonicity" do
  # Counter series must never decrease: rate()/increase() read a drop as a reset
  # and fabricate a spike. These exercise the queue/vhost churn that caused it.

  it "keeps global_messages_delivered_total monotonic when a queue is deleted" do
    with_metrics_server do |http, s|
      vhost = s.vhosts.create("mono_qdel")
      s.users.add_permission("guest", vhost.name, /.*/, /.*/, /.*/)
      with_channel(s, vhost: vhost.name) do |ch|
        q = ch.queue("doomed", durable: true)
        3.times { q.publish_confirm "m" }
        3.times { q.get(no_ack: true).should_not be_nil }
      end

      before = prometheus_counter(http, "lavinmq_global_messages_delivered_total")
      before.should be >= 3

      # Deleting the queue must not drop the global counter.
      vhost.delete_queue("doomed")

      after = prometheus_counter(http, "lavinmq_global_messages_delivered_total")
      after.should be >= before
    end
  end

  it "keeps queues_declared_total monotonic when a vhost is deleted" do
    with_metrics_server do |http, s|
      vhost = s.vhosts.create("mono_vdel")
      vhost.declare_queue("q1", true, false)
      vhost.declare_queue("q2", true, false)

      before = prometheus_counter(http, "lavinmq_queues_declared_total")
      before.should be >= 2

      s.vhosts.delete("mono_vdel")

      after = prometheus_counter(http, "lavinmq_queues_declared_total")
      after.should be >= before
    end
  end

  it "keeps global_messages_delivered_total monotonic when a vhost is deleted via the store" do
    with_metrics_server do |http, s|
      vhost = s.vhosts.create("mono_vdel_msg")
      s.users.add_permission("guest", vhost.name, /.*/, /.*/, /.*/)
      with_channel(s, vhost: vhost.name) do |ch|
        q = ch.queue("q", durable: true)
        3.times { q.publish_confirm "m" }
        3.times { q.get(no_ack: true).should_not be_nil }
      end

      before = prometheus_counter(http, "lavinmq_global_messages_delivered_total")
      before.should be >= 3

      # Must survive the canonical VHostStore#delete path, not just HTTP DELETE.
      s.vhosts.delete("mono_vdel_msg")

      after = prometheus_counter(http, "lavinmq_global_messages_delivered_total")
      after.should be >= before
    end
  end

  it "counts a fan-out publish once, not once per bound queue" do
    with_metrics_server do |_, s|
      vhost = s.vhosts.create("fanout_publish")
      s.users.add_permission("guest", vhost.name, /.*/, /.*/, /.*/)
      vhost.declare_exchange("fx", "fanout", false, false)
      %w[q1 q2 q3].each do |q|
        vhost.declare_queue(q, false, false)
        vhost.bind_queue(q, "fx", "")
      end

      with_channel(s, vhost: vhost.name) do |ch|
        ch.basic_publish_confirm("m", "fx", "")
      end

      # One publish fanned out to 3 queues must still count as 1.
      vhost.message_details[:message_stats][:publish].should eq 1
    end
  end

  it "keeps /api/overview message_stats monotonic when a vhost is deleted" do
    with_http_server do |http, s|
      vhost = s.vhosts.create("ov_mono")
      s.users.add_permission("guest", vhost.name, /.*/, /.*/, /.*/)
      with_channel(s, vhost: vhost.name) do |ch|
        q = ch.queue("q", durable: true)
        3.times { q.publish_confirm "m" }
        3.times { q.get(no_ack: true).should_not be_nil }
      end

      before = JSON.parse(http.get("/api/overview").body).dig("message_stats", "deliver_get").as_i64
      before.should be >= 3

      s.vhosts.delete("ov_mono")

      after = JSON.parse(http.get("/api/overview").body).dig("message_stats", "deliver_get").as_i64
      after.should be >= before
    end
  end

  it "keeps /api/nodes queue_declared monotonic when a vhost is deleted" do
    with_http_server do |http, s|
      vhost = s.vhosts.create("node_mono")
      vhost.declare_queue("q1", true, false)
      vhost.declare_queue("q2", true, false)

      before = JSON.parse(http.get("/api/nodes").body)[0]["queue_declared"].as_i64
      before.should be >= 2

      s.vhosts.delete("node_mono")

      after = JSON.parse(http.get("/api/nodes").body)[0]["queue_declared"].as_i64
      after.should be >= before
    end
  end
end

describe LavinMQ::HTTP::FollowerPrometheusController do
  it "returns gc metrics on /metrics" do
    with_follower_metrics_server do |http|
      response = http.get("/metrics")
      response.status_code.should eq 200
      response.body.lines.any?(&.starts_with? "telemetry_scrape_duration_seconds").should be_true
      response.body.lines.any?(&.starts_with? "lavinmq_gc_heap_size_bytes").should be_true
      response.body.lines.any?(&.starts_with? "lavinmq_gc_pause_seconds_count").should be_true
    end
  end

  it "returns 200 on /metrics/detailed with only scrape telemetry" do
    with_follower_metrics_server do |http|
      response = http.get("/metrics/detailed?family=queue_coarse_metrics")
      response.status_code.should eq 200
      response.body.lines.any?(&.starts_with? "telemetry_scrape_duration_seconds").should be_true
      response.body.lines.any?(&.starts_with? "lavinmq_gc_heap_size_bytes").should be_false
      response.body.lines.any?(&.starts_with? "lavinmq_detailed_queue_messages_ready").should be_false
    end
  end
end

describe LavinMQ::HTTP::MetricsServer do
  it "switches from follower to leader metrics on the same socket" do
    with_amqp_server do |s|
      h = LavinMQ::HTTP::MetricsServer.new
      begin
        addr = h.bind_tcp("127.0.0.1", 0)
        spawn(name: "metrics listen") { h.listen }
        Fiber.yield
        http = HTTPSpecHelper.new(addr)
        http.get("/metrics").body.should_not contain "lavinmq_identity_info"

        h.leader = s
        response = http.get("/metrics")
        response.status_code.should eq 200
        response.body.should contain "lavinmq_identity_info"
      ensure
        h.close
      end
    end
  end
end

# Scrape /metrics and return the value of a single (unlabeled) counter series.
def prometheus_counter(http, key : String) : Float64
  raw = http.get("/metrics").body
  PrometheusSpecHelper.parse_prometheus(raw).find! { |m| m[:key] == key }[:value]
end

def dead_lettered_counter(http, reason : String, strategy : String) : Float64
  raw = http.get("/metrics").body
  PrometheusSpecHelper.parse_prometheus(raw).find! do |m|
    m[:key] == "lavinmq_global_messages_dead_lettered_#{reason}_total" &&
      m[:attrs]["dead_letter_strategy"]? == strategy
  end[:value]
end

def declare_dead_letter_queues(ch, args : Hash(String, AMQ::Protocol::Field), *, suffix = "")
  ch.queue("dl_target#{suffix}")
  plain = ch.queue("dl_plain#{suffix}", args: AMQP::Client::Arguments.new(args))
  dlx_args = args.merge({"x-dead-letter-exchange" => "", "x-dead-letter-routing-key" => "dl_target#{suffix}"} of String => AMQ::Protocol::Field)
  dlx = ch.queue("dl_dlx#{suffix}", args: AMQP::Client::Arguments.new(dlx_args))
  {plain, dlx}
end

class PrometheusSpecHelper
  class Invalid < Exception
    def initialize
      super("invalid input")
    end
  end

  KEY_RE        = /[\w:]+/
  VALUE_RE      = /-?\d+\.?\d*E?-?\d*|NaN/
  ATTR_KEY_RE   = /[ \w-]+/
  ATTR_VALUE_RE = %r{\s*"([\\"'\sa-zA-Z0-9\-_/.+]*)"\s*}

  def self.parse_prometheus(raw)
    s = StringScanner.new(raw)
    res = [] of NamedTuple(key: String, attrs: Hash(String, String), value: Float64)
    until s.eos?
      if s.peek(1) == "#"
        s.scan(/.*\n/)
        next
      end
      key = s.scan KEY_RE
      raise Invalid.new unless key
      attrs = parse_attrs(s)
      value = s.scan VALUE_RE
      raise Invalid.new unless value
      value = value.to_f
      s.scan(/\n/)
      res.push({key: key, attrs: attrs, value: value})
    end
    res
  end

  private def self.parse_attrs(s)
    attrs = Hash(String, String).new
    if s.scan(/\s|{/) == "{"
      loop do
        if s.peek(1) == "}"
          s.scan(/}/)
          break
        end
        key = s.scan ATTR_KEY_RE
        raise Invalid.new unless key
        key = key.strip
        s.scan(/=/)
        s.scan ATTR_VALUE_RE

        value = s[1]
        raise Invalid.new unless value
        attrs[key] = value
        break if s.scan(/,|}/) == "}"
      end
      s.scan(/\s/)
    end
    attrs
  end
end

describe LavinMQ::GCPauseRecorder do
  it "adds recorded nanoseconds to the sum in seconds" do
    GC.disable # no real pauses may land between the snapshots
    begin
      sum_before = LavinMQ::GCPauseRecorder.sum
      1000.times { LavinMQ::GCPauseRecorder.record(1_u64) }
      LavinMQ::GCPauseRecorder.record(1_500_000_u64)
      (LavinMQ::GCPauseRecorder.sum - sum_before).should be_close(0.001501, 1e-12)
    ensure
      GC.enable
    end
  end
end
