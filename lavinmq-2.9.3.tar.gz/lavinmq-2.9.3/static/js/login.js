import * as Auth from './auth.js'

function showLoginError (message) {
  const el = document.getElementById('login-error')
  el.textContent = message
  el.style.display = 'block'
}

window.fetch('oauth/enabled')
  .then(resp => resp.json())
  .then(data => {
    if (data.enabled) {
      const ssoBtn = document.getElementById('sso-btn')
      ssoBtn.classList.remove('hide')
      document.getElementById('sso-separator').classList.remove('hide')
      ssoBtn.addEventListener('click', (e) => {
        e.preventDefault()
        window.fetch('oauth/authorize')
          .then(resp => resp.json().then(data => {
            if (resp.ok) {
              window.location.assign(data.authorize_url)
            } else {
              showLoginError(data.reason || 'SSO authorization failed')
            }
          }))
          .catch(() => { showLoginError('SSO authorization failed') })
      })
    }
  })
  .catch(() => {})

const searchParams = new URLSearchParams(window.location.search)
if (searchParams.has('error')) {
  showLoginError(searchParams.get('error'))
  window.history.replaceState(null, '', window.location.pathname)
}

if (window.location.hash) {
  const params = new URLSearchParams(window.location.hash.substring(1))
  const user = params.get('username')
  const pass = params.get('password')
  window.location.hash = ''
  if (user && pass) tryLogin(user, pass)
}

document.getElementById('login').addEventListener('submit', (e) => {
  e.preventDefault()
  const user = document.getElementById('username').value
  const pass = document.getElementById('password').value
  tryLogin(user, pass)
})

function tryLogin (user, pass) {
  Auth.login(user, pass)
    .then(() => window.location.assign('.'))
    .catch(() => showLoginError('Authentication failure'))
}
