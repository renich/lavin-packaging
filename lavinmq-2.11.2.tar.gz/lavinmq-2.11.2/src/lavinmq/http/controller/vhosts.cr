require "../controller"
require "../../sortable_json"

module LavinMQ
  module HTTP
    struct VHostView
      include SortableJSON
      @name : String

      def initialize(@vhost : VHost)
        @name = @vhost.name
      end

      def details_tuple
        @vhost.details_tuple.merge(@vhost.message_details)
      end
    end

    class VHostsController < Controller
      private def register_routes
        get "/api/vhosts" do |context, _params|
          arr = vhosts(user(context)).map { |v| VHostView.new(v) }
          page(context, arr)
        end

        get "/api/vhosts/:name" do |context, params|
          with_vhost(context, params, vhost_key: "name") do |vhost|
            refuse_unless_management(context, user(context), vhost)
            VHostView.new(vhost).to_json(context.response.output)
          end
        end

        put "/api/vhosts/:name" do |context, params|
          u = user(context)
          refuse_unless_administrator(context, u)
          name = params["name"]
          if context.request.body
            body = parse_body(context)
            tags = body["tags"]?.to_s.split(',').map(&.strip).reject(&.empty?)
            description = body["description"]?.to_s
          else
            tags = Array(String).new(0)
            description = ""
          end
          is_update = @server.vhosts[name]?
          if name.bytesize > UInt8::MAX
            bad_request(context, "Vhost name too long, can't exceed 255 characters")
          end
          @server.vhosts.create(name, u, description, tags)
          context.response.status_code = is_update ? 204 : 201
          context
        end

        delete "/api/vhosts/:name" do |context, params|
          refuse_unless_administrator(context, user(context))
          with_vhost(context, params, vhost_key: "name") do |vhost|
            if @server.vhosts.delete(vhost.name)
              context.response.status_code = 204
            else
              context.response.status_code = 404
            end
          end
        end

        get "/api/vhosts/:name/permissions" do |context, params|
          refuse_unless_administrator(context, user(context))
          with_vhost(context, params, vhost_key: "name") do |vhost|
            @server.users.compact_map do |_, u|
              next if u.hidden?
              u.permissions[vhost.name]?.try { |p| u.permissions_details(vhost.name, p) }
            end.to_json(context.response.output)
          end
        end
      end
    end
  end
end
