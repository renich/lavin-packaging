require "./spec_helper"

describe "Publish Confirm Persistence" do
  it "confirms are still received by the client" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("confirm_test")
        10.times do |i|
          q.publish_confirm "message #{i}"
        end
      end
    end
  end

  it "confirms a single publish quickly (no batching delay)" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("single_publish_test")
        start = Time.instant
        q.publish_confirm "message 1"
        duration = Time.instant - start
        duration.should be < 100.milliseconds
      end
    end
  end

  it "nacks rejected publishes and acks the accepted ones" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        ch.confirm_select
        args = AMQP::Client::Arguments.new
        args["x-max-length"] = 1_i64
        args["x-overflow"] = "reject-publish"
        q = ch.queue("mix_confirm", args: args)

        results = {} of UInt64 => Bool
        lock = Mutex.new

        id1 = ch.basic_publish("m1", "", q.name) { |ok| lock.synchronize { results[1_u64] = ok } }
        should_eventually(be_true) { s.vhosts["/"].queue(q.name).message_count == 1 }

        id2 = ch.basic_publish("m2", "", q.name) { |ok| lock.synchronize { results[2_u64] = ok } }
        id3 = ch.basic_publish("m3", "", q.name) { |ok| lock.synchronize { results[3_u64] = ok } }

        should_eventually(be_true) do
          lock.synchronize { results.size == 3 }
        end
        lock.synchronize do
          results[id1].should be_true  # accepted
          results[id2].should be_false # rejected
          results[id3].should be_false # rejected
        end
      end
    end
  end

  # A queue is closed while its connections are still publishing when the
  # broker shuts down
  {"classic", "stream"}.each do |type|
    it "nacks a publish that a closed #{type} queue didn't store" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.confirm_select
          q = ch.queue("closed_#{type}", args: {"x-queue-type": type})
          q.publish_confirm("stored").should be_true
          s.vhosts["/"].queue(q.name).close
          q.publish_confirm("not stored").should be_false
        end
      end
    end
  end

  it "batches concurrent in-flight publishes into multi-acks" do
    # When many publishes are in flight at once, they should accumulate in
    # @pending_acks while the loop is busy syncing the previous batch, so the
    # number of sync calls is much less than the number of publishes.
    with_amqp_server do |s|
      with_channel(s) do |ch|
        ch.confirm_select
        q = ch.queue("batch_test")
        n = 500
        n.times { ch.basic_publish "msg", "", q.name }
        ch.wait_for_confirms.should be_true
        s.vhosts["/"].queue(q.name).message_count.should eq n
      end
    end
  end

  it "confirms immediately when sync is disabled" do
    LavinMQ::Config.instance.sync = false
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("no_sync_confirm")
        100.times { |i| q.publish_confirm "message #{i}" }
        s.vhosts["/"].queue(q.name).message_count.should eq 100
      end
    end
  end

  describe "runtime sync-mode flip (regression for #2078)" do
    # Smoke test for #2078: confirms keep flowing across a mid-stream `sync` flip
    # (see Persister#enqueue_ack for why). Asserts confirms + counts only, not
    # Basic.Ack ordering - the Crystal client tolerates out-of-order tags.
    it "keeps confirming when sync is disabled mid-stream" do
      LavinMQ::Config.instance.sync = true
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.confirm_select
          q = ch.queue("flip_sync_off")
          50.times { q.publish "msg" }
          LavinMQ::Config.instance.sync = false # operator SIGHUPs sync off mid-stream
          50.times { q.publish "msg" }
          ch.wait_for_confirms.should be_true
          s.vhosts["/"].queue(q.name).message_count.should eq 100
        end
      end
    ensure
      LavinMQ::Config.instance.sync = true
    end

    it "keeps confirming when sync is enabled mid-stream" do
      LavinMQ::Config.instance.sync = false
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.confirm_select
          q = ch.queue("flip_sync_on")
          50.times { q.publish "msg" }
          LavinMQ::Config.instance.sync = true
          50.times { q.publish "msg" }
          ch.wait_for_confirms.should be_true
          s.vhosts["/"].queue(q.name).message_count.should eq 100
        end
      end
    ensure
      LavinMQ::Config.instance.sync = true
    end
  end

  it "correctly acknowledges multiple messages with one ack frame" do
    # This is hard to verify from the client side without internal access,
    # but we can verify that everything is eventually acked.
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("multi_confirm_test")
        msgs = (1..100).map { |i| "msg #{i}" }
        ch.confirm_select
        msgs.each do |m|
          q.publish m
        end
        ch.wait_for_confirms
      end
    end
  end
end
