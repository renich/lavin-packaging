require "./spec_helper"
require "./../src/lavinmq/amqp/queue"
require "./../src/lavinmq/policy"

alias Policy = LavinMQ::Policy

# A queue whose post-push expire-fiber bookkeeping raises ClosedError, as if a
# delete closed the store right after the message was pushed.
class StoreClosedAfterPushQueue < LavinMQ::AMQP::Queue
  private def ensure_expire_fiber
    raise LavinMQ::MessageStore::ClosedError.new
  end
end

def with_queue(&)
  with_amqp_server do |s|
    vhost = s.vhosts["/"]
    vhost.declare_queue("q", durable: true, auto_delete: false)
    q = vhost.queue("q")
    yield q
  ensure
    q.try &.delete
  end
end

describe LavinMQ::AMQP::Queue do
  it "should not expire message before server is fully started" do
    # https://github.com/cloudamqp/lavinmq/issues/1697
    with_amqp_server do |s|
      with_channel(s) do |ch|
        # Must go via a queue with binding keys
        dlq = ch.queue("dlq")
        dlq.bind(ch.topic_exchange.name, dlq.name)
        q = ch.queue("ttl", args: AMQP::Client::Arguments.new(
          {"x-message-ttl" => 1000, "x-dead-letter-exchange" => "amq.topic", "x-dead-letter-routing-key" => dlq.name}
        ))
        # declare a queue after ttl that will cause yields in its message store during load
        other_queue = ch.queue("other")
        x = ch.default_exchange
        x.publish_confirm("foo", other_queue.name)
        x.publish_confirm("ttl", q.name)
      end
      s.stop
      RoughTime.paused do |t|
        # Move time so message will be expired on startup
        t.travel 2.seconds
        s.restart
        with_channel(s) do |ch|
          ch.queue("dlq").get.should_not be_nil, failure_message: "Message not dead lettered?!"
        end
      end
    end
  end

  it "should expire itself after last consumer disconnects" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("qexpires", args: AMQP::Client::Arguments.new({"x-expires" => 100}))
        queue = s.vhosts["/"].queue("qexpires")
        tag = q.subscribe { }
        sleep 110.milliseconds
        queue.closed?.should be_false
        ch.basic_cancel(tag)
        start = Time.instant
        should_eventually(be_true) { queue.closed? }
        (Time.instant - start).total_milliseconds.should be_close 100, 50
      end
    end
  end

  it "Should dead letter expired messages" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("ttl", args: AMQP::Client::Arguments.new(
          {"x-message-ttl" => 1, "x-dead-letter-exchange" => "", "x-dead-letter-routing-key" => "dlq"}
        ))
        dlq = ch.queue("dlq")
        x = ch.default_exchange
        x.publish_confirm("ttl", q.name)
        msg = wait_for { dlq.get }
        msg.not_nil!.body_io.to_s.should eq "ttl"
        q.get.should eq nil
      end
    end
  end

  it "Should expire message after consuming non-expiring message" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        # Create a queue with dead letter exchange so we can verify expiration happened
        q = ch.queue("exp_test", args: AMQP::Client::Arguments.new(
          {"x-dead-letter-exchange" => "", "x-dead-letter-routing-key" => "dlq"}
        ))
        dlq = ch.queue("dlq")
        q.publish_confirm("no expiration")
        q.publish_confirm("with expiration", props: AMQP::Client::Properties.new(expiration: "100"))

        msg1 = q.get(no_ack: true).should_not be_nil
        msg1.body_io.to_s.should eq "no expiration"

        # Queue should have 1 message that should expire
        msg = wait_for { dlq.get(no_ack: true) }.should_not be_nil
        msg.body_io.to_s.should eq "with expiration"

        # The Queue should be empty
        q.get(no_ack: true).should be_nil
      end
    end
  end

  it "Should expire short-TTL message after consuming long-TTL message", tags: "slow" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        # Create a queue with dead letter exchange so we can verify expiration happened
        q = ch.queue("exp_test2", args: AMQP::Client::Arguments.new(
          {"x-dead-letter-exchange" => "", "x-dead-letter-routing-key" => "dlq2"}
        ))
        dlq = ch.queue("dlq2")
        # Publish message with long TTL (60 seconds)
        q.publish_confirm("long ttl", props: AMQP::Client::Properties.new(expiration: "60000"))
        # Publish message with short TTL (500ms)
        q.publish_confirm("short ttl", props: AMQP::Client::Properties.new(expiration: "500"))

        # Consume the long-TTL message immediately
        msg1 = q.get(no_ack: true).should_not be_nil
        msg1.body_io.to_s.should eq "long ttl"

        # The short-TTL message should expire after ~500ms, not 60 seconds
        msg = wait_for { dlq.get(no_ack: true) }
        msg.should_not be_nil
        msg.body_io.to_s.should eq "short ttl"

        # The Queue should be empty
        q.get(no_ack: true).should be_nil
      end
    end
  end

  it "Should not dead letter messages to itself due to queue length" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q1 = ch.queue("", args: AMQP::Client::Arguments.new(
          {"x-max-length" => 1, "x-dead-letter-exchange" => ""}
        ))
        q1.publish_confirm ""
        q1.publish_confirm ""
        q1.get.should_not be_nil
        q1.get.should be_nil
      end
    end
  end

  it "Should dead letter messages to itself only if rejected" do
    queue_name = Random::Secure.hex
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q1 = ch.queue(queue_name, args: AMQP::Client::Arguments.new(
          {"x-dead-letter-exchange" => ""}
        ))
        ch.default_exchange.publish_confirm("", queue_name)
        msg = q1.get(no_ack: false).not_nil!
        msg.reject(requeue: false)
        q1.get(no_ack: false).should_not be_nil
      end
    end
  end

  describe "Paused" do
    x_name = "paused"
    q_name = "paused"
    it "should pause the queue by setting it in flow (get)" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          x = ch.exchange(x_name, "direct")
          q = ch.queue(q_name)
          q.bind(x.name, q.name)
          x.publish_confirm "test message", q.name
          q.get(no_ack: true).try(&.body_io.to_s).should eq("test message")

          iq = s.vhosts["/"].queue(q.name)
          iq.pause!

          x.publish_confirm "test message 2", q.name
          q.get(no_ack: true).should be_nil
        end
      end
    end

    it "should be able to declare queue as paused" do
      with_amqp_server do |s|
        s.vhosts.create("/")
        v = s.vhosts["/"].not_nil!
        v.declare_queue("q", true, false)
        data_dir = s.vhosts["/"].queue("q").as(LavinMQ::AMQP::Queue).@msg_store.@msg_dir
        s.vhosts["/"].queue("q").pause!
        File.exists?(File.join(data_dir, "paused")).should be_true
        s.restart
        s.vhosts["/"].queue("q").state.paused?.should be_true
        s.vhosts["/"].queue("q").resume!
        File.exists?(File.join(data_dir, "paused")).should be_false
      end
    end

    it "should handle '.paused' files and rename to 'paused'" do
      with_amqp_server do |s|
        s.vhosts.create("/")
        v = s.vhosts["/"].not_nil!
        v.declare_queue("q", true, false)
        data_dir = s.vhosts["/"].queue("q").as(LavinMQ::AMQP::Queue).@msg_store.@msg_dir
        File.touch(File.join(data_dir, ".paused"))
        s.restart
        File.exists?(File.join(data_dir, "paused")).should be_true
        s.vhosts["/"].queue("q").state.paused?.should be_true
      end
    end

    it "should pause the queue by setting it in flow (consume)", tags: "slow" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          x = ch.exchange(x_name, "direct")
          q = ch.queue(q_name)
          q.bind(x.name, q.name)

          x.publish_confirm "test message", q.name
          q.get(no_ack: true).try(&.body_io.to_s).should eq("test message")

          iq = s.vhosts["/"].queue(q.name)
          iq.pause!

          x.publish_confirm "test message 2", q.name
          channel = Channel(String).new

          # Subscribe on the queue
          # Wait 1 second and unpause the queue, fail test if we get message during that time
          # Make sure the queue continues
          q.subscribe(no_ack: false) do |msg|
            channel.send msg.body_io.to_s
            ch.basic_ack(msg.delivery_tag)
          end
          select
          when msg = channel.receive
            fail "Consumer should not get a message '#{msg}'"
          when timeout 1.second
            iq.resume!
          end
          channel.receive.should eq "test message 2"
        end
      end
    end

    it "should be able to get messages from paused queue with force flag" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          x = ch.exchange(x_name, "direct")
          q = ch.queue(q_name)
          q.bind(x.name, q.name)
          x.publish_confirm "test message", q.name
          q.get(no_ack: true).try(&.body_io.to_s).should eq("test message")

          iq = s.vhosts["/"].queue(q.name)
          iq.pause!

          x.publish_confirm "test message 2", q.name
          x.publish_confirm "test message 3", q.name

          # cannot get from client, queue is paused
          q.get(no_ack: true).should be_nil

          body = %({ "count": 1, "ack_mode": "get", "encoding": "auto" })
          response = http.post("/api/queues/%2f/#{q_name}/get", body: body)
          response.status_code.should eq 200
          body = JSON.parse(response.body)
          body.size.should eq 1
          # can get from UI/API even though queue is paused
          body[0]["payload"].should eq "test message 2"

          # resume queue and consume next msg
          iq.resume!
          q.get(no_ack: true).try(&.body_io.to_s).should eq("test message 3")
        end
      end
    end
  end

  describe "Close" do
    q_name = "close"
    it "should cancel consumer" do
      with_amqp_server do |s|
        tag = "consumer-to-be-canceled"
        with_channel(s) do |ch|
          q = ch.queue(q_name)
          queue = s.vhosts["/"].queue(q_name).as(LavinMQ::AMQP::DurableQueue)
          q.publish_confirm "m1"

          # Should get canceled
          q.subscribe(tag: tag, no_ack: false, &.ack)
          queue.close
        end

        with_channel(s) do |ch|
          ch.has_subscriber?(tag).should eq false
        end

        # Queue is closed, delete to prevent spec failure because of closed queue
        s.vhosts["/"].queue(q_name).try &.delete
      end
    end
  end

  describe "Restarting queues" do
    q_name = "restart"
    it "should restart a closed queue" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue(q_name, durable: true)
          queue = s.vhosts["/"].queue(q_name).as(LavinMQ::AMQP::DurableQueue)

          # Publish a message
          q.publish_confirm "test message"
          queue.message_count.should eq 1

          # Close the queue
          queue.close
          queue.closed?.should be_true

          # Restart the queue & verify
          queue.restart!.should be_true
          queue.closed?.should be_false
          queue.message_count.should eq 1
          msg = q.get(no_ack: true)
          msg.should_not be_nil
          msg.not_nil!.body_io.to_s.should eq "test message"
        end
      end
    end

    it "should restart after corrupt data closes the queue" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue(q_name, durable: true)
          queue = s.vhosts["/"].queue(q_name).as(LavinMQ::AMQP::DurableQueue)
          q.publish_confirm "test message"
          queue.message_count.should eq 1

          # Write corrupt data to the segment file
          mfile = queue.@msg_store.@segments.first_value
          File.open(mfile.path, "w+") do |f|
            f.seek(mfile.size - mfile.size + 4)
            f.write(("x"*10).to_slice)
          end

          # Try to consume, which will trigger the close due to corrupt data
          q.subscribe(tag: "tag", no_ack: false, &.ack)
          should_eventually(be_true) { queue.state.closed? }

          # Delete corrupted segment file
          File.delete(mfile.path)

          # Restart the queue & verify that it is running
          queue.restart!.should be_true
          queue.closed?.should be_false
          queue.state.running?.should be_true
          queue.message_count.should eq 0
        end
      end
    end

    it "should expire msgs after restarting a queue" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue(q_name, durable: true, args: AMQP::Client::Arguments.new(
            {"x-message-ttl" => 500, "x-dead-letter-exchange" => "", "x-dead-letter-routing-key" => "dlq"}
          ))
          queue = s.vhosts["/"].queue(q_name).as(LavinMQ::AMQP::DurableQueue)

          # Publish a message
          q.publish_confirm "test message"
          queue.message_count.should eq 1

          # Close the queue
          queue.close
          queue.closed?.should be_true

          # Restart the queue & verify
          queue.restart!.should be_true
          queue.closed?.should be_false
          queue.message_count.should eq 1
          should_eventually(be_true) { queue.message_count == 0 }
        end
      end
    end

    it "should expire queue after restarting a queue" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.queue(q_name, durable: true, args: AMQP::Client::Arguments.new({"x-expires" => 100}))
          queue = s.vhosts["/"].queue(q_name).as(LavinMQ::AMQP::DurableQueue)

          # Close the queue
          queue.close
          queue.closed?.should be_true

          # Restart the queue & verify
          queue.restart!.should be_true
          queue.closed?.should be_false
          should_eventually(be_true) { queue.closed? }
        end
      end
    end

    it "should reapply policies after restart" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue(q_name, durable: true)
          queue = s.vhosts["/"].queue(q_name).as(LavinMQ::AMQP::DurableQueue)

          # Apply a max-length policy
          definition = {"max-length" => JSON::Any.new(2i64)}
          policy = LavinMQ::Policy.new("test", "/", /.*/, LavinMQ::Policy::Target::Queues, definition, 0i8)
          queue.apply_policy(policy, nil)

          # Close and restart the queue
          queue.close
          queue.closed?.should be_true
          queue.restart!.should be_true

          # Publish 4 messages, only 2 should be kept
          4.times { |i| q.publish_confirm "msg #{i}" }
          queue.message_count.should eq 2
        end
      end
    end

    it "should not restart if queue is still running" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.queue(q_name, durable: true)
          queue = s.vhosts["/"].queue(q_name).as(LavinMQ::AMQP::DurableQueue)

          # Try to restart without closing
          queue.restart!.should be_false
        end
      end
    end

    it "should clear exclusive consumer flag after restart" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue(q_name, durable: true)
          queue = s.vhosts["/"].queue(q_name).as(LavinMQ::AMQP::DurableQueue)

          q.subscribe(no_ack: true, exclusive: true) { }
          should_eventually(be_true) { queue.has_exclusive_consumer? }

          queue.close
          queue.restart!.should be_true

          queue.has_exclusive_consumer?.should be_false
        end

        with_channel(s) do |ch|
          q = ch.queue(q_name, durable: true)
          q.subscribe(no_ack: true) { }
        end
      end
    end
  end

  describe "Purge" do
    x_name = "purge"
    q_name = "purge"
    it "should purge the queue" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          x = ch.exchange(x_name, "direct")
          q = ch.queue(q_name, durable: true)
          q.bind(x.name, q.name)
          x.publish_confirm "test message 1", q.name
          x.publish_confirm "test message 2", q.name
          x.publish_confirm "test message 3", q.name
          x.publish_confirm "test message 4", q.name

          internal_queue = s.vhosts["/"].queue(q.name)
          internal_queue.message_count.should eq 4

          response = http.delete("/api/queues/%2f/#{q_name}/contents")
          response.status_code.should eq 204

          internal_queue.message_count.should eq 0
        end
      end
    end

    it "should purge only X messages from queue" do
      with_http_server do |http, s|
        with_channel(s) do |ch|
          x = ch.exchange(x_name, "direct")
          q = ch.queue(q_name, durable: true)
          q.bind(x.name, q.name)
          10.times do |i|
            x.publish_confirm "test message #{i}", q.name
          end

          vhost = s.vhosts["/"]
          internal_queue = vhost.queue(q.name)
          internal_queue.message_count.should eq 10

          response = http.delete("/api/queues/%2f/#{q_name}/contents?count=5")
          response.status_code.should eq 204

          internal_queue.message_count.should eq 5
        end
      end
    end
  end

  it "should keep track of unacked basic_get messages" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        q.publish_confirm "a"

        msg = q.get(no_ack: false)
        msg.should_not be_nil
        sq = s.vhosts["/"].queue(q.name)
        sq.unacked_count.should eq 1
        msg.not_nil!.ack
        sleep 10.milliseconds
        sq.unacked_count.should eq 0
      end
    end
  end

  it "should keep track of unacked delivered messages" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue
        q.publish_confirm "a"

        done = Channel(AMQP::Client::DeliverMessage).new
        q.subscribe(no_ack: false) do |msg|
          done.send msg
        end
        msg = done.receive
        sq = s.vhosts["/"].queue(q.name)
        sq.unacked_count.should eq 1
        msg.ack
        sleep 10.milliseconds
        sq.unacked_count.should eq 0
      end
    end
  end

  it "should delete transient queues on Server stop" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        ch.queue "transient", durable: false
      end
      data_dir = s.vhosts["/"].queue("transient").as(LavinMQ::AMQP::Queue).@msg_store.@msg_dir
      s.stop
      Dir.exists?(data_dir).should be_false
    end
  end

  it "should delete transient queues segments on creation" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        ch.queue "transient", durable: false
      end
      data_dir = s.vhosts["/"].queue("transient").as(LavinMQ::AMQP::Queue).@msg_store.@msg_dir
      Dir.exists?(data_dir).should be_true
      File.exists?("#{data_dir}/msgs.0000000001").should be_false
    end
  end

  it "should delete left over transient queue data on Server start" do
    with_amqp_server do |s|
      data_dir = ""
      with_channel(s) do |ch|
        q = ch.queue "transient", durable: false
        q.publish_confirm "foobar"
        data_dir = s.vhosts["/"].queue("transient").as(LavinMQ::AMQP::Queue).@msg_store.@msg_dir
        FileUtils.cp_r data_dir, "#{s.vhosts["/"].data_dir}.copy"
      end
      s.stop
      Dir.mkdir_p data_dir
      FileUtils.cp_r "#{s.vhosts["/"].data_dir}.copy", data_dir
      s.restart
      with_channel(s) do |ch|
        q = ch.queue_declare "transient", durable: false
        q[:message_count].should eq 0
        q = ch.queue_declare "transient", passive: true
        q[:message_count].should eq 0
      end
    end
  end

  it "should delete queue with auto_delete when the last consumer disconnects" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("q", auto_delete: true)
        data_dir = s.vhosts["/"].queue("q").as(LavinMQ::AMQP::Queue).@msg_store.@msg_dir
        sub = q.subscribe(no_ack: true) { |_| }
        Dir.exists?(data_dir).should be_true
        q.unsubscribe(sub)
        sleep 0.1.seconds
        Dir.exists?(data_dir).should be_false
      end
    end
  end

  describe "Flow" do
    it "should stop queues from being declared when disk is full" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          s.flow(false)
          expect_raises(AMQP::Client::Channel::ClosedException, "PRECONDITION_FAILED") do
            ch.queue("test_queue_flow", durable: true)
          end
        end
      end
    end
  end

  describe "MessageStore" do
    # Delete unused segments bug
    # https://github.com/cloudamqp/lavinmq/pull/565
    it "should remove unused segments after being consumed" do
      data_dir = File.join(LavinMQ::Config.instance.data_dir, "msgstore")
      Dir.mkdir_p data_dir
      begin
        store = LavinMQ::MessageStore.new(data_dir, nil)
        body = IO::Memory.new(Random::Secure.random_bytes(LavinMQ::Config.instance.segment_size), writable: false)
        msg = LavinMQ::Message.new(1i64, "amq.topic", "rk", AMQ::Protocol::Properties.new, body.size.to_u64, body)
        sps = Array(LavinMQ::SegmentPosition).new(10) { store.push msg }
        sps.each { |sp| store.delete sp }
        Fiber.yield
        store.@segments.size.should be <= 2
      ensure
        FileUtils.rm_rf data_dir
      end
    end

    it "should not create ack files when cleaning up segments" do
      # This spec verifies a bugfix where one ack file per segment was created
      data_dir = File.join(LavinMQ::Config.instance.data_dir, "msgstore2")
      Dir.mkdir_p data_dir
      begin
        body = IO::Memory.new(Random::Secure.random_bytes(LavinMQ::Config.instance.segment_size), writable: false)
        msg = LavinMQ::Message.new(1i64, "amq.topic", "rk", AMQ::Protocol::Properties.new, body.size.to_u64, body)

        store = LavinMQ::MessageStore.new(data_dir, nil)
        2.times { store.push msg }
        store.close

        # recreate store to let it read the segments and cleanup
        LavinMQ::MessageStore.new(data_dir, nil)
        Dir.glob(File.join(data_dir, "acks.*")).should eq [] of String
      ensure
        FileUtils.rm_rf data_dir
      end
    end

    it "should yield fiber while purging" do
      tmpdir = File.tempname "lavin", ".spec"
      Dir.mkdir_p tmpdir
      store = LavinMQ::MessageStore.new(tmpdir, nil)

      (LavinMQ::MessageStore::PURGE_YIELD_INTERVAL * 2 + 1).times do
        store.push(LavinMQ::Message.new(1i64, "a", "b", AMQ::Protocol::Properties.new, 0u64, IO::Memory.new(0)))
      end

      yields = 0
      done = Channel(Nil).new
      spawn(name: "yield counter") do
        loop do
          select
          when timeout(0.seconds)
            yields += 1
          when done.receive
            break
          end
        end
      end

      spawn(name: "purger") do
        store.purge
        2.times { done.send nil }
      end

      done.receive

      yields.should eq 2
    ensure
      FileUtils.rm_rf tmpdir if tmpdir
    end

    it "should not raise NotFoundError if segment is gone when deleting" do
      tmpdir = File.tempname "lavin", ".spec"
      Dir.mkdir_p tmpdir
      store = LavinMQ::MessageStore.new(tmpdir, nil)
      data = Random::Secure.hex(512)
      io = IO::Memory.new(data.to_slice)

      # Publish enough data to have more than one segment
      until store.@segments.size > 1
        io.rewind
        store.push(LavinMQ::Message.new(1i64, "a", "b", AMQ::Protocol::Properties.new, data.bytesize.to_u64, io))
      end

      Dir.glob(File.join(tmpdir, "msgs.*")).each do |f|
        File.delete(f)
      end

      store.purge
    ensure
      FileUtils.rm_rf tmpdir if tmpdir
    end

    pending "should not ack 'empty' msg if mfile.size is too big" do
      with_amqp_server do |s|
        s.vhosts["/"].declare_queue("expire_test_queue", true, false, AMQP::Client::Arguments.new({
          "x-message-ttl" => 600,
        }))
        queue = s.vhosts["/"].queue("expire_test_queue").as(LavinMQ::AMQP::DurableQueue)

        10_000.times do
          queue.publish(LavinMQ::Message.new("ex", "rk", "body" * 250, AMQ::Protocol::Properties.new))
        end

        # Change size of each segment to be bigger than actual size
        queue.@msg_store.@segments.each_value do |mfile|
          mfile.truncate(mfile.size + 100)
          mfile.write Bytes.new(100)
        end

        # Wait for messages to expire
        wait_for(2.seconds) { queue.message_count == 0 }
        Fiber.yield

        queue.message_count.should eq 0
        queue.@msg_store.@segments.each_key do |seg|
          acks = queue.@msg_store.@acks[seg]
          (acks.size // sizeof(UInt32)).should eq queue.@msg_store.@segment_msg_count[seg]
        end
      end
    end

    it "drops a publish when the store is closed concurrently" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.queue("closed_store_publish", durable: false)
          queue = s.vhosts["/"].queue("closed_store_publish").as(LavinMQ::AMQP::Queue)
          # Simulate a delete racing publish_internal: the store is closed after
          # the @closed check but before push, so push raises ClosedError. The
          # publish must report Dropped, not raise (which surfaced as an HTTP 500).
          queue.@msg_store.close
          msg = LavinMQ::Message.new("", "closed_store_publish", "body", LavinMQ::AMQP::Properties.new)
          queue.publish(msg).dropped?.should be_true
        end
      end
    end

    it "reports a publish as Ok when the store is closed after the message is stored" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        queue = StoreClosedAfterPushQueue.create(vhost, "pushed_then_closed")
        # The expiration makes publish run the post-push expire-fiber check, which
        # here raises ClosedError *after* push already stored the message, so the
        # publish must report Ok (not Dropped) and the message is kept.
        props = LavinMQ::AMQP::Properties.new(expiration: "10000")
        queue.publish(LavinMQ::Message.new("", queue.name, "body", props)).ok?.should be_true
        queue.message_count.should eq 1
      end
    end

    it "reports no message instead of erroring when its queue is deleted during a get" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.queue("get_during_delete", durable: false)
          queue = s.vhosts["/"].queue("get_during_delete").as(LavinMQ::AMQP::Queue)
          # The queue is deleted out from under an in-flight basic_get, so
          # Queue#get raises ClosedError. It must surface as Basic.GetEmpty
          # (false), not escape into the connection's read loop as an error.
          s.vhosts["/"].delete_queue("get_during_delete")
          delivered = false
          queue.basic_get(true) { delivered = true }.should be_false
          delivered.should be_false
        end
      end
    end
  end

  describe "deduplication" do
    it "should not accept message if it's a duplicate" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          queue_name = "dedup-queue"
          q1 = ch.queue(queue_name, args: AMQP::Client::Arguments.new({
            "x-message-deduplication" => true,
          }))
          props = LavinMQ::AMQP::Properties.new(headers: LavinMQ::AMQP::Table.new({
            "x-deduplication-header" => "msg1",
          }))
          ch.default_exchange.publish_confirm("body", queue_name, props: props)
          ch.default_exchange.publish_confirm("body", queue_name, props: props)
          q1.get(no_ack: false).not_nil!.body_io.to_s.should eq "body"
          q1.get(no_ack: false).should be_nil
        end
      end
    end
  end

  describe "unacked_bytesize" do
    it "should count bytes for all unacked messages" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue
          sq = s.vhosts["/"].queue(q.name).should be_a LavinMQ::AMQP::Queue

          q.publish_confirm "a"
          q.publish_confirm "b"

          msg_store = sq.@msg_store
          bytesize = msg_store.bytesize

          msg = q.get(no_ack: false).should_not be_nil
          q.get(no_ack: false).should_not be_nil
          sq.unacked_count.should eq 2
          sq.unacked_bytesize.should eq bytesize
          msg.ack
          sleep 10.milliseconds
          sq.unacked_count.should eq 1
          sq.unacked_bytesize.should eq(bytesize/2)
        end
      end
    end
  end

  describe "effective arguments" do
    arguments = {
      {"x-dead-letter-exchange": "dlx", "x-dead-letter-routing-key": "dlrk"},
      {"x-expires": 100},
      {"x-max-length": 200},
      {"x-max-length-bytes": 300},
      {"x-message-ttl": 400},
      {"x-overflow": "drop-head"},
      {"x-overflow": "reject-publish"},
      {"x-delivery-limit": 500},
      {"x-consumer-timeout": 600},
      {"x-single-active-consumer": true},
      {"x-message-deduplication": true, "x-cache-size": 700},
      {"x-message-deduplication": true, "x-cache-ttl": 800},
      {"x-message-deduplication": true, "x-deduplication-header": "foo"},
    }
    arguments.each do |args|
      it "should contain #{args.keys.join(", ")} when args is #{args}" do
        with_amqp_server do |s|
          q = s.vhosts["/"].try do |vhost|
            vhost.declare_queue("q", durable: true, auto_delete: false, arguments: AMQP::Client::Arguments.new(args))
            vhost.queue("q")
          end

          effective_arguments = q.details_tuple[:effective_arguments]
          args.keys.map(&.to_s).each do |key|
            effective_arguments.should contain key
          end
        end
      end
    end

    invalid_arguments = {
      {"x-overflow": "drop-arm"},
      {"x-overflow": "reject-ack"},
    }
    invalid_arguments.each do |args|
      it "should not contain #{args.keys.join(", ")} when args is #{args}" do
        with_amqp_server do |s|
          q = s.vhosts["/"].try do |vhost|
            vhost.declare_queue("q", durable: true, auto_delete: false, arguments: AMQP::Client::Arguments.new(args))
            vhost.queue("q")
          end

          effective_arguments = q.details_tuple[:effective_arguments]
          args.keys.map(&.to_s).each do |key|
            effective_arguments.should_not contain key
          end
        end
      end
    end

    overriden_arguments = {
      {
        args:     {"x-message-ttl": 100},
        policy:   {"message-ttl": 50},
        expected: Tuple.new,
      },
      {
        args:     {"x-message-ttl": 10},
        policy:   {"message-ttl": 50},
        expected: {"x-message-ttl"},
      },
      {
        args:     {"x-message-ttl": 100, "x-max-length": 10},
        policy:   {"message-ttl": 50, "x-max-length": 100},
        expected: {"x-max-length"},
      },
    }
    overriden_arguments.each do |value|
      args = value[:args]
      policy_args = value[:policy]
      expected = value[:expected]
      it "should be #{expected.join(", ")} with args #{args} and policy #{policy_args}" do
        with_amqp_server do |s|
          q = s.vhosts["/"].try do |vhost|
            vhost.declare_queue("q", durable: true, auto_delete: false, arguments: AMQP::Client::Arguments.new(args))
            vhost.queue("q")
          end
          definition = JSON.parse(policy_args.to_json).as_h
          policy = LavinMQ::Policy.new("p1", "/", %r{"."}, LavinMQ::Policy::Target::All, definition, 1i8)
          q.apply_policy(policy, nil)
          effective_arguments = q.details_tuple[:effective_arguments]
          expected.each do |key|
            effective_arguments.should contain key
          end
        end
      end
    end
  end

  describe "PolicyTarget" do
    definition = {
      "max-length" => JSON::Any.new(100),
    }
    policy = Policy.new("p1", "/", %r{.*}, Policy::Target::Queues, definition, 0i8)
    definition2 = {
      "message-ttl" => JSON::Any.new(1337),
    }
    policy2 = Policy.new("p2", "/", %r{.*}, Policy::Target::Queues, definition2, 0i8)
    describe "#apply_policy" do
      it "should apply policy" do
        with_queue do |q|
          q.apply_policy(policy, nil)
          q.details_tuple[:effective_policy_definition].keys.should contain "max-length"
          q.details_tuple[:effective_policy_definition]["max-length"].should eq 100
        end
      end

      it "should replace policy" do
        with_queue do |q|
          q.apply_policy(policy, nil)
          q.details_tuple[:effective_policy_definition].keys.should contain "max-length"
          q.apply_policy(policy2, nil)
          q.details_tuple[:effective_policy_definition].keys.should_not contain "max-length"
          q.details_tuple[:effective_policy_definition].keys.should contain "message-ttl"
          q.details_tuple[:effective_policy_definition]["message-ttl"].should eq 1337
        end
      end
    end

    describe "#clear_policy" do
      policy = Policy.new("p1", "/", %r{.*}, Policy::Target::Queues, definition, 0i8)
      it "should clear policy" do
        with_queue do |q|
          q.apply_policy(policy, nil)
          q.details_tuple[:effective_policy_definition].keys.should contain "max-length"
          q.clear_policy
          q.details_tuple[:effective_policy_definition].keys.should_not contain "max-length"
        end
      end
    end
  end

  describe "Exclusive queue cleanup" do
    it "drops the queue from Client#exclusive_queues when auto-deleted server-side" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("", exclusive: true, auto_delete: true)
          tag = q.subscribe(no_ack: true) { }

          conn = s.vhosts["/"].connections.first.as(LavinMQ::AMQP::Client)
          conn.@exclusive_queues.size.should eq 1

          ch.basic_cancel(tag) # last consumer leaves -> auto-delete fires

          should_eventually(eq 0) { conn.@exclusive_queues.size }
        end
      end
    end

    it "still cleans up exclusive queues on connection close when many are open" do
      # Regression for the iteration-mutation hazard: cleanup iterates
      # @exclusive_queues while Queue#close fires the observer that mutates it.
      with_amqp_server do |s|
        ch = nil
        with_channel(s) do |c|
          ch = c
          5.times { c.queue("", exclusive: true, auto_delete: true) }
          conn = s.vhosts["/"].connections.first.as(LavinMQ::AMQP::Client)
          conn.@exclusive_queues.size.should eq 5
        end
        # Connection closed by `with_channel`. All 5 queues should be gone,
        # not just every other one.
        should_eventually(eq 0) { s.vhosts["/"].queues_size }
      end
    end

    it "drops the queue from Client#exclusive_queues when expired via x-expires" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.queue("", exclusive: true,
            args: AMQP::Client::Arguments.new({"x-expires" => 100}))

          conn = s.vhosts["/"].connections.first.as(LavinMQ::AMQP::Client)
          conn.@exclusive_queues.size.should eq 1

          should_eventually(eq 0) { conn.@exclusive_queues.size }
        end
      end
    end
  end

  describe "Idle fiber management" do
    it "should not start message_expire_loop for empty queue" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        vhost.declare_queue("empty_q", durable: false, auto_delete: false)
        queue = vhost.queue("empty_q")
        queue.message_expire_fiber_active?.should be_false
      end
    end

    it "should not start message_expire_loop for queue with no TTL messages" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("no_ttl_test")
          queue = s.vhosts["/"].queue("no_ttl_test")

          # Publish message without TTL
          q.publish_confirm("test message")

          # Fiber should not start
          queue.message_expire_fiber_active?.should be_false
        end
      end
    end

    it "should start fiber when TTL message published and expire it" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("ttl_test", args: AMQP::Client::Arguments.new({"x-message-ttl" => 10}))
          queue = s.vhosts["/"].queue("ttl_test")

          # Should not have fiber initially (empty queue)
          queue.message_expire_fiber_active?.should be_false

          # Publish message with TTL
          q.publish_confirm("test message")

          # Fiber should start
          queue.message_expire_fiber_active?.should be_true

          # Message should be expired
          should_eventually(be_true) { queue.empty? }
        end
      end
    end

    it "should start fiber when message with per-message TTL is published" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("per_msg_ttl_test")
          queue = s.vhosts["/"].queue("per_msg_ttl_test")

          # Should not have fiber initially
          queue.message_expire_fiber_active?.should be_false

          # Publish message with per-message TTL
          props = AMQP::Client::Properties.new(expiration: "10")
          ch.default_exchange.publish_confirm("test message", q.name, props: props)

          # Fiber should start
          queue.message_expire_fiber_active?.should be_true

          # Message should be expired
          should_eventually(be_true) { queue.empty? }
        end
      end
    end

    it "should not start expire fiber while consumers are active" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("ttl_with_consumer", args: AMQP::Client::Arguments.new({"x-message-ttl" => 60_000}))
          queue = s.vhosts["/"].queue("ttl_with_consumer")
          q.subscribe(no_ack: true) { }
          should_eventually(eq 1) { queue.consumers.size }
          q.publish_confirm("msg")
          # rm_consumer will start the fiber once consumers disconnect; until then it stays idle
          queue.message_expire_fiber_active?.should be_false
        end
      end
    end

    it "should start fiber when a partial purge exposes a TTL message behind a no-TTL head" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("purge_expose_ttl", args: AMQP::Client::Arguments.new(
            {"x-dead-letter-exchange" => "", "x-dead-letter-routing-key" => "purge_expose_dlq"}
          ))
          dlq = ch.queue("purge_expose_dlq")
          queue = s.vhosts["/"].queue("purge_expose_ttl")

          # Head message has no TTL, so the expire fiber never starts
          q.publish_confirm("no ttl")
          q.publish_confirm("short ttl", props: AMQP::Client::Properties.new(expiration: "500"))
          queue.message_expire_fiber_active?.should be_false

          # Partial purge removes the no-TTL head, exposing the short-TTL message.
          # The fiber must restart so the now-head message gets expired.
          queue.purge(1).should eq 1
          queue.message_expire_fiber_active?.should be_true

          msg = wait_for { dlq.get(no_ack: true) }
          msg.should_not be_nil
          msg.not_nil!.body_io.to_s.should eq "short ttl"
          q.get(no_ack: true).should be_nil
        end
      end
    end
  end
end
