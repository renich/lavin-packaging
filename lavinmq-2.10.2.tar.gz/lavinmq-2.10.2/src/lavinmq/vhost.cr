require "json"
require "../stdlib/*"
require "./logger"
require "./policy"
require "./parameter_store"
require "./parameter"
require "./shovel/store"
require "./federation/upstream_store"
require "./sortable_json"
require "./amqp/exchange/exchange"
require "./amqp/exchange/*"
require "digest/sha1"
require "./amqp/queue"
require "./schema"
require "./event_type"
require "./stats"
require "./queue_factory"
require "./mqtt/session"
require "./mqtt/permission_service"
require "./connection_store"
require "./direct_reply_consumer_store"
require "./definitions_store"
require "./amqp/channel"
require "./persister"

module LavinMQ
  class VHost
    include SortableJSON
    include Stats

    STATS_KEYS = {"channel_closed", "channel_created", "connection_closed", "connection_created",
                  "queue_declared", "queue_deleted", "ack", "deliver", "deliver_no_ack", "deliver_get", "get", "get_no_ack", "publish", "confirm",
                  "redeliver", "reject", "return_unroutable", "consumer_added", "consumer_removed", "recv_oct", "send_oct"}
    rate_stats(STATS_KEYS)

    getter name, data_dir, operator_policies, policies, parameters, shovels, dir, users, replicator
    getter mqtt_permission_service : MQTT::PermissionService
    getter closed = BoolChannel.new(true)
    property max_connections : Int32?
    property max_queues : Int32?

    @flow = true
    @direct_reply_consumers = DirectReplyConsumerStore.new
    @definitions : DefinitionsStore?
    @shovels : Shovel::Store?
    @upstreams : Federation::UpstreamStore?
    @connections = ConnectionStore.new

    # Bool accessors (later become Atomic)
    def flow? : Bool
      @flow
    end

    def flow=(active : Bool)
      @flow = active
    end

    def closed? : Bool
      @closed.value
    end

    # Exchange accessors

    def exchange?(name : String) : Exchange?
      definitions.exchange?(name)
    end

    def exchange(name : String) : Exchange
      definitions.exchange(name)
    end

    def exchange_exists?(name : String) : Bool
      definitions.exchange_exists?(name)
    end

    def each_exchange(& : Exchange ->) : Nil
      definitions.each_exchange { |v| yield v }
    end

    def exchanges : Array(Exchange)
      definitions.exchanges
    end

    def exchanges_size : Int32
      definitions.exchanges_size
    end

    def exchanges_any?(& : {String, Exchange} -> Bool) : Bool
      definitions.exchanges_any? { |kv| yield kv }
    end

    def register_exchange(exchange : Exchange) : Nil
      definitions.register_exchange(exchange)
    end

    def mqtt_exchange : MQTT::Exchange
      definitions.mqtt_exchange
    end

    # Queue accessors

    def queue?(name : String) : AMQP::Queue?
      definitions.queue?(name)
    end

    def queue(name : String) : AMQP::Queue
      definitions.queue(name)
    end

    def queue_exists?(name : String) : Bool
      definitions.queue_exists?(name)
    end

    def each_queue(& : LavinMQ::Queue ->)
      definitions.each_queue { |q| yield q }
    end

    private def each_policy_target(& : Queue | Exchange ->)
      resources = Array(Queue | Exchange).new(queues_size + exchanges_size + sessions_size)
      resources.concat(queues).concat(sessions).concat(exchanges)
      resources.each do |r|
        yield r
      end
    end

    def queues : Array(AMQP::Queue)
      definitions.queues
    end

    def queues_size : Int32
      definitions.queues_size
    end

    def register_queue(queue : AMQP::Queue) : Nil
      definitions.register_queue(queue)
    end

    def queues_clear : Nil
      definitions.queues_clear
    end

    # Session accessors

    def session?(name : String) : MQTT::Session?
      definitions.session?(name)
    end

    def session(name : String) : MQTT::Session
      definitions.session(name)
    end

    def session_exists?(name : String) : Bool
      definitions.session_exists?(name)
    end

    def each_session(& : MQTT::Session ->) : Nil
      definitions.each_session { |v| yield v }
    end

    def sessions : Array(MQTT::Session)
      definitions.sessions
    end

    def sessions_size : Int32
      definitions.sessions_size
    end

    def sessions_clear : Nil
      definitions.sessions_clear
    end

    # Connection accessors

    def each_connection(& : Client ->) : Nil
      @connections.each { |c| yield c }
    end

    def connections : Array(Client)
      @connections.to_a
    end

    def connections_size : Int32
      @connections.size
    end

    def add_connection(client : Client)
      event_tick(EventType::ConnectionCreated)
      @connections.add client
    end

    def rm_connection(client : Client)
      event_tick(EventType::ConnectionClosed)
      @connections.delete client
    end

    # Direct reply consumer accessors

    def direct_reply_consumer?(consumer_tag : String) : Client::Channel?
      @direct_reply_consumers[consumer_tag]?
    end

    def direct_reply_consumer_set(consumer_tag : String, channel : Client::Channel) : Nil
      @direct_reply_consumers[consumer_tag] = channel
    end

    def direct_reply_consumer_delete(consumer_tag : String) : Client::Channel?
      @direct_reply_consumers.delete(consumer_tag)
    end

    def direct_reply_consumer_has_key?(consumer_tag : String) : Bool
      @direct_reply_consumers.has_key?(consumer_tag)
    end

    Log = LavinMQ::Log.for "vhost"

    def initialize(@name : String, @server_data_dir : String, @users : Auth::UserStore, @replicator : Clustering::Replicator?, @persister : Persister, @description = "", @tags = Array(String).new(0), mqtt_default_group = true)
      @log = Logger.new(Log, vhost: @name)
      @dir = Digest::SHA1.hexdigest(@name)
      @data_dir = File.join(@server_data_dir, @dir)
      Dir.mkdir_p File.join(@data_dir)
      FileUtils.rm_rf File.join(@data_dir, "transient")
      File.write(File.join(@data_dir, ".vhost"), @name)
      load_limits
      @operator_policies = ParameterStore(OperatorPolicy).new(@data_dir, "operator_policies.json", @replicator, vhost: @name)
      @policies = ParameterStore(Policy).new(@data_dir, "policies.json", @replicator, vhost: @name)
      @parameters = ParameterStore(Parameter).new(@data_dir, "parameters.json", @replicator, vhost: @name)
      @mqtt_permission_service = MQTT::PermissionService.new(@name, @data_dir, @replicator, mqtt_default_group)
      @shovels = Shovel::Store.new(self)
      @upstreams = Federation::UpstreamStore.new(self)
      @definitions = DefinitionsStore.new(self, @data_dir, @replicator, @log)
      load!
      spawn check_consumer_timeouts_loop, name: "Consumer timeouts loop"
    end

    private def check_consumer_timeouts_loop
      loop do
        select
        when timeout Config.instance.consumer_timeout_loop_interval.seconds
        when closed.when_true.receive?
          return
        end
        each_connection do |c|
          c.each_channel do |ch|
            ch.check_consumer_timeout
          end
        end
      end
    end

    def enqueue_ack(channel : AMQP::Channel, msgid : UInt64)
      @persister.enqueue_ack(channel, msgid)
    end

    def max_connections=(value : Int32) : Nil
      value = nil if value < 0
      @max_connections = value
      store_limits
    end

    def connection_limit_reached? : Bool
      @max_connections.try { |max| connections_size >= max } || false
    end

    def max_queues=(value : Int32) : Nil
      value = nil if value < 0
      @max_queues = value
      store_limits
    end

    def queue_limit_reached? : Bool
      @max_queues.try { |max| definitions.queues_size + definitions.sessions_size >= max } || false
    end

    private def load_limits
      File.open(File.join(@data_dir, "limits.json")) do |f|
        limits = JSON.parse(f)
        @max_queues = limits["max-queues"]?.try &.as_i?
        @max_connections = limits["max-connections"]?.try &.as_i?
        @replicator.try &.register_file(f)
      end
    rescue File::NotFoundError
    end

    private def store_limits
      File.open(File.join(@data_dir, "limits.json"), "w") do |f|
        JSON.build(f) do |json|
          json.object do
            json.field "max-queues", @max_queues if @max_queues
            json.field "max-connections", @max_connections if @max_connections
          end
        end
      end
      @replicator.try &.replace_file(File.join(@data_dir, "limits.json"))
    end

    def inspect(io : IO)
      io << "#<" << self.class << ": " << "@name=" << @name << ">"
    end

    # Routes a message through the named exchange.
    # Returns an `AMQP::Exchange::PublishResult` describing whether the message
    # was routed to at least one queue, and whether any matched queue rejected
    # it due to a reject-publish overflow policy. As long as at least one queue
    # rejects the publish, the caller should NACK the publisher on confirm
    # channels, even if other queues accepted the message (behaviour confirmed
    # with RabbitMQ).
    # The position of the msg.body_io should be at the start of the body
    # When this method finishes, the position will be the same, start of the body
    def publish(msg : Message, immediate = false,
                visited = Set(LavinMQ::Exchange).new, found_queues = Set(AMQP::Queue).new) : AMQP::Exchange::PublishResult
      if ex = exchange?(msg.exchange_name)
        ex.publish(msg, immediate, found_queues, visited)
      else
        AMQP::Exchange::PublishResult::None
      end
    ensure
      visited.clear
      found_queues.clear
    end

    def details_tuple
      {
        name:          @name,
        dir:           @dir,
        tracing:       false,
        tags:          @tags,
        description:   @description,
        cluster_state: NamedTuple.new,
      }
    end

    def message_details
      ready = unacked = 0_u64
      each_queue do |q|
        ready += q.message_count
        unacked += q.unacked_count
      end
      each_session do |s|
        ready += s.message_count
        unacked += s.unacked_count
      end

      {
        messages:                ready + unacked,
        messages_unacknowledged: unacked,
        messages_ready:          ready,
        message_stats:           {
          ack:               ack_count,
          confirm:           confirm_count,
          deliver:           deliver_count,
          deliver_no_ack:    deliver_no_ack_count,
          get:               get_count,
          get_no_ack:        get_no_ack_count,
          deliver_get:       deliver_get_count,
          publish:           publish_count,
          redeliver:         redeliver_count,
          return_unroutable: return_unroutable_count,
        },
      }
    end

    def declare_queue(name, durable, auto_delete, arguments = AMQP::Table.new, fsync = true)
      apply AMQP::Frame::Queue::Declare.new(0_u16, 0_u16, name, false, durable, false,
        auto_delete, false, arguments), fsync: fsync
      @log.info { "Created queue: #{name} (durable=#{durable} auto_delete=#{auto_delete} arguments=#{arguments})" }
    end

    def delete_queue(name)
      apply AMQP::Frame::Queue::Delete.new(0_u16, 0_u16, name, false, false, false)
      @log.debug { "Deleted queue: #{name}" }
    end

    def declare_exchange(name, type, durable, auto_delete, internal = false,
                         arguments = AMQP::Table.new, fsync = true)
      apply AMQP::Frame::Exchange::Declare.new(0_u16, 0_u16, name, type, false, durable,
        auto_delete, internal, false, arguments), fsync: fsync
      @log.info { "Created exchange: #{name} (type=#{type} durable=#{durable} auto_delete=#{auto_delete} arguments=#{arguments})" }
    end

    def delete_exchange(name)
      apply AMQP::Frame::Exchange::Delete.new(0_u16, 0_u16, name, false, false)
      @log.info { "Deleted exchange: #{name}" }
    end

    def bind_queue(destination, source, routing_key, arguments = AMQP::Table.new, fsync = true)
      apply AMQP::Frame::Queue::Bind.new(0_u16, 0_u16, destination, source,
        routing_key, false, arguments), fsync: fsync
    end

    def bind_exchange(destination, source, routing_key, arguments = AMQP::Table.new, fsync = true)
      apply AMQP::Frame::Exchange::Bind.new(0_u16, 0_u16, destination, source,
        routing_key, false, arguments), fsync: fsync
    end

    def unbind_queue(destination, source, routing_key, arguments = AMQP::Table.new)
      apply AMQP::Frame::Queue::Unbind.new(0_u16, 0_u16, destination, source,
        routing_key, arguments)
    end

    def unbind_exchange(destination, source, routing_key, arguments = AMQP::Table.new)
      apply AMQP::Frame::Exchange::Unbind.new(0_u16, 0_u16, destination, source,
        routing_key, false, arguments)
    end

    def apply(f, loading = false, fsync = true) : Bool
      definitions.apply(f, loading, fsync)
    end

    # Flush definitions written with fsync: false (e.g. during bulk import).
    def fsync_definitions
      definitions.fsync
    end

    def queue_bindings(queue : Queue)
      definitions.queue_bindings(queue)
    end

    def add_operator_policy(name : String, pattern : String, apply_to : String,
                            definition : Hash(String, JSON::Any), priority : Int8, save = true, apply = true) : OperatorPolicy
      op = OperatorPolicy.new(name, @name, Regex.new(pattern),
        Policy::Target.parse(apply_to), definition, priority)
      @operator_policies.create(op, save: save)
      spawn apply_policies, name: "ApplyPolicies (after add) OperatingPolicy #{@name}" if apply
      @log.info { "OperatorPolicy=#{name} Created" }
      op
    end

    def add_policy(name : String, pattern : String, apply_to : String,
                   definition : Hash(String, JSON::Any), priority : Int8, save = true, apply = true) : Policy
      p = Policy.new(name, @name, Regex.new(pattern), Policy::Target.parse(apply_to),
        definition, priority)
      @policies.create(p, save: save)
      spawn apply_policies, name: "ApplyPolicies (after add) #{@name}" if apply
      @log.info { "Policy=#{name} Created" }
      p
    end

    # Persist the policy/operator-policy/parameter stores; used to flush after a
    # bulk import that created entries with save: false.
    def save_policies!
      @policies.save!
    end

    def save_operator_policies!
      @operator_policies.save!
    end

    def save_parameters!
      @parameters.save!
    end

    def delete_operator_policy(name)
      @operator_policies.delete(name)
      spawn apply_policies, name: "ApplyPolicies (after delete) #{@name}"
      @log.info { "OperatorPolicy=#{name} Deleted" }
    end

    def delete_policy(name)
      @policies.delete(name)
      spawn apply_policies, name: "ApplyPolicies (after delete) #{@name}"
      @log.info { "Policy=#{name} Deleted" }
    end

    SHOVEL                  = "shovel"
    FEDERATION_UPSTREAM     = "federation-upstream"
    FEDERATION_UPSTREAM_SET = "federation-upstream-set"

    def add_parameter(p : Parameter, save = true, apply = true)
      @log.debug { "Add parameter #{p.name}" }
      @parameters.create(p, save: save)
      apply_parameters(p)
      spawn apply_policies, name: "ApplyPolicies (add parameter) #{@name}" if apply
    end

    def delete_parameter(component_name, parameter_name)
      @log.debug { "Delete parameter #{parameter_name}" }
      @parameters.delete({component_name, parameter_name})
      case component_name
      when SHOVEL
        shovels.delete(parameter_name)
      when FEDERATION_UPSTREAM
        upstreams.delete_upstream(parameter_name)
      when FEDERATION_UPSTREAM_SET
        upstreams.delete_upstream_set(parameter_name)
      else
        @log.warn { "No action when deleting parameter #{component_name}" }
      end
    end

    def stop_shovels
      shovels.each_value &.terminate
    end

    def stop_upstream_links
      upstreams.stop_all
    end

    def close(reason = "Broker shutdown")
      return if @closed.swap(true)
      stop_shovels
      stop_upstream_links

      @log.info { "Closing connections" }
      close_done = Channel(Nil).new

      spawn do
        @connections.close_all(reason, @log)
        @log.debug { "Close sent to all connections" }
        close_done.close
      end

      select
      when close_done.receive?
        @log.info { "All connections closed gracefully" }
      when timeout 15.seconds
        @log.warn { "Timeout waiting for connections to close. #{connections_size} left that will be forced closed." }
      end
      close_done.close
      # then force close the remaining (close tcp socket)
      each_connection &.force_close
      Fiber.yield # yield so that Client read_loops can shutdown
      each_queue &.close
      each_session &.close
      each_exchange &.close
      Fiber.yield
      definitions.close
      FileUtils.rm_rf File.join(@data_dir, "transient")
    end

    def delete
      close(reason: "VHost deleted")
      Fiber.yield
      @replicator.try &.delete_dir(@data_dir)
      FileUtils.rm_rf @data_dir
    end

    def apply_policies(resources : Array(Queue | Exchange)? = nil)
      policies = @policies.values.sort_by!(&.priority).reverse
      operator_policies = @operator_policies.values.sort_by!(&.priority).reverse
      if r = resources
        r.each do |resource|
          policy = policies.find &.match?(resource)
          operator_policy = operator_policies.find &.match?(resource)
          resource.apply_policy(policy, operator_policy)
        end
      else
        each_policy_target do |resource|
          policy = policies.find &.match?(resource)
          operator_policy = operator_policies.find &.match?(resource)
          resource.apply_policy(policy, operator_policy)
        end
      end
    rescue ex : TypeCastError
      @log.error { "Invalid policy. #{ex.message}" }
    end

    private def apply_parameters(parameter : Parameter? = nil)
      @parameters.apply(parameter) do |p|
        case p.component_name
        when SHOVEL
          shovels.create(p.parameter_name, p.value)
        when FEDERATION_UPSTREAM
          upstreams.create_upstream(p.parameter_name, p.value)
        when FEDERATION_UPSTREAM_SET
          upstreams.create_upstream_set(p.parameter_name, p.value)
        else
          @log.warn { "No action when applying parameter #{p.component_name}" }
        end
      end
    end

    private def load!
      definitions.load!
      has_parameters = !@parameters.empty?
      has_policies = !@policies.empty? || !@operator_policies.empty?
      if has_parameters || has_policies
        spawn(name: "Load parameters") do
          sleep 10.milliseconds
          next if closed?
          apply_parameters
          apply_policies
        end
      end
      closed.set(false)
      Fiber.yield
    end

    def upstreams
      @upstreams.not_nil!
    end

    def shovels
      @shovels.not_nil!
    end

    def event_tick(event_type)
      case event_type
      in EventType::ChannelClosed          then @channel_closed_count.add(1, :relaxed)
      in EventType::ChannelCreated         then @channel_created_count.add(1, :relaxed)
      in EventType::ConnectionClosed       then @connection_closed_count.add(1, :relaxed)
      in EventType::ConnectionCreated      then @connection_created_count.add(1, :relaxed)
      in EventType::QueueDeclared          then @queue_declared_count.add(1, :relaxed)
      in EventType::QueueDeleted           then @queue_deleted_count.add(1, :relaxed)
      in EventType::ClientAck              then @ack_count.add(1, :relaxed)
      in EventType::ClientPublish          then @publish_count.add(1, :relaxed)
      in EventType::ClientPublishConfirm   then @confirm_count.add(1, :relaxed)
      in EventType::ClientRedeliver        then @redeliver_count.add(1, :relaxed)
      in EventType::ClientReject           then @reject_count.add(1, :relaxed)
      in EventType::ConsumerAdded          then @consumer_added_count.add(1, :relaxed)
      in EventType::ConsumerRemoved        then @consumer_removed_count.add(1, :relaxed)
      in EventType::ClientReturnUnroutable then @return_unroutable_count.add(1, :relaxed)
      in EventType::ClientGet
        @get_count.add(1, :relaxed)
        @deliver_get_count.add(1, :relaxed)
      in EventType::ClientGetNoAck
        @get_no_ack_count.add(1, :relaxed)
        @deliver_get_count.add(1, :relaxed)
      in EventType::ClientDeliver
        @deliver_count.add(1, :relaxed)
        @deliver_get_count.add(1, :relaxed)
      in EventType::ClientDeliverNoAck
        @deliver_no_ack_count.add(1, :relaxed)
        @deliver_get_count.add(1, :relaxed)
      end
    end

    def add_recv_bytes(bytes : UInt64) : Nil
      @recv_oct_count.add(bytes, :relaxed)
    end

    def add_send_bytes(bytes : UInt64) : Nil
      @send_oct_count.add(bytes, :relaxed)
    end

    def sync : Nil
      @persister.sync
    end

    private def definitions : DefinitionsStore
      @definitions.not_nil!
    end
  end
end
