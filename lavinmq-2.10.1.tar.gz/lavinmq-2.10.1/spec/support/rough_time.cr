module RoughTime
  @@paused_utc = Time.utc
  @@paused_unix_ms : Int64 = @@paused_utc.to_unix_ms // 100 * 100
  @@paused_instant = Time.instant
  @@paused = false

  def self.utc : Time
    if @@paused
      return @@paused_utc
    end
    previous_def
  end

  def self.unix_ms : Int64
    if @@paused
      return @@paused_unix_ms
    end
    previous_def
  end

  def self.instant : Time::Instant
    if @@paused
      return @@paused_instant
    end
    previous_def
  end

  def self.pause
    @@paused = true
    @@paused_utc = Time.utc
    @@paused_unix_ms = @@paused_utc.to_unix_ms // 100 * 100
    @@paused_instant = Time.instant
  end

  def self.travel(time : Time::Span)
    @@paused_utc += time
    @@paused_unix_ms = @@paused_utc.to_unix_ms // 100 * 100
    @@paused_instant += time
  end

  def self.resume
    @@paused = false
  end

  def self.paused(&)
    pause
    yield self
  ensure
    resume
  end
end
