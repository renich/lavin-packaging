import { test, expect } from './fixtures.js'
import { trackCspViolations } from './helpers.js'

test.describe('Content Security Policy', _ => {
  test('authenticated page loads without CSP violations', async ({ page }) => {
    const getViolations = await trackCspViolations(page)
    await page.goto('/')
    expect(await getViolations()).toEqual([])
  })
})

test.describe('theme switcher', _ => {
  test('system theme button is active by default', async ({ page }) => {
    await page.goto('/')
    await expect(page.locator('#theme-system')).toHaveClass(/active/)
  })

  test('clicking light sets theme-light class on html', async ({ page }) => {
    await page.goto('/')
    await page.locator('#theme-light').click()
    await expect(page.locator('html')).toContainClass('theme-light')
    await expect(page.locator('html')).not.toContainClass('theme-dark')
    await expect(page.locator('#theme-light')).toHaveClass(/active/)
  })

  test('clicking dark sets theme-dark class on html', async ({ page }) => {
    await page.goto('/')
    await page.locator('#theme-dark').click()
    await expect(page.locator('html')).toContainClass('theme-dark')
    await expect(page.locator('html')).not.toContainClass('theme-light')
    await expect(page.locator('#theme-dark')).toHaveClass(/active/)
  })

  test('clicking system adds system class on html', async ({ page }) => {
    await page.goto('/')
    await page.locator('#theme-dark').click()
    await page.locator('#theme-system').click()
    await expect(page.locator('html')).toContainClass('system')
    await expect(page.locator('#theme-system')).toHaveClass(/active/)
  })

  test('theme is persisted across navigation', async ({ page }) => {
    await page.goto('/')
    await page.locator('#theme-dark').click()
    await page.goto('/nodes')
    await expect(page.locator('html')).toContainClass('theme-dark')
  })

  test('theme changed in another tab is applied', async ({ page, context }) => {
    await page.goto('/')
    await expect(page.locator('html')).not.toContainClass('theme-dark')
    const other = await context.newPage()
    await other.goto('/')
    await other.locator('#theme-dark').click()
    await expect(page.locator('html')).toContainClass('theme-dark')
    await expect(page.locator('#theme-dark')).toHaveClass(/active/)
  })

  test('theme set on a later page is applied when navigating back', async ({ playwright, browserName, baseURL, storageState }, testInfo) => {
    test.skip(browserName !== 'chromium', 'launch flags are chromium specific')
    // Playwright disables the back/forward cache by default
    const browser = await playwright.chromium.launch({
      ...testInfo.project.use.launchOptions,
      ignoreDefaultArgs: ['--disable-back-forward-cache'],
      args: ['--enable-features=BackForwardCache']
    })
    try {
      const page = await (await browser.newContext({ baseURL, storageState })).newPage()
      await page.goto('/')
      await page.locator('#theme-light').click()
      await page.goto('/queues')
      await page.locator('#theme-dark').click()
      await page.evaluate(() => history.back())
      await expect(page.locator('html')).toContainClass('theme-dark')
      await expect(page.locator('#theme-dark')).toHaveClass(/active/)
    } finally {
      await browser.close()
    }
  })

  test('html gets theme-dark when OS changes to dark and system theme is active', async ({ page }) => {
    await page.emulateMedia({ colorScheme: 'light' })
    await page.goto('/')
    await expect(page.locator('html')).toContainClass('theme-light')
    await page.emulateMedia({ colorScheme: 'dark' })
    await expect(page.locator('html')).toContainClass('theme-dark')
    await expect(page.locator('html')).not.toContainClass('theme-light')
  })

  test('html gets theme-light when OS changes to light and system theme is active', async ({ page }) => {
    await page.emulateMedia({ colorScheme: 'dark' })
    await page.goto('/')
    await expect(page.locator('html')).toContainClass('theme-dark')
    await page.emulateMedia({ colorScheme: 'light' })
    await expect(page.locator('html')).toContainClass('theme-light')
    await expect(page.locator('html')).not.toContainClass('theme-dark')
  })

  test('OS color scheme change does not affect manually set theme', async ({ page }) => {
    await page.emulateMedia({ colorScheme: 'light' })
    await page.goto('/')
    await page.locator('#theme-dark').click()
    await page.emulateMedia({ colorScheme: 'dark' })
    await expect(page.locator('html')).toContainClass('theme-dark')
    await page.emulateMedia({ colorScheme: 'light' })
    await expect(page.locator('html')).toContainClass('theme-dark')
    await expect(page.locator('html')).not.toContainClass('theme-light')
  })
})

test.describe('API docs theme', _ => {
  test('follows the theme chosen in the management UI', async ({ page }) => {
    await page.goto('/')
    await page.locator('#theme-dark').click()
    await page.goto('/docs/')
    await expect(page.locator('html')).toContainClass('theme-dark')
    await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark')
    await expect(page.locator('#theme-dark')).toHaveClass(/active/)
  })

  test('theme chosen in the docs is used by the management UI', async ({ page }) => {
    await page.goto('/docs/')
    await page.locator('#theme-dark').click()
    await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark')
    await page.goto('/')
    await expect(page.locator('html')).toContainClass('theme-dark')
    await expect(page.locator('#theme-dark')).toHaveClass(/active/)
  })

  test('system theme follows the OS even when another color is stored with it', async ({ page }) => {
    await page.emulateMedia({ colorScheme: 'light' })
    await page.goto('/docs/')
    await page.evaluate(() => window.localStorage.setItem('lmq.stateclasses', 'system theme-dark'))
    await page.reload()
    await expect(page.locator('html')).toHaveAttribute('data-theme', 'light')
    await expect(page.locator('#theme-system')).toHaveClass(/active/)
    await page.emulateMedia({ colorScheme: 'dark' })
    await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark')
  })

  test('code samples are readable in dark mode', async ({ page }) => {
    await page.goto('/docs/#/operations/GetQueues')
    await page.locator('#theme-dark').click()
    const sample = page.locator('.sl-code-viewer').filter({ hasText: '--request' })
    await expect(sample.locator('.token.string').first()).toBeVisible()
    // Lowest WCAG contrast ratio of a token against the background behind it
    const minContrast = await sample.evaluate(viewer => {
      const rgb = color => color.match(/[\d.]+/g).map(Number)
      const luminance = color => {
        const [r, g, b] = rgb(color).slice(0, 3).map(v => {
          v /= 255
          return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4
        })
        return 0.2126 * r + 0.7152 * g + 0.0722 * b
      }
      const background = el => {
        for (; el; el = el.parentElement) {
          const color = window.getComputedStyle(el).backgroundColor
          if (rgb(color)[3] !== 0) return color
        }
        return 'rgb(255, 255, 255)'
      }
      return Math.min(...[...viewer.querySelectorAll('.token')].map(token => {
        const [a, b] = [luminance(window.getComputedStyle(token).color), luminance(background(token))]
        return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05)
      }))
    })
    expect(minContrast).toBeGreaterThanOrEqual(4.5)
  })
})

test.describe('phone header', _ => {
  test.use({ viewport: { width: 390, height: 844 } })

  test('the open user menu fits the screen', async ({ page }) => {
    await page.goto('/')
    await page.locator('#usermenu-button').click()
    for (const item of ['#username', '#refresh-toggle', '#theme-switcher', '#signoutLink']) {
      await expect(page.locator(item)).toBeInViewport({ ratio: 1 })
    }
  })

  test('the theme toggle cycles through system, light and dark', async ({ page }) => {
    await page.goto('/')
    await page.locator('#usermenu-button').click()
    for (const theme of ['theme-light', 'theme-dark', 'system']) {
      await page.locator('#theme-switcher button:visible').click()
      await expect(page.locator('html')).toContainClass(theme)
    }
  })
})

test.describe('version', _ => {
  // The version is advertised via the `LavinMQ-Version` header on API responses
  // and picked up by http.js. The queues page is used because the nodes page
  // deliberately overwrites #version from /api/nodes (nodes.js). /api/queues is
  // read (not /api/vhosts, which the loadVhosts fixture mocks without the header).
  test('is shown from the LavinMQ-Version header', async ({ page }) => {
    const apiResponse = page.waitForResponse(r => r.url().includes('/api/queues'))
    await page.goto('/queues')
    const expected = (await apiResponse).headers()['lavinmq-version']
    expect(expected).toBeTruthy()
    await expect(page.locator('#version')).toHaveText(expected)
  })

  test('is cached in sessionStorage', async ({ page }) => {
    await page.goto('/queues')
    await expect(page.locator('#version')).not.toBeEmpty()
    const shown = await page.locator('#version').textContent()
    const stored = await page.evaluate(() => window.sessionStorage.getItem('lavinmq_version'))
    expect(stored).toBe(shown)
  })

  test('stats interval is read from the LavinMQ-Stats-Interval header', async ({ page }) => {
    await page.route(/\/api\//, async route => {
      const response = await route.fetch()
      const headers = { ...response.headers(), 'lavinmq-stats-interval': '60000' }
      await route.fulfill({ response, headers })
    })
    await page.goto('/')
    await expect.poll(() =>
      page.evaluate(url => import(url).then(m => m.statsInterval()), '/js/http.js')
    ).toBe(60000)
    await page.unrouteAll({ behavior: 'wait' })
  })

  // The header partial has an inline script that paints the cached version
  // during parsing (before first paint) to avoid flicker. With all API calls
  // aborted, http.js never updates #version, so only the inline paint is seen.
  test('paints the cached version without any API response', async ({ page }) => {
    await page.addInitScript(() => window.sessionStorage.setItem('lavinmq_version', '1.2.3-cached'))
    await page.route(url => url.pathname.startsWith('/api/'), route => route.abort())
    await page.goto('/queues')
    await expect(page.locator('#version')).toHaveText('1.2.3-cached')
  })
})

test.describe('vhosts', _ => {
  test('are loaded', async ({ page, vhosts }) => {
    await page.goto('/')
    vhosts = await vhosts
    await expect(page.locator('#userMenuVhost option')).toHaveCount(vhosts.length + 1) // + 1 for "All"
  })

  test('remember selection', async ({ page, vhosts }) => {
    await page.goto('/')
    vhosts = await vhosts
    await page.locator('#userMenuVhost').selectOption(vhosts[0]) // selectOption trigger page load
    await expect(page.locator('#userMenuVhost option:checked')).toHaveText([vhosts[0]])
  })
})
