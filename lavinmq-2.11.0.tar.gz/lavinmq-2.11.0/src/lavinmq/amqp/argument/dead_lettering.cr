require "sync/exclusive"
require "amq-protocol"
require "../argument"
require "../argument_validator/string_validator.cr"
require "../argument_validator/dead_lettering_validator.cr"

module LavinMQ::AMQP
  module Argument
    module DeadLettering
      # Use included hook to make this being run in the including class
      macro included
        add_argument_validator "x-dead-letter-exchange", ArgumentValidator::StringValidator.new
        add_argument_validator "x-dead-letter-routing-key", ArgumentValidator::DeadLetteringValidator.new
      end

      # stored is false when a closing vhost closed a destination; the source keeps the message
      alias MessageRoutedCallback = Proc(Bool, Nil)
      alias Task = {AMQP::Queue, Message} | MessageRoutedCallback

      struct Tasks
        @pending_tasks = Deque(Task).new

        def enqueue(task : Task)
          @pending_tasks << task
        end

        def dequeue? : Task?
          @pending_tasks.shift?
        end

        def empty? : Bool
          @pending_tasks.empty?
        end
      end

      class DeadLetterer
        # The DLX and DLRK are swapped in as one reference, so a route on
        # another thread never pairs a new DLX with an old DLRK
        class Target
          getter dlx : String?
          getter dlrk : String?

          def initialize(@dlx : String?, @dlrk : String?)
          end
        end

        @target = Atomic(Target).new(Target.new(nil, nil))

        def dlx : String?
          @target.get(:acquire).dlx
        end

        def dlrk : String?
          @target.get(:acquire).dlrk
        end

        def set_target(dlx : String?, dlrk : String?) : Nil
          previous = @target.swap(Target.new(dlx, dlrk), :acquire_release)
          # Warns again about an exchange it warned about before, once the
          # queue dead-letters somewhere else in between, see #warn_unroutable
          @warned_unroutable.set(nil, :release) if previous.dlx != dlx
        end

        # Tasks of drained chains, for the next chains to reuse. A chain holds
        # its tasks until drained, so chains running at once get one each.
        @free_tasks = Sync::Exclusive(Array(Tasks)).new(Array(Tasks).new, :unchecked)
        MAX_FREE_TASKS = 16

        # The exchange last warned about, see #warn_unroutable
        @warned_unroutable = Atomic(String?).new(nil)

        def initialize(@vhost : VHost, @queue_name : String, @log : Logger)
        end

        # Once per exchange in a row, and again after the queue's dead-letter
        # exchange changed, as every message dead-lettered to it is dropped,
        # and a burst would flood the log
        private def warn_unroutable(ex : AMQP::Exchange) : Nil
          return if @warned_unroutable.swap(ex.name) == ex.name
          @log.warn do
            "Dropping dead-lettered messages: exchange '#{ex.name}' (#{ex.type}) only routes MQTT publishes"
          end
        end

        private def cycle?(qname, props, reason) : Bool
          unless headers = props.headers
            return false
          end
          unless xdeaths = headers["x-death"]?.try &.as?(Array(AMQ::Protocol::Field))
            return false
          end
          # xdeath is sorted with the newest death first. To figure out if it's a
          # cycle or not we scan until we find the current queue with the same
          # reason. If we find any death because of a reject first, it's not
          # a cycle.
          xdeaths.each do |field|
            next unless xdeath = field.as?(AMQ::Protocol::Table)
            return false if xdeath["reason"]? == "rejected"
            return true if xdeath["queue"]? == qname && xdeath["reason"]? == reason.to_s
          end
          false
        end

        # This method will publish direct to queues instead of to the DLX.
        # It's done like this to be able to dead letter to all destinations
        # except to the queue itself if a cycle is detected.
        # This is also how it's done in rabbitmq

        def route(msg : BytesMessage, reason, dlx_tasks : Tasks? = nil, &routed : MessageRoutedCallback) : Nil
          # No dead letter exchange => nothing to do
          target = @target.get(:acquire)
          return routed.call(true) unless dlx = (msg.dlx || target.dlx)
          ex = dead_letter_exchange(dlx) || return routed.call(true)

          dlrk = msg.dlrk || target.dlrk

          props = create_message_properties(msg, reason)
          routing_headers = props.headers

          # If a dead lettering key exists, CC/BCC must be stripped from the
          # message entirely — the new routing key supersedes them.
          if dlrk
            props.headers.try do |h|
              h.delete("CC")
              h.delete("BCC")
            end
            routing_headers = props.headers
          end
          routing_rk = (dlrk || msg.routing_key).to_s

          # We're not publishing to an exchange, the queue itself is responsible
          # for delivering to destinations. This is to be able to do correct
          # cycle detection and to not create a lot of faulty stats.
          # This means that no delay, consistent hash check or such is performed
          # if the dead letter exchange has any of these features enabled.
          queues = Set(AMQP::Queue).new
          ex.find_queues(routing_rk, routing_headers, queues)
          return routed.call(true) if queues.empty?

          # The first dead lettering in a chain gets its own tasks, as the
          # queue can dead letter on several fibers/threads at once, while
          # nested ones (from overflow in a destination queue) add theirs
          # to the chain's
          first_in_chain = dlx_tasks.nil?
          ctx = dlx_tasks || take_tasks

          dead_letter_msg = Message.moved_copy(msg, timestamp: RoughTime.unix_ms,
            exchange_name: dlx.to_s, routing_key: routing_rk.to_s, properties: props)

          queues.each do |q|
            if cycle?(q.name, props, reason)
              @log.trace { "dead lettering cycle dest=#{q.name} msg=#{dead_letter_msg}" }
            else
              @log.trace { "dead lettering dest=#{q.name} msg=#{dead_letter_msg}" }
              ctx.enqueue({q, dead_letter_msg})
            end
          end
          ctx.enqueue(routed)

          drain_chain(ctx) if first_in_chain
        end

        # The exchange to dead-letter to, nil if it doesn't exist or doesn't
        # route AMQP messages
        private def dead_letter_exchange(dlx) : AMQP::Exchange?
          ex = @vhost.exchange?(dlx.to_s).as?(AMQP::Exchange) || return
          unless ex.routes_amqp_messages?
            warn_unroutable(ex)
            return
          end
          ex
        end

        private def take_tasks : Tasks
          @free_tasks.lock(&.pop?) || Tasks.new
        end

        private def drain_chain(tasks : Tasks) : Nil
          drain_context(tasks)
          @free_tasks.lock do |free|
            free.push(tasks) if tasks.empty? && free.size < MAX_FREE_TASKS
          end
        end

        private def drain_context(tasks : Tasks)
          # A message's destinations are queued right before its callback
          dst_closed = false
          while task = tasks.dequeue?
            case task
            when MessageRoutedCallback
              stored = !dst_closed
              dst_closed = false
              begin
                task.call(stored)
              rescue ex
                @log.error(exception: ex) { "Unexpected error in dead letter routed callback" }
              end
            else
              dst_q, msg = task
              begin
                dst_q.strip_delivery_count(msg)
                # Dropped on overflow, or by a queue closed on an error while it stays bound
                if dst_q.publish_internal(msg, dlx_tasks: tasks).closed? && @vhost.closed?
                  dst_closed = true
                end
              rescue ex : Exception
                @log.error(exception: ex) { "Unexpected error when dead lettering to #{dst_q.name}, messages dropped" }
              end
            end
          end
        end

        private def create_message_properties(msg, reason)
          props = msg.properties
          h = props.headers || AMQP::Table.new
          h.reject! { |k, _| k.in?("x-dead-letter-exchange", "x-dead-letter-routing-key") }

          # there's a performance advantage to do `has_key?` over `||=`
          h["x-first-death-reason"] = reason.to_s unless h.has_key? "x-first-death-reason"
          h["x-first-death-queue"] = @queue_name unless h.has_key? "x-first-death-queue"
          h["x-first-death-exchange"] = msg.exchange_name unless h.has_key? "x-first-death-exchange"

          routing_keys = [msg.routing_key.as(AMQP::Field)]
          # Add any CC, but NOT BCC!
          if cc = h["CC"]?.try(&.as?(Array(AMQP::Field)))
            routing_keys.concat cc.as(Array(AMQP::Field))
          end

          props.headers = update_x_death(h, msg.exchange_name, routing_keys, reason, msg.properties.expiration)
          props.expiration = nil
          props
        end

        private def update_x_death(headers, exchange_name, routing_keys, reason, expiration) : AMQP::Table
          xdeaths = headers["x-death"]?.as?(Array(AMQP::Field)) || Array(AMQP::Field).new(1)

          found_at = -1
          xdeaths.each_with_index do |xd, idx|
            next unless xd = xd.as?(AMQP::Table)
            next if xd["reason"]? != reason.to_s
            next if xd["queue"]? != @queue_name
            count = xd["count"].as?(Int) || 0
            xd.merge!({
              count:          count + 1,
              time:           RoughTime.utc,
              "routing-keys": routing_keys,
            })
            xd["original-expiration"] = expiration if expiration
            found_at = idx
            break
          end

          case found_at
          when -1 # not found so inserting new x-death
            death = AMQP::Table.new({
              "queue":        @queue_name,
              "reason":       reason.to_s,
              "exchange":     exchange_name,
              "count":        1,
              "time":         RoughTime.utc,
              "routing-keys": routing_keys,
            })
            death["original-expiration"] = expiration if expiration
            xdeaths.unshift death
          when 0
            # do nothing, updated xd is in the front
          else
            # move updated xd to the front
            xd = xdeaths.delete_at(found_at)
            xdeaths.unshift xd
          end
          headers["x-death"] = xdeaths
          headers
        end
      end
    end
  end
end

# Required after the module: Queue includes DeadLettering, so a top require would break the include.
require "../queue/queue"
