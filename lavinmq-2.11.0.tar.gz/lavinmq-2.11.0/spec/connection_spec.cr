require "./spec_helper"
require "log/spec"

# AMQP::Client is too good at handling errors, so we need to make it unsafe
class AMQP::Client::UnsafeConnection < AMQP::Client::Connection
  # It does not allow the client to send a channel_max or frame_max higher than the server's
  # We need to test that the server can handle this case
  private def self.tune(io, channel_max, frame_max, heartbeat)
    _tune = ::AMQ::Protocol::Stream.new(io).next_frame do |f|
      case f
      when Frame::Connection::Tune  then f
      when Frame::Connection::Close then raise ClosedException.new(f)
      else                               raise Error::UnexpectedFrame.new(f)
      end
    end
    # channel_max = tune.channel_max.zero? ? channel_max : Math.min(tune.channel_max, channel_max)
    # frame_max = tune.frame_max.zero? ? frame_max : Math.min(tune.frame_max, frame_max)
    io.write_bytes Frame::Connection::TuneOk.new(channel_max: channel_max,
      frame_max: frame_max,
      heartbeat: heartbeat),
      IO::ByteFormat::NetworkEndian
    {channel_max, frame_max, heartbeat}
  end

  # AMQP::Client protects against the client opening more than channel_max channels
  # We need to test that the server can handle this case
  def channel(id : Int? = nil)
    ch = nil
    @channels_lock.synchronize do
      if id
        # raise "channel_max reached" if @channel_max.positive? && id > @channel_max
        if ch = @channels.fetch(id, nil)
          return ch
        else
          ch = @channels[id] = Channel.new(self, id)
        end
      end
      # range = @channel_max.zero? ? (1_u16..UInt16::MAX) : (1_u16..@channel_max)
      range = (1_u16..UInt16::MAX)
      range.each do |i|
        next if @channels.has_key? i
        ch = @channels[i] = Channel.new(self, i)
        break
      end
    end
    # raise "channel_max reached" if ch.nil?
    # We must open the channel outside of the lock to avoid deadlocks
    raise "bug in unsafe spec #channel implementation" if ch.nil?
    ch.open
  end
end

class AMQP::Client::UnsafeClient < AMQP::Client
  def connect_unsafe : Connection
    socket = connect_tcp
    AMQP::Client::UnsafeConnection.start(socket, @user, @password, @vhost, @channel_max,
      @frame_max, @heartbeat, @connection_information, @name)
  end
end

# Opens a raw AMQP connection that consumes from *queue* but never reads,
# and publishes until the server's write to it blocks
def with_stuck_consumer(s, queue, body_size = 64 * 1024, count = 200, &)
  with_raw_amqp_connection(s) do |io, stream|
    io.write_bytes AMQ::Protocol::Frame::Channel::Open.new(1_u16), IO::ByteFormat::NetworkEndian
    io.flush
    stream.next_frame.as(AMQ::Protocol::Frame::Channel::OpenOk)
    with_channel(s) do |ch|
      q = ch.queue(queue)
      io.write_bytes AMQ::Protocol::Frame::Basic::Consume.new(1_u16, 0_u16, queue, "", false, true, false, false,
        AMQ::Protocol::Table.new), IO::ByteFormat::NetworkEndian
      io.flush
      stream.next_frame.as(AMQ::Protocol::Frame::Basic::ConsumeOk)
      client = s.connections.find! do |c|
        c.as(LavinMQ::AMQP::Client).connection_info.remote_address.port == io.local_address.port
      end.as(LavinMQ::AMQP::Client)
      body = Bytes.new(body_size)
      # more than the socket buffers can hold, so delivery to the client blocks
      count.times { q.publish body }
      wait_for { s.vhosts["/"].queue(queue).message_count > 0 }
      yield client, io, stream
    end
  end
end

describe LavinMQ::Server do
  describe "channel close" do
    it "does not close the connection for frames on a channel waiting for close-ok" do
      with_amqp_server do |s|
        with_raw_amqp_connection(s) do |io, stream|
          io.write_bytes AMQ::Protocol::Frame::Channel::Open.new(1_u16), IO::ByteFormat::NetworkEndian
          io.flush
          stream.next_frame.as(AMQ::Protocol::Frame::Channel::OpenOk)

          io.write_bytes AMQ::Protocol::Frame::Basic::Ack.new(1_u16, 999_u64, false), IO::ByteFormat::NetworkEndian
          io.flush
          close = stream.next_frame.as(AMQ::Protocol::Frame::Channel::Close)
          close.reply_code.should eq 406

          io.write_bytes AMQ::Protocol::Frame::Basic::Ack.new(1_u16, 999_u64, false), IO::ByteFormat::NetworkEndian
          io.write_bytes AMQ::Protocol::Frame::Channel::Open.new(2_u16), IO::ByteFormat::NetworkEndian
          io.flush
          stream.next_frame.should be_a(AMQ::Protocol::Frame::Channel::OpenOk)

          io.write_bytes AMQ::Protocol::Frame::Channel::CloseOk.new(1_u16), IO::ByteFormat::NetworkEndian
          io.write_bytes AMQ::Protocol::Frame::Connection::Close.new(200_u16, "done", 0_u16, 0_u16),
            IO::ByteFormat::NetworkEndian
          io.flush
          stream.next_frame.as(AMQ::Protocol::Frame::Connection::CloseOk)
        end
      end
    end

    it "discards a method frame pipelined after a server-initiated channel close" do
      with_amqp_server do |s|
        with_raw_amqp_connection(s) do |io, stream|
          io.write_bytes AMQ::Protocol::Frame::Channel::Open.new(1_u16), IO::ByteFormat::NetworkEndian
          io.flush
          stream.next_frame.as(AMQ::Protocol::Frame::Channel::OpenOk)

          # A passive declare of a missing queue makes the server close the channel.
          # The client cannot know that yet, so it pipelines another method frame on
          # the same channel. The server must discard it and keep the connection.
          io.write_bytes AMQ::Protocol::Frame::Queue::Declare.new(1_u16, 0_u16, "no-such-queue",
            true, false, false, false, false, AMQ::Protocol::Table.new), IO::ByteFormat::NetworkEndian
          io.write_bytes AMQ::Protocol::Frame::Basic::Qos.new(1_u16, 0_u32, 1_u16, false),
            IO::ByteFormat::NetworkEndian
          io.write_bytes AMQ::Protocol::Frame::Channel::Open.new(2_u16), IO::ByteFormat::NetworkEndian
          io.flush

          close = stream.next_frame.as(AMQ::Protocol::Frame::Channel::Close)
          close.reply_code.should eq 404
          stream.next_frame.should be_a(AMQ::Protocol::Frame::Channel::OpenOk)

          # The id is free again once the client has replied CloseOk.
          io.write_bytes AMQ::Protocol::Frame::Channel::CloseOk.new(1_u16), IO::ByteFormat::NetworkEndian
          io.write_bytes AMQ::Protocol::Frame::Channel::Open.new(1_u16), IO::ByteFormat::NetworkEndian
          io.flush
          stream.next_frame.should be_a(AMQ::Protocol::Frame::Channel::OpenOk)

          io.write_bytes AMQ::Protocol::Frame::Connection::Close.new(200_u16, "done", 0_u16, 0_u16),
            IO::ByteFormat::NetworkEndian
          io.flush
          stream.next_frame.as(AMQ::Protocol::Frame::Connection::CloseOk)
        end
      end
    end

    it "does not close the connection for a settlement frame on an already-closed channel" do
      with_amqp_server do |s|
        with_raw_amqp_connection(s) do |io, stream|
          io.write_bytes AMQ::Protocol::Frame::Channel::Open.new(1_u16), IO::ByteFormat::NetworkEndian
          io.flush
          stream.next_frame.as(AMQ::Protocol::Frame::Channel::OpenOk)

          # Client closes the channel; the broker removes it and replies CloseOk.
          io.write_bytes AMQ::Protocol::Frame::Channel::Close.new(1_u16, 200_u16, "", 0_u16, 0_u16),
            IO::ByteFormat::NetworkEndian
          io.flush
          stream.next_frame.as(AMQ::Protocol::Frame::Channel::CloseOk)

          # A delivery settled in another fiber races the close and arrives after
          # the channel is gone. The broker must discard it, not kill the whole
          # connection. Open a second channel to prove the connection survived.
          io.write_bytes AMQ::Protocol::Frame::Basic::Ack.new(1_u16, 1_u64, false), IO::ByteFormat::NetworkEndian
          io.write_bytes AMQ::Protocol::Frame::Channel::Open.new(2_u16), IO::ByteFormat::NetworkEndian
          io.flush
          stream.next_frame.should be_a(AMQ::Protocol::Frame::Channel::OpenOk)

          io.write_bytes AMQ::Protocol::Frame::Connection::Close.new(200_u16, "done", 0_u16, 0_u16),
            IO::ByteFormat::NetworkEndian
          io.flush
          stream.next_frame.as(AMQ::Protocol::Frame::Connection::CloseOk)
        end
      end
    end

    it "does not close the connection for a settlement frame on a never-opened channel" do
      with_amqp_server do |s|
        with_raw_amqp_connection(s) do |io, stream|
          io.write_bytes AMQ::Protocol::Frame::Channel::Open.new(1_u16), IO::ByteFormat::NetworkEndian
          io.flush
          stream.next_frame.as(AMQ::Protocol::Frame::Channel::OpenOk)

          # A stray settlement (here on a channel that was never opened) is
          # discarded with a warning, not treated as a fatal protocol error.
          # Open another channel to prove the connection survived.
          io.write_bytes AMQ::Protocol::Frame::Basic::Ack.new(5_u16, 1_u64, false), IO::ByteFormat::NetworkEndian
          io.write_bytes AMQ::Protocol::Frame::Channel::Open.new(2_u16), IO::ByteFormat::NetworkEndian
          io.flush
          stream.next_frame.should be_a(AMQ::Protocol::Frame::Channel::OpenOk)

          io.write_bytes AMQ::Protocol::Frame::Connection::Close.new(200_u16, "done", 0_u16, 0_u16),
            IO::ByteFormat::NetworkEndian
          io.flush
          stream.next_frame.as(AMQ::Protocol::Frame::Connection::CloseOk)
        end
      end
    end
  end

  describe "unexpected frames" do
    it "doesn't time out a client whose frames never start at a socket read" do
      with_amqp_server do |s|
        with_raw_amqp_connection(s, heartbeat: 1_u16) do |io, _stream|
          wait_for { s.connections.size == 1 }
          client = s.connections.first.as(LavinMQ::AMQP::Client)
          frame = IO::Memory.new
          frame.write_bytes AMQ::Protocol::Frame::Heartbeat.new, IO::ByteFormat::NetworkEndian
          bytes = frame.to_slice
          # Every write ends in the middle of a frame, for longer than the
          # heartbeat timeout (1 s + 5 s), then the client goes quiet
          straddling = IO::Memory.new
          straddling.write bytes[4, 4]
          straddling.write bytes[0, 4]
          io.write bytes[0, 4]
          io.flush
          deadline = Time.instant + 7.seconds
          while Time.instant < deadline
            io.write straddling.to_slice
            io.flush
            sleep 100.milliseconds
          end
          io.write bytes[4, 4]
          io.flush
          sleep 1.5.seconds
          client.closed?.should be_false
        end
      end
    end

    it "doesn't time out a client that sends heartbeats when socket_buffer_size is 0" do
      config = LavinMQ::Config.new
      config.socket_buffer_size = 0
      with_amqp_server(config: config) do |s|
        with_raw_amqp_connection(s, heartbeat: 1_u16) do |io, _stream|
          wait_for { s.connections.size == 1 }
          client = s.connections.first.as(LavinMQ::AMQP::Client)
          # Longer than the heartbeat timeout (1 s + 5 s), with a pause
          # between heartbeats that lets the server's read time out
          8.times do
            io.write_bytes AMQ::Protocol::Frame::Heartbeat.new, IO::ByteFormat::NetworkEndian
            io.flush
            sleep 1.second
          end
          client.closed?.should be_false
        end
      end
    end

    it "closes the connection with unexpected frame for heartbeat on non-zero channel" do
      with_amqp_server do |s|
        with_raw_amqp_connection(s) do |io, stream|
          io.write_byte(8_u8)                             # heartbeat frame type
          IO::ByteFormat::NetworkEndian.encode(1_u16, io) # channel
          IO::ByteFormat::NetworkEndian.encode(0_u32, io) # frame size
          io.write_byte(206_u8)                           # frame end
          io.flush

          close = stream.next_frame.as(AMQ::Protocol::Frame::Connection::Close)
          close.reply_code.should eq 505
        end
      end
    end
  end

  describe "channel_max" do
    it "should not accept a channel_max from the client lower than the server config" do
      with_amqp_server do |s|
        server_channel_max = LavinMQ::Config.instance.channel_max
        client_channel_max = server_channel_max + 1
        expect_raises(AMQP::Client::Connection::ClosedException, /failed to negotiate connection parameters/) do
          AMQP::Client::UnsafeClient.new(port: amqp_port(s), channel_max: client_channel_max).connect_unsafe
        end
      end
    end

    it "should not allow client to set channel_max to zero (unlimited) if the server has a limit" do
      with_amqp_server do |s|
        expect_raises(AMQP::Client::Connection::ClosedException, /failed to negotiate connection parameters/) do
          AMQP::Client::UnsafeClient.new(port: amqp_port(s), channel_max: 0).connect_unsafe
        end
      end
    end

    it "should allow client to set channel_max to zero (unlimited) if the server has no limit" do
      config = LavinMQ::Config.new
      config.channel_max = 0
      with_amqp_server(config: config) do |s|
        AMQP::Client.new(port: amqp_port(s), channel_max: 0).connect
        s.connections.first.as(LavinMQ::AMQP::Client).channel_max.should eq 0
      end
    end

    it "should not allow client to create more channels than the negotiated max" do
      with_amqp_server do |s|
        conn = AMQP::Client::UnsafeClient.new(port: amqp_port(s), channel_max: 1).connect_unsafe
        conn.channel
        expect_raises(AMQP::Client::Connection::ClosedException, /number of channels opened \(1\) has reached the negotiated channel_max \(1\)/) do
          conn.channel
        end
      end
    end

    it "should allow client to create 'unlimited' channels if the server has no limit" do
      config = LavinMQ::Config.new
      config.channel_max = 0
      with_amqp_server(config: config) do |s|
        conn = AMQP::Client.new(port: amqp_port(s), channel_max: 0).connect
        conn.channel
        conn.channel
        s.connections.first.channel_count.should eq 2
        s.connections.first.as(LavinMQ::AMQP::Client).channel_max.should eq 0
      end
    end
  end

  describe "invalid frame end" do
    it "should respond with frame error when routing key exceeds 255 bytes" do
      with_amqp_server do |s|
        io = TCPSocket.new("localhost", amqp_port(s))
        io.read_timeout = 5.seconds

        # AMQP handshake
        io.write AMQ::Protocol::PROTOCOL_START_0_9_1.to_slice
        io.flush
        stream = AMQ::Protocol::Stream.new(io)
        stream.next_frame.as(AMQ::Protocol::Frame::Connection::Start)
        response = "\u0000guest\u0000guest"
        io.write_bytes(AMQ::Protocol::Frame::Connection::StartOk.new(
          AMQ::Protocol::Table.new, "PLAIN", response, ""),
          IO::ByteFormat::NetworkEndian)
        io.flush
        tune = stream.next_frame.as(AMQ::Protocol::Frame::Connection::Tune)
        io.write_bytes AMQ::Protocol::Frame::Connection::TuneOk.new(
          channel_max: tune.channel_max, frame_max: tune.frame_max, heartbeat: 0_u16),
          IO::ByteFormat::NetworkEndian
        io.write_bytes AMQ::Protocol::Frame::Connection::Open.new("/"), IO::ByteFormat::NetworkEndian
        io.flush
        stream.next_frame.as(AMQ::Protocol::Frame::Connection::OpenOk)
        io.write_bytes AMQ::Protocol::Frame::Channel::Open.new(1_u16), IO::ByteFormat::NetworkEndian
        io.flush
        stream.next_frame.as(AMQ::Protocol::Frame::Channel::OpenOk)

        # Simulate a broken client sending a 10,000-byte routing key
        # with a truncated ShortString length byte (10000 & 0xFF = 16)
        routing_key = "x" * 10_000
        exchange = "amq.direct"

        payload = IO::Memory.new
        IO::ByteFormat::NetworkEndian.encode(60_u16, payload) # class_id (Basic)
        IO::ByteFormat::NetworkEndian.encode(40_u16, payload) # method_id (Publish)
        IO::ByteFormat::NetworkEndian.encode(0_u16, payload)  # reserved1
        payload.write_byte(exchange.bytesize.to_u8)           # exchange ShortString
        payload.write(exchange.to_slice)
        payload.write_byte((routing_key.bytesize & 0xFF).to_u8) # truncated length byte
        payload.write(routing_key.to_slice)                     # full 10,000 bytes
        payload.write_byte(0_u8)                                # mandatory=false, immediate=false

        io.write_byte(1_u8)                                          # frame type (Method)
        IO::ByteFormat::NetworkEndian.encode(1_u16, io)              # channel
        IO::ByteFormat::NetworkEndian.encode(payload.pos.to_u32, io) # frame size
        io.write(payload.to_slice)
        io.write_byte(206_u8) # frame end
        io.flush

        close = stream.next_frame.as(AMQ::Protocol::Frame::Connection::Close)
        close.reply_code.should eq 501
      ensure
        io.try &.close
      end
    end
  end

  describe "frame_max" do
    it "should not accept a frame_max from the client lower than the server config" do
      with_amqp_server do |s|
        server_frame_max = LavinMQ::Config.instance.frame_max
        client_frame_max = server_frame_max + 1
        expect_raises(AMQP::Client::Connection::ClosedException, /failed to negotiate connection parameters/) do
          AMQP::Client::UnsafeClient.new(port: amqp_port(s), frame_max: client_frame_max).connect_unsafe
        end
      end
    end

    it "should not allow client to set frame_max to zero (unlimited) if the server has a limit" do
      with_amqp_server do |s|
        expect_raises(AMQP::Client::Connection::ClosedException, /failed to negotiate connection parameters/) do
          AMQP::Client::UnsafeClient.new(port: amqp_port(s), frame_max: 0).connect_unsafe
        end
      end
    end

    it "should allow client to set frame_max to zero (unlimited) if the server has no limit" do
      config = LavinMQ::Config.new
      config.frame_max = 0
      with_amqp_server(config: config) do |s|
        AMQP::Client.new(port: amqp_port(s), frame_max: 0).connect
        s.connections.first.as(LavinMQ::AMQP::Client).max_frame_size.should eq 0
      end
    end

    it "should not allow client to send a frame larger than the negotiated frame_max" do
      with_amqp_server do |s|
        conn = AMQP::Client.new(port: amqp_port(s)).connect
        ch = conn.channel
        frame_max = LavinMQ::Config.instance.frame_max
        bytes = frame_max + 1
        expect_raises(AMQP::Client::Connection::ClosedException, /Frame size #{bytes} exceeds max frame size #{frame_max}/) do
          conn.unsafe_write AMQ::Protocol::Frame::Basic::Publish.new(ch.id, 0_u16, "amq.direct", "test", false, false)
          conn.unsafe_write AMQ::Protocol::Frame::Header.new(ch.id, 60_u16, 0_u16, bytes.to_u64, AMQ::Protocol::Properties.new)
          conn.unsafe_write AMQ::Protocol::Frame::BytesBody.new(ch.id, bytes, Slice.new(bytes.to_i32, 0_u8))
          conn.channel # We need to do something blocking on the channel to trigger the error
        end
      end
    end
  end

  describe "tcp_send_timeout" do
    it "disconnects a consumer that doesn't read" do
      LavinMQ::Config.instance.tcp_send_timeout = 1
      with_amqp_server do |s|
        with_stuck_consumer(s, "tcp_send_timeout") do |client|
          wait_for(10.seconds) { client.closed? }
        end
      end
    end

    it "doesn't resend buffered data when disconnecting a consumer that doesn't read" do
      LavinMQ::Config.instance.tcp_send_timeout = 1
      with_amqp_server do |s|
        # small messages go through the socket's write buffer
        with_stuck_consumer(s, "tcp_send_timeout_resend", body_size: 100, count: 100_000) do |client, io, stream|
          sleep 1.5.seconds # the first write has timed out, the connection is closing
          io.read_timeout = 10.seconds
          frames = 0
          loop do
            stream.next_frame # raises on a duplicated, so misaligned, frame
            frames += 1
          rescue IO::EOFError
            break
          end
          frames.should be > 0
          client.closed?.should be_true
        end
      end
    end

    it "can force close a connection while a delivery to it is blocked" do
      LavinMQ::Config.instance.tcp_send_timeout = 2
      with_amqp_server do |s|
        with_stuck_consumer(s, "tcp_send_timeout_force_close") do |client|
          closed = Channel(Nil).new
          spawn do
            client.force_close
            closed.send nil
          end
          select
          when closed.receive
          when timeout(10.seconds)
            fail "force_close didn't complete"
          end
          client.closed?.should be_true
        end
      end
    end

    it "closes a connection within force_close_timeout while a delivery to it is blocked" do
      LavinMQ::Config.instance.tcp_send_timeout = 30
      with_amqp_server do |s|
        with_stuck_consumer(s, "tcp_send_timeout_close") do |client|
          Log.capture("lmq.amqp.client", :info) do |logs|
            closed = Channel(Nil).new
            spawn do
              client.close("Closed via management plugin", force_close_timeout: 1.second)
              closed.send nil
            end
            select
            when closed.receive
            when timeout(5.seconds)
              fail "close didn't complete within force_close_timeout"
            end
            client.closed?.should be_true
            logs.check(:info, /Sending the Close frame didn't complete within 1.0s/)
          end
        end
      end
    end

    it "closes a connection through the HTTP API while a delivery to it is blocked" do
      LavinMQ::Config.instance.tcp_send_timeout = 30
      with_http_server do |http, s|
        with_stuck_consumer(s, "tcp_send_timeout_api_close") do |client|
          name = URI.encode_path(client.name)
          deleted = Channel(Int32).new
          spawn { deleted.send http.delete("/api/connections/#{name}").status_code }
          select
          when status = deleted.receive
            status.should eq 204
          when timeout(7.seconds)
            fail "DELETE /api/connections didn't complete within force_close_timeout"
          end
          client.closed?.should be_true
        end
      end
    end

    it "gets the Close frame to a client that resumes reading when closed without force_close_timeout" do
      LavinMQ::Config.instance.tcp_send_timeout = 30
      with_amqp_server do |s|
        with_stuck_consumer(s, "tcp_send_timeout_close_resumed_reader") do |client, io|
          # Like ConnectionStore#close_all, without force_close_timeout
          spawn { client.close("Server shutdown", timeout: 500.milliseconds) }
          # The delivery holds the write lock past the close timeout
          sleep 1.second
          io.read_timeout = 10.seconds
          stream = AMQ::Protocol::Stream.new(io, frame_max: LavinMQ::Config.instance.frame_max)
          loop do
            break if stream.next_frame.is_a?(AMQ::Protocol::Frame::Connection::Close)
          end
        end
      end
    end

    it "can force close a connection while a large message is delivered to a slow reader" do
      LavinMQ::Config.instance.tcp_send_timeout = 30
      with_amqp_server do |s|
        with_stuck_consumer(s, "tcp_send_timeout_slow_reader", body_size: 32 * 1024 * 1024, count: 2) do |client, io|
          # reads too slowly for the delivery to finish, but fast enough for
          # the write not to time out
          spawn do
            buf = Bytes.new(1024)
            loop do
              break if io.read(buf).zero?
              sleep 10.milliseconds
            end
          rescue IO::Error
          end
          sleep 0.5.seconds # the delivery is in progress, holding the write lock
          closed = Channel(Nil).new
          spawn do
            client.force_close
            closed.send nil
          end
          select
          when closed.receive
          when timeout(5.seconds)
            fail "force_close didn't complete"
          end
          client.closed?.should be_true
        end
      end
    end
  end
end
