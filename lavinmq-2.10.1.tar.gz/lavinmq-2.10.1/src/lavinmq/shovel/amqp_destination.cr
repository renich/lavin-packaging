require "amqp-client"
require "./destination"

module LavinMQ
  module Shovel
    class AMQPDestination < Destination
      @conn : ::AMQP::Client::Connection?
      @ch : ::AMQP::Client::Channel?

      def initialize(@name : String, @uri : URI, @queue : String?, @exchange : String? = nil,
                     @exchange_key : String? = nil, @ack_mode = DEFAULT_ACK_MODE, direct_user : Auth::User? = nil)
        if @uri.user.nil? && @uri.host.to_s.empty?
          if direct_user
            @uri.user = direct_user.name
            @uri.password = direct_user.plain_text_password
          else
            raise ArgumentError.new("direct_user required")
          end
        end
        params = @uri.query_params
        params["name"] ||= "Shovel #{@name} sink"
        @uri.query = params.to_s
        if queue
          @exchange = ""
          @exchange_key = queue
        end
        if @exchange.nil?
          raise ArgumentError.new("Shovel destination requires an exchange")
        end
      end

      def start
        return if started?
        if c = @conn
          c.close
        end
        conn = ::AMQP::Client.new(@uri).connect
        @conn = conn
        @ch = ch = conn.channel
        if q = @queue
          begin
            ch.queue_declare(q, passive: true)
          rescue ::AMQP::Client::Channel::ClosedException
            @ch = ch = conn.channel
            ch.queue_declare(q, passive: false)
          end
        end
      end

      def stop
        @conn.try &.close
        @ch = nil
      end

      def started? : Bool
        !@ch.nil? && !@conn.try &.closed?
      end

      def push(msg) : Nil
        ch = @ch || raise "Not started"
        ex = @exchange || msg.exchange
        rk = @exchange_key || msg.routing_key
        tag = msg.delivery_tag
        case @ack_mode
        in AckMode::OnConfirm
          # The confirm callback's Bool is the broker's ack/nack. A nack (e.g.
          # reject-publish overflow) is transient — the queue may drain — so it
          # becomes Retry, never a silent ack. When the connection goes away
          # amqp-client voids every pending confirm with `false` as well. That
          # is reported as Retry too: when the connection drops on its own the
          # source is still open and
          # every in-flight message has to go back to it, or a later cumulative
          # ack would settle it undelivered. When the whole shovel is stopping
          # the source is already closed and the Runner ignores the report.
          ch.basic_publish(msg.body_io, ex, rk, props: msg.properties) do |confirmed|
            @listener.report(tag, confirmed ? Outcome::Confirmed : Outcome::Retry)
          end
        in AckMode::OnPublish
          ch.basic_publish(msg.body_io, ex, rk, props: msg.properties)
          @listener.report(tag, Outcome::Confirmed)
        in AckMode::NoAck
          ch.basic_publish(msg.body_io, ex, rk, props: msg.properties)
        end
      end
    end
  end
end
