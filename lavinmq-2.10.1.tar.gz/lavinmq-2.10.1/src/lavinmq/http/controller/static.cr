require "http/server/handler"
require "compress/zlib"

module LavinMQ
  module HTTP
    class StaticController
      include ::HTTP::Handler

      PUBLIC_DIR = "#{__DIR__}/../../../../static"

      LAYOUT_INLINE_JS_SHA    = "sha256-xCBzVV2TewAz4Dk/CrTquSJ4NTH48Y5fckwTF8Lg5bE="
      LOGIN_INLINE_JS_SHA     = "sha256-3bUZcnRc7hbNc+igS1dxqJNEEypKXCvZ9ozHwAxXIvc="
      VERSION_INLINE_JS_SHA   = "sha256-GgZA/DYl7oCp6n7XdT+Bi2RHOQdZ/onfVRmY6d8/Jow="
      CONTENT_SECURITY_POLICY = "default-src 'none'; style-src 'self'; font-src 'self'; img-src 'self'; connect-src 'self'; script-src 'self' '#{LAYOUT_INLINE_JS_SHA}' '#{LOGIN_INLINE_JS_SHA}' '#{VERSION_INLINE_JS_SHA}'"

      # HTML views reachable without a session
      PUBLIC_HTML = {"/login.html", "/401.html", "/404.html"}

      def call(context)
        path = context.request.path
        if context.request.method.in?("GET", "HEAD") && !path.starts_with?("/api/")
          path = "/docs/index.html" if path == "/docs/"
          if html_view?(path)
            return context if redirect_unless_logged_in(context, path)
            add_security_headers(context)
          end
          serve(context, path) || call_next(context)
        else
          call_next(context)
        end
      end

      # Management UI pages are baked as static .html files and are therefore
      # directly addressable. They must carry the same security headers and
      # login redirect whether reached through the clean route (ViewsController
      # rewrites the path to .html) or requested directly. The docs are exempt.
      private def html_view?(path)
        path.ends_with?(".html") && !path.starts_with?("/docs/")
      end

      private def add_security_headers(context)
        context.response.headers.add("X-Frame-Options", "SAMEORIGIN")
        context.response.headers.add("Referrer-Policy", "same-origin")
        context.response.headers.add("Content-Security-Policy", CONTENT_SECURITY_POLICY)
      end

      private def redirect_unless_logged_in(context, path)
        return false if path.in?(PUBLIC_HTML)
        return false if context.request.cookies.has_key?("m") || context.request.cookies.has_key?("oauth_token")
        context.response.status = ::HTTP::Status::TEMPORARY_REDIRECT
        context.response.headers["Location"] = "login"
        true
      end

      {% if flag?(:release) || flag?(:bake_static) %}
        private def lookup(file_path)
          case file_path
          {{ run("./static/bake", PUBLIC_DIR) }}
          end
        end

        private def serve(context, file_path)
          if static_file = lookup(file_path)
            bytes, etag, deflated = static_file
            if context.request.headers["If-None-Match"]? == etag
              context.response.status_code = 304
            else
              context.response.headers.add("Cache-Control", "no-cache")
              context.response.headers.add("ETag", etag)
              context.response.content_type = mime_type(file_path)
              if deflated
                if context.request.headers["Accept-Encoding"]?.try &.includes?("deflate")
                  context.response.headers.add("Content-Encoding", "deflate")
                  context.response.content_length = bytes.size
                  if context.request.method == "GET" # HEAD requests don't get bodies
                    begin
                      context.response.write(bytes)
                    rescue ex : IndexError
                      raise IO::Error.new(cause: ex)
                    end
                  end
                else # client doesn't want deflated bodies
                  if context.request.method == "GET" # HEAD requests don't get bodies
                    io = IO::Memory.new(bytes)
                    Compress::Zlib::Reader.open(io) do |zlib|
                      IO.copy(zlib, context.response)
                    end
                  end
                end
              else # not deflated
                context.response.content_length = bytes.size
                if context.request.method == "GET" # HEAD requests don't get bodies
                  begin
                    context.response.write(bytes)
                  rescue ex : IndexError
                    raise IO::Error.new(cause: ex)
                  end
                end
              end
            end
            context
          end
        end
      {% else %}
        private def serve(context, file_path)
          Log.debug { "Serve #{file_path} from static?" }
          full_path = File.join(PUBLIC_DIR, file_path)
          raise File::NotFoundError.new("file isn't a file", file: full_path) unless File.file?(full_path)
          File.open(full_path) do |file|
            Log.debug { "Serving static #{file_path}" }
            file.read_buffering = false
            etag = %(W/"#{Digest::MD5.hexdigest(file)}")
            if context.request.headers["If-None-Match"]? == etag
              context.response.status_code = 304
            else
              context.response.headers.add("Cache-Control", "no-cache")
              context.response.headers.add("ETag", etag)
              context.response.content_type = mime_type(file.path)
              context.response.content_length = file.size
              if context.request.method == "GET"
                file.rewind
                IO.copy(file, context.response)
              end
            end
            context
          end
        rescue File::NotFoundError
          nil
        end
      {% end %}

      private def mime_type(path)
        case File.extname(path)
        when ".txt"        then "text/plain;charset=utf-8"
        when ".html"       then "text/html;charset=utf-8"
        when ".css"        then "text/css;charset=utf-8"
        when ".js", ".mjs" then "application/javascript"
        when ".png"        then "image/png"
        when ".ico"        then "image/x-icon"
        when ".jpg"        then "image/jpeg"
        when ".gif"        then "image/gif"
        when ".svg"        then "image/svg+xml"
        when ".webp"       then "image/webp"
        when ".yaml"       then "application/yaml"
        else                    "application/octet-stream"
        end
      end
    end
  end
end
