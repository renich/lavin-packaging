require "openssl"
require "socket"
require "../client"
require "../error"
require "../rough_time"
require "../../stdlib/io_buffered_discard"
require "../../stdlib/socket_shutdown"
require "./session"
require "./protocol"
require "../bool_channel"
require "./consts"
require "./publish_context"
require "../stats"
require "../persister"
require "sync/exclusive"

module LavinMQ
  module MQTT
    # Protocol level from the CONNECT packet:
    # level 3 is MQTT 3.1 (MQIsdp), level 4 is MQTT 3.1.1 (MQTT).
    enum ProtocolVersion : UInt8
      V3_1   = 3
      V3_1_1 = 4

      def name
        case self
        in .v3_1?   then "MQTT 3.1"
        in .v3_1_1? then "MQTT 3.1.1"
        end
      end
    end

    class Client < LavinMQ::Client
      include Stats
      include SortableJSON
      include Persister::ConfirmTarget

      # A QoS 1 publish waiting for its PUBACK, which is sent once the
      # persister has made the publish durable. `seq` orders the publishes, so
      # the persister's cumulative confirm releases every PUBACK up to it.
      record PendingPubAck, seq : UInt64, packet_id : UInt16

      getter log, name, user, client_id, socket, connection_info
      getter? clean_session
      @connected_at = RoughTime.unix_ms
      @channels = Hash(UInt16, Client::Channel).new
      @session : MQTT::Session?
      @publish_context = PublishContext.new
      @protocol : String
      @publish_seq = 0u64
      @pending_pubacks = Sync::Exclusive(Deque(PendingPubAck)).new(Deque(PendingPubAck).new, :unchecked)
      # Created with the PUBACK writer fiber on the first QoS 1 publish
      @puback_mailbox : ::Channel(UInt64)?
      rate_stats({"send_oct", "recv_oct"})
      Log = LavinMQ::Log.for "mqtt.client"

      def vhost
        @broker.vhost
      end

      # Stub channel accessors for polymorphic dispatch with AMQP::Client

      def channel_count : Int32
        0
      end

      def each_channel(& : LavinMQ::Client::Channel ->) : Nil
      end

      def channels : Array(LavinMQ::Client::Channel)
        [] of LavinMQ::Client::Channel
      end

      def channel?(id : UInt16) : LavinMQ::Client::Channel?
        nil
      end

      def initialize(@io : Protocol::IO,
                     @connection_info : ConnectionInfo,
                     @user : Auth::BaseUser,
                     @broker : MQTT::Broker,
                     @client_id : String,
                     protocol_version : ProtocolVersion,
                     @clean_session : Bool = false,
                     @keepalive : UInt16 = 30,
                     @will : Protocol::Will? = nil)
        @protocol = protocol_version.name
        @permission_context = PermissionService::Context.new(@user.name, @client_id)
        @lock = Mutex.new
        @waitgroup = WaitGroup.new(1)
        @name = "#{@connection_info.remote_address} -> #{@connection_info.local_address}"
        metadata = ::Log::Metadata.new(nil, {vhost: @broker.vhost.name, address: @connection_info.remote_address.to_s, client_id: client_id})
        @log = Logger.new(Log, metadata)
      end

      def run : Nil
        @log.info { "Connection established for user=#{@user.name}" }
        case user = @user
        when Auth::OAuthUser
          user.on_expiration do
            close("token expired")
          end
        end
        read_loop
      end

      def client_name
        "mqtt-client-#{@client_id}"
      end

      private def read_loop
        received_bytes = 0_u32
        socket = @io.io
        if socket.responds_to?(:"read_timeout=")
          # 50% grace period according to [MQTT-3.1.2-24]
          socket.read_timeout = @keepalive.zero? ? nil : (@keepalive * 1.5).seconds
        end
        loop do
          @log.trace { "waiting for packet" }
          packet = read_and_handle_packet
          if (received_bytes &+= packet.bytesize) > Config.instance.yield_each_received_bytes
            received_bytes = 0_u32
            Fiber.yield
          end
          # The disconnect packet has been handled and the socket has been closed.
          # If we dont breakt the loop here we'll get a IO/Error on next read.
          if packet.is_a?(Protocol::Disconnect)
            @log.debug { "Received disconnect" }
            break
          end
        end
      rescue ex : Protocol::Error::PacketDecode
        @log.warn(exception: ex) { "Packet decode error" }
        publish_will
      rescue ex : ::IO::TimeoutError
        @log.warn { "Keepalive timeout (keepalive:#{@keepalive}): #{ex.message}" }
        publish_will
      rescue ex : ::IO::Error
        @log.error { "Client unexpectedly closed connection: #{ex.message}" } unless @closed
        publish_will
      rescue ex
        @log.error(exception: ex) { "Read Loop error" }
        publish_will
      ensure
        case user = @user
        when Auth::OAuthUser
          user.cleanup
        end
        @puback_mailbox.try &.close
        @waitgroup.done
        close_socket
        @log.info { "Connection disconnected for user=#{@user.name} duration=#{duration}" }
      end

      private def duration
        ms = RoughTime.unix_ms - @connected_at
        seconds = (ms / 1000).round.to_i
        Time::Span.new(seconds: seconds)
      end

      def read_and_handle_packet
        packet = @io.read_packet
        @log.trace { "Received packet:  #{packet.inspect}" }
        @recv_oct_count.add(packet.bytesize, :relaxed)
        vhost.add_recv_bytes(packet.bytesize.to_u64)

        case packet
        when Protocol::Publish     then recieve_publish(packet)
        when Protocol::PubAck      then recieve_puback(packet)
        when Protocol::Subscribe   then recieve_subscribe(packet)
        when Protocol::Unsubscribe then recieve_unsubscribe(packet)
        when Protocol::PingReq     then receive_pingreq(packet)
        when Protocol::Disconnect  then return packet
        else                            raise "received unexpected packet: #{packet}"
        end
        packet
      end

      def send(packet)
        @lock.synchronize do
          @io.write_packet(packet)
          @io.flush
          @send_oct_count.add(packet.bytesize, :relaxed)
          vhost.add_send_bytes(packet.bytesize.to_u64)
        end
        case packet
        when Protocol::Publish
          if packet.dup?
            vhost.event_tick(EventType::ClientRedeliver)
          else
            vhost.event_tick(EventType::ClientDeliverNoAck) if packet.qos == 0
            vhost.event_tick(EventType::ClientDeliver) if packet.qos > 0
          end
        when Protocol::PubAck
          vhost.event_tick(EventType::ClientPublishConfirm)
        end
      end

      def receive_pingreq(packet : Protocol::PingReq)
        send Protocol::PingResp.new
      end

      def recieve_publish(packet : Protocol::Publish)
        if Config.instance.mqtt_permission_check_enabled? && !user.can_write?(@broker.vhost.name, EXCHANGE)
          Log.debug { "Access refused: user '#{user.name}' does not have permissions" }
          disconnect
          return
        end
        # A topic denial acks and drops, it never closes the connection.
        unless @broker.permission_service.can_write?(@permission_context, packet.topic)
          Log.debug { "Publish refused: no topic permission rule allows user '#{@user.name}' (client '#{@client_id}') to write topic '#{packet.topic}'" }
          # Queued like the others, as PUBACKs must be sent in publish order
          if packet.qos > 0 && (packet_id = packet.packet_id)
            enqueue_puback(packet_id)
          end
          return
        end
        # MQTT 3.1.1 has no negative PUBACK, so closing is the only way to
        # tell the client its publish wasn't accepted
        unless @broker.publish(packet, @publish_context)
          @log.warn { "Publish refused, server low on disk space" }
          disconnect
          return
        end
        vhost.event_tick(EventType::ClientPublish)
        # Ok to not send anything if qos = 0 (fire and forget)
        if packet.qos > 0 && (packet_id = packet.packet_id)
          enqueue_puback(packet_id)
        end
      end

      # QoS 1 publishes are acked like publish confirms, once durable. The
      # PUBACK is sent by the writer fiber, so the read loop never waits for
      # the disk.
      private def enqueue_puback(packet_id : UInt16) : Nil
        unless @puback_mailbox
          mailbox = @puback_mailbox = ::Channel(UInt64).new(1)
          spawn puback_writer(mailbox), name: "MQTT client #{@client_id} puback writer"
        end
        seq = @publish_seq &+= 1
        @pending_pubacks.lock &.push(PendingPubAck.new(seq, packet_id))
        vhost.enqueue_ack(self, seq)
      end

      # Non-blocking; if the 1-slot mailbox is full, the stale seq is dropped
      # (confirms are cumulative).
      def enqueue_confirm_ack(msgid : UInt64) : Nil
        mailbox = @puback_mailbox || return
        loop do
          return if mailbox.try_send(msgid)
          mailbox.try_receive?
        end
      rescue ::Channel::ClosedError
      end

      private def puback_writer(mailbox : ::Channel(UInt64))
        while seq = mailbox.receive?
          while pending = next_puback(seq)
            send(Protocol::PubAck.new(pending.packet_id))
          end
        end
      rescue ex : ::IO::TimeoutError
        @log.info { "Timeout while sending PUBACK (#{ex.inspect})" }
        close_socket
      rescue ::IO::Error | OpenSSL::SSL::Error
        close_socket
      end

      private def next_puback(seq : UInt64) : PendingPubAck?
        @pending_pubacks.lock do |pending|
          pending.shift if pending.first?.try(&.seq.<= seq)
        end
      end

      def recieve_puback(packet : Protocol::PubAck)
        # No session means we never delivered anything to ack
        unless session = @broker.sessions[@client_id]?
          @log.warn { "Received PubAck from client without a session" }
          disconnect
          return
        end
        session.ack(packet)
        vhost.event_tick(EventType::ClientAck)
      end

      def recieve_subscribe(packet : Protocol::Subscribe)
        if Config.instance.mqtt_permission_check_enabled?
          unless user.can_read?(@broker.vhost.name, EXCHANGE) && user.can_write?(@broker.vhost.name, "mqtt.#{client_id}")
            Log.debug { "Access refused: user '#{user.name}' does not have permissions" }
            disconnect
            return
          end
        end
        # Topic permissions are enforced at delivery, not at SUBSCRIBE, so a client
        # may subscribe to a filter it cannot read. Mosquitto also filters at
        # delivery, but it additionally refuses the filter in the SUBACK.
        qos = @broker.subscribe(self, packet.topic_filters)
        send(Protocol::SubAck.new(qos, packet.packet_id))
      end

      def recieve_unsubscribe(packet : Protocol::Unsubscribe)
        @broker.unsubscribe(client_id, packet.topics)
        send(Protocol::UnsubAck.new(packet.packet_id))
      end

      def details_tuple
        {
          vhost:             @broker.vhost.name,
          user:              @user.name,
          protocol:          @protocol,
          client_id:         @client_id,
          name:              @name,
          timeout:           @keepalive,
          connected_at:      @connected_at,
          state:             state,
          host:              @connection_info.local_address.address,
          port:              @connection_info.local_address.port,
          peer_host:         @connection_info.remote_address.address,
          peer_port:         @connection_info.remote_address.port,
          ssl:               @connection_info.ssl?,
          tls_version:       @connection_info.ssl_version,
          cipher:            @connection_info.ssl_cipher,
          client_properties: NamedTuple.new,
        }.merge(current_stats_details)
      end

      def to_json(json : JSON::Builder)
        details_tuple.merge(stats_details).to_json(json)
      end

      def search_match?(value : String) : Bool
        @name.includes?(value) ||
          @user.name.includes?(value)
      end

      def search_match?(value : Regex) : Bool
        value === @name ||
          value === @user.name
      end

      private def publish_will
        if will = @will
          if Config.instance.mqtt_permission_check_enabled? && !user.can_write?(@broker.vhost.name, EXCHANGE)
            Log.debug { "Access refused: user '#{user.name}' does not have permissions" }
            return
          end
          unless @broker.permission_service.can_write?(@permission_context, will.topic)
            Log.debug { "Will publish refused: no topic permission rule allows user '#{@user.name}' (client '#{@client_id}') to write topic '#{will.topic}'" }
            return
          end
          published = @broker.publish(Protocol::Publish.new(
            topic: will.topic,
            payload: will.payload,
            packet_id: nil,
            qos: will.qos,
            retain: will.retain?,
            dup: false,
          ), @publish_context)
          @log.warn { "Will publish refused, server low on disk space" } unless published
        end
      rescue ex
        @log.warn { "Failed to publish will: #{ex.message}" }
      end

      # should only be used when server needs to froce close client
      def close(reason = "")
        return if @closed
        @log.info { "Closing connection: #{reason}" }
        @closed = true
        close_socket
        @waitgroup.wait
      end

      def state
        @closed ? "closed" : (@broker.vhost.flow? ? "running" : "flow")
      end

      def force_close
        close_socket
      end

      # For closing from the read loop, which then doesn't log the close as
      # unexpected (see #close for closing from elsewhere)
      private def disconnect : Nil
        @closed = true
        close_socket
      end

      # The connection is first shut down, which makes an ongoing write,
      # e.g. of a large message to a slowly reading client, fail right away
      # instead of holding the write lock. The socket is then closed under
      # the write lock, so that closing never runs concurrently with a write.
      # Buffered data is dropped instead of flushed: after a failed write it
      # may already have been partly sent, and the connection is being
      # abandoned anyway.
      private def close_socket
        socket = @io.io # Protocol::IO forwards methods, which responds_to? doesn't see
        socket.shutdown_read_write if socket.responds_to?(:shutdown_read_write)
        @lock.synchronize do
          socket.discard_write_buffer if socket.responds_to?(:discard_write_buffer)
          socket.close
        end
      rescue ::IO::Error | OpenSSL::SSL::Error
      end
    end
  end
end
