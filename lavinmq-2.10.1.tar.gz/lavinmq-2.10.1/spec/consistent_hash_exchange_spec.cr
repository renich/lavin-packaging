require "./spec_helper"
require "../src/lavinmq/consistent_hasher.cr"
require "../src/lavinmq/jump_consistent_hasher.cr"

describe LavinMQ::AMQP::ConsistentHashExchange do
  describe "#bind" do
    it "raises on invalid weight (routing key)" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        vhost.declare_exchange "con-hash", "x-consistent-hash", durable: true, auto_delete: false
        vhost.declare_queue "my-queue", durable: true, auto_delete: false
        exchange = vhost.exchange("con-hash").should be_a(LavinMQ::AMQP::ConsistentHashExchange)
        queue = vhost.queue("my-queue").as(LavinMQ::AMQP::Queue)
        expect_raises(LavinMQ::Error::PreconditionFailed) do
          exchange.bind(queue, "non-numeric", nil)
        end
        exchange.bindings_details.should be_empty
      end
    end
  end

  describe "#unbind" do
    it "raises on invalid weight (routing key)" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        vhost.declare_exchange "con-hash", "x-consistent-hash", durable: true, auto_delete: false
        vhost.declare_queue "my-queue", durable: true, auto_delete: false
        exchange = vhost.exchange("con-hash").should be_a(LavinMQ::AMQP::ConsistentHashExchange)
        queue = vhost.queue("my-queue").as(LavinMQ::AMQP::Queue)
        expect_raises(LavinMQ::Error::PreconditionFailed) do
          exchange.unbind(queue, "non-numeric", nil)
        end
      end
    end
  end

  describe "exchange => queue bindings" do
    x_name = "con-hash"
    # List of queues to keep track of so we can clean up
    it "should route all messages to queue if only one queue" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          x = ch.exchange(x_name, "x-consistent-hash")
          q = ch.queue("my-queue-0")
          q.bind(x.name, "1")
          x.publish("test message", "rk")
          q.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message")
        end
      end
    end

    it "should route on routing key" do
      q_names = Array(String).new
      with_amqp_server do |s|
        with_channel(s) do |ch|
          x = ch.exchange(x_name, "x-consistent-hash")

          q_names << "1"
          q0 = ch.queue(q_names[0])
          q0.bind(x.name, "3")

          q_names << "2"
          q1 = ch.queue(q_names[1])
          q1.bind(x.name, "3")

          q_names << "3"
          q2 = ch.queue(q_names[2])
          q2.bind(x.name, "3")

          x.publish "test message 0", "r1"
          x.publish "test message 1", "r2"
          x.publish "test message 2", "r3"

          q0.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message 0")
          q1.get(no_ack: true)
            .try(&.body_io.to_s)
            .should be_nil
          q2.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message 1")
          q2.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message 2")
        end
      end
    end

    it "should fail if header value isn't a string" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          x_args = AMQP::Client::Arguments.new({"x-hash-on" => "cluster"})
          x = ch.exchange(x_name, "x-consistent-hash", args: x_args)
          q0 = ch.queue("1")
          q0.bind(x.name, "3")

          hdrs1 = AMQP::Client::Arguments.new({"cluster" => 123})

          expect_raises(AMQP::Client::Channel::ClosedException, "PRECONDITION_FAILED") do
            x.publish_confirm "test message 0", "abc", props: AMQP::Client::Properties.new(headers: hdrs1)
          end
        end
      end
    end

    it "should route on empty string is header isn't set" do
      q_names = Array(String).new
      with_amqp_server do |s|
        with_channel(s) do |ch|
          x_args = AMQP::Client::Arguments.new({"x-hash-on" => "cluster"})
          x = ch.exchange(x_name, "x-consistent-hash", args: x_args)
          q_names << "1"
          q0 = ch.queue(q_names[0])
          q0.bind(x.name, "3")

          q_names << "2"
          q1 = ch.queue(q_names[1])
          q1.bind(x.name, "3")

          hdrs1 = AMQP::Client::Arguments.new
          hdrs2 = AMQP::Client::Arguments.new({"cluster" => "1"})
          hdrs3 = AMQP::Client::Arguments.new({"cluster" => ""})

          x.publish_confirm "test message 0", "abc", props: AMQP::Client::Properties.new(headers: hdrs1)
          x.publish_confirm "test message 1", "abc", props: AMQP::Client::Properties.new(headers: hdrs2)
          x.publish_confirm "test message 2", "abc", props: AMQP::Client::Properties.new(headers: hdrs3)

          q0.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message 0")
          q0.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message 2")
          q1.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message 1")
        end
      end
    end

    it "should route on header key" do
      q_names = Array(String).new
      with_amqp_server do |s|
        with_channel(s) do |ch|
          x_args = AMQP::Client::Arguments.new({"x-hash-on" => "cluster"})
          x = ch.exchange(x_name, "x-consistent-hash", args: x_args)

          q_names << "1"
          q0 = ch.queue(q_names[0])
          q0.bind(x.name, "3")

          q_names << "2"
          q1 = ch.queue(q_names[1])
          q1.bind(x.name, "3")

          q_names << "3"
          q2 = ch.queue(q_names[2])
          q2.bind(x.name, "3")

          hdrs1 = AMQP::Client::Arguments.new({"cluster" => "r1"})
          x.publish "test message 0", "abc", props: AMQP::Client::Properties.new(headers: hdrs1)

          hdrs2 = AMQP::Client::Arguments.new({"cluster" => "r2"})
          x.publish "test message 1", "abc", props: AMQP::Client::Properties.new(headers: hdrs2)

          hdrs3 = AMQP::Client::Arguments.new({"cluster" => "r3"})
          x.publish "test message 2", "abc", props: AMQP::Client::Properties.new(headers: hdrs3)

          q0.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message 0")
          q1.get(no_ack: true)
            .try(&.body_io.to_s)
            .should be_nil
          q2.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message 1")
          q2.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message 2")
        end
      end
    end

    it "should still route after unbinding duplicate binding with different arguments" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          x = ch.exchange(x_name, "x-consistent-hash")
          q = ch.queue("my-queue")

          q.bind(x.name, "3")
          q.bind(x.name, "3", args: AMQP::Client::Arguments.new({"x-hash-on" => "cluster"}))

          x.publish("test message 1", "rk")
          q.get(no_ack: true).try(&.body_io.to_s).should eq("test message 1")

          q.unbind(x.name, "3", args: AMQP::Client::Arguments.new({"x-hash-on" => "cluster"}))

          x.publish("test message 2", "rk")
          q.get(no_ack: true).try(&.body_io.to_s).should eq("test message 2")
        end
      end
    end

    it "should route on to same queue even after delete" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          x = ch.exchange(x_name, "x-consistent-hash")

          q0 = ch.queue("1")
          q0.bind(x.name, "3")

          q1 = ch.queue("2")
          q1.bind(x.name, "3")

          q2 = ch.queue("3")
          q2.bind(x.name, "3")

          x.publish "test message 0", "r1"
          x.publish "test message 1", "r2"
          x.publish "test message 2", "r3"

          q0.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message 0")
          q2.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message 1")
          q2.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message 2")

          s.vhosts["/"].delete_queue("2")

          x.publish "test message 0", "r1"
          x.publish "test message 1", "r2"
          x.publish "test message 2", "r3"

          q0.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message 0")
          q2.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message 1")
          q2.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message 2")
        end
      end
    end

    it "should allow setting hashing algorithm using x-algorithm argument" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          x_args = AMQP::Client::Arguments.new({"x-algorithm" => "jump"})
          ch.exchange(x_name, "x-consistent-hash", args: x_args)
          ex = s.vhosts["/"].exchange(x_name).as(LavinMQ::AMQP::ConsistentHashExchange)
          ex.@hasher.class.should eq JumpConsistentHasher(LavinMQ::AMQP::Exchange | LavinMQ::AMQP::Queue)
        end
      end
    end
    it "should allow setting hashing algorithm using x-algorithm argument" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          x_args = AMQP::Client::Arguments.new({"x-algorithm" => "ring"})
          ch.exchange(x_name, "x-consistent-hash", args: x_args)
          ex = s.vhosts["/"].exchange(x_name).as(LavinMQ::AMQP::ConsistentHashExchange)
          ex.@hasher.class.should eq RingConsistentHasher(LavinMQ::AMQP::Exchange | LavinMQ::AMQP::Queue)
        end
      end
    end
    it "should fallback to default if no x-algorithm was supplied" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          LavinMQ::Config.instance.default_consistent_hash_algorithm.should eq LavinMQ::ConsistentHashAlgorithm::Ring
          ch.exchange(x_name, "x-consistent-hash")
          ex = s.vhosts["/"].exchange(x_name).as(LavinMQ::AMQP::ConsistentHashExchange)
          ex.@hasher.class.should eq RingConsistentHasher(LavinMQ::AMQP::Exchange | LavinMQ::AMQP::Queue)
        end
      end
    end
    it "should fallback to default if invalid x-algorithm was supplied" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          LavinMQ::Config.instance.default_consistent_hash_algorithm.should eq LavinMQ::ConsistentHashAlgorithm::Ring
          x_args = AMQP::Client::Arguments.new({"x-algorithm" => "juump"})
          ch.exchange(x_name, "x-consistent-hash", args: x_args)
          ex = s.vhosts["/"].exchange(x_name).as(LavinMQ::AMQP::ConsistentHashExchange)
          ex.@hasher.class.should eq RingConsistentHasher(LavinMQ::AMQP::Exchange | LavinMQ::AMQP::Queue)
        end
      end
    end
  end

  describe "exchange => exchange bindings" do
    it "should route all messages to exchange if only one exchange" do
      x_name = "con-hash"
      x2_name = "next-exchange"

      with_amqp_server do |s|
        with_channel(s) do |ch|
          x = ch.exchange(x_name, "x-consistent-hash")

          x2 = ch.exchange(x2_name, "direct")
          x2.bind(x_name, "1")

          q = ch.queue("my-queue")
          q.bind(x2_name, "rk")

          x.publish("test message", "rk")
          q.get(no_ack: true)
            .try(&.body_io.to_s)
            .should eq("test message")
        end
      end
    end
  end
end
describe RingConsistentHasher do
  describe "Hasher" do
    # weight/replicas = binding key as INT
    # hash on queue name
    it "should return nil if empty" do
      ch = RingConsistentHasher(String).new
      ch.get("1").should be_nil
    end

    it "should return first value is ring size is 1" do
      ch = RingConsistentHasher(String).new
      ch.add("first", 1, "first")
      ch.get("any key").should eq "first"
    end

    it "should be consistent (test 1)" do
      ch = RingConsistentHasher(String).new
      ch.add("1", 3, "first")
      key = "q1"
      v = ch.get(key)
      ch.add("2", 3, "second")
      ch.get(key).should eq v
      ch.add("3", 3, "third")
      ch.get(key).should eq v
    end

    it "should be consistent (test 2)" do
      # Since replias for this test is 3, each entry get three hashes
      # So 9 Hashes will be stored on the ring
      # Here its listed in alphabetical order and which entry they point to
      #   423 104 025 => 1
      #   448 584 311 => 3
      #   461 287 488 => 2
      # 2 150 719 395 => 1
      # 2 188 894 714 => 2
      # 2 209 713 101 => 3
      # 4 105 354 075 => 3
      # 4 117 811 564 => 2
      # 4 147 539 765 => 1

      # routing keys
      # r1 =>   219 023 793
      # r2 => 2 483 509 259
      # r3 => 3 808 454 813

      ch = RingConsistentHasher(String).new
      ch.add("1", 3, "first")
      ch.add("2", 3, "second")
      ch.add("3", 3, "third")

      # 1. Look up the hash for r1
      # 2. Find the hash in the ring that is the closes above in value
      ch.get("r1").should eq "first"
      ch.get("r2").should eq "third"
      ch.get("r3").should eq "third"
    end

    it "should be consistent after delete" do
      ch = RingConsistentHasher(String).new
      ch.add("1", 3, "first")
      ch.add("2", 3, "second")
      ch.add("3", 3, "third")

      ch.get("r1").should eq "first"
      ch.get("r2").should eq "third"
      ch.get("r3").should eq "third"

      ch.remove("2", 3)

      ch.get("r1").should eq "first"
      ch.get("r2").should eq "third"
      ch.get("r3").should eq "third"
    end
  end
end

describe JumpConsistentHasher do
  describe "Hasher" do
    it "should return nil if empty" do
      jch = JumpConsistentHasher(String).new
      jch.get("1").should be_nil
    end

    it "should return first value if only one target" do
      jch = JumpConsistentHasher(String).new
      jch.add("first", 1, "first")
      jch.get("any key").should eq "first"
    end

    it "should distribute keys across targets" do
      jch = JumpConsistentHasher(String).new
      jch.add("1", 1, "first")
      jch.add("2", 1, "second")
      jch.add("3", 1, "third")

      # With jump consistent hash, distribution should be more even
      results = Hash(String, Int32).new(0)
      1000.times do |i|
        target = jch.get("key#{i}")
        results[target.not_nil!] += 1
      end

      # Each target should get roughly 1/3 of keys (allowing 15% variance)
      expected = 1000 / 3
      results.each_value do |count|
        count.should be_close(expected, expected * 0.15)
      end
    end

    it "should be consistent for same key" do
      jch = JumpConsistentHasher(String).new
      jch.add("1", 1, "first")
      jch.add("2", 1, "second")
      jch.add("3", 1, "third")

      key = "test_key"
      first_result = jch.get(key)
      100.times do
        jch.get(key).should eq first_result
      end
    end

    it "should minimize remapping when target is added" do
      jch = JumpConsistentHasher(String).new
      jch.add("1", 1, "first")
      jch.add("2", 1, "second")

      # Record initial mappings with 2 targets
      initial_mappings = Hash(String, String).new
      100.times do |i|
        key = "key#{i}"
        initial_mappings[key] = jch.get(key).not_nil!
      end

      # Add a third target
      jch.add("3", 1, "third")

      # Count how many keys changed to the new target
      moved_to_third = 0
      stayed_same = 0
      initial_mappings.each do |key, original_target|
        new_target = jch.get(key).not_nil!
        if new_target == "third"
          moved_to_third += 1
        elsif new_target == original_target
          stayed_same += 1
        end
      end

      # With jump consistent hash, only ~1/3 of keys should move to the new bucket
      # and keys that don't move should stay on their original target
      moved_to_third.should be_close(33, 15) # ~1/3 of 100
      stayed_same.should be_close(67, 15)    # ~2/3 of 100
    end

    it "should handle target removal" do
      jch = JumpConsistentHasher(String).new
      jch.add("1", 1, "first")
      jch.add("2", 1, "second")
      jch.add("3", 1, "third")

      100.times do |i|
        key = "key#{i}"
        target = jch.get(key)
        target.should_not be_nil
        ["first", "second", "third"].should contain(target)
      end

      # Remove one target
      jch.remove("2", 1)

      # Verify all keys still map to a valid target
      100.times do |i|
        key = "key#{i}"
        target = jch.get(key)
        target.should_not be_nil
        ["first", "third"].should contain(target)
      end
    end

    it "should get the same messages after adding a target and then remove it" do
      jch = JumpConsistentHasher(String).new
      jch.add("1", 1, "first")
      jch.add("2", 1, "second")

      # Record initial mappings with 2 targets
      initial_mappings = Hash(String, String).new
      1000.times do |i|
        key = "key#{i}"
        initial_mappings[key] = jch.get(key).not_nil!
      end

      jch.add("3", 1, "third")

      # All messages ending up in target 1 and 2 now, should also have been in
      # target 1 and 2 in the first run above.
      1000.times do |i|
        key = "key#{i}"
        target = jch.get(key)
        next if target == "third"
        target.should eq initial_mappings[key]
      end

      jch.remove("3", 1)

      # Verify all keys still maps to the same target as before we added and removed a target
      1000.times do |i|
        key = "key#{i}"
        target = jch.get(key)
        target.should eq initial_mappings[key]
      end
    end

    it "should respect weight for distribution" do
      jch = JumpConsistentHasher(String).new
      jch.add("1", 3, "first")  # weight 3
      jch.add("2", 1, "second") # weight 1

      results = Hash(String, Int32).new(0)
      1000.times do |i|
        target = jch.get("key#{i}")
        results[target.not_nil!] += 1
      end

      # "first" should get roughly 3x as many as "second"
      ratio = results["first"].to_f / results["second"].to_f
      ratio.should be_close(3.0, 0.5)
    end
  end
end
