require "./subscription_key"
require "../sortable_json"
require "./session"

module LavinMQ
  module MQTT
    # Mirrors the interface of `LavinMQ::AMQP::BindingDetails` so that the two are
    # interchangeable through duck typing (e.g. when listed via the HTTP API), while
    # keeping MQTT subscriptions decoupled from the AMQP binding type.
    struct SubscriptionDetails
      include SortableJSON
      getter source, vhost, binding_key, destination

      def initialize(@source : String, @vhost : String,
                     @binding_key : SubscriptionKey, @destination : MQTT::Session)
      end

      def arguments
        @binding_key.arguments
      end

      def routing_key
        @binding_key.routing_key
      end

      def details_tuple
        {
          source:           @source,
          vhost:            @vhost,
          destination:      @destination.name,
          destination_type: "queue",
          routing_key:      @binding_key.routing_key,
          arguments:        @binding_key.arguments,
          properties_key:   @binding_key.properties_key,
        }
      end

      def search_match?(value : String) : Bool
        @destination.name.includes?(value) ||
          @binding_key.routing_key.includes?(value)
      end

      def search_match?(value : Regex) : Bool
        value === @destination.name ||
          value === @binding_key.routing_key
      end
    end
  end
end
