require "./spec_helper"
require "../src/lavinmq/definitions_generator"

private def with_data_dir(&)
  data_dir = File.tempname
  Dir.mkdir_p data_dir
  File.write(File.join(data_dir, "vhosts.json"), "[]")
  File.write(File.join(data_dir, "users.json"), "[]")
  yield data_dir
ensure
  FileUtils.rm_rf data_dir if data_dir
end

describe LavinMQCtl::DefinitionsGenerator do
  it "includes permission groups read from each vhost's mqtt_permissions.json" do
    with_data_dir do |data_dir|
      File.write(File.join(data_dir, "vhosts.json"), %([{"name": "/", "dir": "vh1"}]))
      vhost_dir = File.join(data_dir, "vh1")
      Dir.mkdir_p vhost_dir
      File.open(File.join(vhost_dir, "definitions.amqp"), "w") { |f| f.write_bytes(1i32) }
      groups = [{name: "g1", vhost: "/", members: ["*"],
                 rules: [{identifier: "a", pattern: "a/#", read: true, write: false}]}]
      File.write(File.join(vhost_dir, "mqtt_permissions.json"), groups.to_json)

      io = IO::Memory.new
      LavinMQCtl::DefinitionsGenerator.new(data_dir).generate(io)
      body = JSON.parse(io.to_s)

      body["mqtt_permissions"].as_a.size.should eq 1
      group = body["mqtt_permissions"][0]
      group["name"].as_s.should eq "g1"
      group["vhost"].as_s.should eq "/"
      group["rules"][0]["pattern"].as_s.should eq "a/#"
    end
  end

  it "emits no permission groups for a vhost without mqtt_permissions.json" do
    with_data_dir do |data_dir|
      File.write(File.join(data_dir, "vhosts.json"), %([{"name": "/", "dir": "vh1"}]))
      vhost_dir = File.join(data_dir, "vh1")
      Dir.mkdir_p vhost_dir
      File.open(File.join(vhost_dir, "definitions.amqp"), "w") { |f| f.write_bytes(1i32) }

      io = IO::Memory.new
      LavinMQCtl::DefinitionsGenerator.new(data_dir).generate(io)
      body = JSON.parse(io.to_s)

      body["mqtt_permissions"].as_a.should be_empty
    end
  end

  it "emits an empty mqtt_permissions array when there is no vhost" do
    with_data_dir do |data_dir|
      io = IO::Memory.new
      LavinMQCtl::DefinitionsGenerator.new(data_dir).generate(io)
      body = JSON.parse(io.to_s)

      body["mqtt_permissions"].as_a.should be_empty
    end
  end
end
