require "uri"
require "benchmark"
require "../controller"
require "../binding_helpers"
require "../../clustering/client"
require "../../../stdlib/io_buffered"
require "../../gc_pause"

module LavinMQ
  module HTTP
    # Formats into a buffer, whose writes are direct calls, and hands the
    # output full buffers: the output is typed `IO`, so every write through it
    # is a type switch, paid once per buffer instead of once per token.
    class PrometheusWriter
      BUFFER_SIZE = 32 * 1024

      private class Buffer < IO
        def initialize(@output : IO)
          @buffer = Bytes.new(BUFFER_SIZE)
          @pos = 0
        end

        def read(slice : Bytes) : NoReturn
          raise IO::Error.new("Write-only")
        end

        def write(slice : Bytes) : Nil
          if slice.size > @buffer.size - @pos
            flush
            return @output.write(slice) if slice.size > @buffer.size
          end
          slice.copy_to(@buffer.to_unsafe + @pos, slice.size)
          @pos += slice.size
        end

        def write_string(slice : Bytes) : Nil
          write(slice)
        end

        def write_byte(byte : UInt8) : Nil
          flush if @pos == @buffer.size
          @buffer.to_unsafe[@pos] = byte
          @pos += 1
        end

        def flush : Nil
          @output.write(@buffer[0, @pos]) if @pos > 0
          @pos = 0
        end
      end

      alias MetricValue = UInt16 | Int32 | UInt32 | UInt64 | Int64 | Float64
      alias MetricLabels = Hash(String, String) |
                           NamedTuple(name: String) |
                           NamedTuple(channel: String) |
                           NamedTuple(id: String) |
                           NamedTuple(le: String) |
                           NamedTuple(buffer_size: String) |
                           NamedTuple(vhost: String) |
                           NamedTuple(dead_letter_strategy: String) |
                           NamedTuple(queue: String, vhost: String) |
                           NamedTuple(exchange: String, vhost: String) |
                           NamedTuple(channel: String, vhost: String, connection: String)
      alias Metric = NamedTuple(name: String, value: MetricValue) |
                     NamedTuple(name: String, value: MetricValue, labels: MetricLabels) |
                     NamedTuple(name: String, value: MetricValue, help: String) |
                     NamedTuple(name: String, value: MetricValue, type: String, help: String) |
                     NamedTuple(name: String, value: MetricValue, help: String, labels: MetricLabels) |
                     NamedTuple(name: String, value: MetricValue, type: String, help: String, labels: MetricLabels)

      property prefix : String

      private def initialize(output : IO, @prefix : String)
        @io = Buffer.new(output)
      end

      def self.open(output : IO, prefix : String, & : PrometheusWriter ->) : Nil
        writer = new(output, prefix)
        begin
          yield writer
        ensure
          writer.flush
        end
      end

      def flush : Nil
        @io.flush
      end

      private def write_labels(io, labels)
        first = true
        io << "{"
        labels.each do |k, v|
          io << ", " unless first
          io << k << "=\"" << v << "\""
          first = false
        end
        io << "}"
      end

      def write(m : Metric)
        return if m[:value].nil?
        io = @io

        name = name_writer(m)
        if t = m[:type]?
          io << "# TYPE " << name << " " << t << "\n"
        end
        if h = m[:help]?
          io << "# HELP " << name << " " << h << "\n"
        end
        io << name
        if l = m[:labels]?
          write_labels(io, l)
        end
        io << " " << m[:value] << "\n"
      end

      # Write only the TYPE and HELP header for a metric (no value)
      def write_header(name : String, type : String, help : String)
        io = @io
        full_name = NameWriter.new(@prefix, name)
        io << "# TYPE " << full_name << " " << type << "\n"
        io << "# HELP " << full_name << " " << help << "\n"
      end

      # Write only the metric value with labels (no TYPE/HELP)
      def write_value(name : String, value : MetricValue, labels : MetricLabels)
        return if value.nil?
        io = @io
        full_name = NameWriter.new(@prefix, name)
        io << full_name
        write_labels(io, labels)
        io << " " << value << "\n"
      end

      struct NameWriter
        def initialize(@prefix : String, @name : String)
        end

        def to_s(io : IO) : IO
          io << @prefix << "_" << @name
        end
      end

      private def name_writer(m : Metric)
        NameWriter.new(@prefix, m[:name])
      end
    end

    module Prometheus
      def report(output : IO, prefix : String, & : PrometheusWriter ->)
        PrometheusWriter.open(output, prefix) do |writer|
          mem = 0
          elapsed = Time.measure do
            mem = Benchmark.memory do
              yield writer
            rescue ex
              Log.error(exception: ex) { "Error while reporting prometheus metrics" }
            end
          end
          writer.prefix = "telemetry"
          writer.write({name:  "scrape_duration_seconds",
                        type:  "gauge",
                        value: elapsed.total_seconds,
                        help:  "Duration for metrics collection in seconds"})
          writer.write({name:  "scrape_mem",
                        type:  "gauge",
                        value: mem,
                        help:  "Memory used for metrics collections in bytes"})
        end
      end

      def gc_metrics(writer)
        gc_stats = GC.prof_stats

        writer.write({name: "gc_heap_size_bytes", value: gc_stats.heap_size,
                      type: "gauge",
                      help: "Heap size in bytes (including the area unmapped to OS)"})

        writer.write({name: "gc_free_bytes", value: gc_stats.free_bytes,
                      type: "gauge",
                      help: "Total bytes contained in free and unmapped blocks"})

        writer.write({name: "gc_unmapped_bytes", value: gc_stats.unmapped_bytes,
                      type: "gauge",
                      help: "Amount of memory unmapped to OS"})

        writer.write({name: "gc_since_recent_collection_allocated_bytes", value: gc_stats.bytes_since_gc,
                      type: "gauge",
                      help: "Number of bytes allocated since the recent GC"})

        writer.write({name: "gc_before_recent_collection_allocated_bytes_total", value: gc_stats.bytes_before_gc,
                      type: "counter",
                      help: "Number of bytes allocated before the recent GC (value may wrap)"})

        writer.write({name: "gc_non_candidate_bytes", value: gc_stats.non_gc_bytes,
                      type: "gauge",
                      help: "Number of bytes not considered candidates for GC"})

        writer.write({name: "gc_cycles_total", value: gc_stats.gc_no,
                      type: "counter",
                      help: "Garbage collection cycle number (value may wrap)"})

        writer.write({name: "gc_marker_threads", value: gc_stats.markers_m1,
                      type: "gauge",
                      help: "Number of marker threads (excluding the initiating one)"})

        writer.write({name: "gc_since_recent_collection_reclaimed_bytes", value: gc_stats.bytes_reclaimed_since_gc,
                      type: "gauge",
                      help: "Approximate number of reclaimed bytes after recent GC"})

        writer.write({name: "gc_before_recent_collection_reclaimed_bytes_total", value: gc_stats.reclaimed_bytes_before_gc,
                      type: "counter",
                      help: "Approximate number of bytes reclaimed before the recent GC (value may wrap)"})

        writer.write({name: "gc_since_recent_collection_explicitly_freed_bytes", value: gc_stats.expl_freed_bytes_since_gc,
                      type: "counter",
                      help: "Number of bytes freed explicitly since the recent GC"})

        writer.write({name: "gc_from_os_obtained_bytes_total", value: gc_stats.obtained_from_os_bytes,
                      type: "counter",
                      help: "Total amount of memory obtained from OS, in bytes"})

        gc_pause_metrics(writer)
      end

      private def gc_pause_metrics(writer)
        writer.write_header("gc_pause_seconds", "histogram", "Stop-the-world GC pause durations in seconds")
        count = 0_u64
        LavinMQ::GCPauseRecorder.each_bucket do |le, cumulative|
          writer.write_value("gc_pause_seconds_bucket", cumulative, {le: le.nil? ? "+Inf" : le.to_s})
          count = cumulative
        end
        writer.write({name: "gc_pause_seconds_sum", value: LavinMQ::GCPauseRecorder.sum})
        writer.write({name: "gc_pause_seconds_count", value: count})
      end
    end

    class FollowerPrometheusController
      include Router
      include Prometheus

      Log = LavinMQ::Log.for "http.prometheus"

      def initialize(@clustering_client : LavinMQ::Clustering::Client? = nil)
        register_routes
      end

      private def register_routes
        get "/metrics" do |context, _|
          context.response.content_type = "text/plain"
          prefix = context.request.query_params["prefix"]? || "lavinmq"
          if prefix.bytesize > 20
            context.response.status_code = 400
            reason = "Prefix too long (max 20 characters)"
            raise Controller::HaltRequest.new(reason)
          end

          report(context.response.output, prefix) do |writer|
            gc_metrics(writer)
            cluster_metrics(writer)
          end
          context
        end

        # Followers have no AMQP state for per-family samples. Respond 200 with only the
        # scrape telemetry so Prometheus doesn't mark `/metrics/detailed` targets as failed.
        get "/metrics/detailed" do |context, _|
          context.response.content_type = "text/plain"
          report(context.response.output, "lavinmq") { }
          context
        end
      end

      private def cluster_metrics(writer)
        client = @clustering_client
        return unless client
        writer.write({name:  "cluster_received_bytes_total",
                      value: client.streamed_bytes,
                      type:  "counter",
                      help:  "Bytes streamed from the current leader, counted from when this follower starts streaming; kept across reconnects, resets on leader change"})
      end
    end

    class PrometheusController < Controller
      include Prometheus

      def initialize(amqp_server : LavinMQ::Server, @require_authentication : Bool)
        super(amqp_server)
      end

      private def target_vhosts(context)
        vhosts = if @require_authentication
                   u = user(context)
                   vhosts(u)
                 else
                   @server.vhosts.values
                 end

        selected = context.request.query_params.fetch_all("vhost")
        vhosts = vhosts.select { |vhost| selected.includes? vhost.name } unless selected.empty?
        vhosts.to_a
      end

      private def register_routes
        get "/metrics" do |context, _|
          context.response.content_type = "text/plain"
          prefix = context.request.query_params["prefix"]? || "lavinmq"
          bad_request(context, "Prefix too long (max 20 characters)") if prefix.bytesize > 20
          vhosts = target_vhosts(context)
          report(context.response.output, prefix) do |writer|
            overview_broker_metrics(vhosts, writer)
            overview_queue_metrics(vhosts, writer)
            custom_metrics(writer)
            buffer_pool_metrics(writer)
            gc_metrics(writer)
            global_metrics(writer)
          end
          context
        end

        get "/metrics/detailed" do |context, _|
          context.response.content_type = "text/plain"
          prefix = context.request.query_params["prefix"]? || "lavinmq"
          bad_request(context, "Prefix too long (max 20 characters)") if prefix.bytesize > 20
          families = context.request.query_params.fetch_all("family")
          vhosts = target_vhosts(context)
          report(context.response.output, prefix) do |writer|
            families.each do |family|
              case family
              when "connection_churn_metrics"
                detailed_connection_churn_metrics(vhosts, writer)
              when "queue_coarse_metrics"
                detailed_queue_coarse_metrics(vhosts, writer)
              when "queue_consumer_count"
                detailed_queue_consumer_count(vhosts, writer)
              when "connection_coarse_metrics", "connection_metrics"
                detailed_connection_coarse_metrics(vhosts, writer)
              when "channel_metrics"
                detailed_channel_metrics(vhosts, writer)
              when "exchange_metrics"
                detailed_exchange_metrics(vhosts, writer)
              when "vhost_message_stats"
                detailed_vhost_message_stats(vhosts, writer)
              end
            end
          end
          context
        end
      end

      private def overview_broker_metrics(vhosts, writer)
        stats = vhost_stats(vhosts)
        writer.write({name:   "identity_info",
                      type:   "gauge",
                      value:  1,
                      help:   "System information",
                      labels: {
                        "#{writer.prefix}_version" => LavinMQ::VERSION,
                        "#{writer.prefix}_cluster" => System.hostname,
                      }})

        writer.write({name:  "connections_opened_total",
                      value: stats[:connection_created],
                      type:  "counter",
                      help:  "Total number of connections opened"})
        writer.write({name:  "connections_closed_total",
                      value: stats[:connection_closed],
                      type:  "counter",
                      help:  "Total number of connections closed or terminated"})
        writer.write({name:  "channels_opened_total",
                      value: stats[:channel_created],
                      type:  "counter",
                      help:  "Total number of channels opened"})
        writer.write({name:  "channels_closed_total",
                      value: stats[:channel_closed],
                      type:  "counter",
                      help:  "Total number of channels closed"})
        writer.write({name:  "queues_declared_total",
                      value: stats[:queue_declared],
                      type:  "counter",
                      help:  "Total number of queues declared"})
        writer.write({name:  "queues_deleted_total",
                      value: stats[:queue_deleted],
                      type:  "counter",
                      help:  "Total number of queues deleted"})
        writer.write({name:  "process_open_fds",
                      value: System.file_descriptor_count,
                      type:  "gauge",
                      help:  "Open file descriptors"})
        writer.write({name:  "process_open_tcp_sockets",
                      value: @server.vhosts.sum { |_, v| v.connections_size },
                      type:  "gauge",
                      help:  "Open TCP sockets"})
        writer.write({name:  "process_resident_memory_bytes",
                      type:  "gauge",
                      value: @server.rss,
                      help:  "Memory used in bytes"})
        writer.write({name:  "disk_space_available_bytes",
                      type:  "gauge",
                      value: @server.disk_free,
                      help:  "Disk space available in bytes"})
        writer.write({name:  "process_max_fds",
                      value: System.file_descriptor_limit[0],
                      type:  "gauge",
                      help:  "Open file descriptors limit"})
        writer.write({name:  "resident_memory_limit_bytes",
                      value: @server.mem_limit,
                      type:  "gauge",
                      help:  "Memory available to the broker in bytes: the cgroup memory limit, or physical memory if no limit is set"})
      end

      private def global_metrics(writer)
        deleted_stats = @server.vhosts.deleted_stats
        message_stats = @server.vhosts.map { |_, v| v.message_details[:message_stats] }
        writer.write({name:  "global_messages_delivered_total",
                      value: deleted_stats.deliver_get +
                             message_stats.sum { |ms| ms[:deliver_get] },
                      type: "counter",
                      help: "Total number of messaged delivered to consumers"})
        writer.write({name:  "global_messages_redelivered_total",
                      value: deleted_stats.redeliver +
                             message_stats.sum { |ms| ms[:redeliver] },
                      type: "counter",
                      help: "Total number of messages redelivered to consumers"})
        writer.write({name:  "global_messages_acknowledged_total",
                      value: deleted_stats.ack +
                             message_stats.sum { |ms| ms[:ack] },
                      type: "counter",
                      help: "Total number of messages acknowledged by consumers"})
        writer.write({name:  "global_messages_confirmed_total",
                      value: deleted_stats.confirm +
                             message_stats.sum { |ms| ms[:confirm] },
                      type: "counter",
                      help: "Total number of messages confirmed to publishers"})
        writer.write({name:  "global_messages_unroutable_returned_total",
                      value: deleted_stats.return_unroutable +
                             message_stats.sum { |ms| ms[:return_unroutable] },
                      type: "counter",
                      help: "Total number of unroutable messages returned to publishers"})
        dead_lettered_metrics(writer, deleted_stats)
      end

      DEAD_LETTER_REASONS = {
        delivery_limit: "Total number of messages dead-lettered due to delivery-limit exceeded",
        expired:        "Total number of messages dead-lettered due to message TTL exceeded",
        maxlen:         "Total number of messages dead-lettered due to max-length or max-length-bytes exceeded",
        rejected:       "Total number of messages dead-lettered due to basic.reject or basic.nack",
      }

      private def dead_lettered_metrics(writer, deleted_stats)
        vhosts = @server.vhosts
        {% for reason, help in DEAD_LETTER_REASONS %}
          writer.write_header("global_messages_dead_lettered_{{ reason.id }}_total", "counter", {{ help }})
          {% for strategy in {"disabled", "at_most_once"} %}
            writer.write_value("global_messages_dead_lettered_{{ reason.id }}_total",
              deleted_stats.dead_lettered_{{ reason.id }}_{{ strategy.id }} +
              vhosts.sum { |_, v| v.dead_lettered_{{ reason.id }}_{{ strategy.id }}_count },
              {dead_letter_strategy: {{ strategy }}})
          {% end %}
        {% end %}
      end

      private def overview_queue_metrics(vhosts, writer)
        ready = unacked = connections = channels = consumers = queues = bindings = 0_u64
        vhosts.each do |vhost|
          d = vhost.message_details
          ready += d[:messages_ready]
          unacked += d[:messages_unacknowledged]
          connections += vhost.connections_size
          vhost.each_connection do |conn|
            channels += conn.channel_count
            conn.each_channel do |ch|
              consumers += ch.consumers_size
            end
          end
          queues += vhost.queues_size + vhost.sessions_size
          vhost.each_exchange { |e| bindings += e.binding_count }
        end
        writer.write({name:  "connections",
                      value: connections,
                      type:  "gauge",
                      help:  "Connections currently open"})
        writer.write({name:  "channels",
                      value: channels,
                      type:  "gauge",
                      help:  "Channels currently open"})
        writer.write({name:  "consumers",
                      value: consumers,
                      type:  "gauge",
                      help:  "Consumers currently connected"})
        writer.write({name:  "queues",
                      value: queues,
                      type:  "gauge",
                      help:  "Queues available"})
        writer.write({name:  "bindings",
                      value: bindings,
                      type:  "gauge",
                      help:  "Bindings currently configured"})
        writer.write({name:  "queue_messages_ready",
                      value: ready,
                      type:  "gauge",
                      help:  "Messages ready to be delivered to consumers"})
        writer.write({name:  "queue_messages_unacked",
                      value: unacked,
                      type:  "gauge",
                      help:  "Messages delivered to consumers but not yet acknowledged"})
        writer.write({name:  "queue_messages",
                      value: ready + unacked,
                      type:  "gauge",
                      help:  "Sum of ready and unacknowledged messages - total queue depth"})
      end

      private def custom_metrics(writer)
        writer.write({name: "uptime", value: @server.uptime.to_i,
                      type: "counter",
                      help: "Server uptime in seconds"})
        writer.write({name:  "cpu_system_time_total",
                      value: @server.sys_time,
                      type:  "counter",
                      help:  "Total CPU system time"})
        writer.write({name:  "cpu_user_time_total",
                      value: @server.user_time,
                      type:  "counter",
                      help:  "Total CPU user time"})
        writer.write({name:  "stats_collection_duration_seconds_total",
                      value: @server.stats_collection_duration_seconds_total.to_f,
                      type:  "gauge",
                      help:  "Total time it takes to collect metrics (stats_loop)"})
        writer.write({name:  "stats_rates_collection_duration_seconds",
                      value: @server.stats_rates_collection_duration_seconds.to_f,
                      type:  "gauge",
                      help:  "Time it takes to update stats rates (update_stats_rates)"})
        writer.write({name:  "stats_system_collection_duration_seconds",
                      value: @server.stats_system_collection_duration_seconds.to_f,
                      type:  "gauge",
                      help:  "Time it takes to collect system metrics"})
        writer.write({name:  "total_connected_followers",
                      value: @server.followers.size,
                      type:  "gauge",
                      help:  "Amount of follower nodes connected"})
        @server.followers.each do |f|
          writer.write({name:   "follower_lag_in_bytes",
                        labels: {id: f.id.to_s(36)},
                        value:  f.lag_in_bytes,
                        type:   "gauge",
                        help:   "Bytes that hasn't been synchronized with the follower yet"})
          writer.write({name:   "follower_bytes_sent_total",
                        labels: {id: f.id.to_s(36)},
                        value:  f.sent_bytes,
                        type:   "counter",
                        help:   "Bytes streamed to the follower over its current connection, counted from when it starts streaming; resets on reconnect"})
          writer.write({name:   "follower_bytes_acked_total",
                        labels: {id: f.id.to_s(36)},
                        value:  f.acked_bytes,
                        type:   "counter",
                        help:   "Bytes the follower acknowledged over its current connection, counted from when it starts streaming; resets on reconnect"})
        end
        writer.write({name:  "mfile_count",
                      value: MFile.mmap_count,
                      type:  "gauge",
                      help:  "Number of MFile memory-mapped files"})
      end

      private def buffer_pool_metrics(writer)
        stats = IO::BufferPool.all.map(&.stats)
        return if stats.empty?
        {
          {:available, "available", "gauge", "Socket buffers cached for reuse"},
          {:allocated, "allocated_total", "counter", "Socket buffers allocated because none was cached"},
          {:reused, "reused_total", "counter", "Socket buffers taken from the cache"},
          {:released, "released_total", "counter", "Socket buffers returned to the cache"},
          {:dropped, "dropped_total", "counter", "Socket buffers left to the GC because the cache was full"},
        }.each do |field, key, type, help|
          name = "socket_buffer_pool_#{key}"
          writer.write_header(name, type, help)
          stats.each do |s|
            writer.write_value(name, s[field], {buffer_size: s[:buffer_size].to_s})
          end
        end
      end

      SERVER_METRICS = {:connection_created, :connection_closed, :channel_created, :channel_closed,
                        :queue_declared, :queue_deleted, :consumer_added, :consumer_removed}

      private def vhost_stats(vhosts)
        deleted_stats = @server.vhosts.deleted_stats
        {% for sm in SERVER_METRICS %}
          {{ sm.id }} = deleted_stats.{{ sm.id }}
        {% end %}
        vhosts.each do |vhost|
          stats_details = vhost.stats_details
          {% for sm in SERVER_METRICS %}
            {{ sm.id }} += stats_details[:{{ sm.id }}]
          {% end %}
        end
        {% begin %}
        {
          {% for sm in SERVER_METRICS %}
            {{ sm.id }}: {{ sm.id }},
          {% end %}
        }
        {% end %}
      end

      private def detailed_connection_churn_metrics(vhosts, writer)
        stats = vhost_stats(vhosts)
        writer.write({name:  "detailed_connections_opened_total",
                      value: stats[:connection_created],
                      type:  "counter",
                      help:  "Total number of connections opened"})
        writer.write({name:  "detailed_connections_closed_total",
                      value: stats[:connection_closed],
                      type:  "counter",
                      help:  "Total number of connections closed or terminated"})
        writer.write({name:  "detailed_channels_opened_total",
                      value: stats[:channel_created],
                      type:  "counter",
                      help:  "Total number of channels opened"})
        writer.write({name:  "detailed_channels_closed_total",
                      value: stats[:channel_closed],
                      type:  "counter",
                      help:  "Total number of channels closed"})
        writer.write({name:  "detailed_queues_declared_total",
                      value: stats[:queue_declared],
                      type:  "counter",
                      help:  "Total number of queues declared"})
        writer.write({name:  "detailed_queues_deleted_total",
                      value: stats[:queue_deleted],
                      type:  "counter",
                      help:  "Total number of queues deleted"})
        writer.write({name:  "detailed_consumers_added_total",
                      value: stats[:consumer_added],
                      type:  "counter",
                      help:  "Total number of consumers added"})
        writer.write({name:  "detailed_consumers_removed_total",
                      value: stats[:consumer_removed],
                      type:  "counter",
                      help:  "Total number of consumers removed"})
      end

      private def detailed_queue_coarse_metrics(vhosts, writer)
        # Group TYPE, HELP and values together for each metric
        writer.write_header("detailed_queue_messages_ready", "gauge",
          "Messages ready to be delivered to consumers")
        vhosts.each do |vhost|
          vhost.each_queue do |q|
            labels = {queue: q.name, vhost: vhost.name}
            writer.write_value("detailed_queue_messages_ready", q.message_count, labels)
          end
          vhost.each_session do |s|
            labels = {queue: s.name, vhost: vhost.name}
            writer.write_value("detailed_queue_messages_ready", s.message_count, labels)
          end
        end

        writer.write_header("detailed_queue_messages_unacked", "gauge",
          "Messages delivered to consumers but not yet acknowledged")
        vhosts.each do |vhost|
          vhost.each_queue do |q|
            labels = {queue: q.name, vhost: vhost.name}
            writer.write_value("detailed_queue_messages_unacked", q.unacked_count, labels)
          end
          vhost.each_session do |s|
            labels = {queue: s.name, vhost: vhost.name}
            writer.write_value("detailed_queue_messages_unacked", s.unacked_count, labels)
          end
        end

        writer.write_header("detailed_queue_messages", "gauge",
          "Sum of ready and unacknowledged messages - total queue depth")
        vhosts.each do |vhost|
          vhost.each_queue do |q|
            labels = {queue: q.name, vhost: vhost.name}
            writer.write_value("detailed_queue_messages", q.message_count + q.unacked_count, labels)
          end
          vhost.each_session do |s|
            labels = {queue: s.name, vhost: vhost.name}
            writer.write_value("detailed_queue_messages", s.message_count + s.unacked_count, labels)
          end
        end

        writer.write_header("detailed_queue_deduplication", "counter",
          "Number of deduplicated messages for this queue")
        vhosts.each do |vhost|
          vhost.each_queue do |q|
            labels = {queue: q.name, vhost: vhost.name}
            writer.write_value("detailed_queue_deduplication", q.dedup_count, labels)
          end
        end

        writer.write_header("detailed_queue_messages_delivered_total", "counter",
          "Total number of messages delivered to consumers or fetched via basic.get for this queue")
        vhosts.each do |vhost|
          vhost.each_queue do |q|
            labels = {queue: q.name, vhost: vhost.name}
            writer.write_value("detailed_queue_messages_delivered_total", q.deliver_get_count, labels)
          end
        end

        writer.write_header("detailed_queue_messages_acked_total", "counter",
          "Total number of messages acknowledged for this queue")
        vhosts.each do |vhost|
          vhost.each_queue do |q|
            labels = {queue: q.name, vhost: vhost.name}
            writer.write_value("detailed_queue_messages_acked_total", q.ack_count, labels)
          end
        end
      end

      private def detailed_queue_consumer_count(vhosts, writer)
        # Write header once
        writer.write_header("detailed_queue_consumers", "gauge", "Consumers on a queue")

        # Write values
        vhosts.each do |vhost|
          vhost.each_queue do |q|
            labels = {queue: q.name, vhost: vhost.name}
            writer.write_value("detailed_queue_consumers", q.consumer_count, labels)
          end
        end
      end

      private def detailed_exchange_metrics(vhosts, writer)
        # Write header once
        writer.write_header("detailed_exchange_deduplication", "counter",
          "Number of deduplicated messages for this exchange")

        # Write values
        vhosts.each do |vhost|
          vhost.each_exchange do |e|
            labels = {exchange: e.name, vhost: vhost.name}
            writer.write_value("detailed_exchange_deduplication", e.dedup_count, labels)
          end
        end
      end

      private def detailed_vhost_message_stats(vhosts, writer)
        writer.write_header("detailed_vhost_messages_published_total", "counter",
          "Total messages published to a vhost (all protocols)")
        vhosts.each do |vhost|
          labels = {vhost: vhost.name}
          writer.write_value("detailed_vhost_messages_published_total", vhost.publish_count, labels)
        end

        writer.write_header("detailed_vhost_messages_delivered_total", "counter",
          "Total messages delivered to clients on a vhost (all protocols)")
        vhosts.each do |vhost|
          labels = {vhost: vhost.name}
          writer.write_value("detailed_vhost_messages_delivered_total", vhost.deliver_get_count, labels)
        end

        writer.write_header("detailed_vhost_queues", "gauge",
          "Number of queues on a vhost")
        vhosts.each do |vhost|
          labels = {vhost: vhost.name}
          writer.write_value("detailed_vhost_queues", vhost.queues_size + vhost.sessions_size, labels)
        end
      end

      private def detailed_connection_coarse_metrics(vhosts, writer)
        # Group TYPE, HELP and values together for each metric
        writer.write_header("detailed_connection_incoming_bytes_total", "counter",
          "Total number of bytes received on a connection")
        vhosts.each do |vhost|
          vhost.each_connection do |conn|
            labels = {channel: conn.name}
            writer.write_value("detailed_connection_incoming_bytes_total", conn.recv_oct_count, labels)
          end
        end

        writer.write_header("detailed_connection_outgoing_bytes_total", "counter",
          "Total number of bytes sent on a connection")
        vhosts.each do |vhost|
          vhost.each_connection do |conn|
            labels = {channel: conn.name}
            writer.write_value("detailed_connection_outgoing_bytes_total", conn.send_oct_count, labels)
          end
        end

        writer.write_header("detailed_connection_channels", "counter",
          "Channels on a connection")
        vhosts.each do |vhost|
          vhost.each_connection do |conn|
            labels = {channel: conn.name}
            writer.write_value("detailed_connection_channels", conn.channel_count, labels)
          end
        end
      end

      private def detailed_channel_metrics(vhosts, writer)
        # Group TYPE, HELP and values together for each metric
        writer.write_header("detailed_channel_consumers", "gauge", "Consumers on a channel")
        vhosts.each do |vhost|
          vhost.each_connection do |conn|
            conn.each_channel do |ch|
              labels = {channel: ch.name, vhost: vhost.name, connection: conn.name}
              writer.write_value("detailed_channel_consumers", ch.details_tuple[:consumer_count], labels)
            end
          end
        end

        writer.write_header("detailed_messages_unacked", "gauge",
          "Delivered but not yet acknowledged messages")
        vhosts.each do |vhost|
          vhost.each_connection do |conn|
            conn.each_channel do |ch|
              labels = {channel: ch.name, vhost: vhost.name, connection: conn.name}
              writer.write_value("detailed_messages_unacked", ch.details_tuple[:messages_unacknowledged], labels)
            end
          end
        end

        writer.write_header("detailed_channel_prefetch", "gauge",
          "Total limit of unacknowledged messages for all consumers on a channel")
        vhosts.each do |vhost|
          vhost.each_connection do |conn|
            conn.each_channel do |ch|
              labels = {channel: ch.name, vhost: vhost.name, connection: conn.name}
              writer.write_value("detailed_channel_prefetch", ch.details_tuple[:prefetch_count], labels)
            end
          end
        end
      end
    end
  end
end
