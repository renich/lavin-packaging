require "../user"
require "../../tag"

module LavinMQ
  module Auth
    module JWT
      record TokenClaim,
        username : String,
        tags : Array(Tag),
        permissions : Hash(String, User::Permissions),
        expires_at : Time

      class TokenParser
        def initialize(@config : Config)
        end

        def parse(token : JWT::Token) : TokenClaim
          payload = token.payload
          username = extract_username(payload)
          tags, permissions = parse_roles(payload)
          expires_at = payload.exp
          raise JWT::DecodeError.new("No expiration time found in JWT token") unless expires_at
          TokenClaim.new(username, tags, permissions, Time.unix(expires_at))
        end

        private def extract_username(payload : JWT::Payload) : String
          claims = @config.oauth_preferred_username_claims
          claims.each do |claim|
            # Check standard JWT properties first
            username = case claim
                       when "sub"
                         payload.sub
                       when "iss"
                         payload.iss
                       else
                         nil
                       end
            return username if username

            # Check unmapped fields
            if value = payload[claim]?
              if username = value.as_s?
                return username
              end
            end
          end
          raise JWT::DecodeError.new("No username found in JWT claims (tried: #{claims.join(", ")})")
        end

        private def parse_roles(payload : JWT::Payload)
          scopes = [] of String

          if server_id = @config.oauth_resource_server_id
            if resource_access = payload.resource_access
              if server_roles = resource_access[server_id]?
                if roles = server_roles.roles
                  scopes.concat(roles)
                end
              end
            end
          end

          if scope_str = payload.scope
            scopes.concat(scope_str.split)
          end

          @config.oauth_additional_scopes_keys.each do |scopes_key|
            if claim = payload[scopes_key]?
              scopes.concat(extract_scopes_from_claim(claim))
            end
          end

          tags = Set(Tag).new
          permissions = Hash(String, User::Permissions).new do |h, k|
            h[k] = {config: Regex.new("^$"), read: Regex.new("^$"), write: Regex.new("^$")}
          end
          filter_scopes(scopes).each { |scope| parse_role(scope, tags, permissions) }
          {tags.to_a, permissions}
        end

        private def extract_scopes_from_claim(claim) : Array(String)
          case claim
          when .as_h?
            claim.as_h.flat_map do |key, value|
              if !@config.oauth_resource_server_id || key == @config.oauth_resource_server_id
                extract_scopes_from_claim(value)
              end
            end.compact
          when .as_a?
            claim.as_a.flat_map do |item|
              extract_scopes_from_claim(item)
            end
          when .as_s?
            claim.as_s.split
          else
            Array(String).new(0)
          end
        end

        private def filter_scopes(scopes : Array(String)) : Array(String)
          prefix = @config.oauth_scope_prefix
          if !prefix && @config.oauth_resource_server_id
            prefix = "#{@config.oauth_resource_server_id}."
          end

          return scopes unless prefix

          scopes.compact_map do |scope|
            scope[prefix.size..] if scope.starts_with?(prefix)
          end
        end

        private def parse_role(role, tags, permissions)
          if role.starts_with?("tag:")
            parse_tag_role(role, tags)
          else
            parse_permission_role(role, permissions)
          end
        end

        private def parse_tag_role(role, tags)
          tag_name = role[4..]
          if tag = Tag.parse?(tag_name)
            tags << tag
          end
        end

        private def parse_permission_role(role, permissions)
          perm_type, _, remainder = role.partition(":")
          return if !perm_type.in?("read", "write", "configure") || remainder.empty?

          parts = remainder.split("/")

          # Allow 2 or 3 parts: vhost/pattern or vhost/pattern/routing_key
          # RabbitMQ allows a third part (routing_key), but we don't use it
          return unless parts.size == 2 || parts.size == 3

          vhost = URI.decode_www_form(parts[0])
          pattern = URI.decode_www_form(parts[1])
          regex_pattern = wildcard_to_regex(pattern)

          begin
            regex = Regex.new(regex_pattern)
          rescue ex : ArgumentError
            Log.warn { "Skipping scope '#{role}' due to invalid regex pattern: #{ex.message}" }
            return
          end

          current = permissions[vhost]
          permissions[vhost] = case perm_type
                               when "configure" then current.merge({config: combine_regex(current[:config], regex)})
                               when "read"      then current.merge({read: combine_regex(current[:read], regex)})
                               when "write"     then current.merge({write: combine_regex(current[:write], regex)})
                               else                  current
                               end
        end

        private def combine_regex(existing : Regex, new_regex : Regex) : Regex
          if existing.source == "^$"
            new_regex
          else
            Regex.new("#{existing.source}|#{new_regex.source}")
          end
        end

        private def wildcard_to_regex(pattern : String) : String
          return ".*" if pattern == "*"
          escaped = pattern.gsub(/[.+?^${}()|[\]\\]/) { |m| "\\#{m}" } # Prefix each regex metacharacter with \ to escape it
          regex = escaped.gsub("*", ".*")
          "^#{regex}$"
        end
      end
    end
  end
end
