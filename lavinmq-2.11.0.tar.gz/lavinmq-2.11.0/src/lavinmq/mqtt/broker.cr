require "./client"
require "./consts"
require "./exchange"
require "./protocol"
require "./session"
require "./sessions"
require "./retain_store"
require "../vhost"

module LavinMQ
  module MQTT
    # Raised for a topic that cannot become an AMQP routing key, so the
    # packet can never be processed, which the client read loop and the
    # connection factory handle like a packet that can't be decoded
    class TopicTooLong < ::MQTT::Protocol::Error::PacketDecode; end

    class Broker
      getter vhost, sessions
      Log = LavinMQ::Log.for "mqtt.broker"

      # The `Broker` class acts as an intermediary between the `Server` and MQTT connections.
      # It is initialized by the `Server` and manages client connections, sessions, and message exchange.
      # Responsibilities include:
      # - Handling client connections and disconnections
      # - Managing client sessions (clean and persistent)
      # - Publishing messages to the exchange
      # - Subscribing and unsubscribing clients to/from topics
      # - Handling the retain store
      # - Interfacing with the virtual host (vhost) and the exchange to route messages
      # The `Broker` class helps keep the MQTT client concise and focused on the protocol.
      def initialize(@vhost : VHost)
        @sessions = Sessions.new(@vhost)
        @clients = Hash(String, Client).new
        @retain_store = RetainStore.new(File.join(@vhost.data_dir, "mqtt_retained_store"), @vhost.replicator, persister: @vhost.persister)
        @exchange = @vhost.mqtt_exchange
      end

      def permission_service : PermissionService
        @vhost.mqtt_permission_service
      end

      def session_present?(client_id : String, clean_session) : Bool
        return false if clean_session
        session = sessions[client_id]? || return false
        return false if session.clean_session?
        true
      end

      # A reconnecting client_id displaces the existing connection in
      # `add_client`, so the connection count doesn't grow
      def connection_limit_reached?(client_id : String) : Bool
        return false if @clients.has_key?(client_id)
        @vhost.connection_limit_reached?
      end

      def add_client(io, connection_info, user, packet) : Client
        if prev_client = @clients[packet.client_id]?
          prev_client.close(
            "New client #{connection_info.remote_address} " \
            "(username=#{packet.username}) connected as #{packet.client_id}")
          remove_client(prev_client)
        end
        client = MQTT::Client.new(io,
          connection_info,
          user,
          self,
          packet.client_id,
          ProtocolVersion.from_value(packet.version),
          packet.clean_session?,
          packet.keepalive,
          packet.will)
        if client.clean_session?
          sessions[client.client_id]?.try &.delete
        else
          # If an existing session exists, reuse it. If no session exists
          # it will be created on first subscribe
          if session = sessions[client.client_id]?
            session.client = client
          end
        end
        @clients[packet.client_id] = client
        @vhost.add_connection client
        client
      end

      def run_client(io, connection_info, user, packet) : Client
        client = add_client(io, connection_info, user, packet)
        begin
          client.run
        ensure
          remove_client(client)
        end
        client
      end

      def remove_client(client)
        client_id = client.client_id
        if session = sessions[client_id]?
          if session.client.nil? || (session.client == client)
            session.client = nil
            session.delete if session.clean_session?
          end
        end
        @clients.delete(client_id) if @clients[client_id]? == client
        @vhost.rm_connection(client)
      end

      # Returns false, without storing or routing the packet, during a disk alarm
      def publish(packet : Protocol::Publish, ctx : PublishContext) : Bool
        if packet.topic.bytesize > MAX_TOPIC_BYTESIZE
          raise TopicTooLong.new("topic is #{packet.topic.bytesize} bytes, max #{MAX_TOPIC_BYTESIZE}")
        end
        return false unless @vhost.flow?
        @retain_store.retain(packet) if packet.retain?
        @exchange.publish(packet, ctx)
        true
      end

      def subscribe(client, topics) : Array(Protocol::SubAck::ReturnCode)
        session = sessions.declare(client)
        unless session
          Log.warn { "Rejecting subscribe from client_id=#{client.client_id}, queue limit in vhost '#{@vhost.name}' (#{@vhost.max_queues}) is reached" }
          return topics.map { Protocol::SubAck::ReturnCode::Failure }
        end
        topics.map { |tf| grant(session, tf) }
      end

      def grant(session : Session, tf) : Protocol::SubAck::ReturnCode
        qos = tf.qos.zero? ? 0u8 : 1u8 # downgrade to 1 if > 1
        return Protocol::SubAck::ReturnCode::Failure if tf.topic.bytesize > MAX_TOPIC_BYTESIZE
        return Protocol::SubAck::ReturnCode::Failure unless session.subscribe(tf.topic, qos)
        ts = RoughTime.unix_ms
        @retain_store.each(tf.topic) do |topic, body_io, body_bytesize|
          props = AMQP::Properties.new(headers: RETAIN_HEADERS, delivery_mode: qos)
          msg = Message.new(ts, EXCHANGE, topic, props, body_bytesize, body_io)
          session.publish(msg)
        end
        Protocol::SubAck::ReturnCode.from_int(qos)
      end

      def unsubscribe(client_id, topics)
        session = sessions[client_id]? || return
        topics.each do |tf|
          session.unsubscribe(tf)
        end
      end

      def close
        @retain_store.close
      end
    end
  end
end
