require "./spec_helper"
require "../src/lavinmq/launcher"

class LavinMQ::Launcher
  def start_for_spec
    start
  end
end

describe LavinMQ::Launcher do
  it "aborts startup when the AMQP listener can not bind" do
    blocker = TCPServer.new("127.0.0.1", 0)
    with_datadir do |data_dir|
      launcher : LavinMQ::Launcher? = nil
      config = LavinMQ::Config.new
      config.data_dir = data_dir
      config.data_dir_lock = false
      config.amqp_bind = "127.0.0.1"
      config.amqp_port = blocker.local_address.port
      config.amqps_port = -1
      config.http_port = -1
      config.https_port = -1
      config.mqtt_port = -1
      config.mqtts_port = -1
      config.metrics_http_port = -1
      config.control_unix_path = File.join(data_dir, "control.sock")
      launcher = LavinMQ::Launcher.new(config)

      expect_raises(SpecExit, /Exiting with code 1/) do
        launcher.start_for_spec
      end
    ensure
      launcher.try &.stop
    end
  ensure
    blocker.try &.close
  end

  it "aborts startup when the control socket is in use, leaving it to the node serving it" do
    with_datadir do |data_dir|
      socket_path = File.tempname("lavinmqctl-spec", ".sock")
      serving = UNIXServer.new(socket_path)
      launcher : LavinMQ::Launcher? = nil
      config = LavinMQ::Config.new
      config.data_dir = data_dir
      config.data_dir_lock = false
      config.amqp_bind = "127.0.0.1"
      config.amqp_port = 0
      config.amqps_port = -1
      config.http_port = -1
      config.https_port = -1
      config.mqtt_port = -1
      config.mqtts_port = -1
      config.metrics_http_port = -1
      config.control_unix_path = socket_path
      original_config = LavinMQ::Config.instance
      LavinMQ::Config.instance = config # the HTTP server reads the control socket path from it
      launcher = LavinMQ::Launcher.new(config)

      expect_raises(SpecExit, /Exiting with code 1/) do
        launcher.start_for_spec
      end
      File.exists?(socket_path).should be_true
    ensure
      launcher.try &.stop
      LavinMQ::Config.instance = original_config if original_config
      serving.try &.close
    end
  end

  it "exits when the data directory is locked by another process" do
    with_datadir do |data_dir|
      lock = LavinMQ::DataDirLock.new(data_dir)
      lock.acquire
      config = LavinMQ::Config.new
      config.data_dir = data_dir
      expect_raises(SpecExit, /Exiting with code 1/) do
        LavinMQ::Launcher.new(config)
      end
    ensure
      lock.try &.release
    end
  end
end

describe LavinMQ::DataDirLock do
  it "raises when the lock is already held" do
    with_datadir do |data_dir|
      first = LavinMQ::DataDirLock.new(data_dir)
      first.acquire
      expect_raises(LavinMQ::DataDirLock::Error, /Data directory locked by 'PID #{Process.pid}/) do
        LavinMQ::DataDirLock.new(data_dir).acquire
      end
      first.release
      second = LavinMQ::DataDirLock.new(data_dir)
      second.acquire
      second.release
    end
  end
end
