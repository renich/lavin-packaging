require "./spec_helper"
require "./../src/lavinmq/amqp/queue"

module StreamSpecHelpers
  def self.publish(s, queue_name, nr_of_messages)
    args = {"x-queue-type": "stream"}
    with_channel(s) do |ch|
      q = ch.queue(queue_name, args: AMQP::Client::Arguments.new(args))
      nr_of_messages.times { |i| q.publish "m#{i}" }
    end
  end

  def self.consume_one(s, queue_name, c_tag, c_args = AMQP::Client::Arguments.new)
    args = {"x-queue-type": "stream"}
    with_channel(s) do |ch|
      ch.prefetch 1
      q = ch.queue(queue_name, args: AMQP::Client::Arguments.new(args))
      msgs = Channel(AMQP::Client::DeliverMessage).new
      q.subscribe(no_ack: false, tag: c_tag, args: c_args) do |msg|
        msgs.send msg
        msg.ack
      end
      msgs.receive
    end
  end

  # Resident kB of the mapping of `path` in this process, from /proc/self/smaps
  def self.mapped_rss_kb(path : String) : Int32
    in_mapping = false
    File.each_line("/proc/self/smaps") do |line|
      if line.ends_with?(path)
        in_mapping = true
      elsif in_mapping && line.starts_with?("Rss:")
        return line.split[1].to_i
      end
    end
    fail("No mapping found for #{path}")
  end

  def self.offset_from_headers(headers)
    if headers
      headers["x-stream-offset"].as(Int64)
    else
      fail("No headers found")
    end
  end
end

describe LavinMQ::AMQP::Stream do
  stream_queue_args = LavinMQ::AMQP::Table.new({"x-queue-type": "stream"})

  describe "Consume" do
    it "should get message with offset 2" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("pub_and_consume", args: stream_queue_args)
          10.times { |i| q.publish "m#{i}" }
          ch.prefetch 1
          msgs = Channel(AMQP::Client::DeliverMessage).new
          q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": 2})) do |msg|
            msgs.send msg
          end
          msg = msgs.receive
          msg.properties.headers.should eq LavinMQ::AMQP::Table.new({"x-stream-offset": 2})
          msg.body_io.to_s.should eq "m1"
        end
      end
    end

    it "should get same nr of messages as published" do
      with_amqp_server do |s|
        with_channel(s) do |ch2|
          q = ch2.queue("pub_and_consume_2", args: stream_queue_args)
          10.times { |i| q.publish "m#{i}" }
          ch2.prefetch 1
          msgs = Channel(AMQP::Client::DeliverMessage).new
          q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": 0})) do |msg|
            msgs.send(msg)
            msg.ack
          end
          10.times do
            msgs.receive
          end
        end
      end
    end

    it "should be able to consume multiple times" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("pub_and_consume_3", args: stream_queue_args)
          10.times { |i| q.publish "m#{i}" }
          msgs = Channel(AMQP::Client::DeliverMessage).new(20)
          ch.prefetch 1
          2.times do
            q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": 0})) do |msg|
              msgs.send(msg)
              msg.ack
            end
          end
          20.times do
            msgs.receive
          end
        end
      end
    end

    it "consumer gets new messages as they arrive" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.prefetch 1
          args = {"x-queue-type": "stream"}
          q = ch.queue("stream-consume", args: AMQP::Client::Arguments.new(args))
          q.publish "1"
          msgs = Channel(AMQP::Client::DeliverMessage).new
          q.subscribe(no_ack: false) do |msg|
            msg.ack
            msgs.send(msg)
          end
          msgs.receive.body_io.to_s.should eq "1"
          q.publish "2"
          msgs.receive.body_io.to_s.should eq "2"
        end
      end
    end

    it "multiple consumers get new messages immediately as they arrive" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.prefetch 1
          args = {"x-queue-type": "stream"}
          q = ch.queue("stream-consume-multiple", args: AMQP::Client::Arguments.new(args))

          # Publish an initial message
          q.publish "initial"

          # Set up two consumers
          consumer1_msgs = Channel(AMQP::Client::DeliverMessage).new
          consumer2_msgs = Channel(AMQP::Client::DeliverMessage).new

          # Consumer 1 starts from the beginning
          q.subscribe(no_ack: false, tag: "consumer1", args: AMQP::Client::Arguments.new({"x-stream-offset": 0})) do |msg|
            msg.ack
            consumer1_msgs.send(msg)
          end

          # Consumer 2 starts from the beginning as well
          q.subscribe(no_ack: false, tag: "consumer2", args: AMQP::Client::Arguments.new({"x-stream-offset": 0})) do |msg|
            msg.ack
            consumer2_msgs.send(msg)
          end

          # Both consumers should receive the initial message
          consumer1_msgs.receive.body_io.to_s.should eq "initial"
          consumer2_msgs.receive.body_io.to_s.should eq "initial"

          # Publish a new message
          q.publish "new_message"

          # Both consumers should immediately receive the new message
          # Use select with timeout to detect if messages aren't delivered immediately
          received_count = 0
          timeout = 2.seconds

          select
          when msg1 = consumer1_msgs.receive
            msg1.body_io.to_s.should eq "new_message"
            received_count += 1
          when timeout(timeout)
            fail("Consumer 1 didn't receive new message within #{timeout}")
          end

          select
          when msg2 = consumer2_msgs.receive
            msg2.body_io.to_s.should eq "new_message"
            received_count += 1
          when timeout(timeout)
            fail("Consumer 2 didn't receive new message within #{timeout}")
          end

          received_count.should eq 2
        end
      end
    end

    it "reproduces bug: second consumer doesn't get immediate delivery" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.prefetch 1
          args = {"x-queue-type": "stream"}
          q = ch.queue("stream-bug-test", args: AMQP::Client::Arguments.new(args))

          # Set up two consumers that both start from "next" (end of stream)
          consumer1_msgs = Channel(AMQP::Client::DeliverMessage).new
          consumer2_msgs = Channel(AMQP::Client::DeliverMessage).new

          # Both consumers start from the next offset (waiting for new messages)
          q.subscribe(no_ack: false, tag: "consumer1", args: AMQP::Client::Arguments.new({"x-stream-offset": "next"})) do |msg|
            msg.ack
            consumer1_msgs.send(msg)
          end

          q.subscribe(no_ack: false, tag: "consumer2", args: AMQP::Client::Arguments.new({"x-stream-offset": "next"})) do |msg|
            msg.ack
            consumer2_msgs.send(msg)
          end

          # Small delay to ensure consumers are ready
          sleep 0.1.seconds

          # Publish a new message - both consumers should receive it immediately
          q.publish "test_message"

          # Test with a short timeout - both should receive within 1 second
          timeout = 1.seconds

          # Check consumer 1
          select
          when msg1 = consumer1_msgs.receive
            msg1.body_io.to_s.should eq "test_message"
          when timeout(timeout)
            fail("Consumer 1 failed to receive new message")
          end

          # Check consumer 2
          select
          when msg2 = consumer2_msgs.receive
            msg2.body_io.to_s.should eq "test_message"
          when timeout(timeout)
            fail("Consumer 2 failed to receive new message")
          end
        end
      end
    end
  end

  it "consume from timestamp offset across segment boundary", tags: "slow" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("stream-ts-across-segments", args: stream_queue_args)
        # Half-segment payload so each publish lands in its own segment.
        data = Bytes.new(LavinMQ::Config.instance.segment_size // 2)
        q.publish_confirm data
        # Sleep > 1s so the two messages land in distinct whole seconds
        sleep 1.2.seconds
        q.publish_confirm data
        # Derive target from msg1's stored timestamp; Time.utc here would race RoughTime's
        # 100ms coarsening and could land inside segment 2's bucket, hanging the consumer.
        store = s.vhosts["/"].queue("stream-ts-across-segments").as(LavinMQ::AMQP::Stream).stream_msg_store
        msg1_ts = store.@segment_last_ts.values.first
        target_time = Time.unix(msg1_ts // 1000 + 1)
        ch.prefetch 1
        msgs = Channel(AMQP::Client::DeliverMessage).new
        q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": target_time})) do |msg|
          msgs.send msg
          msg.ack
        end
        msg = msgs.receive
        StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq 2
      end
    end
  end

  describe "deliver loop scheduling" do
    it "yields to other fibers after yield_each_delivered_bytes during a replay" do
      config = LavinMQ::Config.instance
      original = config.yield_each_delivered_bytes
      config.yield_each_delivered_bytes = 4096
      msg_count = 150
      body = Bytes.new(512)
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("stream-yield-bytes", args: stream_queue_args)
          msg_count.times { q.publish_confirm body }
          stream = s.vhosts["/"].queue("stream-yield-bytes").as(LavinMQ::AMQP::Stream)

          # Sample the consumer's offset every time this fiber gets scheduled.
          # It can only observe an offset in the middle of the replay if the
          # deliver loop yields before it has pushed every message.
          observed = Array(Int64).new
          done = false
          spawn(name: "offset sampler") do
            until done
              if consumer = stream.consumers.first?.as?(LavinMQ::AMQP::StreamConsumer)
                observed << consumer.offset
              end
              Fiber.yield
            end
          end

          ch.prefetch 1000
          all_received = Channel(Nil).new
          first_offset = 0_i64
          last_offset = 0_i64
          received = 0
          q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": "first"})) do |msg|
            offset = StreamSpecHelpers.offset_from_headers(msg.properties.headers)
            first_offset = offset if received.zero?
            last_offset = offset
            msg.ack
            received += 1
            all_received.send(nil) if received == msg_count
          end
          all_received.receive
          done = true

          observed.any? { |o| first_offset < o < last_offset }.should be_true
        end
      end
    ensure
      LavinMQ::Config.instance.yield_each_delivered_bytes = original.not_nil!
    end

    it "yields to other fibers while scanning past filtered-out messages" do
      # The deliver loop yields every 32_768 iterations, so scan far enough
      # for it to yield more than once regardless of scheduling order.
      skipped = 70_000
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("stream-yield-filtered", args: stream_queue_args)
          skipped.times { q.publish "skip" }
          headers = AMQP::Client::Arguments.new({"x-stream-filter-value": "wanted"})
          q.publish_confirm "deliver", props: AMQP::Client::Properties.new(headers: headers)
          stream = s.vhosts["/"].queue("stream-yield-filtered").as(LavinMQ::AMQP::Stream)

          # Nothing is delivered while the deliver loop scans past the
          # filtered-out messages, so only a voluntary yield lets this fiber
          # observe an offset in the middle of the scan.
          observed = Array(Int64).new
          done = false
          spawn(name: "offset sampler") do
            until done
              if consumer = stream.consumers.first?.as?(LavinMQ::AMQP::StreamConsumer)
                observed << consumer.offset
              end
              Fiber.yield
            end
          end

          ch.prefetch 1
          msgs = Channel(AMQP::Client::DeliverMessage).new
          args = AMQP::Client::Arguments.new({"x-stream-offset": "first", "x-stream-filter": "wanted"})
          q.subscribe(no_ack: false, args: args) do |msg|
            msgs.send msg
            msg.ack
          end
          msg = msgs.receive
          done = true

          StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq skipped + 1
          observed.any? { |o| 1 < o <= skipped }.should be_true
        end
      end
    end
  end

  describe "x-stream-offset negative integer" do
    it "delivers the last N messages" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("neg-offset-last-n", args: stream_queue_args)
          200.times { |i| q.publish "m#{i}" }
          ch.prefetch 100
          msgs = Channel(AMQP::Client::DeliverMessage).new(100)
          q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": -100})) do |msg|
            msgs.send(msg)
            msg.ack
          end
          received = Array(AMQP::Client::DeliverMessage).new
          100.times { received << msgs.receive }
          StreamSpecHelpers.offset_from_headers(received.first.properties.headers).should eq 101
          StreamSpecHelpers.offset_from_headers(received.last.properties.headers).should eq 200
        end
      end
    end

    it "continues with new messages after delivering the last N messages" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("neg-offset-continues", args: stream_queue_args)
          5.times { |i| q.publish "m#{i}" }
          ch.prefetch 10
          msgs = Channel(AMQP::Client::DeliverMessage).new(4)
          q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": -3})) do |msg|
            msgs.send(msg)
            msg.ack
          end

          received = Array(AMQP::Client::DeliverMessage).new
          3.times { received << msgs.receive }
          received.map { |msg| StreamSpecHelpers.offset_from_headers(msg.properties.headers) }.should eq [3_i64, 4_i64, 5_i64]
          received.map(&.body_io.to_s).should eq ["m2", "m3", "m4"]

          q.publish "m5"
          select
          when msg = msgs.receive
            StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq 6
            msg.body_io.to_s.should eq "m5"
          when timeout(1.second)
            fail("Consumer did not continue with the next stream message")
          end
        end
      end
    end

    it "clamps to oldest available when stream has fewer messages than requested" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("neg-offset-underflow", args: stream_queue_args)
          30.times { |i| q.publish "m#{i}" }
          ch.prefetch 30
          msgs = Channel(AMQP::Client::DeliverMessage).new(30)
          q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": -100})) do |msg|
            msgs.send(msg)
            msg.ack
          end
          received = Array(AMQP::Client::DeliverMessage).new
          30.times { received << msgs.receive }
          StreamSpecHelpers.offset_from_headers(received.first.properties.headers).should eq 1
          StreamSpecHelpers.offset_from_headers(received.last.properties.headers).should eq 30
        end
      end
    end

    it "waits for new messages from the next offset when the stream is empty" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("neg-offset-empty", args: stream_queue_args)
          ch.prefetch 1
          msgs = Channel(AMQP::Client::DeliverMessage).new
          q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": -100})) do |msg|
            msgs.send(msg)
            msg.ack
          end
          q.publish "m"
          msg = msgs.receive
          StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq 1
          msg.body_io.to_s.should eq "m"
        end
      end
    end

    it "x-stream-offset=-1 delivers only the latest message" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("neg-offset-one", args: stream_queue_args)
          5.times { |i| q.publish "m#{i}" }
          ch.prefetch 1
          msgs = Channel(AMQP::Client::DeliverMessage).new
          q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": -1})) do |msg|
            msgs.send(msg)
            msg.ack
          end
          msg = msgs.receive
          StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq 5
          msg.body_io.to_s.should eq "m4"
        end
      end
    end

    it "delivers remaining messages when older segments have been dropped" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          args = {"x-queue-type": "stream", "x-max-length": 1}
          q = ch.queue("neg-offset-after-drop", args: AMQP::Client::Arguments.new(args))
          data = Bytes.new(LavinMQ::Config.instance.segment_size)
          3.times { q.publish_confirm data }
          # The second segment is kept: dropping it would go below max-length
          q.message_count.should eq 2
          ch.prefetch 1
          msgs = Channel(AMQP::Client::DeliverMessage).new
          q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": -100})) do |msg|
            msgs.send(msg)
            msg.ack
          end
          msg = msgs.receive
          StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq 2
        end
      end
    end

    it "anchors to the end of the restored stream after a restart" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("neg-offset-restart", args: stream_queue_args)
          200.times { |i| q.publish_confirm "m#{i}" }
        end

        # The last offset is rebuilt from the segments on boot; a negative
        # offset resolved against a stale or zeroed one would replay the whole
        # stream instead of its tail.
        restart_server(s)

        with_channel(s) do |ch|
          q = ch.queue("neg-offset-restart", args: stream_queue_args)
          ch.prefetch 100
          msgs = Channel(AMQP::Client::DeliverMessage).new(100)
          q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": -100})) do |msg|
            msgs.send(msg)
            msg.ack
          end
          received = Array(AMQP::Client::DeliverMessage).new
          100.times { received << msgs.receive }
          StreamSpecHelpers.offset_from_headers(received.first.properties.headers).should eq 101
          StreamSpecHelpers.offset_from_headers(received.last.properties.headers).should eq 200
        end
      end
    end

    it "clamps Int64::MIN to the oldest available message" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("neg-offset-min", args: stream_queue_args)
          q.publish_confirm "m"
          ch.prefetch 1
          msgs = Channel(AMQP::Client::DeliverMessage).new
          q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": Int64::MIN})) do |msg|
            msgs.send(msg)
            msg.ack
          end
          msg = msgs.receive
          StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq 1
          msg.body_io.to_s.should eq "m"
        end
      end
    end
  end

  describe "Expiration" do
    it "segments should be removed if max-length set" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          args = {"x-queue-type": "stream", "x-max-length": 1}
          q = ch.queue("stream-max-length", args: AMQP::Client::Arguments.new(args))
          data = Bytes.new(LavinMQ::Config.instance.segment_size)
          3.times { q.publish_confirm data }
          # Never drops below the limit, so the newest full segment is kept
          q.message_count.should eq 2
        end
      end
    end

    it "segments should be removed if max-length-bytes set" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          args = {"x-queue-type": "stream", "x-max-length-bytes": 1}
          q = ch.queue("stream-max-length-bytes", args: AMQP::Client::Arguments.new(args))
          data = Bytes.new(LavinMQ::Config.instance.segment_size)
          3.times { q.publish_confirm data }
          # Never drops below the limit, so the newest full segment is kept
          q.message_count.should eq 2
        end
      end
    end

    it "segments should be removed if max-age set", tags: "slow" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          args = {"x-queue-type": "stream", "x-max-age": "1s"}
          q = ch.queue("stream-max-age", args: AMQP::Client::Arguments.new(args))
          data = Bytes.new(LavinMQ::Config.instance.segment_size)
          2.times { q.publish_confirm data }
          sleep 1.1.seconds
          q.publish_confirm data
          q.message_count.should eq 1
        end
      end
    end

    it "removes segments on publish if max-age policy is set", tags: "slow" do
      with_amqp_server do |s|
        s.vhosts["/"].add_policy("max", "stream-max-age-policy", "queues", {"max-age" => JSON::Any.new("1s")}, 0i8)
        with_channel(s) do |ch|
          args = {"x-queue-type": "stream", "x-max-age": "1M"}
          q = ch.queue("stream-max-age-policy", args: AMQP::Client::Arguments.new(args))
          data = Bytes.new(LavinMQ::Config.instance.segment_size)
          2.times { q.publish_confirm data }
          sleep 1.1.seconds
          q.publish_confirm data
          q.message_count.should eq 1
        end
      end
    end

    it "removes segments when max-age policy is applied", tags: "slow" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          args = {"x-queue-type": "stream", "x-max-age": "1M"}
          q = ch.queue("stream-max-age-policy", args: AMQP::Client::Arguments.new(args))
          data = Bytes.new(LavinMQ::Config.instance.segment_size)
          2.times { q.publish_confirm data }
          q.message_count.should eq 2
          sleep 1.1.seconds
          s.vhosts["/"].add_policy("max", "stream-max-age-policy", "queues", {"max-age" => JSON::Any.new("1s")}, 0i8)
          q.message_count.should eq 1
        end
      end
    end

    it "applies a relaxed max-age when a policy is edited to a larger value" do
      with_amqp_server do |s|
        s.vhosts["/"].add_policy("max", "stream-max-age-relax", "queues", {"max-age" => JSON::Any.new("1s")}, 0i8)
        with_channel(s) do |ch|
          args = {"x-queue-type": "stream"}
          ch.queue("stream-max-age-relax", args: AMQP::Client::Arguments.new(args))
          stream = s.vhosts["/"].queue("stream-max-age-relax").as(LavinMQ::AMQP::Stream)
          wait_for { stream.stream_msg_store.max_age == 1.second }
          s.vhosts["/"].add_policy("max", "stream-max-age-relax", "queues", {"max-age" => JSON::Any.new("1h")}, 0i8)
          wait_for { stream.stream_msg_store.max_age == 1.hour }
        end
      end
    end

    it "clears max-age when a policy is deleted" do
      with_amqp_server do |s|
        s.vhosts["/"].add_policy("max", "stream-max-age-delete", "queues", {"max-age" => JSON::Any.new("1s")}, 0i8)
        with_channel(s) do |ch|
          args = {"x-queue-type": "stream"}
          ch.queue("stream-max-age-delete", args: AMQP::Client::Arguments.new(args))
          stream = s.vhosts["/"].queue("stream-max-age-delete").as(LavinMQ::AMQP::Stream)
          wait_for { stream.stream_msg_store.max_age == 1.second }
          s.vhosts["/"].delete_policy("max")
          wait_for { stream.stream_msg_store.max_age.nil? }
        end
      end
    end

    it "removes segments when max-length-bytes policy is applied" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          args = {"x-queue-type": "stream"}
          q = ch.queue("stream-max-length-bytes-policy", args: AMQP::Client::Arguments.new(args))
          data = Bytes.new(LavinMQ::Config.instance.segment_size)
          2.times { q.publish_confirm data }
          q.message_count.should eq 2
          # Apply policy - should immediately trigger cleanup
          s.vhosts["/"].add_policy("mlb", "stream-max-length-bytes-policy", "queues",
            {"max-length-bytes" => JSON::Any.new(1_i64)}, 0i8)
          q.message_count.should eq 1
        end
      end
    end

    it "removes segments when max-length policy is applied" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          args = {"x-queue-type": "stream"}
          q = ch.queue("stream-max-length-policy", args: AMQP::Client::Arguments.new(args))
          data = Bytes.new(LavinMQ::Config.instance.segment_size)
          2.times { q.publish_confirm data }
          q.message_count.should eq 2
          # Apply policy - should immediately trigger cleanup
          s.vhosts["/"].add_policy("ml", "stream-max-length-policy", "queues",
            {"max-length" => JSON::Any.new(1_i64)}, 0i8)
          q.message_count.should eq 1
        end
      end
    end

    # Regression: a `delivery-limit` policy matching a stream queue used to
    # fall through to AMQP::Queue#apply_policy_argument, which spawned a
    # drop_redelivered fiber. That fiber called the inherited
    # MessageStore#first? and dereferenced the legacy `@rfile` — which
    # streams don't maintain through `drop_segments_while` — pointing at
    # a closed mfile from a long-dropped segment. The spawn died with
    # IO::Error("Closed mfile"). Stream now rejects the policy key
    # alongside the declare-time validation.
    it "ignores delivery-limit policy on streams" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          args = {"x-queue-type": "stream"}
          q = ch.queue("stream-delivery-limit-policy", args: AMQP::Client::Arguments.new(args))
          # Roll a few segments, then drop them via max-length-bytes so the
          # inherited @rfile is left dangling at a closed mfile — the same
          # state observed in the production crash.
          data = Bytes.new(LavinMQ::Config.instance.segment_size)
          3.times { q.publish_confirm data }
          s.vhosts["/"].add_policy("mlb", "stream-delivery-limit-policy", "queues",
            {"max-length-bytes" => JSON::Any.new(1_i64)}, 0i8)
          q.message_count.should eq 1
          # Now apply delivery-limit. Pre-fix this spawned drop_redelivered
          # and crashed; post-fix it's skipped entirely.
          s.vhosts["/"].add_policy("dl", "stream-delivery-limit-policy", "queues",
            {"delivery-limit" => JSON::Any.new(5_i64)}, 1i8)
          stream = s.vhosts["/"].queue("stream-delivery-limit-policy").as(LavinMQ::AMQP::Stream)
          stream.effective_policy_args.should_not contain "delivery-limit"
          # Give the (non-existent post-fix) spawn fiber a chance to run and
          # verify the queue is still functional.
          Fiber.yield
          q.publish_confirm "ok"
          q.message_count.should eq 2
        end
      end
    end

    it "does not start the expire fiber when the last consumer leaves" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          args = {"x-queue-type": "stream"}
          q = ch.queue("stream-expire-after-drop", args: AMQP::Client::Arguments.new(args))
          data = Bytes.new(LavinMQ::Config.instance.segment_size)
          4.times { q.publish_confirm data }

          stream = s.vhosts["/"].queue("stream-expire-after-drop").as(LavinMQ::AMQP::Stream)
          # Pin the inherited @rfile onto a populated segment, then drop that
          # segment via max-length-bytes so @rfile dangles at a closed mfile —
          # the same state observed in the production crash.
          stream.@msg_store.first?
          s.vhosts["/"].add_policy("mlb", "stream-expire-after-drop", "queues",
            {"max-length-bytes" => JSON::Any.new(1_i64)}, 0i8)

          ch.prefetch 1
          q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": "next"})) { }
          should_eventually(eq 1) { stream.consumers.size }

          # Pre-fix this ran ensure_expire_fiber -> should_start_expire_fiber? ->
          # MessageStore#first?, dereferencing the dropped+closed read segment
          # and crashing the connection's read_loop fiber. Post-fix the check is
          # skipped for streams, so removing the last consumer must not raise.
          stream.rm_consumer(stream.consumers.first)
          stream.message_expire_fiber_active?.should be_false
        end
      end
    end

    it "meta files should be removed when segment is removed" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          args = {"x-queue-type": "stream", "x-max-length": 1}
          q = ch.queue("stream-max-length", args: AMQP::Client::Arguments.new(args))
          data = Bytes.new(LavinMQ::Config.instance.segment_size)
          3.times { q.publish_confirm data }
          dir = s.vhosts["/"].queue("stream-max-length").as(LavinMQ::AMQP::Stream).@data_dir
          File.exists?(File.join(dir, "msgs.0000000001")).should be_false
          File.exists?(File.join(dir, "meta.0000000001")).should be_false
          q.message_count.should eq 2
        end
      end
    end

    it "should not lose messages on restart when max-age is set" do
      queue_name = Random::Secure.hex
      with_amqp_server do |s|
        with_channel(s) do |ch|
          args = {"x-queue-type": "stream", "x-max-age": "1h"}
          q = ch.queue(queue_name, args: AMQP::Client::Arguments.new(args))
          data = Bytes.new(LavinMQ::Config.instance.segment_size)
          3.times { q.publish_confirm data }
          q.message_count.should eq 3

          stream = s.vhosts["/"].queue(queue_name).as(LavinMQ::AMQP::Stream)
          stream.close
          stream.restart!
          stream.message_count.should eq 3
        end
      end
    end
  end

  it "doesn't support basic_get" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("stream_basic_get", args: stream_queue_args)
        q.publish_confirm "foobar"
        expect_raises(AMQP::Client::Channel::ClosedException, /NOT_IMPLEMENTED.*basic_get/) do
          ch.basic_get(q.name, no_ack: false)
        end
      end
    end
  end

  it "drops a publish when the store is closed concurrently" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        ch.queue("stream-closed-store-publish", args: stream_queue_args)
        stream = s.vhosts["/"].queue("stream-closed-store-publish").as(LavinMQ::AMQP::Stream)
        # Simulate a delete racing publish_internal: the store is closed after
        # the @state.closed? check but before push, so push raises ClosedError.
        # The publish must report Dropped, not raise (mirrors the queue spec).
        stream.@msg_store.close
        msg = LavinMQ::Message.new("", "stream-closed-store-publish", "body", LavinMQ::AMQP::Properties.new)
        stream.publish(msg).dropped?.should be_true
      end
    end
  end

  it "can requeue msgs per consumer" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("stream-requeue", args: stream_queue_args)
        q.publish_confirm "foobar"
        msgs = Channel(AMQP::Client::DeliverMessage).new
        ch.prefetch 1
        q.subscribe(no_ack: false) do |msg|
          msgs.send msg
        end
        msg1 = msgs.receive
        msg1.body_io.to_s.should eq "foobar"
        msg1.reject(requeue: true)
        msg2 = msgs.receive
        msg2.body_io.to_s.should eq "foobar"
      end
    end
  end

  it "can start consume from last segment even if queue is empty" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("empty-stream", args: stream_queue_args)
        ch.prefetch 1
        q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": "last"})) do |msg|
          msg.ack
        end
      end
    end
  end

  it "can be purged" do
    with_amqp_server do |s|
      with_channel(s) do |ch|
        q = ch.queue("purge-stream", args: stream_queue_args)
        data = Bytes.new(LavinMQ::Config.instance.segment_size)
        3.times { q.publish_confirm data }
        q.purge[:message_count].should eq 2 # never deletes the last segment
      end
    end
  end

  describe "Automatic consumer offset tracking" do
    it "resumes from last offset on reconnect" do
      queue_name = Random::Secure.hex
      consumer_tag = Random::Secure.hex
      offset = 3

      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, offset + 1)
        offset.times { StreamSpecHelpers.consume_one(s, queue_name, consumer_tag) }
        sleep 0.1.seconds

        # consume again, should start from last offset automatically
        msg = StreamSpecHelpers.consume_one(s, queue_name, consumer_tag)
        StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq offset + 1
      end
    end

    it "reads offsets from file on init" do
      queue_name = Random::Secure.hex
      offsets = [84_i64, 24_i64, 1_i64, 100_i64, 42_i64]
      tag_prefix = "ctag-"

      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        StreamSpecHelpers.publish(s, queue_name, 1)

        data_dir = File.join(vhost.data_dir, Digest::SHA1.hexdigest queue_name)
        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        offsets.each_with_index do |offset, i|
          msg_store.store_consumer_offset(tag_prefix + i.to_s, offset)
        end
        msg_store.close
        wait_for { msg_store.@closed }

        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        offsets.each_with_index do |offset, i|
          msg_store.last_offset_by_consumer_tag(tag_prefix + i.to_s).should eq offset
        end
        msg_store.close
      end
    end

    it "appends consumer tag file" do
      queue_name = Random::Secure.hex
      offsets = [84_i64, 24_i64, 1_i64, 100_i64, 42_i64]
      consumer_tag = "ctag-1"
      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 1)

        data_dir = File.join(s.vhosts["/"].data_dir, Digest::SHA1.hexdigest queue_name)
        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        offsets.each do |offset|
          msg_store.store_consumer_offset(consumer_tag, offset)
        end
        bytesize = consumer_tag.bytesize + 1 + 8
        msg_store.@consumer_offsets.size.should eq bytesize*5
        msg_store.last_offset_by_consumer_tag(consumer_tag).should eq offsets.last
        msg_store.close
      end
    end

    it "compacts consumer tag file on restart" do
      queue_name = Random::Secure.hex
      offsets = [84_i64, 24_i64, 1_i64, 100_i64, 42_i64]
      consumer_tag = "ctag-1"
      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 1)

        data_dir = File.join(s.vhosts["/"].data_dir, Digest::SHA1.hexdigest queue_name)
        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        offsets.each do |offset|
          msg_store.store_consumer_offset(consumer_tag, offset)
        end
        msg_store.close

        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        msg_store.last_offset_by_consumer_tag(consumer_tag).should eq offsets.last
        bytesize = consumer_tag.bytesize + 1 + 8
        msg_store.@consumer_offsets.size.should eq bytesize
        msg_store.close
      end
    end

    it "compacts consumer tag file when full" do
      queue_name = Random::Secure.hex
      offsets = [84_i64, 24_i64, 1_i64, 100_i64, 42_i64]
      consumer_tag = Random::Secure.hex(32)
      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 1)
        data_dir = File.join(s.vhosts["/"].data_dir, Digest::SHA1.hexdigest queue_name)
        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        bytesize = consumer_tag.bytesize + 1 + 8

        offsets = (LavinMQ::Config.instance.segment_size / bytesize).to_i32 + 1
        offsets.times do |i|
          msg_store.store_consumer_offset(consumer_tag, i)
        end
        msg_store.last_offset_by_consumer_tag(consumer_tag).should eq offsets - 1
        msg_store.@consumer_offsets.size.should eq bytesize*2
        msg_store.close
      end
    end

    it "compacts consumer tag file again when it fills a second time with an unchanged retention floor" do
      queue_name = Random::Secure.hex
      consumer_tag = Random::Secure.hex(32)
      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 1)
        data_dir = File.join(s.vhosts["/"].data_dir, Digest::SHA1.hexdigest queue_name)
        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        bytesize = consumer_tag.bytesize + 1 + 8

        first_fill = (LavinMQ::Config.instance.segment_size / bytesize).to_i32 + 1
        first_fill.times { |i| msg_store.store_consumer_offset(consumer_tag, i.to_i64) }
        capacity_after_first_compaction = msg_store.@consumer_offsets.@mfile.capacity

        # No retention policy is set, so the retention floor never advances.
        # Filling the file a second time must still compact it - it must not
        # short-circuit (as it would if `cleanup`'s unchanged-floor guard
        # applied here) and raise IO::EOFError from the write that follows.
        second_fill = (capacity_after_first_compaction / bytesize).to_i32 + 1
        last_offset = first_fill.to_i64
        second_fill.times do
          msg_store.store_consumer_offset(consumer_tag, last_offset)
          last_offset += 1
        end

        msg_store.last_offset_by_consumer_tag(consumer_tag).should eq last_offset - 1
        msg_store.close
      end
    end

    it "does not track offset if x-stream-offset is set" do
      queue_name = Random::Secure.hex
      consumer_tag = Random::Secure.hex
      c_args = AMQP::Client::Arguments.new({"x-stream-offset": 0})

      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 2)
        msg = StreamSpecHelpers.consume_one(s, queue_name, consumer_tag, c_args)
        StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq 1
        sleep 0.1.seconds

        # should consume the same message again since tracking was not saved from last consume
        msg_2 = StreamSpecHelpers.consume_one(s, queue_name, consumer_tag)
        StreamSpecHelpers.offset_from_headers(msg_2.properties.headers).should eq 1
      end
    end

    it "should not use saved offset if x-stream-offset is set" do
      queue_name = Random::Secure.hex
      consumer_tag = Random::Secure.hex
      c_args = AMQP::Client::Arguments.new({"x-stream-offset": 0})

      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 2)

        # get message without x-stream-offset, tracks offset
        msg = StreamSpecHelpers.consume_one(s, queue_name, consumer_tag)
        StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq 1
        sleep 0.1.seconds

        # consume with x-stream-offset set, should consume the same message again
        msg_2 = StreamSpecHelpers.consume_one(s, queue_name, consumer_tag, c_args)
        StreamSpecHelpers.offset_from_headers(msg_2.properties.headers).should eq 1
      end
    end

    it "should use saved offset if x-stream-offset & x-stream-automatic-offset-tracking is set" do
      queue_name = Random::Secure.hex
      consumer_tag = Random::Secure.hex
      c_args = AMQP::Client::Arguments.new({"x-stream-offset": 0, "x-stream-automatic-offset-tracking": "true"})

      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 2)

        # tracks offset
        msg = StreamSpecHelpers.consume_one(s, queue_name, consumer_tag, c_args)
        StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq 1
        sleep 0.1.seconds

        # should continue from tracked offset
        msg = StreamSpecHelpers.consume_one(s, queue_name, consumer_tag, c_args)
        StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq 2
      end
    end

    it "should not use saved offset if x-stream-automatic-offset-tracking is false" do
      queue_name = Random::Secure.hex
      consumer_tag = Random::Secure.hex
      c_args = AMQP::Client::Arguments.new({"x-stream-offset": 0, "x-stream-automatic-offset-tracking": "false"})

      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 2)

        # does not track offset
        msg = StreamSpecHelpers.consume_one(s, queue_name, consumer_tag, c_args)
        StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq 1
        sleep 0.1.seconds

        # should consume the same message again, no tracked offset
        msg = StreamSpecHelpers.consume_one(s, queue_name, consumer_tag, c_args)
        StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq 1
      end
    end

    it "drop_overflow does not raise after the store has been deleted" do
      queue_name = Random::Secure.hex
      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 1)

        data_dir = File.join(s.vhosts["/"].data_dir, Digest::SHA1.hexdigest queue_name)
        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        msg_store.store_consumer_offset("ctag", 1_i64)
        msg_store.delete
        msg_store.drop_overflow
      end
    end

    it "store_consumer_offset raises ClosedError after the store is closed" do
      queue_name = Random::Secure.hex
      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 1)

        data_dir = File.join(s.vhosts["/"].data_dir, Digest::SHA1.hexdigest queue_name)
        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        msg_store.close
        # A late ack must surface ClosedError (like find_offset/shift?/push),
        # not a raw "Closed mfile" IO::Error that escapes the read_loop.
        expect_raises(LavinMQ::MessageStore::ClosedError) do
          msg_store.store_consumer_offset("ctag", 1_i64)
        end
      end
    end

    it "acking after the queue is deleted does not tear down the connection" do
      queue_name = Random::Secure.hex
      consumer_tag = Random::Secure.hex
      c_args = AMQP::Client::Arguments.new({"x-stream-automatic-offset-tracking": "true"})
      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 1)
        with_channel(s) do |ch|
          ch.prefetch 1
          q = ch.queue(queue_name, args: stream_queue_args)
          msgs = Channel(AMQP::Client::DeliverMessage).new(1)
          # Hold the message unacked so we control when the ack is sent.
          q.subscribe(no_ack: false, tag: consumer_tag, args: c_args) do |msg|
            msgs.send msg
          end
          msg = msgs.receive

          # Delete the queue out from under the in-flight ack: the message store
          # is closed while the channel's Unack still references this consumer.
          s.vhosts["/"].queue(queue_name).delete

          # The late ack stores the offset on a closed store, which raises
          # MessageStore::ClosedError. StreamConsumer#ack must swallow it so the
          # exception doesn't escape basic_ack and tear down the read_loop.
          msg.ack

          # Connection/read_loop survives: a follow-up RPC on the same channel
          # still round-trips. Without the rescue this raises (connection gone).
          ch.queue(Random::Secure.hex, args: stream_queue_args).should_not be_nil
        end
      end
    end

    it "negative x-stream-offset does not override tracked offset on reconnect" do
      queue_name = Random::Secure.hex
      consumer_tag = Random::Secure.hex
      c_args = AMQP::Client::Arguments.new({"x-stream-offset": -5, "x-stream-automatic-offset-tracking": "true"})

      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 10)
        msg = StreamSpecHelpers.consume_one(s, queue_name, consumer_tag, c_args)
        StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq 6
        sleep 0.1.seconds

        StreamSpecHelpers.publish(s, queue_name, 5)

        # tracked offset (7) wins over the -5 that would otherwise re-anchor to 11
        msg2 = StreamSpecHelpers.consume_one(s, queue_name, consumer_tag, c_args)
        StreamSpecHelpers.offset_from_headers(msg2.properties.headers).should eq 7
      end
    end

    it "cleanup_consumer_offsets removes outdated offset" do
      queue_name = Random::Secure.hex
      offsets = [84_i64, -10_i64]
      tag_prefix = "ctag-"

      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 1)

        data_dir = File.join(s.vhosts["/"].data_dir, Digest::SHA1.hexdigest queue_name)
        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        offsets.each_with_index do |offset, i|
          msg_store.store_consumer_offset(tag_prefix + i.to_s, offset)
        end
        sleep 0.1.seconds
        msg_store.cleanup_consumer_offsets
        msg_store.close
        sleep 0.1.seconds

        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        msg_store.last_offset_by_consumer_tag(tag_prefix + 1.to_s).should be_nil
        msg_store.last_offset_by_consumer_tag(tag_prefix + 0.to_s).should eq offsets[0]
        msg_store.close
      end
    end

    it "cleanup_consumer_offsets does not overflow with many consumer offsets" do
      queue_name = Random::Secure.hex
      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 1)
        data_dir = File.join(s.vhosts["/"].data_dir, Digest::SHA1.hexdigest queue_name)
        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)

        # Enough fixed-width entries that the summed size exceeds
        # Int32::MAX // 1000 (~2.1 MB), which overflowed the old `capacity * 1000`.
        tag_prefix = "c" * 240
        entry_size = (tag_prefix.bytesize + 5) + 1 + 8
        count = Int32::MAX // 1000 // entry_size + 2
        count.times do |i|
          msg_store.store_consumer_offset("#{tag_prefix}#{i.to_s.rjust(5, '0')}", i.to_i64)
        end

        msg_store.cleanup_consumer_offsets # raised OverflowError before the fix
        msg_store.close
      end
    end

    it "skips rewriting the consumer offsets file when the retention floor is unchanged" do
      queue_name = Random::Secure.hex
      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 1)
        data_dir = File.join(s.vhosts["/"].data_dir, Digest::SHA1.hexdigest queue_name)
        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        msg_store.store_consumer_offset("ctag-1", 1_i64)

        msg_store.cleanup_consumer_offsets
        mfile_before = msg_store.@consumer_offsets.@mfile

        # Nothing dropped the stream's oldest segment in between, so the
        # retention floor is the same and this call should be a no-op.
        msg_store.cleanup_consumer_offsets
        msg_store.@consumer_offsets.@mfile.should be mfile_before

        msg_store.close
      end
    end

    it "ConsumerOffsets.trim_to_size drops the oldest offsets when over the cap" do
      # {consumer_tag, offset, file_position}; higher position == more recent.
      # Each entry is 6 + 1 + 8 = 15 bytes.
      tracked_offsets = [
        {"oldest", 1_i64, 0_i64},
        {"middle", 2_i64, 100_i64},
        {"newest", 3_i64, 200_i64},
      ]
      # 30-byte cap fits one entry (`>=` stays strictly below), keeps newest only.
      kept = LavinMQ::AMQP::ConsumerOffsets.trim_to_size(tracked_offsets, max_size: 30_i64)
      kept.map(&.first).should eq ["newest"]

      # Larger cap keeps more, oldest-first, still dropping the oldest.
      kept = LavinMQ::AMQP::ConsumerOffsets.trim_to_size(tracked_offsets, max_size: 45_i64)
      kept.map(&.first).should eq ["middle", "newest"]
    end

    it "runs cleanup when removing segment" do
      consumer_tag = "ctag-1"
      queue_name = Random::Secure.hex
      args = {"x-queue-type": "stream", "x-max-length": 1}
      msg_body = Bytes.new(LavinMQ::Config.instance.segment_size)

      with_amqp_server do |s|
        data_dir = File.join(s.vhosts["/"].data_dir, Digest::SHA1.hexdigest queue_name)

        with_channel(s) do |ch|
          q = ch.queue(queue_name, args: AMQP::Client::Arguments.new(args))
          q.publish_confirm msg_body
        end

        with_channel(s) do |ch|
          ch.prefetch 1
          q = ch.queue(queue_name, args: AMQP::Client::Arguments.new(args))
          msgs = Channel(AMQP::Client::DeliverMessage).new
          q.subscribe(no_ack: false, tag: consumer_tag) do |msg|
            msgs.send msg
            msg.ack
          end
          msgs.receive
        end

        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        msg_store.last_offset_by_consumer_tag(consumer_tag).should eq 2

        with_channel(s) do |ch|
          q = ch.queue(queue_name, args: AMQP::Client::Arguments.new(args))
          # Retention keeps max-length messages, so offset 2 only falls out
          # of the stream once three more segments have been written
          3.times { q.publish_confirm msg_body }
        end

        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        msg_store.last_offset_by_consumer_tag(consumer_tag).should be_nil
      end
    end

    it "does not track offset if c-tag is auto-generated" do
      queue_name = Random::Secure.hex

      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 1)
        args = {"x-queue-type": "stream"}
        c_tag = ""
        with_channel(s) do |ch|
          ch.prefetch 1
          q = ch.queue(queue_name, args: AMQP::Client::Arguments.new(args))
          msgs = Channel(AMQP::Client::DeliverMessage).new
          c_tag = q.subscribe(no_ack: false) do |msg|
            msgs.send msg
            msg.ack
          end
          msgs.receive
        end

        sleep 0.1.seconds
        data_dir = File.join(s.vhosts["/"].data_dir, Digest::SHA1.hexdigest queue_name)
        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        msg_store.last_offset_by_consumer_tag(c_tag).should be_nil
      end
    end

    it "expands consumer offset file when needed" do
      queue_name = Random::Secure.hex
      consumer_tag_prefix = Random::Secure.hex(32)
      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 1)
        data_dir = File.join(s.vhosts["/"].data_dir, Digest::SHA1.hexdigest queue_name)
        msg_store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        one_offset_bytesize = "#{consumer_tag_prefix}1000".bytesize + 1 + 8
        offsets = (LavinMQ::Config.instance.segment_size / one_offset_bytesize).to_i32 + 1
        bytesize = 0
        offsets.times do |i|
          consumer_tag = "#{consumer_tag_prefix}#{i + 1000}"
          msg_store.store_consumer_offset(consumer_tag, i + 1000)
          bytesize += consumer_tag.bytesize + 1 + 8
        end
        msg_store.@consumer_offsets.size.should eq bytesize
        msg_store.@consumer_offsets.size.should be > LavinMQ::Config.instance.segment_size
        offsets.times do |i|
          msg_store.last_offset_by_consumer_tag("#{consumer_tag_prefix}#{i + 1000}").should eq i + 1000
        end
      end
    end
  end

  describe "Restarting stream" do
    queue_name = Random::Secure.hex
    it "should restart a closed stream" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.prefetch 1
          args = {"x-queue-type": "stream"}
          q = ch.queue(queue_name, args: AMQP::Client::Arguments.new(args))
          stream = s.vhosts["/"].queue(queue_name).as(LavinMQ::AMQP::Stream)
          q.publish_confirm "test message"
          stream.message_count.should eq 1

          # Close the stream
          stream.close
          stream.closed?.should be_true

          # Restart the stream & verify
          stream.restart!
          stream.closed?.should be_false
          stream.message_count.should eq 1

          msgs = Channel(AMQP::Client::DeliverMessage).new
          q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": 0})) do |msg|
            msgs.send msg
            msg.ack
          end
          if msg = msgs.receive
            msg.body_io.to_s.should eq "test message"
          else
            fail("Did not receive message after stream restart")
          end
        end
      end
    end

    it "should resume consuming from the correct position after a restart" do
      queue_name = Random::Secure.hex
      consumer_tag = Random::Secure.hex
      c_args = AMQP::Client::Arguments.new({"x-stream-offset": 0, "x-stream-automatic-offset-tracking": "true"})

      with_amqp_server do |s|
        StreamSpecHelpers.publish(s, queue_name, 2)

        # tracks offset
        msg = StreamSpecHelpers.consume_one(s, queue_name, consumer_tag, c_args)
        StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq 1

        stream = s.vhosts["/"].queue(queue_name).as(LavinMQ::AMQP::Stream)
        stream.close
        stream.closed?.should be_true
        stream.restart!
        stream.closed?.should be_false

        # should continue from tracked offset
        msg = StreamSpecHelpers.consume_one(s, queue_name, consumer_tag, c_args)
        StreamSpecHelpers.offset_from_headers(msg.properties.headers).should eq 2
      end
    end

    it "loads when trailing segment has only the 4-byte schema header" do
      with_datadir do |data_dir|
        # Push 2 large msgs so segment 1 fills and segment 2 is opened.
        store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        msg_size = LavinMQ::Config.instance.segment_size.to_u64 - (LavinMQ::BytesMessage::MIN_BYTESIZE + 5)
        msg = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k",
          AMQ::Protocol::Properties.new, msg_size, IO::Memory.new("a" * msg_size))
        2.times { store.push(msg) }
        store.@segments.size.should be >= 2
        last_seg_path = store.@segments.last_value.path
        store.close

        # Simulate "killed after open_new_segment but before first message":
        # truncate the trailing segment to its 4-byte schema header and remove
        # its meta file so produce_metadata runs on reload.
        File.open(last_seg_path, "r+", &.truncate(4))
        meta_path = last_seg_path.sub("msgs.", "meta.")
        File.delete(meta_path) if File.exists?(meta_path)

        # Reload must not raise IndexError on the empty trailing segment.
        store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        last_seg_id = store.@segments.last_key
        store.@segment_msg_count[last_seg_id].should eq 0
        store.push(msg) # the trailing segment should still be writable
        store.@segment_msg_count[last_seg_id].should eq 1
        store.close
      end
    end

    it "loads when the trailing record is torn mid-body" do
      with_datadir do |data_dir|
        store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        body = "a stream message"
        msg = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k",
          AMQ::Protocol::Properties.new, body.bytesize.to_u64, IO::Memory.new(body))
        store.push(msg)
        torn_pos = store.push(msg).position
        seg_path = store.@segments.last_value.path
        store.close

        # Cut the last few body bytes of the final record, and remove the meta
        # file so produce_metadata has to rebuild the segment metadata.
        File.open(seg_path, "r+") { |f| f.truncate(f.size - 3) }
        meta_path = seg_path.sub("msgs.", "meta.")
        File.delete(meta_path) if File.exists?(meta_path)

        store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        store.@size.should eq 1
        store.@segments.last_value.size.should eq torn_pos
        store.close
      end
    end

    it "appends after a torn trailing record was dropped" do
      with_datadir do |data_dir|
        store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        body = "a stream message"
        msg = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k",
          AMQ::Protocol::Properties.new, body.bytesize.to_u64, IO::Memory.new(body))
        store.push(msg)
        torn_pos = store.push(msg).position
        seg_path = store.@segments.last_value.path
        store.close

        File.open(seg_path, "r+") { |f| f.truncate(f.size - 3) }
        meta_path = seg_path.sub("msgs.", "meta.")
        File.delete(meta_path) if File.exists?(meta_path)

        store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        seg_id = store.@segments.last_key
        store.push(msg).position.should eq torn_pos
        store.close

        store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        store.@size.should eq 2
        env = store.read(seg_id, torn_pos)
        env.should_not be_nil
        String.new(env.not_nil!.message.body).should eq body
        store.close
      end
    end
  end

  describe "max-age loop" do
    it "drops expired segments without any new publishes", tags: "slow" do
      queue_name = Random::Secure.hex
      data = Bytes.new(LavinMQ::Config.instance.segment_size)
      with_amqp_server do |s|
        with_channel(s) do |ch|
          args = {"x-queue-type": "stream", "x-max-age": "1s"}
          q = ch.queue(queue_name, args: AMQP::Client::Arguments.new(args))
          2.times { q.publish_confirm data }
        end
        stream = s.vhosts["/"].queue(queue_name).as(LavinMQ::AMQP::Stream)
        stream.message_count.should eq 2
        wait_for(3.seconds) { stream.message_count == 1 }
      end
    end

    it "only runs for streams with max-age" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.queue("no-max-age", args: stream_queue_args)
          ch.queue("with-max-age", args: AMQP::Client::Arguments.new({"x-queue-type": "stream", "x-max-age": "1h"}))
        end
        s.vhosts["/"].queue("no-max-age").as(LavinMQ::AMQP::Stream).@max_age_loop_running.should be_false
        s.vhosts["/"].queue("with-max-age").as(LavinMQ::AMQP::Stream).@max_age_loop_running.should be_true
      end
    end

    it "starts with a max-age policy and stops when it is removed" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.queue("max-age-policy-loop", args: stream_queue_args)
        end
        stream = s.vhosts["/"].queue("max-age-policy-loop").as(LavinMQ::AMQP::Stream)
        stream.@max_age_loop_running.should be_false
        s.vhosts["/"].add_policy("ma", "max-age-policy-loop", "queues", {"max-age" => JSON::Any.new("1h")}, 0i8)
        wait_for { stream.@max_age_loop_running }
        s.vhosts["/"].delete_policy("ma")
        wait_for { !stream.@max_age_loop_running }
      end
    end

    it "stops when the stream is closed" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          ch.queue("max-age-close", args: AMQP::Client::Arguments.new({"x-queue-type": "stream", "x-max-age": "1h"}))
        end
        stream = s.vhosts["/"].queue("max-age-close").as(LavinMQ::AMQP::Stream)
        stream.@max_age_loop_running.should be_true
        stream.close
        wait_for { !stream.@max_age_loop_running }
      end
    end

    it "store's unmap_if_unused is a no-op after the store is closed instead of raising" do
      # Regression: MessageStore#close closes each segment's MFile but leaves
      # them in @segments, so an unmap that runs after the store closed used
      # to hit mfile.dontneed -> IO::Error: Closed mfile.
      with_datadir do |data_dir|
        store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        msg_size = LavinMQ::Config.instance.segment_size.to_u64 - (LavinMQ::BytesMessage::MIN_BYTESIZE + 5)
        msg = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k",
          AMQ::Protocol::Properties.new, msg_size, IO::Memory.new("a" * msg_size))
        2.times { store.push(msg) }
        store.@segments.size.should be >= 2
        store.close

        store.unmap_if_unused(store.@segments.first_key)
      end
    end
  end

  describe "length retention" do
    {
      {"x-max-length", 2},
      {"x-max-length-bytes", 200},
    }.each do |arg, limit|
      it "#{arg} keeps a segment if dropping it would go below the limit" do
        queue_name = Random::Secure.hex
        with_amqp_server do |s|
          with_channel(s) do |ch|
            args = {"x-queue-type" => "stream", arg => limit}
            q = ch.queue(queue_name, args: AMQP::Client::Arguments.new(args))
            6.times { q.publish_confirm Bytes.new(50) }
            # Opens a new segment, the first one holds all 6 small messages
            q.publish_confirm Bytes.new(LavinMQ::Config.instance.segment_size)
          end
          stream = s.vhosts["/"].queue(queue_name).as(LavinMQ::AMQP::Stream)
          stream.stream_msg_store.@segments.size.should eq 2
          stream.message_count.should eq 7
        end
      end

      it "#{arg} drops old segments on rollover once newer ones meet the limit" do
        queue_name = Random::Secure.hex
        data = Bytes.new(LavinMQ::Config.instance.segment_size // 4)
        with_amqp_server do |s|
          with_channel(s) do |ch|
            args = {"x-queue-type" => "stream", arg => limit}
            q = ch.queue(queue_name, args: AMQP::Client::Arguments.new(args))
            20.times { q.publish_confirm data }
          end
          stream = s.vhosts["/"].queue(queue_name).as(LavinMQ::AMQP::Stream)
          store = stream.stream_msg_store
          store.@segments.first_key.should be > 1
          if arg == "x-max-length"
            stream.message_count.should be >= limit
          else
            store.bytesize.should be >= limit
          end
        end
      end
    end
  end

  describe "ack files" do
    it "deletes leftover ack files and counts every message on load" do
      with_datadir do |data_dir|
        store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        msg = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k",
          AMQ::Protocol::Properties.new, 1u64, IO::Memory.new("a"))
        3.times { store.push(msg) }
        store.close

        ack_path = File.join(data_dir, "acks.0000000001")
        File.open(ack_path, "w") do |f|
          f.write_bytes 4u32
          f.write_bytes 4u32 + LavinMQ::BytesMessage::MIN_BYTESIZE + 1
        end

        store = LavinMQ::AMQP::StreamMessageStore.new(data_dir, nil)
        File.exists?(ack_path).should be_false
        store.size.should eq 3
        store.close
      end
    end
  end

  {% if flag?(:linux) %}
    describe "requeued redeliveries" do
      it "keeps an older segment mapped until its last requeued message is redelivered" do
        queue_name = Random::Secure.hex
        # Two messages per segment
        data = Bytes.new(LavinMQ::Config.instance.segment_size // 3)
        with_amqp_server do |s|
          with_channel(s) do |ch|
            q = ch.queue(queue_name, args: stream_queue_args)
            6.times { q.publish_confirm data }
            stream = s.vhosts["/"].queue(queue_name).as(LavinMQ::AMQP::Stream)
            store = stream.stream_msg_store
            first_seg, first = store.@segments.first

            ch.prefetch 10
            msgs = Channel(AMQP::Client::DeliverMessage).new(10)
            q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": "first"})) do |msg|
              msgs.send msg
            end
            6.times { msgs.receive.ack }
            consumer = stream.@consumers.first.as(LavinMQ::AMQP::StreamConsumer)
            wait_for { consumer.segment != first_seg }
            # Stop the deliver loop so the spec drives the redeliveries
            ch.flow(false)

            sp1 = store.read(first_seg, 4u32).not_nil!.segment_position
            sp2 = store.read(first_seg, 4u32 + sp1.bytesize).not_nil!.segment_position
            consumer.requeued.push(sp1)
            consumer.requeued.push(sp2)

            stream.@msg_store_lock.synchronize { store.shift?(consumer) }
            StreamSpecHelpers.mapped_rss_kb(first.path).should be > 0
            stream.@msg_store_lock.synchronize { store.shift?(consumer) }
            StreamSpecHelpers.mapped_rss_kb(first.path).should eq 0
          end
        end
      end
    end

    describe "segment rollover" do
      it "unmaps the first segment when the stream has no consumers" do
        queue_name = Random::Secure.hex
        data = Bytes.new(LavinMQ::Config.instance.segment_size * 3 // 4)
        with_amqp_server do |s|
          with_channel(s) do |ch|
            q = ch.queue(queue_name, args: stream_queue_args)
            2.times { q.publish_confirm data }
          end
          stream = s.vhosts["/"].queue(queue_name).as(LavinMQ::AMQP::Stream)
          first = stream.stream_msg_store.@segments.first_value
          StreamSpecHelpers.mapped_rss_kb(first.path).should eq 0
        end
      end
    end
  {% end %}

  describe "segment readers" do
    it "tracks which segment each consumer is reading and releases on cancel" do
      queue_name = Random::Secure.hex
      data = Bytes.new(LavinMQ::Config.instance.segment_size // 2)
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue(queue_name, args: stream_queue_args)
          3.times { q.publish_confirm data }
          stream = s.vhosts["/"].queue(queue_name).as(LavinMQ::AMQP::Stream)
          store = stream.stream_msg_store
          last_seg = store.@segments.last_key

          ch.prefetch 1
          msgs = Channel(AMQP::Client::DeliverMessage).new
          tag = q.subscribe(no_ack: false, args: AMQP::Client::Arguments.new({"x-stream-offset": "first"})) do |msg|
            msgs.send msg
          end
          3.times { msgs.receive.ack }
          wait_for { store.@segment_readers == {last_seg => 1u32} }

          q.unsubscribe(tag)
          wait_for { store.@segment_readers.empty? }
        end
      end
    end

    it "keeps the count for consumers still in a shared segment" do
      queue_name = Random::Secure.hex
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue(queue_name, args: stream_queue_args)
          q.publish_confirm "m"
          stream = s.vhosts["/"].queue(queue_name).as(LavinMQ::AMQP::Stream)
          store = stream.stream_msg_store
          seg = store.@segments.first_key

          ch.prefetch 1
          args = AMQP::Client::Arguments.new({"x-stream-offset": "first"})
          tag1 = q.subscribe(no_ack: false, args: args, &.ack)
          q.subscribe(no_ack: false, args: args, &.ack)
          wait_for { store.@segment_readers == {seg => 2u32} }

          q.unsubscribe(tag1)
          wait_for { store.@segment_readers == {seg => 1u32} }
        end
      end
    end
  end
end
