import * as helpers from './helpers.js'
import { test, expect } from './fixtures.js'

test.describe('overview', _ => {
  test('is loaded', async ({ page }) => {
    const apiOverviewRequest = helpers.waitForPathRequest(page, '/api/overview')
    await page.goto('/')
    await expect(apiOverviewRequest).toBeRequested()
  })

  test('is refreshed automatically', async ({ page }) => {
    await page.clock.install()
    await page.goto('/')
    // Verify that at least 3 requests are made
    for (let i = 0; i < 3; i++) {
      const apiOverviewRequest = helpers.waitForPathRequest(page, '/api/overview')
      await page.clock.runFor(10000) // advance time by 10 seconds
      await expect(apiOverviewRequest).toBeRequested()
    }
  })

  test('legend click isolates a series', async ({ page }) => {
    await page.goto('/')
    const items = page.locator('#msgChart .u-legend-item')
    await expect(items).toHaveCount(2)

    await items.nth(0).click()
    await expect(items.nth(1)).toHaveClass(/u-legend-hidden/)
    await expect(items.nth(0)).not.toHaveClass(/u-legend-hidden/)

    await items.nth(0).click()
    await expect(items.nth(1)).not.toHaveClass(/u-legend-hidden/)
  })

  // Shift and Meta (cmd) are the macOS multi-select conventions.
  for (const modifier of ['Shift', 'Meta']) {
    test(`${modifier}-click toggles a single series without isolating`, async ({ page }) => {
      await page.goto('/')
      const items = page.locator('#msgChart .u-legend-item')
      await expect(items).toHaveCount(2)

      await items.nth(1).click({ modifiers: [modifier] })
      await expect(items.nth(1)).toHaveClass(/u-legend-hidden/)
      await expect(items.nth(0)).not.toHaveClass(/u-legend-hidden/)

      await items.nth(1).click({ modifiers: [modifier] })
      await expect(items.nth(1)).not.toHaveClass(/u-legend-hidden/)
      await expect(items.nth(0)).not.toHaveClass(/u-legend-hidden/)
    })
  }

  // ctrlKey is the Windows and Linux multi-select convention. It is asserted
  // by dispatching the event rather than driving real input, because macOS
  // turns a real ctrl+click into a context-menu gesture and the extra events
  // that produces are an input-layer artifact, not the binding under test.
  test('ctrlKey on a legend click toggles a single series without isolating', async ({ page }) => {
    await page.goto('/')
    const items = page.locator('#msgChart .u-legend-item')
    await expect(items).toHaveCount(2)

    const ctrlClickSecond = () => page.evaluate(() => {
      document.querySelectorAll('#msgChart .u-legend-item')[1]
        .dispatchEvent(new MouseEvent('click', { bubbles: true, ctrlKey: true }))
    })

    await ctrlClickSecond()
    await expect(items.nth(1)).toHaveClass(/u-legend-hidden/)
    await expect(items.nth(0)).not.toHaveClass(/u-legend-hidden/)

    await ctrlClickSecond()
    await expect(items.nth(1)).not.toHaveClass(/u-legend-hidden/)
    await expect(items.nth(0)).not.toHaveClass(/u-legend-hidden/)
  })

  test('hovering one chart moves the cursor and legend of every chart', async ({ page }) => {
    // Enough samples that a point at 40% across is not the newest one, so a
    // synced legend is distinguishable from one showing its own live value.
    const ramp = (step) => Array.from({ length: 30 }, (_, i) => (i + 1) * step)
    await page.route(/\/api\/overview(\?|$)/, async route => {
      const response = await route.fetch()
      const body = await response.json()
      body.queue_totals = {
        ...body.queue_totals,
        messages_ready: 300,
        messages_unacknowledged: 30,
        messages_ready_log: ramp(10),
        messages_unacknowledged_log: ramp(1)
      }
      body.send_oct_details = { rate: 3000, log: ramp(100) }
      body.recv_oct_details = { rate: 6000, log: ramp(200) }
      // Replace message_stats wholesale so every chart spans the same number of
      // samples; with differing ranges a synced x value can land outside a
      // chart and its cursor is suppressed.
      body.message_stats = {
        publish: 900,
        publish_details: { rate: 30, log: ramp(3) },
        deliver: 600,
        deliver_details: { rate: 20, log: ramp(2) }
      }
      await route.fulfill({ response, json: body })
    })
    // A frozen clock stops polling, which would otherwise re-time every sample
    // between reading one legend and comparing it with the others.
    await page.clock.install()
    await page.goto('/')

    const ids = ['msgChart', 'dataChart', 'rateChart']
    const legendTime = (id) => page.locator(`section.card:has(#${id}) .u-legend-time`)
    const cursor = (id) => page.locator(`#${id} .u-cursor-x`)
    for (const id of ids) await expect(legendTime(id)).toHaveText(/^\d{2}:\d{2}:\d{2}$/)
    const live = (await legendTime('rateChart').textContent()).trim()

    // hover() scrolls the plot into view first; page.mouse.move does not, and a
    // move to coordinates below the fold silently never enters the chart
    const plot = page.locator('#rateChart .u-over')
    const box = await plot.boundingBox()
    await plot.hover({ position: { x: box.width * 0.4, y: box.height / 2 } })

    await expect(legendTime('rateChart')).not.toHaveText(live)
    const hovered = (await legendTime('rateChart').textContent()).trim()
    for (const id of ids) {
      await expect(cursor(id)).toHaveCSS('display', 'block')
      await expect(legendTime(id)).toHaveText(hovered)
    }

    // leaving the plot returns every chart to its live value together
    await page.mouse.move(0, 0)
    for (const id of ids) await expect(cursor(id)).toHaveCSS('display', 'none')
    for (const id of ids) await expect(legendTime(id)).toHaveText(live)
  })

  test('chart timestamp shows the latest sample and the pause state', async ({ page }) => {
    await page.goto('/')
    const legendTime = page.locator('.u-legend-time').first()
    await expect(legendTime).toHaveText(/^\d{2}:\d{2}:\d{2}$/)
    await page.locator('#refresh-toggle').click()
    await expect(legendTime).toContainText('Paused at')
    await page.locator('#refresh-toggle').click()
    await expect(legendTime).toHaveText(/^\d{2}:\d{2}:\d{2}$/)
  })

  function yAxisTicks (page, unit, log) {
    return page.evaluate(async ({ url, unit, log }) => {
      const Chart = await import(url)
      const el = document.createElement('div')
      el.id = 'axisChart'
      el.style.width = '1400px'
      document.body.append(el)
      const chart = Chart.render(el.id, unit)
      Chart.update(chart, [{ key: 'value', value: log.at(-1), log }])
      await new Promise(resolve => window.requestAnimationFrame(resolve))
      const axis = chart.uplot.axes[1]
      return { splits: axis._splits, labels: axis._values }
    }, { url: '/js/chart.js', unit, log })
  }

  const LABEL_SCALES = { K: 1e3, M: 1e6, G: 1e9, KiB: 1024, MiB: 1024 ** 2, GiB: 1024 ** 3 }

  function parseLabel (label) {
    const [, digits, scale] = label.match(/^([\d.,]+)\s*(\w*)/)
    return Number(digits.replace(/,/g, '')) * (LABEL_SCALES[scale] ?? 1)
  }

  for (const [unit, value] of [['msgs/s', 0.2], ['msgs/s', 1400], ['bytes/s', 0.2], ['bytes/s', 1.4 * 1024 ** 2]]) {
    test(`y axis labels name their tick values exactly at ${value} ${unit}`, async ({ page }) => {
      await page.goto('/')
      const { splits, labels } = await yAxisTicks(page, unit, [value, value])
      expect(splits.length).toBeGreaterThan(2)
      expect(labels.map(parseLabel)).toEqual(splits.map(v => Number(v.toPrecision(12))))
    })
  }

  test('y axis ticks of message counts are whole numbers', async ({ page }) => {
    await page.goto('/')
    const { splits } = await yAxisTicks(page, 'msgs', [1, 1])
    expect(splits.filter(v => !Number.isInteger(v))).toEqual([])
  })

  test('y axis shrinks after five polls below the range, not five redraws', async ({ page }) => {
    await page.goto('/')
    const maxes = await page.evaluate(async url => {
      const { stableMax } = await import(url)
      const handle = { scaleMax: 0, shrinkCount: 0, poll: 1 }
      stableMax(handle, 1000)
      const seen = []
      for (let poll = 2; poll <= 6; poll++) {
        handle.poll = poll
        for (let redraw = 0; redraw < 3; redraw++) seen.push(stableMax(handle, 100))
      }
      return seen
    }, '/js/chart.js')
    expect(maxes).toEqual([...new Array(12).fill(1000), 100, 100, 100])
  })

  // Chromium on Linux reports e.g. 'en-US@posix' when started without LANG
  for (const language of ['en-US@posix', 'C']) {
    test(`renders charts when navigator.language is '${language}'`, async ({ page }) => {
      await page.addInitScript(language => {
        Object.defineProperty(Navigator.prototype, 'language', { get: () => language })
      }, language)
      const errors = []
      page.on('pageerror', error => errors.push(error.message))
      await page.goto('/')
      await expect(page.locator('#msgChart .u-legend-item')).toHaveCount(2)
      expect(errors).toEqual([])
    })
  }

  test('definitions export trigger GET to /api/definitions for all vhosts', async ({ page }) => {
    const definitionsRequest = helpers.waitForPathRequest(page, '/api/definitions')
    await page.goto('/')
    await page.locator('#exportDefinitions').getByRole('button', { name: /download/i }).click()
    await expect(definitionsRequest).toBeRequested()
  })

  test('definitions export trigger GET to /api/definitions/<selected vhost>', async ({ page, vhostsLoaded }) => {
    await page.goto('/')
    const vhosts = await vhostsLoaded
    const definitionsRequest = helpers.waitForPathRequest(page, `/api/definitions/${vhosts[0]}`)
    await page.locator('#exportDefinitions').getByRole('combobox').selectOption(vhosts[0])
    await page.locator('#exportDefinitions').getByRole('button', { name: /download/i }).click()
    await expect(definitionsRequest).toBeRequested()
  })

  test('definitions import trigger POST to /api/definitions/upload', async ({ page }) => {
    const definitionsRequest = helpers.waitForPathRequest(page, '/api/definitions/upload', { method: 'POST' })
    await page.goto('/')

    const importDefs = page.locator('#importDefinitions')
    const fileChooserPromise = page.waitForEvent('filechooser')
    await importDefs.getByLabel('File').click()
    const fileChooser = await fileChooserPromise
    await fileChooser.setFiles({ name: 'definitions.json', buffer: Buffer.from('{}') })
    await importDefs.getByRole('button', { name: /upload/i }).click()

    await expect(definitionsRequest).toBeRequested()
  })
})
