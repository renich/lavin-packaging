require "../../amqp"
require "../binding_key"
require "../binding_details"
require "../destination"
require "../../error"
require "../../exchange"
require "../../observable"
require "../../policy"
require "../../stats"
require "../../sortable_json"
require "../queue"
require "./event"

module LavinMQ
  module AMQP
    abstract class Exchange < LavinMQ::Exchange
      include PolicyTarget
      include Stats
      include SortableJSON
      include Observable(ExchangeEvent)

      getter name, arguments, vhost, type, alternate_exchange
      getter? durable, internal, auto_delete
      getter? delayed = false

      @alternate_exchange : String?
      @delayed_queue : DelayedExchangeQueue?
      @deleted = false
      @deduper : Deduplication::Deduper?
      @effective_args = Array(String).new

      rate_stats({"publish_in", "publish_out", "unroutable", "dedup"})

      def initialize(@vhost : VHost, @name : String, @durable = false,
                     @auto_delete = false, @internal = false,
                     @arguments = AMQP::Table.new)
        handle_arguments
      end

      private def apply_policy_argument(key : String, value : JSON::Any) : Bool
        case key
        when "alternate-exchange"
          if @alternate_exchange.nil?
            @alternate_exchange = value.as_s?
            @effective_args.delete("x-alternate-exchange")
            @effective_args.delete("alternate-exchange")
            return true
          end
        when "delayed-message"
          if value.as?(Bool) == true
            @effective_args.delete("x-delayed-message")
            @delayed = true
            init_delayed_queue
            return true
          end
        when "federation-upstream"
          @vhost.upstreams.try &.link(value.as_s, self) unless internal?
          return true
        when "federation-upstream-set"
          @vhost.upstreams.try &.link_set(value.as_s, self) unless internal?
          return true
        end
        false
      end

      private def clear_policy_arguments
        handle_arguments
        @vhost.upstreams.try &.stop_link(self)
      end

      def handle_arguments
        @effective_args = Array(String).new
        if @alternate_exchange = @arguments["x-alternate-exchange"]?.try &.to_s
          @effective_args << "x-alternate-exchange"
        elsif @alternate_exchange = @arguments["alternate-exchange"]?.try &.to_s
          @effective_args << "alternate-exchange"
        end
        if @arguments["x-delayed-exchange"]?.try &.as?(Bool)
          @delayed = true
          init_delayed_queue
          @effective_args << "x-delayed-exchange"
        end
        if @arguments["x-message-deduplication"]?.try(&.as?(Bool))
          @effective_args << "x-message-deduplication"
          ttl = parse_header("x-cache-ttl", Int).try(&.to_u32)
          @effective_args << "x-cache-ttl" if ttl
          size = parse_header("x-cache-size", Int).try(&.to_u32)
          @effective_args << "x-cache-size" if size
          header_key = parse_header("x-deduplication-header", String)
          @effective_args << "x-deduplication-header" if header_key
          @deduper ||= begin
            cache = Deduplication::MemoryCache(AMQ::Protocol::Field).new(size)
            Deduplication::Deduper.new(cache, ttl, header_key)
          end
        end
      end

      private macro parse_header(header, type)
        if value = @arguments["{{ header.id }}"]?
          value.as?({{ type }}) || raise LavinMQ::Error::PreconditionFailed.new("{{ header.id }} header not a {{ type.id }}")
        end
      end

      def details_tuple
        {
          name: @name, type: type, durable: @durable, auto_delete: @auto_delete,
          internal: @internal, arguments: @arguments, vhost: @vhost.name,
          policy: policy.try &.name,
          operator_policy: operator_policy.try &.name,
          effective_policy_definition: Policy.merge_definitions(policy, operator_policy),
          message_stats: current_stats_details,
          effective_arguments: @effective_args,
        }
      end

      def match?(frame : AMQP::Frame)
        match?(frame.exchange_type, frame.durable, frame.auto_delete, frame.internal, frame.arguments)
      end

      def match?(type, durable, auto_delete, internal, arguments)
        delayed = type == "x-delayed-message"
        frame_args = arguments
        if delayed
          frame_args = frame_args.clone.merge!({"x-delayed-exchange": true})
          frame_args.delete("x-delayed-type")
        end
        self.type == (delayed ? arguments["x-delayed-type"]? : type) &&
          @durable == durable &&
          @auto_delete == auto_delete &&
          @internal == internal &&
          @arguments == frame_args
      end

      def in_use?
        return true unless bindings_details.empty?
        @vhost.exchanges_any? do |_, x|
          x.bindings_details.any? { |bd| bd.destination == self }
        end
      end

      private def init_delayed_queue
        return if @delayed_queue
        return unless @delayed

        @delayed_queue = queue = AMQP::DelayedExchangeQueue.create(@vhost, @name, durable: durable?, auto_delete: @auto_delete)

        @vhost.register_queue(queue)
      end

      REPUBLISH_HEADERS = {"x-head", "x-tail", "x-from"}

      protected def delete
        return if @deleted
        @deleted = true
        @delayed_queue.try &.delete
        @vhost.delete_exchange(@name)
        notify_observers(ExchangeEvent::Deleted)
      end

      # This outer macro will add a finished macro hook to all inherited classes
      # in LavinMQ::AMQP namespace.
      macro inherited
        {% if @type.name.starts_with?("LavinMQ::AMQP::") %}
          # This macro will find the "bind" method of classes inheriting from this class
          # and redefine them to raise AccessRefused exception if the first argument
          # isn't a type in LavinMQ::AMQP namespace.
          #
          # TODO remove this when LavinMQ::MQTT::Session no longer inherit from
          # LavinMQ::AMQP::Queue and LavinMQ::MQTT::Exchange no longer inherit from
          # lavinMQ::AMQP::Exchange
        macro finished
          \{% if (m = @type.methods.find(&.name.== "bind"))  %}
            def bind(\{{ m.args.map(&.id).join(",").id}}) : Bool
              unless \{{m.args[0].name.id}}.class.name.starts_with?("LavinMQ::AMQP::")
                raise AccessRefused.new(self)
              end
              \{{ m.body }}
          end
         \{% end %}
        end
        {% end %}
      end

      def bind(destination : LavinMQ::Destination, routing_key, arguments = nil) : Bool
        raise AccessRefused.new(self)
      end

      def unbind(destination : LavinMQ::Destination, routing_key, arguments = nil) : Bool
        raise AccessRefused.new(self)
      end

      protected def validate_delayed_binding!(destination : AMQP::Destination) : Bool
        return true unless delayed?
        if destination == @delayed_queue
          raise LavinMQ::Error::PreconditionFailed.new("Cannot bind delayed exchange '#{@name}' to its internal delayed queue '#{destination.name}'")
        end
        true
      end

      abstract def type : String
      abstract def bind(destination : AMQP::Destination, routing_key : String, arguments : AMQP::Table?)
      abstract def unbind(destination : AMQP::Destination, routing_key : String, arguments : AMQP::Table?)
      # No return-type restriction: AMQP exchanges return `Array(AMQP::BindingDetails)`
      # while `MQTT::Exchange` overrides this to return `Array(MQTT::SubscriptionDetails)`.
      abstract def bindings_details
      abstract def each_destination(routing_key : String, headers : AMQP::Table?, & : LavinMQ::Destination ->)

      # Number of bindings on this exchange. Counted cheaply, without allocating
      # the full `bindings_details` array.
      abstract def binding_count : Int32

      # Result of routing a message through an exchange.
      # `Routed` is set if at least one queue accepted the message.
      # `Overflowed` is set if at least one matched queue rejected the message
      # due to a reject-publish overflow policy. The two flags are independent:
      # a publish can be both routed (one queue accepted) and overflowed
      # (another queue rejected), in which case the publisher should still be
      # nack'ed on confirm channels.
      @[Flags]
      enum PublishResult
        Routed
        Overflowed
      end

      def publish(msg : Message, immediate : Bool,
                  queues : Set(AMQP::Queue) = Set(AMQP::Queue).new,
                  exchanges : Set(LavinMQ::Exchange) = Set(LavinMQ::Exchange).new) : PublishResult
        @publish_in_count.add(1, :relaxed)
        if d = @deduper
          if d.duplicate?(msg)
            @dedup_count.add(1, :relaxed)
            return PublishResult::None
          end
          d.add(msg)
        end
        if should_delay_message?(msg.properties.headers)
          if q = @delayed_queue
            q.delay(msg)
            @publish_out_count.add(1, :relaxed)
            return PublishResult::Routed
          else
            @unroutable_count.add(1, :relaxed)
            return PublishResult::None
          end
        end
        route_msg(msg, immediate, queues, exchanges)
      end

      def route_msg(msg : Message) : PublishResult
        route_msg(msg, false, Set(AMQP::Queue).new, Set(LavinMQ::Exchange).new)
      end

      private def route_msg(msg : Message, immediate : Bool, queues : Set(AMQP::Queue), exchanges : Set(LavinMQ::Exchange)) : PublishResult
        headers = msg.properties.headers
        find_queues(msg.routing_key, headers, queues, exchanges)
        if queues.empty? || (immediate && !queues.any? &.immediate_delivery?)
          @unroutable_count.add(1, :relaxed)
          return PublishResult::None
        end

        count = 0u32
        overflow = false
        queues.each do |queue|
          case queue.publish(msg)
          in .ok?
            count += 1
            msg.body_io.seek(-msg.bodysize.to_i64, IO::Seek::Current) # rewind
          in .overflow?
            overflow = true
          in .dropped?
            # queue was closed or message was a duplicate; nothing to do
          end
        end
        @publish_out_count.add(count, :relaxed)
        @unroutable_count.add(1, :relaxed) if count.zero? && !overflow

        result = PublishResult::None
        result |= PublishResult::Routed if count.positive?
        result |= PublishResult::Overflowed if overflow
        result
      end

      def find_queues(routing_key : String, headers : AMQP::Table?,
                      queues : Set(AMQP::Queue) = Set(AMQP::Queue).new,
                      exchanges : Set(LavinMQ::Exchange) = Set(LavinMQ::Exchange).new) : Nil
        return unless exchanges.add? self
        each_destination(routing_key, headers) do |d|
          case d
          in AMQP::Queue
            # Prevent routing to own internal delayed queue to avoid infinite loops
            unless delayed? && d == @delayed_queue
              queues.add(d)
            end
          in LavinMQ::Exchange
            d.find_queues(routing_key, headers, queues, exchanges)
          end
        end

        if hdrs = headers
          find_cc_queues(hdrs, "CC", queues)
          find_cc_queues(hdrs, "BCC", queues)
        end

        if queues.empty? && (ae_name = alternate_exchange)
          @vhost.exchange?(ae_name).try do |ae|
            ae.find_queues(routing_key, headers, queues, exchanges)
          end
        end
      end

      private def find_cc_queues(headers, key, queues)
        return unless cc = headers[key]?
        cc = cc.as?(Array(AMQP::Field))

        raise LavinMQ::Error::PreconditionFailed.new("#{key} header not a string array") unless cc

        hdrs = headers.clone
        hdrs.delete "CC"
        hdrs.delete key
        cc.each do |rk|
          if rk = rk.as?(String)
            find_queues(rk, hdrs, queues)
          else
            raise LavinMQ::Error::PreconditionFailed.new("#{key} header not a string array")
          end
        end
      end

      private def should_delay_message?(headers)
        return false if headers.nil? || headers.empty?
        return false unless delayed?
        return false unless q = @delayed_queue
        x_delay = headers["x-delay"]?
        return false unless x_delay
        x_deaths = headers["x-death"]?.try(&.as?(Array(AMQP::Field)))
        x_death = x_deaths.try(&.first).try(&.as?(AMQP::Table))
        return true if x_death.nil?
        q.name != x_death["queue"]?
      end

      def close
        @delayed_queue.try &.close
      end

      def to_json(json : JSON::Builder)
        json.object do
          details_tuple.merge(message_stats: stats_details).each do |k, v|
            json.field(k, v) unless v.nil?
          end
        end
      end
    end
  end
end
