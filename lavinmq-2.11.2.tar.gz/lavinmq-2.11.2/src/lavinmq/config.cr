require "log"
require "uri"
require "option_parser"
require "ini"
require "./version"
require "./log_formatter"
require "./log_backend"
require "./in_memory_backend"
require "./auth/password"
require "./sni_config"
require "./config/options"
require "./filesystem"

module LavinMQ
  class Config
    include Options

    # Raised when the config file can't be parsed or is invalid. Aborts on
    # boot, caught on SIGHUP reload to keep the running config.
    class Error < Exception; end

    @@instance : Config = self.new
    getter sni_manager : SNIManager = SNIManager.new
    @io : IO = STDERR
    @log_backend : LogBackend?

    def self.instance : LavinMQ::Config
      @@instance
    end

    private def initialize(@io : IO = STDERR)
    end

    # Parse configuration from environment, command line arguments and configuration file.
    # Command line arguments take precedence over environment variables,
    # which take precedence over the configuration file.
    def parse(argv = ARGV)
      parse_info_option(argv)
      config_dir = ENV.fetch("LAVINMQ_CONFIGURATION_DIRECTORY") { ENV.fetch("CONFIGURATION_DIRECTORY", "/etc/lavinmq") }
      @config_file = File.exists?(
        File.join(config_dir, "lavinmq.ini")) ? File.join(config_dir, "lavinmq.ini") : ""
      parse_config_from_cli(argv)
      parse_ini(@config_file)
      parse_env()
      parse_cli(argv)
      validate!
      setup_logger
      if (@oauth_mgmt_base_url || @oauth_client_id) && !oauth_mgmt_ui_enabled?
        Log.warn { oauth_mgmt_ui_disabled_reason }
      end
    end

    private def parse_info_option(argv)
      return unless argv.size == 1

      case argv.first
      when "-v", "--version"
        puts LavinMQ::VERSION
        exit 0
      when "--build-info"
        puts LavinMQ::BUILD_INFO
        exit 0
      end
    end

    def oauth_mgmt_ui_enabled? : Bool
      return false unless (base_url = @oauth_mgmt_base_url) && @oauth_client_id && @oauth_issuer_url
      oauth_mgmt_base_url_allowed?(base_url)
    end

    private def oauth_mgmt_base_url_allowed?(uri : URI) : Bool
      return true if uri.scheme == "https"
      return false unless uri.scheme == "http"
      host = uri.host.try(&.downcase)
      {"localhost", "127.0.0.1", "::1", "[::1]"}.includes?(host)
    end

    private def oauth_mgmt_ui_disabled_reason : String
      missing = [] of String
      missing << "oauth.client_id" unless @oauth_client_id
      missing << "oauth.issuer" unless @oauth_issuer_url
      missing << "oauth.mgmt_base_url" unless @oauth_mgmt_base_url
      unless missing.empty?
        return "OAuth management UI SSO not enabled: missing #{missing.join(", ")}"
      end
      "OAuth management UI SSO not enabled: oauth.mgmt_base_url must use https:// or http://{localhost,127.0.0.1,[::1]}"
    end

    protected def validate!
      unless @stats_interval.positive?
        raise Error.new("stats_interval must be positive (got #{@stats_interval})")
      end
      # 0 is not "unlimited": the capacity gate would never open, so every MQTT
      # session would accept publishes and deliver none of them.
      unless @max_inflight_messages.positive?
        raise Error.new("max_inflight_messages must be positive (got #{@max_inflight_messages})")
      end
      # Without it a client that stops reading would block its writers, and
      # closing the connection, forever
      unless @tcp_send_timeout.positive?
        raise Error.new("tcp_send_timeout must be positive (got #{@tcp_send_timeout})")
      end
      unless @clustering_etcd_lease_ttl.positive?
        raise Error.new("clustering etcd_lease_ttl must be positive (got #{@clustering_etcd_lease_ttl})")
      end
      validate_sni_tls!
    end

    # Builds every SNI host's TLS contexts, so an unreadable certificate or
    # key fails startup with a clear error, and is refused on reload with the
    # running configuration kept, instead of failing that host's handshakes
    # later. This is the only place that builds them, so the servername
    # callback always reads contexts that carry the listener's ciphers.
    # Without a TLS listener no SNI host is used, so a bad one only warns.
    private def validate_sni_tls!
      @sni_manager.hosts.each_value { |host| validate_sni_host!(host) }
      @sni_manager.wildcard_hosts.each_value { |host| validate_sni_host!(host) }
    end

    private def validate_sni_host!(host : SNIHost) : Nil
      host.build_tls_contexts(@tls_ciphers, @tls_ciphersuites)
    rescue ex
      raise Error.new("Invalid TLS settings for SNI host '#{host.hostname}': #{ex.message}") if tls_configured?
      @io.puts "WARNING: Invalid TLS settings for SNI host '#{host.hostname}': #{ex.message}"
    end

    private def parse_config_from_cli(argv)
      parser = OptionParser.new
      parser.on("-c CONFIG", "--config=CONFIG", "Path to config file") do |val|
        @config_file = val
      end
      # Silence errors - this is just a pre-parse to extract the config file path.
      # Full argument validation happens later in parse_cli.
      parser.invalid_option { }
      parser.missing_option { }
      parser.parse(argv.dup)
    end

    # Assigns a parsed option value to its property. When `deprecation_message` is
    # present the option is deprecated: the message is printed verbatim and the
    # value is forwarded only if the (getter-less) deprecated property defines a
    # setter. An option with no replacement defines no setter, so its value is
    # dropped after the warning. Shared by `parse_cli` and `parse_section`.
    private macro assign_option(var_name, value, transform, deprecation_message)
      {% if deprecation_message %}
        @io.puts "WARNING: {{ deprecation_message.id }}"
        # Since deprecation_message is set, the variable is deprecated. It may
        # be forwarded to another variable using a setter, but it may also be
        # completley removed, therefore we need to check for a setter.
        {% if @type.has_method?("#{var_name.id}=") %}
          self.{{ var_name.id }} = parse_value({{ value }}, {{ transform }})
        {% end %}
      {% else %}
        self.{{ var_name.id }} = parse_value({{ value }}, {{ transform }})
      {% end %}
    end

    private def parse_env
      {% for ivar in @type.instance_vars.select(&.annotation(EnvOpt)) %}
        {% for ann in ivar.annotations(EnvOpt) %}
          {% env_name, transform = ann.args %}
          if v = ENV.fetch({{ env_name }}, nil)
            @{{ ivar }} = parse_value(v, {{ transform || ivar.type }})
          end
        {% end %}
      {% end %}
    end

    private def parse_cli(argv)
      parser = OptionParser.new
      parser.banner = "Usage: #{PROGRAM_NAME} [arguments]"
      {% begin %}
        sections = {
          options:    {description: "Options", options: Array(Option).new},
          bindings:   {description: "Bindings", options: Array(Option).new},
          tls:        {description: "TLS", options: Array(Option).new},
          clustering: {description: "Clustering", options: Array(Option).new},
        }
        # Build sections structure and populate with CLI options from annotated instance variables
        {% for ivar in @type.instance_vars.select(&.annotation(CliOpt)) %}
          {%
            cli_opt = ivar.annotation(CliOpt)
            # If annotation has exactly 3 args (short_flag, long_flag, description),
            # use ivar.type as value parser. Otherwise, last arg is a custom value parser.
            if cli_opt.args.size == 3
              parser_arg = cli_opt.args
              value_parser = ivar.type
            else
              *parser_arg, value_parser = cli_opt.args
            end
            section_id = cli_opt[:section] || "options"
          %}
          # Create Option object with CLI args and a block that parses and stores the value
          # when the option is encountered during command line parsing
          sections[:{{ section_id }}][:options] << Option.new({{ parser_arg.splat }}) do |value|
            assign_option({{ ivar.name }}, value, {{ value_parser }}, {{ cli_opt[:deprecated] }})
          end
        {% end %}
        sections.each do |_section_id, section|
          parser.separator "\n#{section[:description]}"
          section[:options].sort.each do |opt|
            opt.setup_parser(parser)
          end
        end
      {% end %}
      parser.separator "\nMiscellaneous"
      parser.on("-d", "--debug", "Verbose logging") { @log_level = ::Log::Severity::Debug }
      parser.on("-h", "--help", "Show this help") { puts parser; exit 0 }
      parser.on("-v", "--version", "Show version") { puts LavinMQ::VERSION; exit 0 }
      parser.on("--build-info", "Show build information") { puts LavinMQ::BUILD_INFO; exit 0 }
      parser.parse(argv.dup)
    end

    protected def parse_ini(file)
      return if file.empty?
      raise Error.new("Config could not be found") unless File.file?(file)
      ini = INI.parse(File.read(file))
      {% begin %}
      ini.each do |section, settings|
        case section
        {% for section in INI_SECTIONS %}
        when {{ section }}
          parse_section({{ section }}, settings)
        {% end %}
        when "http"
          @io.puts "WARNING: Config section [http] is deprecated, use [mgmt] instead"
          parse_section("mgmt", settings)
        when .starts_with?("sni:") then parse_sni(section[4..], settings)
        when "replication"
          raise Error.new("#{file}: [replication] is deprecated and replaced with [clustering], see the README for more information")
        else
          raise Error.new("Unknown configuration section: #{section}")
        end
      end
      {% end %}
    rescue ex : ::INI::ParseException
      raise Error.new("Failed to parse config file '#{file}'. " \
                      "Error on line #{ex.line_number}, column #{ex.column_number}")
    rescue ex : IO::Error
      raise Error.new("Could not read config file '#{file}': #{ex.message}")
    end

    # ameba:disable Metrics/CyclomaticComplexity
    private def parse_sni(hostname : String, settings)
      host = @sni_manager.get_exact_host(hostname) || SNIHost.new(hostname)
      settings.each do |config, v|
        case config
        # Default TLS settings
        when "tls_cert"        then host.tls_cert = v
        when "tls_key"         then host.tls_key = v
        when "tls_verify_peer" then host.tls_verify_peer = true?(v)
        when "tls_ca_cert"     then host.tls_ca_cert = v
        when "tls_keylog_file" then host.tls_keylog_file = v
          # AMQP-specific overrides
        when "amqp_tls_cert"        then host.amqp_tls_cert = v
        when "amqp_tls_key"         then host.amqp_tls_key = v
        when "amqp_tls_verify_peer" then host.amqp_tls_verify_peer = true?(v)
        when "amqp_tls_ca_cert"     then host.amqp_tls_ca_cert = v
        when "amqp_tls_keylog_file" then host.amqp_tls_keylog_file = v
          # MQTT-specific overrides
        when "mqtt_tls_cert"        then host.mqtt_tls_cert = v
        when "mqtt_tls_key"         then host.mqtt_tls_key = v
        when "mqtt_tls_verify_peer" then host.mqtt_tls_verify_peer = true?(v)
        when "mqtt_tls_ca_cert"     then host.mqtt_tls_ca_cert = v
        when "mqtt_tls_keylog_file" then host.mqtt_tls_keylog_file = v
          # HTTP-specific overrides
        when "http_tls_cert"        then host.http_tls_cert = v
        when "http_tls_key"         then host.http_tls_key = v
        when "http_tls_verify_peer" then host.http_tls_verify_peer = true?(v)
        when "http_tls_ca_cert"     then host.http_tls_ca_cert = v
        when "http_tls_keylog_file" then host.http_tls_keylog_file = v
        when .ends_with?("tls_min_version"), .ends_with?("tls_ciphers"),
             .ends_with?("tls_ciphersuites"), .ends_with?("tls_prefer_server_ciphers")
          # Removed in 2.11: a per-host tls_min_version never took effect,
          # but TLS 1.2 picks its cipher from the swapped-in context, so
          # per-host cipher settings did apply to TLS 1.2 until 2.10.x
          @io.puts "WARNING: 'sni:#{hostname}/#{config}' is not supported, " \
                   "the listener's TLS version and cipher settings apply to all SNI hosts"
        else
          @io.puts "WARNING: Unrecognized configuration 'sni:#{hostname}/#{config}'"
        end
      end
      if host.tls_cert.empty?
        @io.puts "WARNING: SNI host '#{hostname}' missing required tls_cert"
      else
        @sni_manager.add_host(host)
      end
    end

    private macro parse_section(section, settings)
    {% begin %}
    {%
      ivars_in_section = @type.instance_vars
        # Filter out ivars for given section
        .reject(&.annotation(IniOpt).nil?)
        .select(&.annotation(IniOpt)[:section].== section)
        # This is just to get simpler objects to work with
        .map do |ivar|
          anno = ivar.annotation(IniOpt)
          {
            var_name:   ivar.name,
            ini_name:   anno[:ini_name] || ivar.name,
            transform:  anno[:transform] || ivar.type,
            deprecated: anno[:deprecated],
          }
        end
    %}

    # Generate a case branch for each INI setting in this section. Deprecated
    # settings carry a verbatim warning message and are handled by `assign_option`,
    # which forwards the value to the replacement when a setter exists.
    settings.each do |name, v|
      case name
        {% for var in ivars_in_section %}
          when "{{ var[:ini_name] }}"
            assign_option({{ var[:var_name] }}, v, {{ var[:transform] }}, {{ var[:deprecated] }})
        {% end %}
     else
       @io.puts "WARNING: Unknown setting '#{name}' in section [{{ section.id }}]"
      end
    rescue ex
      raise Error.new("Failed to handle value for '#{name}' in [{{ section.id }}]: #{ex.message}")
    end
  {% end %}
    end

    {% for int in [Int8, Int16, Int32, Int64, UInt8, UInt16, UInt32, UInt64] %}
      private def parse_value(value, type : {{ int }}.class)
        {{ int }}.new(value)
      end

      private def parse_value(value, type : {{ int }}?.class)
        if v = value
          {{ int }}.new(v)
        end
      end
    {% end %}

    private def parse_value(value, type : String.class | String?.class)
      value
    end

    private def parse_value(value, type : Bool.class)
      true?(value)
    end

    private def parse_value(value, type : Proc)
      type.call(value)
    end

    private def parse_value(value, type : Auth::Password::SHA256Password.class)
      Auth::Password::SHA256Password.new(value)
    end

    private def parse_value(value, type : URI.class | URI?.class)
      URI.parse(value)
    end

    private def parse_value(value, type : Time::Span.class)
      value.to_i.seconds
    end

    private def parse_value(value, type : Array(String).class)
      value.split(",").map(&.strip)
    end

    private def parse_bind(value)
      @amqp_bind = value
      @http_bind = value
      @mqtt_bind = value
    end

    # Re-read the config file into a fresh copy and swap it in only if parsing
    # and validation fully succeed. On failure the running config is untouched
    # and it raises, so the SIGHUP handler can log and keep serving.
    def reload
      new_config = dup
      new_config.fresh_sni_manager # don't mutate the live SNIManager while parsing
      new_config.parse_ini(@config_file)
      new_config.validate!
      new_config.try_to_open_log_file
      sync_was = sync?
      apply(new_config)
      setup_logger
      sync_data_dir_after_enabled if sync? && !sync_was
    end

    # What was written while sync was disabled is in the page cache only, and
    # the syncs that follow cover only newer writes, so the data dir is synced
    # once. It can take seconds under load, and until it's done a follower can
    # ack that older data as durable.
    private def sync_data_dir_after_enabled : Nil
      sync_data_dir
      Log.info { "Synced the data dir after sync was enabled" }
    rescue ex
      Log.error(exception: ex) { "Failed to sync the data dir after sync was enabled" }
    end

    private def sync_data_dir : Nil
      File.open(@data_dir) { |dir| FileSystem.syncfs(dir.fd) }
    end

    # Try to open and immediately close the configured log file so an unopenable
    # path raises a Config::Error before the config is applied
    protected def try_to_open_log_file
      if path = @log_file
        File.open(path, "a") { }
      end
    rescue ex : File::Error
      raise Error.new("Cannot open log_file '#{@log_file}': #{ex.message}")
    end

    protected def fresh_sni_manager
      @sni_manager = SNIManager.new
    end

    # Copy every instance variable from the parsed config in one non-yielding
    # loop, so no fiber sees a half-applied state. @@instance is a class
    # variable and is untouched, keeping `Config.instance` references valid.
    protected def apply(other : self)
      {% for ivar in @type.instance_vars %}
        @{{ ivar.id }} = other.@{{ ivar.id }}
      {% end %}
    end

    private def setup_logger
      backend = if path = @log_file
                  LogBackend.new(path, formatter: StdoutLogFormat)
                elsif journald_stream?
                  LogBackend.new(formatter: JournalLogFormat)
                else
                  LogBackend.new(formatter: StdoutLogFormat)
                end
      broadcast_backend = ::Log::BroadcastBackend.new

      broadcast_backend.append(backend, @log_level)

      in_memory_backend = ::Log::InMemoryBackend.instance
      broadcast_backend.append(in_memory_backend, @log_level)

      ::Log.setup(@log_level, broadcast_backend)
      # Federation and shovels use the embedded amqp-client, whose connection
      # read loop logs routine teardown (EOF / failed CloseOk) at ERROR whenever
      # a connection drops — unavoidable on broker shutdown and under connection
      # churn. LavinMQ already reports those events through its own
      # federation/shovel layers (lmq.*), so keep the library's redundant
      # connection log out of the broker log.
      ::Log.builder.bind("amqp.client.*", :fatal, broadcast_backend)
      # Closed once the new backend is bound so no entry in flight is lost
      @log_backend.try &.close
      @log_backend = backend
      target = (path = @log_file) ? path : "stdout"
      Log.info &.emit("Logger settings", level: @log_level.to_s, target: target)
    end

    def journald_stream? : Bool
      return false unless journal_stream = ENV["JOURNAL_STREAM"]?
      return false if @log_file # If logging to a file, not using journald

      # JOURNAL_STREAM format is "device:inode"
      parts = journal_stream.split(':')
      return false unless parts.size == 2

      journal_dev = parts[0].to_u64?
      journal_ino = parts[1].to_u64?
      return false unless journal_dev && journal_ino

      # Get STDOUT's device and inode
      LibC.fstat(STDOUT.fd, out stat)
      stat.st_dev == journal_dev && stat.st_ino == journal_ino
    rescue
      false
    end

    def tls_configured?
      !@tls_cert_path.empty?
    end

    private def tcp_keepalive?(str : String?) : Tuple(Int32, Int32, Int32)?
      return if false?(str)
      if keepalive = str.try &.split(":")
        {
          keepalive[0]?.try(&.to_i?) || 60,
          keepalive[1]?.try(&.to_i?) || 10,
          keepalive[2]?.try(&.to_i?) || 3,
        }
      end
    end

    # Folded here, not at the call sites: the [sni:] branch passes raw ini
    # values, so a capitalised TRUE read as false there but true in [main].
    private def false?(str : String?)
      {"0", "false", "no", "off", "n"}.includes? str.try &.downcase
    end

    private def true?(str : String?)
      {"1", "true", "yes", "on", "y"}.includes? str.try &.downcase
    end

    # There is no guarantee that `@type.instance_vars` are sorted in the same way they are added in the code.
    # This struct is needed to simplify the sorting of the options array, because you cannot rely on the order of @type.instance_vars.
    struct Option
      include Comparable(Option)

      def self.new(short_flag : String, long_flag : String, description : String, &block : Proc(String, Nil))
        new(short_flag, long_flag, description, block)
      end

      protected def initialize(@short_flag : String, @long_flag : String, @description : String, @set_value : Proc(String, Nil))
      end

      def <=>(other : Option)
        compare_value <=> other.compare_value
      end

      # Sort options alphabetically by short flag. Options without short flags
      # are sorted to the end by prefixing their long flag with "z".
      protected def compare_value
        if @short_flag.empty?
          "z" + @long_flag
        else
          @short_flag
        end
      end

      def setup_parser(parser)
        if @short_flag.empty?
          do_setup_parser(parser, @long_flag, @description)
        else
          do_setup_parser(parser, @short_flag, @long_flag, @description)
        end
      end

      private def do_setup_parser(parser, *args)
        parser.on(*args) do |val|
          @set_value.call(val)
        end
      end
    end
  end
end
