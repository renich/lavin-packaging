require "./spec_helper"
require "log/spec"

# In the AMQP namespace because AMQP::Exchange#bind refuses any destination
# whose class lives outside it.
class LavinMQ::AMQP::SyncFlagCapturingQueue < LavinMQ::AMQP::Queue
  getter needs_sync_seen : Bool? = nil

  def publish(msg : LavinMQ::Message) : PublishResult
    @needs_sync_seen = msg.needs_sync?
    super
  end
end

# Parks the publishing fiber inside #publish until released, the way a
# contended store lock would, so another publish can interleave with it.
class LavinMQ::AMQP::BlockingPublishQueue < LavinMQ::AMQP::Queue
  getter entered = ::Channel(Nil).new(1)
  getter release = ::Channel(Nil).new

  def publish(msg : LavinMQ::Message) : PublishResult
    @entered.send(nil)
    @release.receive
    super
  end
end

module MqttSpecs
  extend MqttHelpers

  describe "x-mqtt-topic exchange" do
    it "routes an MQTT publish to a queue bound with an MQTT topic filter" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        vhost.declare_queue("q1", true, false)
        vhost.bind_queue("q1", "xmqtt", "a/b/#")

        with_client_io(server) do |io|
          connect(io)
          publish(io, topic: "a/b/c", payload: "hello".to_slice, qos: 0u8)
          disconnect(io)
        end

        queue = vhost.queue("q1")
        wait_for { queue.message_count == 1 }
        queue.basic_get(no_ack: true) do |env|
          env.message.exchange_name.should eq "xmqtt"
          env.message.routing_key.should eq "a/b/c"
          env.message.properties.delivery_mode.should eq 2u8
          String.new(env.message.body).should eq "hello"
        end.should be_true
      end
    end

    it "does not route a non-matching topic" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        vhost.declare_queue("q1", true, false)
        vhost.bind_queue("q1", "xmqtt", "a/+/c")

        with_client_io(server) do |io|
          connect(io)
          publish(io, topic: "a/b/x", payload: "nope".to_slice, qos: 0u8)
          publish(io, topic: "a/b/c", payload: "yes".to_slice, qos: 0u8)
          disconnect(io)
        end

        queue = vhost.queue("q1")
        wait_for { queue.message_count == 1 }
        queue.basic_get(no_ack: true) do |env|
          String.new(env.message.body).should eq "yes"
        end.should be_true
      end
    end

    it "delivers a copy to each queue bound with the same filter" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        vhost.declare_queue("q1", true, false)
        vhost.declare_queue("q2", true, false)
        vhost.bind_queue("q1", "xmqtt", "a/#")
        vhost.bind_queue("q2", "xmqtt", "a/#")

        with_client_io(server) do |io|
          connect(io)
          publish(io, topic: "a/b", payload: "copy".to_slice, qos: 0u8)
          disconnect(io)
        end

        wait_for { vhost.queue("q1").message_count == 1 }
        wait_for { vhost.queue("q2").message_count == 1 }
      end
    end

    it "keeps one exchange's subscription when another unbinds the same filter" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("x1", "x-mqtt-topic", true, false)
        vhost.declare_exchange("x2", "x-mqtt-topic", true, false)
        vhost.declare_queue("q1", true, false)
        vhost.declare_queue("q2", true, false)
        vhost.bind_queue("q1", "x1", "a/#")
        vhost.bind_queue("q2", "x2", "a/#")

        with_client_io(server) do |io|
          connect(io)
          publish(io, topic: "a/b", payload: "both".to_slice, qos: 0u8)
          wait_for { vhost.queue("q1").message_count == 1 }
          wait_for { vhost.queue("q2").message_count == 1 }

          vhost.unbind_queue("q2", "x2", "a/#", LavinMQ::AMQP::Table.new)
          publish(io, topic: "a/b", payload: "one".to_slice, qos: 0u8)
          wait_for { vhost.queue("q1").message_count == 2 }
          vhost.queue("q2").message_count.should eq 1
          disconnect(io)
        end
      end
    end

    it "delivers one copy per matching binding when filters overlap" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        vhost.declare_queue("q1", true, false)
        vhost.bind_queue("q1", "xmqtt", "sensors/#")
        vhost.bind_queue("q1", "xmqtt", "sensors/+/temp")

        with_client_io(server) do |io|
          connect(io)
          publish(io, topic: "sensors/a/temp", payload: "t".to_slice, qos: 0u8)
          disconnect(io)
        end

        wait_for { vhost.queue("q1").message_count == 2 }
      end
    end

    it "stops routing when the exchange is deleted" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        vhost.declare_queue("q1", true, false)
        vhost.bind_queue("q1", "xmqtt", "a/#")
        vhost.delete_exchange("xmqtt")
        vhost.mqtt_subscription_tree.empty?.should be_true

        with_client_io(server) do |io|
          connect(io)
          publish(io, topic: "a/b", payload: "lost".to_slice, qos: 1u8)
          disconnect(io)
        end
        vhost.queue("q1").message_count.should eq 0
      end
    end

    it "stops routing when the bound queue is deleted" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        vhost.declare_queue("q1", true, false)
        vhost.bind_queue("q1", "xmqtt", "a/#")
        vhost.delete_queue("q1")

        exchange = vhost.exchange("xmqtt")
        exchange.binding_count.should eq 0
        vhost.mqtt_subscription_tree.empty?.should be_true
      end
    end

    it "deletes an auto_delete exchange when its last binding is removed" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xad", "x-mqtt-topic", false, true)
        vhost.declare_queue("q1", true, false)
        vhost.bind_queue("q1", "xad", "a/#")
        vhost.unbind_queue("q1", "xad", "a/#", LavinMQ::AMQP::Table.new)
        vhost.exchange?("xad").should be_nil
        vhost.mqtt_subscription_tree.empty?.should be_true
      end
    end

    it "restores durable bindings through definitions replay after a restart" do
      with_server(clean_dir: false) do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        vhost.declare_queue("q1", true, false)
        vhost.bind_queue("q1", "xmqtt", "a/b/#")
      end

      with_server(clean_dir: true) do |server|
        vhost = server.vhosts["/"]
        vhost.exchange("xmqtt").binding_count.should eq 1

        with_client_io(server) do |io|
          connect(io)
          publish(io, topic: "a/b/c", payload: "again".to_slice, qos: 0u8)
          disconnect(io)
        end
        wait_for { vhost.queue("q1").message_count == 1 }
      end
    end

    it "refuses basic.publish into the exchange" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        with_channel(server) do |ch|
          expect_raises(AMQP::Client::Channel::ClosedException, /ACCESS_REFUSED/) do
            ch.basic_publish_confirm("nope", "xmqtt", "a/b")
          end
        end
      end
    end

    # A QoS 1 PUBACK is released by the persister once the files the publish
    # dirtied are synced, and only a message with needs_sync marks its segment
    # dirty. The flag must survive the copy made for AMQP destinations.
    it "keeps needs_sync on the message delivered to AMQP destinations" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        exchange = vhost.exchange("xmqtt").as(LavinMQ::AMQP::MqttTopicExchange)
        queue = LavinMQ::AMQP::SyncFlagCapturingQueue.create(vhost, "sync_flag")
        exchange.bind(queue, "a/b", nil)

        ctx = LavinMQ::MQTT::PublishContext.new
        {true, false}.each do |needs_sync|
          msg = LavinMQ::Message.new(LavinMQ::MQTT::EXCHANGE, "a/b", "payload")
          msg.needs_sync = needs_sync
          exchange.deliver(msg, "a/b", ctx.reset).should be_true
          queue.needs_sync_seen.should eq needs_sync
        end
      ensure
        queue.try &.delete
      end
    end

    # The tree calls #deliver once per matching filter, so stats must not be
    # counted per call.
    it "counts publish_in once per MQTT publish matched by several filters" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        {"q1" => "a/#", "q2" => "a/+", "q3" => "+/b"}.each do |q, filter|
          vhost.declare_queue(q, true, false)
          vhost.bind_queue(q, "xmqtt", filter)
        end

        with_client_io(server) do |io|
          connect(io)
          5.times { publish(io, topic: "a/b", payload: "x".to_slice, qos: 0u8) }
          disconnect(io)
        end

        wait_for { {"q1", "q2", "q3"}.all? { |q| vhost.queue(q).message_count == 5 } }
        exchange = vhost.exchange("xmqtt")
        exchange.publish_in_count.should eq 5
        exchange.publish_out_count.should eq 15
        exchange.unroutable_count.should eq 0
      end
    end

    it "does not count a publish refused for overflow as unroutable" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        args = LavinMQ::AMQP::Table.new({"x-max-length" => 0, "x-overflow" => "reject-publish"})
        vhost.declare_queue("full", true, false, args)
        vhost.bind_queue("full", "xmqtt", "a/#")

        with_client_io(server) do |io|
          connect(io)
          3.times { publish(io, topic: "a/b", payload: "x".to_slice, qos: 0u8) }
          disconnect(io)
        end

        exchange = vhost.exchange("xmqtt")
        wait_for { exchange.publish_in_count == 3 }
        exchange.publish_out_count.should eq 0
        exchange.unroutable_count.should eq 0
      end
    end

    it "does not count a publish refused by a closed queue as unroutable" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        vhost.declare_queue("gone", true, false)
        vhost.bind_queue("gone", "xmqtt", "a/#")
        vhost.queue("gone").close

        with_client_io(server) do |io|
          connect(io)
          publish(io, topic: "a/b", payload: "x".to_slice, qos: 0u8)
          disconnect(io)
        end

        exchange = vhost.exchange("xmqtt")
        wait_for { exchange.publish_in_count == 1 }
        exchange.publish_out_count.should eq 0
        exchange.unroutable_count.should eq 0
      end
    end

    # The order the tree yields filters in is not defined, so a filter that
    # routes the publish can come after one that counted it as unroutable.
    it "counts a publish as unroutable once, and only if no filter routes it" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        exchange = vhost.exchange("xmqtt").as(LavinMQ::AMQP::MqttTopicExchange)
        vhost.declare_exchange("sink", "direct", true, false)
        vhost.declare_queue("open", true, false)
        exchange.bind(vhost.exchange("sink").as(LavinMQ::AMQP::Exchange), "a/#", nil)
        exchange.bind(vhost.queue("open").as(LavinMQ::AMQP::Queue), "a/+", nil)
        msg = LavinMQ::Message.new(LavinMQ::MQTT::EXCHANGE, "a/b", "payload")
        ctx = LavinMQ::MQTT::PublishContext.new

        ctx.reset
        exchange.deliver(msg, "a/#", ctx).should be_false
        exchange.unroutable_count.should eq 1
        exchange.deliver(msg, "a/+", ctx).should be_true
        exchange.unroutable_count.should eq 0

        ctx.reset
        exchange.deliver(msg, "a/#", ctx).should be_false
        exchange.deliver(msg, "a/#", ctx).should be_false
        exchange.unroutable_count.should eq 1
        exchange.publish_in_count.should eq 2
      end
    end

    # Queue#publish can yield on a contended store lock, letting another
    # client's publish into the same exchange run in the middle of this one's
    # tree walk. The per-publish stats state must not be shared between them.
    it "keeps per-publish stats apart when two publishes interleave" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        exchange = vhost.exchange("xmqtt").as(LavinMQ::AMQP::MqttTopicExchange)
        blocking = LavinMQ::AMQP::BlockingPublishQueue.create(vhost, "blocking")
        vhost.declare_queue("open", true, false)
        exchange.bind(blocking, "a/b", nil)
        vhost.bind_queue("open", "xmqtt", "a/#")

        with_client_io(server) do |first|
          connect(first, client_id: "first")
          publish(first, topic: "a/b", payload: "x".to_slice, qos: 0u8)
          blocking.entered.receive

          with_client_io(server) do |second|
            connect(second, client_id: "second")
            publish(second, topic: "a/c", payload: "y".to_slice, qos: 0u8)
            disconnect(second)
          end
          wait_for { vhost.queue("open").message_count == 1 }

          blocking.release.send(nil)
          wait_for { vhost.queue("open").message_count == 2 }
          disconnect(first)
        end

        exchange.publish_in_count.should eq 2
        exchange.publish_out_count.should eq 3
        exchange.unroutable_count.should eq 0
      ensure
        blocking.try &.delete
      end
    end

    it "refuses binding with a malformed MQTT topic filter over AMQP" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        vhost.declare_queue("q1", true, false)
        {"a/#/b", "#/a", "a/+b", "a/b#", "a/##", ""}.each do |filter|
          with_channel(server) do |ch|
            expect_raises(AMQP::Client::Channel::ClosedException, /PRECONDITION_FAILED.*not a valid MQTT topic filter/) do
              ch.queue_bind("q1", "xmqtt", filter)
            end
          end
        end
        vhost.exchange("xmqtt").binding_count.should eq 0
        vhost.mqtt_subscription_tree.empty?.should be_true
      end
    end

    it "refuses binding with a malformed MQTT topic filter over the HTTP API" do
      with_http_server do |http, s|
        vhost = s.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        vhost.declare_queue("q1", true, false)
        response = http.post("/api/bindings/%2f/e/xmqtt/q/q1", body: %({"routing_key": "a/#/b"}))
        response.status_code.should eq 400
        JSON.parse(response.body)["reason"].as_s.should contain "not a valid MQTT topic filter"
        vhost.exchange("xmqtt").binding_count.should eq 0
      end
    end

    it "accepts well-formed wildcard filter" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        vhost.declare_queue("q1", true, false)
        filters = {"#", "+", "+/#", "a/+/+", "a/+/c/#", "a/b/c"}
        with_channel(server) do |ch|
          filters.each { |filter| ch.queue_bind("q1", "xmqtt", filter) }
        end
        vhost.exchange("xmqtt").binding_count.should eq filters.size
      end
    end

    # The exchange only routes MQTT publishes, which can't carry an x-delay,
    # so a delayed x-mqtt-topic exchange would only look delayed
    it "refuses to declare a delayed exchange over AMQP" do
      with_server do |server|
        with_channel(server) do |ch|
          expect_raises(AMQP::Client::Channel::ClosedException, /PRECONDITION_FAILED.*can't be delayed/) do
            ch.exchange_declare("xmqtt", "x-mqtt-topic", args: AMQP::Client::Arguments.new({"x-delayed-exchange" => true}))
          end
        end
        with_channel(server) do |ch|
          expect_raises(AMQP::Client::Channel::ClosedException, /PRECONDITION_FAILED.*can't be delayed/) do
            ch.exchange_declare("xmqtt", "x-delayed-message", args: AMQP::Client::Arguments.new({"x-delayed-type" => "x-mqtt-topic"}))
          end
        end
        server.vhosts["/"].exchange?("xmqtt").should be_nil
      end
    end

    it "refuses to declare an exchange with any x-delayed-exchange value but false" do
      with_server do |server|
        ["true", 1].each do |value|
          with_channel(server) do |ch|
            expect_raises(AMQP::Client::Channel::ClosedException, /PRECONDITION_FAILED.*can't be delayed/) do
              ch.exchange_declare("xmqtt", "x-mqtt-topic", args: AMQP::Client::Arguments.new({"x-delayed-exchange" => value}))
            end
          end
        end
        with_channel(server) do |ch|
          ch.exchange_declare("xmqtt", "x-mqtt-topic", args: AMQP::Client::Arguments.new({"x-delayed-exchange" => false}))
        end
        server.vhosts["/"].exchange?("xmqtt").should_not be_nil
      end
    end

    it "refuses to declare a delayed exchange over the HTTP API" do
      with_http_server do |http, s|
        body = %({"type": "x-mqtt-topic", "durable": true, "arguments": {"x-delayed-exchange": true}})
        response = http.put("/api/exchanges/%2f/xmqtt", body: body)
        response.status_code.should eq 400
        s.vhosts["/"].exchange?("xmqtt").should be_nil
      end
    end

    delayed_definitions = <<-JSON
      {
        "queues": [{"name": "q1", "vhost": "/", "durable": true, "auto_delete": false, "arguments": {}}],
        "exchanges": [{"name": "xmqtt", "vhost": "/", "type": "x-delayed-exchange", "durable": true,
                       "auto_delete": false, "internal": true, "arguments": {"x-delayed-type": "x-mqtt-topic"}}]
      }
      JSON

    it "refuses to import a delayed exchange from definitions and imports nothing" do
      with_http_server do |http, s|
        response = http.post("/api/definitions", body: delayed_definitions)
        response.status_code.should eq 400
        response.body.should contain "can't be delayed"
        s.vhosts["/"].exchange?("xmqtt").should be_nil
        s.vhosts["/"].queue_exists?("q1").should be_false
      end
    end

    it "refuses to import a delayed exchange into a vhost and imports nothing" do
      with_http_server do |http, s|
        response = http.post("/api/definitions/%2f", body: delayed_definitions)
        response.status_code.should eq 400
        s.vhosts["/"].exchange?("xmqtt").should be_nil
        s.vhosts["/"].queue_exists?("q1").should be_false
      end
    end

    it "refuses to load a delayed exchange from a definitions file" do
      tmpfile = File.tempname("lavinmq-defs", ".json")
      File.write(tmpfile, delayed_definitions)
      begin
        with_amqp_server do |s|
          expect_raises(LavinMQ::Error::PreconditionFailed, /can't be delayed/) do
            LavinMQ::GlobalDefinitions.import_from_file(tmpfile, s)
          end
          s.vhosts["/"].exchange?("xmqtt").should be_nil
        end
      ensure
        File.delete?(tmpfile)
      end
    end

    # The exchange only routes MQTT publishes, so dead-letters into it are
    # dropped. That's logged once, as a burst would flood the log.
    {% for dlx in ["xmqtt", "mqtt.default"] %}
    it "drops messages dead-lettered into {{ dlx.id }} and logs a warning once" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        with_channel(server) do |ch|
          ch.queue_declare("dst")
          ch.queue_bind("dst", "xmqtt", "#")
          src = ch.queue("src", args: AMQP::Client::Arguments.new({
            "x-message-ttl"             => 1,
            "x-dead-letter-exchange"    => {{ dlx }},
            "x-dead-letter-routing-key" => "a/b",
          }))
          Log.capture("lmq.queue", :warn) do |logs|
            3.times { src.publish_confirm "x" }
            wait_for { vhost.queue("src").message_count.zero? }
            logs.@entries.count(&.message.includes?("Dropping dead-lettered messages: exchange '{{ dlx.id }}'")).should eq 1
          end
          vhost.queue("dst").message_count.should eq 0
        end
      end
    end
    {% end %}

    it "warns again when the dead-letter exchange changes away and back" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        set_dlx = ->(dlx : String) do
          vhost.add_policy("dlx", "^src$", "queues", {"dead-letter-exchange" => JSON::Any.new(dlx)}, 0_i8)
          wait_for { vhost.queue("src").@dead_letter.dlx == dlx }
        end
        with_channel(server) do |ch|
          src = ch.queue("src", args: AMQP::Client::Arguments.new({"x-message-ttl" => 1}))
          Log.capture("lmq.queue", :warn) do |logs|
            warnings = -> { logs.@entries.count(&.message.includes?("Dropping dead-lettered messages: exchange 'xmqtt'")) }
            set_dlx.call("xmqtt")
            src.publish_confirm "x"
            wait_for { vhost.queue("src").message_count.zero? }
            warnings.call.should eq 1
            set_dlx.call("amq.topic")
            src.publish_confirm "x"
            wait_for { vhost.queue("src").message_count.zero? }
            set_dlx.call("xmqtt")
            src.publish_confirm "x"
            wait_for { warnings.call == 2 }
          end
        end
      end
    end

    it "allows exchange.bind with the exchange as source" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        with_channel(server) do |ch|
          ch.exchange_bind("xmqtt", "amq.topic", "a/#")
        end
        vhost.exchange("xmqtt").binding_count.should eq 1
      end
    end

    # Messages routed in through an exchange binding would hit the no-op
    # each_destination and vanish. Only the internal flag is not enough: it
    # guards basic.publish, not routing from other exchanges.
    it "refuses exchange.bind with the exchange as destination" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        with_channel(server) do |ch|
          expect_raises(AMQP::Client::Channel::ClosedException, /PRECONDITION_FAILED.*cannot be a binding destination/) do
            ch.exchange_bind("amq.topic", "xmqtt", "a.b")
          end
        end
        vhost.exchange("amq.topic").bindings_details.should be_empty
      end
    end

    it "refuses an exchange binding into the exchange over the HTTP API" do
      with_http_server do |http, s|
        s.vhosts["/"].declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        response = http.post("/api/bindings/%2f/e/amq.topic/e/xmqtt", body: %({"routing_key": "a.b"}))
        response.status_code.should eq 400
        s.vhosts["/"].exchange("amq.topic").bindings_details.should be_empty
      end
    end

    it "routes into a bound exchange and onwards with normal AMQP routing" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        vhost.declare_queue("q1", true, false)
        vhost.exchange("xmqtt").bind(vhost.exchange("amq.topic").as(LavinMQ::AMQP::Exchange), "a/#", nil)
        # the routing key stays the MQTT topic verbatim: no dots, so only an
        # exact literal binding key matches on an AMQP topic exchange
        vhost.bind_queue("q1", "amq.topic", "a/b/c")

        with_client_io(server) do |io|
          connect(io)
          publish(io, topic: "a/b/c", payload: "via amq.topic".to_slice, qos: 0u8)
          disconnect(io)
        end

        queue = vhost.queue("q1")
        wait_for { queue.message_count == 1 }
        queue.basic_get(no_ack: true) do |env|
          env.message.routing_key.should eq "a/b/c"
        end.should be_true
      end
    end

    it "keeps x-mqtt-topic bindings out of mqtt.default's binding view" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        vhost.declare_queue("q1", true, false)
        vhost.bind_queue("q1", "xmqtt", "a/b/#")

        with_client_io(server) do |io|
          connect(io, client_id: "sub")
          subscribe(io, topic_filters: [subtopic("a/+/c", 0u8)])

          mqtt_default = vhost.mqtt_exchange
          mqtt_default.binding_count.should eq 1
          details = mqtt_default.bindings_details
          details.size.should eq 1
          details.first.routing_key.should eq "a/+/c"

          vhost.exchange("xmqtt").binding_count.should eq 1
          disconnect(io)
        end
      end
    end

    it "still delivers to MQTT sessions sharing the tree" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        vhost.declare_queue("q1", true, false)
        vhost.bind_queue("q1", "xmqtt", "a/b/#")

        with_client_io(server) do |sub_io|
          connect(sub_io, client_id: "sub")
          subscribe(sub_io, topic_filters: [subtopic("a/+/c", 0u8)])

          with_client_io(server) do |pub_io|
            connect(pub_io, client_id: "pub")
            publish(pub_io, topic: "a/b/c", payload: "both".to_slice, qos: 0u8)
            disconnect(pub_io)
          end

          packet = read_publish(sub_io)
          packet.topic.should eq "a/b/c"
          String.new(packet.payload).should eq "both"
          disconnect(sub_io)
        end

        wait_for { vhost.queue("q1").message_count == 1 }
      end
    end

    it "does not replay retained messages on bind" do
      with_server do |server|
        vhost = server.vhosts["/"]
        with_client_io(server) do |io|
          connect(io)
          publish(io, topic: "a/b/c", payload: "retained".to_slice, qos: 0u8, retain: true)
          disconnect(io)
        end

        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        vhost.declare_queue("q1", true, false)
        vhost.bind_queue("q1", "xmqtt", "a/b/#")
        vhost.queue("q1").message_count.should eq 0

        with_client_io(server) do |io|
          connect(io)
          publish(io, topic: "a/b/c", payload: "live".to_slice, qos: 0u8)
          disconnect(io)
        end
        queue = vhost.queue("q1")
        wait_for { queue.message_count == 1 }
        queue.basic_get(no_ack: true) do |env|
          String.new(env.message.body).should eq "live"
        end.should be_true
      end
    end

    it "keeps a bound queue open after a publish with a topic longer than 255 bytes" do
      with_server do |server|
        vhost = server.vhosts["/"]
        vhost.declare_exchange("xmqtt", "x-mqtt-topic", true, false)
        vhost.declare_queue("q1", true, false)
        vhost.bind_queue("q1", "xmqtt", "#")

        with_client_io(server) do |io|
          connect(io)
          expect_raises(IO::Error) do
            publish(io, topic: "a/#{"x" * 300}", qos: 1u8)
          end
        end

        with_client_io(server) do |io|
          connect(io)
          publish(io, topic: "a/b", qos: 1u8).should be_a(MQTT::Protocol::PubAck)
          disconnect(io)
        end

        queue = vhost.queue("q1")
        queue.closed?.should be_false
        queue.message_count.should eq 1
        queue.basic_get(no_ack: true) do |env|
          env.message.routing_key.should eq "a/b"
        end.should be_true
      end
    end

    # The exchange carries the vhost's MQTT traffic: without this, a user that
    # may only configure its own names could read every MQTT topic
    describe "declare permissions" do
      lim_perms = ->(server : LavinMQ::Server, read : Regex) do
        server.users.create("lim", "pw", [LavinMQ::Tag::Management])
        server.users.add_permission("lim", "/", /^lim\./, read, /^lim\./)
      end
      lim_headers = ::HTTP::Headers{"Authorization" => "Basic bGltOnB3", "Content-Type" => "application/json"} # lim:pw

      it "refuses exchange.declare without read permission on mqtt.default" do
        with_server do |server|
          lim_perms.call(server, /^lim\./)
          with_channel(server, user: "lim", password: "pw") do |ch|
            expect_raises(AMQP::Client::Channel::ClosedException, /ACCESS_REFUSED.*mqtt\.default/) do
              ch.exchange_declare("lim.mq", "x-mqtt-topic")
            end
          end
          server.vhosts["/"].exchange?("lim.mq").should be_nil
        end
      end

      it "allows exchange.declare and binding with read permission on mqtt.default" do
        with_server do |server|
          lim_perms.call(server, /^(lim\.|mqtt\.default$)/)
          with_channel(server, user: "lim", password: "pw") do |ch|
            ch.exchange_declare("lim.mq", "x-mqtt-topic")
            ch.queue_declare("lim.q")
            ch.queue_bind("lim.q", "lim.mq", "#")
          end
          server.vhosts["/"].exchange("lim.mq").binding_count.should eq 1
        end
      end

      it "refuses declaring over the HTTP API without read permission on mqtt.default" do
        with_http_server do |http, s|
          lim_perms.call(s, /^lim\./)
          response = http.put("/api/exchanges/%2f/lim.mq", headers: lim_headers, body: %({"type": "x-mqtt-topic"}))
          response.status_code.should eq 403
          response.body.should contain "mqtt.default"
          s.vhosts["/"].exchange?("lim.mq").should be_nil
        end
      end

      it "allows declaring over the HTTP API with read permission on mqtt.default" do
        with_http_server do |http, s|
          lim_perms.call(s, /^(lim\.|mqtt\.default$)/)
          response = http.put("/api/exchanges/%2f/lim.mq", headers: lim_headers, body: %({"type": "x-mqtt-topic"}))
          response.status_code.should eq 201
          s.vhosts["/"].exchange?("lim.mq").should be_a(LavinMQ::AMQP::MqttTopicExchange)
        end
      end
    end
  end
end
