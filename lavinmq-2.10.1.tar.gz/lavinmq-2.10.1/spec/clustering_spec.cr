require "log/spec"
require "./spec_helper"
require "../src/lavinmq/launcher"
require "../src/lavinmq/clustering/client"
require "../src/lavinmq/clustering/controller"

alias IndexTree = LavinMQ::MQTT::TopicTree(String)

private def metric_value(body : String, name : String, labels : Hash(String, String)) : Float64?
  body.each_line do |line|
    next unless line.starts_with?("#{name}{")
    close = line.index('}')
    next unless close
    parsed = Hash(String, String).new
    line[(name.size + 1)...close].split(", ").each do |pair|
      key, _, value = pair.partition('=')
      parsed[key] = value.strip('"')
    end
    next unless labels.all? { |k, v| parsed[k]? == v }
    return line[(close + 1)..].strip.to_f
  end
  nil
end

private def populate_msg_store(msg_store)
  segment_size = LavinMQ::Config.instance.segment_size
  msg_size = 1000_u64
  num_messages = (segment_size // msg_size) + 10
  props = LavinMQ::AMQP::Properties.new
  num_messages.times do
    msg = LavinMQ::Message.new(Time.utc.to_unix_ms, "exchange", "rk", props, msg_size, IO::Memory.new("x" * msg_size.to_i))
    msg_store.push(msg)
  end
  msg_store.@segments.size.should be > 1
end

private def do_full_sync(tcp_server, replicator, wg : WaitGroup? = nil) : Fiber::ExecutionContext::Isolated
  Fiber::ExecutionContext::Isolated.new("test-follower") do
    client_io = TCPSocket.new("localhost", tcp_server.local_address.port)
    begin
      # Handshake and authentication
      client_io.write LavinMQ::Clustering::Start
      client_io.write_bytes replicator.password.bytesize.to_u8, IO::ByteFormat::LittleEndian
      client_io.write replicator.password.to_slice
      client_io.read_byte
      client_io.write_bytes 2i32, IO::ByteFormat::LittleEndian
      client_io.flush
      # Signal that full sync is about to start
      wg.try &.done
      sha1_size = Digest::SHA1.new.digest_size
      client_lz4 = Compress::LZ4::Reader.new(client_io)
      # Do the full sync two times without requesting files (everything is up
      # to date)
      2.times do
        loop do
          filename_len = client_lz4.read_bytes Int32, IO::ByteFormat::LittleEndian
          break if filename_len.zero?
          client_lz4.skip filename_len
          client_lz4.skip sha1_size
        end
        # 0 means "requesting files done"
        client_io.write_bytes 0i32
        client_io.flush
      end
    ensure
      client_io.close
    end
  end
end

class SelfLeaderEtcd < LavinMQ::Etcd
  getter observed = Channel(Nil).new(1)

  def initialize(@uri : String)
    super("localhost:1")
  end

  def elect_listen(_name, &)
    @observed.send nil
    yield @uri
  end
end

class SelfLeaderController < LavinMQ::Clustering::Controller
  def follow_leader_public
    follow_leader
  end

  def mark_elected_for_spec
    @elected_leader.set(true)
  end
end

class ProxyBindEtcd < LavinMQ::Etcd
  def initialize(@leader_uri : String)
    super("localhost:1")
  end

  def elect_listen(_name, &)
    yield @leader_uri
  end

  def get(_key) : String?
    "secret"
  end
end

describe LavinMQ::Clustering::Controller do
  it "reports follower proxy bind failures without the generic unhandled exception log" do
    blocker = TCPServer.new("127.0.0.1", 0)
    with_datadir do |data_dir|
      config = LavinMQ::Config.new
      config.data_dir = data_dir
      config.amqp_bind = "127.0.0.1"
      config.amqp_port = blocker.local_address.port
      config.http_port = 0
      config.mqtt_port = 0
      config.metrics_http_port = -1
      config.clustering_advertised_uri = "tcp://127.0.0.1:5679"
      etcd = ProxyBindEtcd.new("tcp://192.0.2.10:5679")
      coordinator = LavinMQ::Clustering::EtcdCoordinator.new(config, etcd)
      controller = SelfLeaderController.new(config, etcd, coordinator)

      Log.capture("lmq.clustering.controller", :fatal) do |logs|
        ex = expect_raises(SpecExit) { controller.follow_leader_public }
        ex.code.should eq 36
        logs.check(:fatal, /Could not bind to '127\.0\.0\.1:#{blocker.local_address.port}'/)
        logs.entry.to_s.should_not contain "Unhandled exception while following leader"
      end
    end
  ensure
    blocker.try &.close
  end
end

describe LavinMQ::Clustering::Client, tags: %w[etcd slow] do
  add_etcd_around_each

  it "can stream changes" do
    with_clustering do |cluster|
      with_amqp_server(replicator: cluster.replicator) do |s|
        with_channel(s) do |ch|
          q = ch.queue("repli", durable: true)
          q.publish_confirm "hello world", props: AMQP::Client::Properties.new(delivery_mode: 2_u8)
        end
        wait_for { cluster.replicator.followers.first?.try &.lag_in_bytes == 0 }
        cluster.stop
      end

      server = LavinMQ::Server.new(cluster.follower_config)
      begin
        q = server.vhosts["/"].queue("repli").as(LavinMQ::AMQP::DurableQueue)
        q.message_count.should eq 1
        q.basic_get(true) do |env|
          String.new(env.message.body).to_s.should eq "hello world"
        end.should be_true
      ensure
        server.close
      end
    end
  end

  it "confirms publishes once synced locally and replicated to followers" do
    with_clustering do |cluster|
      with_amqp_server(replicator: cluster.replicator) do |s|
        wait_for { cluster.replicator.followers.first?.try &.synced? }
        with_channel(s) do |ch|
          ch.confirm_select
          q = ch.queue("repli_confirm", durable: true)
          100.times { q.publish "msg", props: AMQP::Client::Properties.new(delivery_mode: 2_u8) }
          # Confirms only arrive once all synced followers have acked the
          # replicated bytes; this would block forever if it never returned.
          ch.wait_for_confirms.should be_true
        end
        s.vhosts["/"].queue("repli_confirm").message_count.should eq 100
        cluster.replicator.followers.first?.try &.lag_in_bytes.should eq 0
      end
    end
  end

  it "exposes inter-node replication byte counters" do
    with_clustering do |cluster|
      with_amqp_server(replicator: cluster.replicator) do |s|
        with_channel(s) do |ch|
          q = ch.queue("repli", durable: true)
          q.publish_confirm "hello world", props: AMQP::Client::Properties.new(delivery_mode: 2_u8)
        end
        wait_for { cluster.replicator.followers.first?.try &.lag_in_bytes == 0 }

        follower_id = cluster.replicator.followers.first.id.to_s(36)

        serve_metrics(s) do |http|
          body = http.get("/metrics").body
          sent = metric_value(body, "lavinmq_follower_bytes_sent_total", {"id" => follower_id})
          acked = metric_value(body, "lavinmq_follower_bytes_acked_total", {"id" => follower_id})
          sent.should_not be_nil
          acked.should_not be_nil
          sent.not_nil!.should be > 0
          acked.not_nil!.should be > 0
        end

        serve_follower_metrics(cluster.repli) do |http|
          body = http.get("/metrics").body
          line = body.lines.find(&.starts_with?("lavinmq_cluster_received_bytes_total "))
          line.should_not be_nil
          line.not_nil!.split(' ').last.to_f.should be > 0
        end
      end
    end
  end

  it "confirms via syncfs while the only follower is still syncing" do
    # Regression: a publish written while all followers are syncing isn't streamed
    # to them. The confirm must not stall waiting for an ack from a follower that
    # flips to synced before the persister drains.
    Dir.mkdir_p LavinMQ::Config.instance.data_dir
    replicator = LavinMQ::Clustering::Server.new(
      LavinMQ::Config.instance, NullCoordinator.new, 0)
    tcp_server = TCPServer.new("localhost", 0)
    spawn(replicator.listen(tcp_server), name: "repli server spec")

    # Fake follower: handshake, read the file list, then hang without finishing
    # the file-request phase, so it stays in the Syncing state on the leader.
    client_io = TCPSocket.new("localhost", tcp_server.local_address.port)
    client_io.write LavinMQ::Clustering::Start
    client_io.write_bytes replicator.password.bytesize.to_u8, IO::ByteFormat::LittleEndian
    client_io.write replicator.password.to_slice
    client_io.read_byte
    client_io.write_bytes 2i32, IO::ByteFormat::LittleEndian
    client_io.flush
    client_lz4 = Compress::LZ4::Reader.new(client_io)
    sha1_size = Digest::SHA1.new.digest_size
    spawn(name: "syncing follower spec") do
      loop do
        filename_len = client_lz4.read_bytes Int32, IO::ByteFormat::LittleEndian
        break if filename_len.zero?
        client_lz4.skip filename_len
        client_lz4.skip sha1_size
      end
      # Intentionally never send the "0 files requested" reply: stay syncing.
    rescue IO::Error
    end

    wait_for { replicator.syncing_followers.size == 1 }
    replicator.followers.should be_empty # none synced

    with_amqp_server(replicator: replicator) do |s|
      with_channel(s) do |ch|
        ch.confirm_select
        q = ch.queue("syncing_confirm", durable: true)
        10.times { q.publish "m", props: AMQP::Client::Properties.new(delivery_mode: 2_u8) }
        # Confirmed via syncfs (no synced follower); must not stall or be skipped.
        ch.wait_for_confirms.should be_true
      end
      s.vhosts["/"].queue("syncing_confirm").message_count.should eq 10
    end
  ensure
    client_io.try &.close
    replicator.try &.close
    tcp_server.try &.close
    FileUtils.rm_rf LavinMQ::Config.instance.data_dir
  end

  # Opens a message store, publishes some messages, then saves replicator.@files
  # Then opens a new message store in the same directory and verifies that the same
  # files are registered in the new replicator (verifies that meta files are registered and replicated).
  it "registers meta files on startup" do
    coordinator = NullCoordinator.new
    msg_dir = File.join(LavinMQ::Config.instance.data_dir, "meta_test_queue")
    FileUtils.mkdir_p(msg_dir)
    node_id = 0

    begin
      replicator = LavinMQ::Clustering::Server.new(LavinMQ::Config.instance, coordinator, node_id)
      msg_store = LavinMQ::MessageStore.new(msg_dir, replicator)
      segment_size = LavinMQ::Config.instance.segment_size
      msg_size = 1000_u64
      num_messages = (segment_size // msg_size) + 100 # ensure we create multiple segments
      props = LavinMQ::AMQP::Properties.new
      msg = LavinMQ::Message.new(Time.utc.to_unix_ms, "exchange", "rk", props, msg_size, IO::Memory.new("x" * msg_size.to_i))
      num_messages.times { msg_store.push(msg) }
      msg_store.@segments.size.should be > 1

      msg_store.close
      files_before = replicator.@file_index.shared { |files, _| files.keys }.sort!
      replicator.close

      # Re-open the message store and verify the same files are registered
      replicator = LavinMQ::Clustering::Server.new(LavinMQ::Config.instance, coordinator, node_id + 1)
      msg_store = LavinMQ::MessageStore.new(msg_dir, replicator)
      msg_store.close
      files_after = replicator.@file_index.shared { |files, _| files.keys }.sort!

      files_before.size.should be > 2
      files_before.find(&.ends_with?("meta.0000000001")).should_not be_nil
      files_before.should eq files_after
      replicator.close
    ensure
      FileUtils.rm_rf(msg_dir)
    end
  end

  it "replicates and streams retained messages to followers" do
    with_clustering do |cluster|
      replicator = cluster.replicator
      retain_store = LavinMQ::MQTT::RetainStore.new("#{cluster.config.data_dir}/retain_store", replicator)
      # This wait is needed for the initial replace of index to be synced.
      # If we don't do this data may have been appended to the file before it's
      # written to socket, meaning that the lag_size has changed.
      wait_for { replicator.followers.first?.try &.lag_in_bytes == 0 }

      pub1 = MQTT::Protocol::Publish.new(topic: "topic1", payload: "body1".to_slice,
        packet_id: nil, dup: false, qos: 0u8, retain: true)
      pub2 = MQTT::Protocol::Publish.new(topic: "topic2", payload: "body2".to_slice,
        packet_id: nil, dup: false, qos: 0u8, retain: true)
      retain_store.retain(pub1)
      retain_store.retain(pub2)

      wait_for { replicator.followers.first?.try &.lag_in_bytes == 0 }
      cluster.stop

      follower_retain_store = LavinMQ::MQTT::RetainStore.new("#{cluster.follower_config.data_dir}/retain_store", nil)
      a = Array(String).new(2)
      b = Array(String).new(2)
      follower_retain_store.each("#") do |topic, body_io, body_bytesize|
        a << topic
        b << body_io.read_string(body_bytesize)
      end

      a.sort!.should eq(["topic1", "topic2"])
      b.sort!.should eq(["body1", "body2"])
      follower_retain_store.@index.size.should eq(2)
    ensure
      follower_retain_store.try &.close
      retain_store.try &.close
    end
  end

  it "can stream full file" do
    with_clustering do |cluster|
      with_amqp_server(replicator: cluster.replicator) do |s|
        s.users.create("u1", "p1")
        wait_for { cluster.replicator.followers.first?.try &.lag_in_bytes == 0 }
        cluster.stop
      end

      server = LavinMQ::Server.new(cluster.follower_config)
      begin
        server.users["u1"].should_not be_nil
      ensure
        server.close
      end
    end
  end

  it "will failover", tags: "slow" do
    config1 = LavinMQ::Config.new
    config1.data_dir = "/tmp/failover1"
    config1.clustering_etcd_endpoints = "localhost:12379"
    config1.clustering_advertised_uri = "tcp://localhost:5681"
    config1.clustering_port = 5681
    config1.amqp_port = 5671
    config1.http_port = 15671
    controller1 = LavinMQ::Clustering::Controller.new(config1)

    config2 = LavinMQ::Config.new
    config2.data_dir = "/tmp/failover2"
    config2.clustering_etcd_endpoints = "localhost:12379"
    config2.clustering_advertised_uri = "tcp://localhost:5682"
    config2.clustering_port = 5682
    config2.amqp_port = 5672
    config2.http_port = 15672
    controller2 = LavinMQ::Clustering::Controller.new(config2)

    listen = Channel(String?).new
    spawn(name: "etcd elect leader spec") do
      etcd = LavinMQ::Etcd.new("localhost:12379")
      etcd.elect_listen("lavinmq/leader") do |value|
        listen.send value
      end
    rescue SpecExit
      # expect this when etcd nodes are terminated
    end
    sleep 0.5.seconds
    spawn(name: "failover1") do
      controller1.run { }
    rescue SpecExit
    end
    spawn(name: "failover2") do
      controller2.run { }
    rescue SpecExit
    end
    sleep 0.1.seconds
    leader = listen.receive
    case leader
    when /1$/
      controller1.stop
      listen.receive.should match /2$/
      sleep 0.1.seconds
      controller2.stop
    when /2$/
      controller2.stop
      listen.receive.should match /1$/
      sleep 0.1.seconds
      controller1.stop
    else fail("no leader elected")
    end
  end

  it "steps down if it wins the election while not in the ISR" do
    config1 = LavinMQ::Config.new
    config1.data_dir = "/tmp/isr-stepdown1"
    config1.clustering_etcd_endpoints = "localhost:12379"
    config1.clustering_advertised_uri = "tcp://localhost:5683"
    FileUtils.rm_rf config1.data_dir
    controller1 = LavinMQ::Clustering::Controller.new(config1)

    config2 = LavinMQ::Config.new
    config2.data_dir = "/tmp/isr-stepdown2"
    config2.clustering_etcd_endpoints = "localhost:12379"
    config2.clustering_advertised_uri = "tcp://localhost:5684"
    FileUtils.rm_rf config2.data_dir
    controller2 = LavinMQ::Clustering::Controller.new(config2)

    etcd = LavinMQ::Etcd.new("localhost:12379")
    leader1 = Channel(Nil).new
    spawn(name: "elect listen spec") do
      etcd.elect_listen("lavinmq/leader") do |value|
        leader1.send nil if value == config1.clustering_advertised_uri
      end
    rescue SpecExit
    end
    sleep 0.1.seconds
    spawn(name: "stepdown ctrl1") do
      controller1.run { }
    rescue SpecExit
    end
    leader1.receive # controller1 is leader

    served2 = false
    stepped_down = Channel(Int32).new(1)
    spawn(name: "stepdown ctrl2") do
      controller2.run { served2 = true }
    rescue ex : SpecExit
      stepped_down.send ex.code
    end
    sleep 0.5.seconds # let controller2 queue its election candidacy

    # controller2 falls out of the ISR (e.g. lagging replication) while its
    # candidacy stays queued; the leader then dies.
    etcd.put("lavinmq/isr", controller1.id.to_s(36))
    controller1.stop

    # Winning the election out of the ISR means it lacks confirmed data:
    # it must step down instead of serving.
    select
    when code = stepped_down.receive
      code.should eq 3
    when timeout(10.seconds)
      fail "out-of-ISR election winner did not step down"
    end
    served2.should be_false
  ensure
    FileUtils.rm_rf "/tmp/isr-stepdown1"
    FileUtils.rm_rf "/tmp/isr-stepdown2"
  end

  it "does not reject its own URI while leadership is validating ISR" do
    with_datadir do |data_dir|
      config = LavinMQ::Config.new
      config.data_dir = data_dir
      config.clustering_advertised_uri = "tcp://localhost:5685"
      etcd = SelfLeaderEtcd.new(config.clustering_advertised_uri.not_nil!)
      coordinator = LavinMQ::Clustering::EtcdCoordinator.new(config, etcd)
      controller = SelfLeaderController.new(config, etcd, coordinator)
      done = Channel(Exception?).new(1)

      spawn(name: "self leader follower monitor spec") do
        controller.follow_leader_public
        done.send nil
      rescue ex
        done.send ex
      end

      etcd.observed.receive
      controller.mark_elected_for_spec

      select
      when ex = done.receive
        ex.should be_nil
      when timeout(500.milliseconds)
        fail "follower monitor kept waiting after this node won the election"
      end
    end
  end

  it "will release lease on shutdown", tags: "slow" do
    config = LavinMQ::Config.new
    config.data_dir = "/tmp/release-lease"
    config.clustering = true
    config.clustering_etcd_endpoints = "localhost:12379"
    config.clustering_advertised_uri = "tcp://localhost:5681"
    launcher = LavinMQ::Launcher.new(config)

    election_done = Channel(Nil).new
    etcd = LavinMQ::Etcd.new(config.clustering_etcd_endpoints)
    spawn do
      etcd.elect_listen("lavinmq/leader") { election_done.close }
    rescue SpecExit
    end

    spawn do
      launcher.run
    rescue SpecExit
    end

    # Wait until our "launcher" is leader
    election_done.receive?

    # The spec gets a lease to use in an election campaign
    lease = etcd.lease_grant(5)

    # graceful stop...
    spawn { launcher.stop }

    # Let the spec campaign for leadership...
    elected = Channel(Nil).new
    spawn do
      etcd.election_campaign("lavinmq/leader", "spec", lease.id)
      elected.close
    end

    # ... and verify spec is elected
    select
    when elected.receive?
    when timeout(1.seconds)
      fail("election campaign did not finish in time, leadership not released on launcher stop?")
    end
  end

  it "won't deadlock under high load when a follower disconnects [#926]" do
    replicator = LavinMQ::Clustering::Server.new(LavinMQ::Config.instance, NullCoordinator.new, 0)
    tcp_server = TCPServer.new("localhost", 0)
    spawn(replicator.listen(tcp_server), name: "repli server spec")

    client_io = TCPSocket.new("localhost", tcp_server.local_address.port)
    # This is raw clustering negotiation
    client_io.write LavinMQ::Clustering::Start
    client_io.write_bytes replicator.password.bytesize.to_u8, IO::ByteFormat::LittleEndian
    client_io.write replicator.password.to_slice
    # Read the password accepted byte (we assume it's correct)
    client_io.read_byte
    # Send the follower id
    client_io.write_bytes 2i32, IO::ByteFormat::LittleEndian
    client_io.flush
    client_lz4 = Compress::LZ4::Reader.new(client_io)
    # Two full syncs
    sha1_size = Digest::SHA1.new.digest_size
    2.times do
      loop do
        filename_len = client_lz4.read_bytes Int32, IO::ByteFormat::LittleEndian
        break if filename_len.zero?
        client_lz4.skip filename_len
        client_lz4.skip sha1_size
      end
      # 0 means we're done requesting files for this full sync
      client_io.write_bytes 0i32
      client_io.flush
    end

    test_path = "#{LavinMQ::Config.instance.data_dir}/path"
    Dir.mkdir_p LavinMQ::Config.instance.data_dir
    replicator.register_file(test_path)
    payload = "ABCD".to_slice

    appended = Channel(Bool).new
    spawn do
      # Fill the socket buffer
      offset = 0i64
      loop do
        replicator.append_bytes(test_path, payload, offset)
        offset += payload.bytesize
        appended.send true
      rescue IO::Error | Socket::Error | Channel::ClosedError
        break
      end
    end

    # Wait for lag to increase
    loop do
      select
      when appended.receive?
      when timeout 0.1.seconds
      end
      break if replicator.@followers.first?.try &.lag_in_bytes.>(0)
    end

    # Now disconnect the follower. Our "fill" fiber should continue or exit
    client_io.close

    select
    when appended.receive?
    when timeout 5.seconds
      deadlock = true
    end

    # If the fiber is blocked on a write to a closed socket, it might never send to 'appended'
    # but we want to make sure the replicator can still be closed
    replicator.try &.close
    deadlock = false if !deadlock # if it didn't deadlock yet, we're good

    appended.close
    if deadlock
      fail "deadlock detected"
    end
  ensure
    FileUtils.mkdir_p LavinMQ::Config.instance.data_dir
    replicator.try &.close
  end

  describe "checksum caching on followers" do
    it "can persist checksums for promotion" do
      with_clustering do |cluster|
        with_amqp_server(replicator: cluster.replicator) do |s|
          with_channel(s) do |ch|
            # Create a queue which will create files during streaming
            q = ch.queue("checksum_test")
            q.publish_confirm "test message"
          end

          # Wait for replication to complete
          wait_for { cluster.replicator.followers.first?.try &.lag_in_bytes == 0 }

          # Brief wait for any async operations
          sleep 0.1.seconds
        end

        # Close follower (simulating promotion) - this persists checksums
        follower = cluster.repli
        follower.close

        # Verify checksums were persisted to disk
        checksums_file = File.join(cluster.follower_config.data_dir, "checksums.sha1")
        File.exists?(checksums_file).should be_true
      end
    end

    it "checksums files during streaming" do
      with_clustering do |cluster|
        with_amqp_server(replicator: cluster.replicator) do |s|
          with_channel(s) do |ch|
            # Create a queue and publish messages
            q = ch.queue("checksum_test", durable: true)
            10.times { |i| q.publish_confirm "message #{i}", props: AMQP::Client::Properties.new(delivery_mode: 2) }
          end

          # Wait for replication to complete
          wait_for { cluster.replicator.followers.first?.try &.lag_in_bytes == 0 }

          # Brief wait for any async operations
          sleep 0.1.seconds
        end

        follower = cluster.repli
        follower.close

        # Verify checksums file exists and has entries
        checksums_file = File.join(cluster.follower_config.data_dir, "checksums.sha1")
        File.exists?(checksums_file).should be_true

        content = File.read(checksums_file)
        lines = content.lines

        # Should have checksums for multiple files (queue definition + message segments)
        lines.size.should be >= 2

        # Verify each line has correct checksum format: 40 hex chars, covered size, asterisk, path
        lines.each do |line|
          line.should match(/^[0-9a-f]{40} \d+ \*/)
        end

        # Should have checksum for the queue's message segment file
        # Queue creates files in %default/queues/<sha1 of queue name>/
        lines.any?(&.includes?("msgs.")).should be_true
      end
    end

    it "handles file deletions without crashing" do
      with_clustering do |cluster|
        with_amqp_server(replicator: cluster.replicator) do |s|
          with_channel(s) do |ch|
            # Create and delete a queue, which will delete its files
            q = ch.queue("checksum_delete_test")
            q.publish_confirm "test"
            q.delete
          end

          # Wait for replication to complete
          wait_for { cluster.replicator.followers.first?.try &.lag_in_bytes == 0 }

          # Brief wait for any async operations
          sleep 0.1.seconds
        end

        follower = cluster.repli

        # Should not crash when closing
        # Just call it and verify no exception is raised
        follower.close
      end
    end
  end

  describe "full sync when message store is closed" do
    it "succeeds when message store is already closed before sync" do
      msg_dir = File.join(LavinMQ::Config.instance.data_dir, "sync_after_close_test")
      FileUtils.mkdir_p(msg_dir)
      replicator = LavinMQ::Clustering::Server.new(LavinMQ::Config.instance, NullCoordinator.new, 0)
      msg_store = LavinMQ::MessageStore.new(msg_dir, replicator)
      populate_msg_store(msg_store)

      msg_store.close
      Fiber.yield # let the spawned close fiber run so MFiles are unmapped

      tcp_server = TCPServer.new("localhost", 0)
      spawn(replicator.listen(tcp_server), name: "repli server spec")

      do_full_sync(tcp_server, replicator).wait
    ensure
      replicator.try &.close
      tcp_server.try &.close
      FileUtils.rm_rf msg_dir if msg_dir
    end

    it "is not aborted when message store is closed concurrently" do
      msg_dir = File.join(LavinMQ::Config.instance.data_dir, "sync_close_concurrent_test")
      FileUtils.mkdir_p(msg_dir)
      replicator = LavinMQ::Clustering::Server.new(LavinMQ::Config.instance, NullCoordinator.new, 0)
      msg_store = LavinMQ::MessageStore.new(msg_dir, replicator)
      populate_msg_store(msg_store)

      tcp_server = TCPServer.new("localhost", 0)
      spawn(replicator.listen(tcp_server), name: "repli server spec")

      wg = WaitGroup.new(1)
      follower_ctx = do_full_sync(tcp_server, replicator, wg)

      wg.wait         # suspend until negotiation is done and files_with_hash has started
      msg_store.close # concurrent close — simulates a corrupt segment triggering close
      Fiber.yield     # let the spawned close fiber run: wg.wait → segment.close (munmap)
      follower_ctx.wait
    ensure
      replicator.try &.close
      tcp_server.try &.close
      FileUtils.rm_rf msg_dir if msg_dir
    end
  end

  it "replicates .queue file when queue is created" do
    with_clustering do |cluster|
      with_amqp_server(replicator: cluster.replicator) do |s|
        wait_for { cluster.replicator.followers.first?.try &.synced? }
        with_channel(s) do |ch|
          ch.queue("dotqueue_test", durable: true)
        end
        vhost = s.vhosts["/"]
        dotqfile = File.join(vhost.queue("dotqueue_test").as(LavinMQ::AMQP::Queue).@data_dir, ".queue")
        dotqfile_relative = dotqfile[(s.data_dir.size + 1)..]
        replicated_dotqfile = File.join(cluster.follower_config.data_dir, dotqfile_relative)
        wait_for { File.exists?(replicated_dotqfile) }
        File.exists?(replicated_dotqfile).should be_true
      end
    end
  end

  it "removes .queue file from follower when queue is deleted", tags: "slow" do
    with_clustering do |cluster|
      with_amqp_server(replicator: cluster.replicator) do |s|
        wait_for { cluster.replicator.followers.first?.try &.synced? }
        with_channel(s) do |ch|
          q = ch.queue("dotqueue_test", durable: true)
          vhost = s.vhosts["/"]
          dotqfile = File.join(vhost.queue("dotqueue_test").as(LavinMQ::AMQP::Queue).@data_dir, ".queue")
          dotqfile_relative = dotqfile[(s.data_dir.size + 1)..]
          replicated_dotqfile = File.join(cluster.follower_config.data_dir, dotqfile_relative)
          wait_for { File.exists?(replicated_dotqfile) }
          q.delete
          wait_for { !File.exists?(replicated_dotqfile) }
          File.exists?(replicated_dotqfile).should be_false
        end
      end
    end
  end

  it "removes empty queue dir from follower when queue is deleted" do
    with_clustering do |cluster|
      with_amqp_server(replicator: cluster.replicator) do |s|
        wait_for { cluster.replicator.followers.first?.try &.synced? }
        with_channel(s) do |ch|
          q = ch.queue("dirdelete_test", durable: true)
          q.publish_confirm "hello"
          qdir = s.vhosts["/"].queue("dirdelete_test").as(LavinMQ::AMQP::Queue).@data_dir
          qdir_relative = qdir[(s.data_dir.size + 1)..]
          replicated_qdir = File.join(cluster.follower_config.data_dir, qdir_relative)
          wait_for { cluster.replicator.followers.first?.try &.lag_in_bytes == 0 }
          wait_for { Dir.exists?(replicated_qdir) }
          q.delete
          wait_for { !Dir.exists?(replicated_qdir) }
        end
      end
    end
  end

  it "keeps the queue dir on follower when a segment is deleted but the queue isn't" do
    with_clustering do |cluster|
      with_amqp_server(replicator: cluster.replicator) do |s|
        wait_for { cluster.replicator.followers.first?.try &.synced? }
        with_channel(s) do |ch|
          q = ch.queue("segdelete_test", durable: true)
          body = "x" * (LavinMQ::Config.instance.segment_size // 100)
          # publish enough to span more than one segment, so an older fully-acked
          # segment can be deleted while the active write segment + .queue remain
          101.times { q.publish_confirm body }

          dq = s.vhosts["/"].queue("segdelete_test").as(LavinMQ::AMQP::DurableQueue)
          dq.@msg_store.@segments.size.should be > 1
          repl_qdir = File.join(cluster.follower_config.data_dir, dq.@data_dir[(s.data_dir.size + 1)..])
          wait_for { cluster.replicator.followers.first?.try &.lag_in_bytes == 0 }
          files_before = Dir.children(repl_qdir).size

          # consume and ack everything; fully-acked non-write segments get deleted
          q.subscribe(no_ack: false, &.ack)
          wait_for { dq.message_count == 0 && dq.@msg_store.@segments.size == 1 }
          wait_for { cluster.replicator.followers.first?.try &.lag_in_bytes == 0 }

          # a segment file was deleted, but the queue dir exists
          Dir.exists?(repl_qdir).should be_true
          Dir.children(repl_qdir).size.should be < files_before
        end
      end
    end
  end

  it "compacts and replicates a stream's consumer_offsets file when it fills [#2068]" do
    with_clustering do |cluster|
      expected = Bytes.new(0)
      follower_offsets_path = ""
      ctag = "ctag-" + "x" * 100
      with_amqp_server(replicator: cluster.replicator) do |s|
        wait_for { cluster.replicator.followers.first?.try &.synced? }
        queue_name = Random::Secure.hex
        with_channel(s) do |ch|
          q = ch.queue(queue_name, args: AMQP::Client::Arguments.new({"x-queue-type": "stream"}))
          q.publish_confirm "m"
        end

        store = s.vhosts["/"].queue(queue_name).as(LavinMQ::AMQP::Queue).@msg_store.as(LavinMQ::AMQP::StreamMessageStore)
        offsets_path = store.@consumer_offsets.@mfile.path
        follower_offsets_path = File.join(cluster.follower_config.data_dir, offsets_path[(s.data_dir.size + 1)..])

        # Fill consumer_offsets past its capacity to trigger compaction. Before
        # #2068's fix the first compaction raised ArgumentError because the
        # rebuilt .tmp MFile was never replication-registered.
        cap = store.@consumer_offsets.@mfile.capacity
        entry = 1 + ctag.bytesize + 8
        ((cap // entry) + 10).times do |i|
          store.store_consumer_offset(ctag, i.to_i64 + 1)
        end
        store.@consumer_offsets.size.should be < cap # got compacted

        # A write AFTER compaction must still succeed and replicate, proving the
        # MFile stayed registered through replace_file.
        store.store_consumer_offset(ctag, 9999_i64)
        store.last_offset_by_consumer_tag(ctag).should eq 9999_i64

        wait_for { cluster.replicator.followers.first?.try &.lag_in_bytes == 0 }
        expected = store.@consumer_offsets.@mfile.to_slice.dup
      end

      # The follower received the compacted file verbatim — its real data
      # length, not the sparse ftruncate capacity.
      File.exists?(follower_offsets_path).should be_true
      follower_bytes = File.open(follower_offsets_path, &.getb_to_end)
      follower_bytes.should eq expected
    end
  end

  it "does not replicate .queue file for non-durable queue" do
    with_clustering do |cluster|
      with_amqp_server(replicator: cluster.replicator) do |s|
        wait_for { cluster.replicator.followers.first?.try &.synced? }
        with_channel(s) do |ch|
          ch.queue("dotqueue_transient", durable: false)
        end
        vhost = s.vhosts["/"]
        dotqfile = File.join(vhost.queue("dotqueue_transient").as(LavinMQ::AMQP::Queue).@data_dir, ".queue")
        dotqfile_relative = dotqfile[(s.data_dir.size + 1)..]
        wait_for { File.exists?(dotqfile) }
        Fiber.yield
        cluster.replicator.with_file(dotqfile_relative) do |f, _size|
          f.should be_nil
        end
      end
    end
  end
end
