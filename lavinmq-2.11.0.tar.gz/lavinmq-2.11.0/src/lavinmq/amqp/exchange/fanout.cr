require "./exchange"

module LavinMQ
  module AMQP
    class FanoutExchange < Exchange
      @bindings = Set({Destination, BindingKey}).new

      def type : String
        "fanout"
      end

      def bindings_details : Array(BindingDetails)
        @bindings.map do |d, binding_key|
          BindingDetails.new(name, vhost.name, binding_key, d)
        end
      end

      def binding_count : Int32
        @bindings.size
      end

      def bind(destination : Destination, routing_key, arguments = nil)
        validate_delayed_binding!(destination)
        binding_key = BindingKey.new(routing_key, arguments)
        return false unless @bindings.add?({destination, binding_key})
        data = BindingDetails.new(name, vhost.name, binding_key, destination)
        upstreams_bound(data)
        true
      end

      def unbind(destination : Destination, routing_key, arguments = nil)
        binding_key = BindingKey.new(routing_key, arguments)
        return false unless @bindings.delete({destination, binding_key})
        data = BindingDetails.new(name, vhost.name, binding_key, destination)
        upstreams_unbound(data)
        delete if @auto_delete && @bindings.empty?
        true
      end

      protected def each_destination(routing_key : String, headers : AMQP::Table?, & : (LavinMQ::Queue | LavinMQ::Exchange) ->)
        @bindings.each do |destination, _binding_key|
          yield destination
        end
      end
    end
  end
end
