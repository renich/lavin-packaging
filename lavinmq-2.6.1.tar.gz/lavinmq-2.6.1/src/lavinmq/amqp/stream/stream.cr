require "../queue/durable_queue"
require "./stream_consumer"
require "./stream_message_store"
require "./stream_reader"

module LavinMQ::AMQP
  class Stream < DurableQueue
    def self.create(vhost : VHost, name : String,
                    exclusive : Bool = false, auto_delete : Bool = false,
                    arguments : AMQP::Table = AMQP::Table.new)
      # Validate non-arguments first
      raise LavinMQ::Error::PreconditionFailed.new("A stream cannot be exclusive") if exclusive
      raise LavinMQ::Error::PreconditionFailed.new("A stream cannot be auto-delete") if auto_delete

      validate_arguments!(arguments)
      new vhost, name, exclusive, auto_delete, arguments
    end

    def self.validate_arguments!(arguments)
      invalid_arguments = {
        "x-dead-letter-exchange",
        "x-dead-letter-routing-key",
        "x-expires",
        "x-delivery-limit",
        "x-overflow",
        "x-single-active-consumer",
        "x-max-priority",
      }

      arguments.each do |key, value|
        if invalid_arguments.includes?(key)
          raise LavinMQ::Error::PreconditionFailed.new("Argument #{key} not allowed for streams")
        end
        if key == "x-max-age"
          ArgumentValidator::MaxAgeValidator.new.validate!(key, value)
        end
      end

      super
    end

    protected def initialize(@vhost : VHost, @name : String,
                             @exclusive = false, @auto_delete = false,
                             @arguments = AMQP::Table.new)
      super
      spawn unmap_and_remove_segments_loop, name: "Stream#unmap_and_remove_segments_loop"
    end

    private def apply_policy_argument(key : String, value : JSON::Any) : Bool
      if key == "max-age"
        result = false
        if max_age_policy = parse_max_age(value.as_s?)
          if current_max = stream_msg_store.max_age
            if current_max > max_age_policy
              stream_msg_store.max_age = max_age_policy
              @effective_args.delete("x-max-age")
              result = true
            end
          else
            stream_msg_store.max_age = max_age_policy
            @effective_args.delete("x-max-age")
            result = true
          end
        end
        stream_msg_store.max_length = @max_length
        stream_msg_store.max_length_bytes = @max_length_bytes
        stream_msg_store.drop_overflow
        result
      else
        super(key, value)
      end
    end

    delegate last_offset, new_messages, find_offset, to: @msg_store.as(StreamMessageStore)

    private def message_expire_loop
      # Streams doesn't handle message expiration
    end

    private def queue_expire_loop
      # Streams doesn't handle queue expiration
    end

    private def init_msg_store(data_dir)
      replicator = @vhost.@replicator
      @msg_store = StreamMessageStore.new(data_dir, replicator, metadata: @metadata)
    end

    def stream_msg_store : StreamMessageStore
      @msg_store.as(StreamMessageStore)
    end

    # save message id / segment position
    def publish(msg : Message) : Bool
      return false if @state.closed?
      @msg_store_lock.synchronize do
        @msg_store.push(msg)
        @publish_count.add(1, :relaxed)
      end
      # Notify all waiting stream consumers about new messages
      notify_all_stream_consumers
      true
    rescue ex : MessageStore::Error
      @log.error(ex) { "Queue closed due to error" }
      close
      raise ex
    end

    # Streams does not support basic_get, so always returns `false`
    def basic_get(no_ack, force = false, & : Envelope -> Nil) : Bool
      false
    end

    def reader(offset)
      StreamReader.new(self, offset)
    end

    def consume_get(consumer : AMQP::StreamConsumer, & : Envelope -> Nil) : Bool
      get(consumer) do |env|
        yield env
        if env.redelivered
          @redeliver_count.add(1, :relaxed)
        else
          @deliver_count.add(1, :relaxed)
          @deliver_get_count.add(1, :relaxed)
        end
      end
    end

    def store_consumer_offset(consumer_tag : String, offset : Int64) : Nil
      stream_msg_store.store_consumer_offset(consumer_tag, offset)
    end

    # yield the next message in the ready queue
    # returns true if a message was deliviered, false otherwise
    # if we encouncer an unrecoverable ReadError, close queue
    private def get(consumer : AMQP::StreamConsumer, & : Envelope -> Nil) : Bool
      raise ClosedError.new if @closed
      env = @msg_store_lock.synchronize { @msg_store.shift?(consumer) } || return false
      yield env # deliver the message
      true
    rescue ex : MessageStore::Error
      @log.error(ex) { "Queue closed due to error" }
      close
      raise ClosedError.new(cause: ex)
    end

    def ack(sp : SegmentPosition) : Nil
    end

    def reject(sp : SegmentPosition, requeue : Bool)
    end

    private def drop_overflow : Nil
      # Overflow handling is done in StreamMessageStore
    end

    private def notify_all_stream_consumers
      @consumers.each do |consumer|
        if stream_consumer = consumer.as?(AMQP::StreamConsumer)
          stream_consumer.notify_new_message if stream_consumer.waiting_for_messages?
        end
      end
    end

    private def handle_arguments
      super
      @effective_args << "x-queue-type"
      if max_age = parse_max_age(@arguments["x-max-age"]?)
        stream_msg_store.max_age = max_age
        @effective_args << "x-max-age"
      end
      stream_msg_store.max_length = @max_length
      stream_msg_store.max_length_bytes = @max_length_bytes
      stream_msg_store.drop_overflow
    end

    private def parse_max_age(value) : Time::Span | Time::MonthSpan | Nil
      return if value.nil?
      if str = value.as?(String)
        if match = str.match(/\A(\d+)([YMDhms])\z/)
          int = match[1].to_i64
          case match[2]
          when "s" then Time::Span.new(seconds: int)
          when "m" then Time::Span.new(minutes: int)
          when "h" then Time::Span.new(hours: int)
          when "D" then Time::Span.new(days: int)
          when "M" then Time::MonthSpan.new(int)
          when "Y" then Time::MonthSpan.new(int * 12)
          else          raise LavinMQ::Error::PreconditionFailed.new("max-age unit unit")
          end
        else
          raise LavinMQ::Error::PreconditionFailed.new("max-age format invalid")
        end
      else
        raise LavinMQ::Error::PreconditionFailed.new("max-age must be a string")
      end
    end

    def purge(max_count : Int = UInt32::MAX) : UInt32
      delete_count = @msg_store_lock.synchronize { @msg_store.purge(max_count) }
      @log.info { "Purged #{delete_count} messages" }
      delete_count
    rescue ex : MessageStore::Error
      @log.error(ex) { "Queue closed due to error" }
      close
      raise ex
    end

    private def unmap_and_remove_segments_loop
      sleep rand(60).seconds
      until closed?
        sleep 60.seconds
        unmap_and_remove_segments
      end
    end

    private def unmap_and_remove_segments
      used_segments = Set(UInt32).new
      @consumers_lock.synchronize do
        @consumers.each do |consumer|
          used_segments << consumer.as(AMQP::StreamConsumer).segment
        end
      end
      @msg_store_lock.synchronize do
        stream_msg_store.drop_overflow
        stream_msg_store.unmap_segments(except: used_segments)
      end
    end
  end
end
