require "json"
require "./sortable_json"

module LavinMQ
  module PolicyTarget
    getter policy : Policy?
    getter operator_policy : OperatorPolicy?
    getter effective_policy_args = Array(String).new
    # apply_policies is spawned per policy/parameter add & delete, so concurrent
    # applies can hit the same resource; serialize them to protect the shared
    # @effective_args / store state.
    @policy_lock = Mutex.new(:reentrant)

    def reapply_policy
      apply_policy(@policy, @operator_policy)
    end

    def apply_policy(policy : Policy?, operator_policy : OperatorPolicy?)
      @policy_lock.synchronize do
        clear_policy
        effective_policy_args = Array(String).new
        Policy.merge_definitions(policy, operator_policy).each do |key, value|
          if apply_policy_argument(key, value)
            effective_policy_args << key
          end
        rescue ex
          # Skip an invalid policy argument and carry on with the rest.
          Log.warn(exception: ex) { "Error applying policy argument #{key}=#{value}: #{ex.message}" }
        end
        @effective_policy_args = effective_policy_args
        @policy = policy
        @operator_policy = operator_policy
        after_policy_applied
      end
    end

    def clear_policy
      clear_policy_arguments
      @effective_policy_args.clear
      @policy = nil
      @operator_policy = nil
    end

    # This can be overriden if the child class needs to do something after
    # a policy has been applied.
    def after_policy_applied
    end

    abstract def clear_policy_arguments
    # Return true if applied
    abstract def apply_policy_argument(key : String, value : JSON::Any) : Bool
  end

  class Policy
    SUPPORTED_POLICIES = {"max-length", "max-length-bytes", "message-ttl", "expires", "overflow",
                          "dead-letter-exchange", "dead-letter-routing-key", "federation-upstream",
                          "federation-upstream-set", "delivery-limit", "max-age",
                          "alternate-exchange", "delayed-message"}
    enum Target
      All
      Queues
      Exchanges
      ClassicQueues
      QuorumQueues
      Streams

      def to_json(json : JSON::Builder)
        to_s.underscore.to_json(json)
      end
    end

    include SortableJSON
    include JSON::Serializable

    getter name : String
    getter vhost : String
    getter pattern : Regex
    @[JSON::Field(key: "apply-to")]
    getter apply_to : Target
    getter priority : Int8
    getter definition : Hash(String, JSON::Any)

    def initialize(@name : String, @vhost : String, @pattern : Regex, @apply_to : Target,
                   @definition : Hash(String, JSON::Any), @priority : Int8)
    end

    def match?(resource : Queue)
      case @apply_to
      in .all?, .queues?
        @pattern.matches?(resource.name)
      in .classic_queues?, .quorum_queues?
        # LavinMQ has no quorum queues; its regular queues support the same
        # policies RabbitMQ allows for quorum queues (delivery-limit), so
        # both targets apply to non-stream queues.
        return false if resource.is_a?(AMQP::Stream)
        @pattern.matches?(resource.name)
      in .streams?
        return false unless resource.is_a?(AMQP::Stream)
        @pattern.matches?(resource.name)
      in .exchanges?
        false
      end
    end

    def match?(resource : Exchange)
      return false unless @apply_to.all? || @apply_to.exchanges?
      @pattern.matches?(resource.name)
    end

    def details_tuple
      {
        name:       @name,
        vhost:      @vhost,
        pattern:    @pattern,
        "apply-to": @apply_to,
        priority:   @priority,
        definition: @definition,
      }
    end

    def self.merge_definitions(p1 : Policy, p2 : Policy) : Hash(String, JSON::Any)
      d1 = p1.definition
      d2 = p2.definition
      merged = Hash(String, JSON::Any).new
      {d1, d2}.each do |d|
        d.each do |k, v|
          if value = v.as_i64?
            merged[k] = v unless merged[k]?.try(&.as_i64?.try { |i| i < value })
          else
            merged[k] = v
          end
        end
      end
      merged.select { |key, _| SUPPORTED_POLICIES.includes?(key) }
    end

    def self.merge_definitions(p1 : Nil, p2 : Policy) : Hash(String, JSON::Any)
      p2.definition.select { |key, _| SUPPORTED_POLICIES.includes?(key) }
    end

    def self.merge_definitions(p1 : Policy, p2 : Nil) : Hash(String, JSON::Any)
      p1.definition.select { |key, _| SUPPORTED_POLICIES.includes?(key) }
    end

    def self.merge_definitions(p1 : Nil, p2 : Nil) : Hash(String, JSON::Any)
      Hash(String, JSON::Any).new
    end
  end

  class OperatorPolicy < Policy
    ALLOWED_ARGUMENTS = ["expires", "message-ttl", "max-length", "max-length-bytes"]

    def initialize(@name : String, @vhost : String, @pattern : Regex, @apply_to : Target,
                   @definition : Hash(String, JSON::Any), @priority : Int8)
      super
      raise "Forbidded operator policy" unless (@definition.keys - ALLOWED_ARGUMENTS).empty?
    end
  end
end
