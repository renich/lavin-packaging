require "./spec_helper"
require "file_utils"
require "log/spec"
require "time"
require "../src/lavinmq/message_store"

class SpyReplicator
  include LavinMQ::Clustering::Replicator

  getter registered_files = Hash(String, Symbol).new
  getter deleted_files = Set(String).new
  getter replaced_files = Array(String).new

  def register_file(path : String)
    @registered_files[path] = :path
  end

  def register_file(file : File)
    @registered_files[file.path] = :file
  end

  def register_file(mfile : MFile)
    @registered_files[mfile.path] = :mfile
  end

  def replace_file(path : String)
    @replaced_files << path
  end

  def replace_file(mfile : MFile)
    @replaced_files << mfile.path
  end

  def append(path : String, pos : Int, length : Int)
  end

  def append_value(path : String, value : UInt32 | Int32, offset : Int64)
  end

  def append_bytes(path : String, bytes : Bytes, offset : Int64)
  end

  def delete_file(path : String)
    @deleted_files << path
  end

  def delete_dir(path : String)
  end

  def followers : Array(LavinMQ::Clustering::Follower)
    Array(LavinMQ::Clustering::Follower).new
  end

  def syncing_followers : Array(LavinMQ::Clustering::Follower)
    Array(LavinMQ::Clustering::Follower).new
  end

  def all_followers : Array(LavinMQ::Clustering::Follower)
    Array(LavinMQ::Clustering::Follower).new
  end

  def isr_dirty? : Bool
    false
  end

  def flush_isr : Nil
  end

  def wait_for_followers : Nil
  end

  def request_fsync(paths : Enumerable(String)) : Nil
  end

  def request_syncfs : Nil
  end

  def close
  end

  def listen(server : TCPServer)
  end

  def clear
  end

  def password : String
    ""
  end
end

def zero_fill_segments(dir, segs)
  segs.each do |seg|
    id = seg.to_s.rjust(10, '0')
    File.delete?(File.join(dir, "meta.#{id}"))
    File.open(File.join(dir, "msgs.#{id}"), "w", &.truncate(LavinMQ::Config.instance.segment_size))
  end
end

def mktmpdir(&)
  path = File.tempname
  Dir.mkdir_p(path)
  begin
    yield path
  ensure
    FileUtils.rm_r(path)
  end
end

# Pushes 12 msgs (9 in seg 1, 3 in seg 2), shifts them all, yields so the spec
# can ack some, then cuts the last 3 msgs off seg 1 at a record boundary while
# meta.0000000001 still counts 9: the state a follower was left in when its
# appends went to a replaced file.
def push_with_lost_tail(dir, &) : Array(LavinMQ::SegmentPosition)
  size = LavinMQ::Config.instance.segment_size.to_u64 // 10 + 1
  msg = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k",
    AMQ::Protocol::Properties.new, size, IO::Memory.new("a" * size))
  store = LavinMQ::MessageStore.new(dir, nil, durable: true)
  sps = Array(LavinMQ::SegmentPosition).new
  12.times { sps << store.push(msg) }
  sps.count(&.segment.==(sps.first.segment)).should eq 9
  envs = Array(LavinMQ::Envelope).new
  12.times { envs << store.shift?.should_not be_nil }
  yield store, envs
  store.close
  seg1 = File.join(dir, "msgs.#{sps.first.segment.to_s.rjust(10, '0')}")
  File.open(seg1, "r+", &.truncate(sps[6].position.to_i64))
  sps
end

def push_with_lost_tail(dir) : Array(LavinMQ::SegmentPosition)
  push_with_lost_tail(dir) { }
end

def with_store(*, replicator = nil, durable = true, &)
  mktmpdir do |dir|
    store = LavinMQ::MessageStore.new(dir, replicator, durable: durable)
    begin
      yield store, dir
    ensure
      store.close
    end
  end
end

# Sets up a fully-acked segment 1 and appends 2 orphaned ack positions past the
# real data end — simulates an unclean shutdown where ack writes survived but
# the matching msg writes didn't.
def setup_orphaned_ack_scenario(dir)
  body = "a" * 1000
  store = LavinMQ::MessageStore.new(dir, nil, durable: true)
  5.times { store.push(LavinMQ::Message.new("ex", "rk", body)) }
  while env = store.shift?
    store.delete(env.segment_position)
  end
  store.close
  wait_for { store.closed }

  msg_path = File.join(dir, "msgs.0000000001")
  real_data_end = File.size(msg_path).to_u32
  File.open(File.join(dir, "acks.0000000001"), "a") do |f|
    f.write_bytes(real_data_end, IO::ByteFormat::SystemEndian)
    f.write_bytes(real_data_end + 1024u32, IO::ByteFormat::SystemEndian)
  end
end

private def synced_message(body) : LavinMQ::Message
  msg = LavinMQ::Message.new("", "rk", body)
  msg.needs_sync = true
  msg
end

{% if flag?(:linux) %}
  # Records the advice segments have when the store starts loading them
  class AdviceOnLoadStore < LavinMQ::MessageStore
    class_getter advice_on_load = Array({String, Array(String)}).new
    # Pages of each segment in the page cache when counting its messages starts
    class_getter cached_on_load = Array(Int32).new

    private def read_metadata_file(seg, mfile)
      @@advice_on_load << {"read_metadata_file", vm_flags(mfile.path)}
      super
    end

    private def produce_metadata(seg, mfile)
      @@advice_on_load << {"produce_metadata", vm_flags(mfile.path)}
      @@cached_on_load << cached_pages(mfile.path)
      super
    end
  end
{% end %}

# A message body that calls a block once half of it is read, which is when
# that half is written to the segment
class HalfwayBody < IO
  def initialize(@body : Bytes, &@halfway : ->)
    @pos = 0
  end

  def read(slice : Bytes) : Int32
    half = @body.size // 2
    @halfway.call if @pos == half
    limit = @pos < half ? half : @body.size
    len = Math.min(slice.size, limit - @pos)
    @body[@pos, len].copy_to(slice)
    @pos += len
    len
  end

  def write(slice : Bytes) : Nil
    raise IO::Error.new("Can't write to a HalfwayBody")
  end
end

private def halfway_message(bodysize, &halfway : ->) : LavinMQ::Message
  body = HalfwayBody.new(("b" * bodysize).to_slice, &halfway)
  LavinMQ::Message.new(RoughTime.unix_ms, "ex", "rk", AMQ::Protocol::Properties.new, bodysize.to_u64, body)
end

# Copies the store's segment as it is in the page cache, at its full capacity,
# to a new directory. That's what a crash at that point leaves on disk.
private def crash_image(store, dir, name) : String
  image_dir = File.join(dir, name)
  Dir.mkdir(image_dir)
  File.copy(store.@segments.last_value.path, File.join(image_dir, "msgs.0000000001"))
  image_dir
end

private def shift_body(store) : String
  env = store.shift?.should_not be_nil
  String.new(env.message.body)
end

# Spec instrumentation: fails the unlink of *path*, like a crash between the
# unlink of a segment and that of its ack file
class File
  class_property fail_delete_of : String? = nil

  def self.delete(path : Path | String) : Nil
    raise File::Error.new("Spec unlink failure", file: path.to_s) if @@fail_delete_of == path.to_s
    previous_def
  end

  def self.delete?(path : Path | String) : Bool
    raise File::Error.new("Spec unlink failure", file: path.to_s) if @@fail_delete_of == path.to_s
    previous_def
  end
end

describe LavinMQ::MessageStore do
  # Regression: avg_bytesize is read without the queue's lock (HTTP API,
  # stats), so the store can become empty between its zero check and the
  # division, which turned into Infinity and raised OverflowError
  it "#avg_bytesize doesn't raise while the store empties concurrently", tags: "slow" do
    with_store do |store|
      sp = store.push(LavinMQ::Message.new("ex", "rk", "body"))
      ctx = Fiber::ExecutionContext::Parallel.new("avg-bytesize", 4)
      done = Atomic(Bool).new(false)
      errors = Atomic(Int32).new(0)
      wg = WaitGroup.new
      3.times do
        wg.add(1)
        ctx.spawn do
          until done.get(:acquire)
            begin
              store.avg_bytesize
            rescue OverflowError
              errors.add(1, :relaxed)
            end
          end
        ensure
          wg.done
        end
      end
      200_000.times do
        store.shift?.should_not be_nil
        store.requeue(sp)
      end
      done.set(true, :release)
      wg.wait
      errors.get.should eq 0
    end
  end

  it "deletes orphaned ack files" do
    mktmpdir do |dir|
      # Create a dummy msgs file
      File.write(File.join(dir, "msgs.0000000001"), "\x04\x00\x00\x00")
      # Create a corresponding acks file
      File.write(File.join(dir, "acks.0000000001"), "")
      # Create an orphaned acks file
      File.write(File.join(dir, "acks.0000000002"), "")

      store = LavinMQ::MessageStore.new(dir, nil)
      store.close

      File.exists?(File.join(dir, "acks.0000000001")).should be_true
      File.exists?(File.join(dir, "acks.0000000002")).should be_false
    end
  end

  it "unlinks an emptied segment before its acks, so a crash in between doesn't bring its messages back" do
    mktmpdir do |dir|
      # One message per segment
      msg_size = LavinMQ::Config.instance.segment_size.to_u64 // 2 + 1
      msg = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k",
        AMQ::Protocol::Properties.new, msg_size, IO::Memory.new("a" * msg_size))
      store = LavinMQ::MessageStore.new(dir, nil, durable: true)
      begin
        3.times { store.push(msg) }
        env = store.shift?.should_not be_nil
        File.fail_delete_of = File.join(dir, "msgs.0000000001")
        expect_raises(LavinMQ::MessageStore::Error) { store.delete(env.segment_position) }
      ensure
        File.fail_delete_of = nil
        store.close
      end
      File.exists?(File.join(dir, "acks.0000000001")).should be_true

      store = LavinMQ::MessageStore.new(dir, nil, durable: true)
      store.size.should eq 2
      File.exists?(File.join(dir, "msgs.0000000001")).should be_false
      store.close
    end
  end

  it "unlinks an unused segment before its acks, so a crash in between doesn't bring its messages back" do
    mktmpdir do |dir|
      msg_size = LavinMQ::Config.instance.segment_size.to_u64 // 2 + 1
      msg = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k",
        AMQ::Protocol::Properties.new, msg_size, IO::Memory.new("a" * msg_size))
      # A fully acked segment that is kept as the one written to
      store = LavinMQ::MessageStore.new(dir, nil, durable: true)
      store.push(msg)
      env = store.shift?.should_not be_nil
      store.delete(env.segment_position)
      store.close

      store = LavinMQ::MessageStore.new(dir, nil, durable: true)
      begin
        # The rollover deletes the unused segment
        File.fail_delete_of = File.join(dir, "msgs.0000000001")
        expect_raises(File::Error) { store.push(msg) }
      ensure
        File.fail_delete_of = nil
        store.close
      end
      File.exists?(File.join(dir, "acks.0000000001")).should be_true

      store = LavinMQ::MessageStore.new(dir, nil, durable: true)
      store.size.should eq 0
      File.exists?(File.join(dir, "msgs.0000000001")).should be_false
      store.close
    end
  end

  it "unmaps the segments it opened when loading raises" do
    mktmpdir do |dir|
      File.write(File.join(dir, "msgs.0000000001"), "\x04\x00\x00\x00")
      # MFile can't open a directory, so loading fails after segment 1 is mapped
      Dir.mkdir(File.join(dir, "msgs.0000000002"))
      count_before = MFile.mmap_count
      10.times do
        expect_raises(File::Error) { LavinMQ::MessageStore.new(dir, nil) }
      end
      MFile.mmap_count.should eq count_before
    end
  end

  describe "a message that isn't completely written" do
    it "isn't loaded after a crash while its body was written" do
      mktmpdir do |dir|
        store = LavinMQ::MessageStore.new(File.join(dir, "store").tap { |d| Dir.mkdir(d) }, nil)
        store.push(LavinMQ::Message.new("ex", "rk", "first"))
        crashed = ""
        store.push(halfway_message(4096) { crashed = crash_image(store, dir, "crashed") })
        store.close

        store = LavinMQ::MessageStore.new(crashed, nil)
        store.size.should eq 1
        # A shorter message takes its place, and the rest of it must not be
        # loaded as a message after another crash
        store.push(LavinMQ::Message.new("ex", "rk", "second"))
        crashed_again = crash_image(store, dir, "crashed_again")
        store.close

        store = LavinMQ::MessageStore.new(crashed_again, nil)
        store.size.should eq 2
        shift_body(store).should eq "first"
        shift_body(store).should eq "second"
        store.shift?.should be_nil
        store.close
      end
    end

    it "is removed when its body can't be read" do
      mktmpdir do |dir|
        store = LavinMQ::MessageStore.new(File.join(dir, "store").tap { |d| Dir.mkdir(d) }, nil)
        store.push(LavinMQ::Message.new("ex", "rk", "first"))
        expect_raises(IO::Error, "Spec body failure") do
          store.push(halfway_message(4096) { raise IO::Error.new("Spec body failure") })
        end
        store.size.should eq 1
        store.push(LavinMQ::Message.new("ex", "rk", "second"))
        crashed = crash_image(store, dir, "crashed")
        shift_body(store).should eq "first"
        shift_body(store).should eq "second"
        store.close

        store = LavinMQ::MessageStore.new(crashed, nil)
        store.size.should eq 2
        shift_body(store).should eq "first"
        shift_body(store).should eq "second"
        store.close
      end
    end
  end

  it "ignores a delete for a segment purged after the message was shifted" do
    with_store do |store, dir|
      msg_size = LavinMQ::Config.instance.segment_size.to_u64 - (LavinMQ::BytesMessage::MIN_BYTESIZE + 5)
      msg = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k", AMQ::Protocol::Properties.new, msg_size, IO::Memory.new("a" * msg_size))
      3.times { store.push(msg) }
      # Shifting into the second segment moves the read segment past the first,
      # so purge_all deletes the first
      sp = store.shift?.should_not be_nil
      store.shift?.should_not be_nil
      store.purge_all
      store.@segments.has_key?(sp.segment_position.segment).should be_false

      # Like a release or dead-lettering that routed the message outside the lock
      store.delete(sp.segment_position)
      store.@acks.has_key?(sp.segment_position.segment).should be_false
      File.exists?(File.join(dir, "acks.#{sp.segment_position.segment.to_s.rjust(10, '0')}")).should be_false
    end
  end

  # Verifies #1296
  it "deletes unused segments on startup when multiple 'empty' segments exist" do
    with_store do |store, dir|
      msg_size = LavinMQ::Config.instance.segment_size.to_u64 - (LavinMQ::BytesMessage::MIN_BYTESIZE + 5)
      msg = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k", AMQ::Protocol::Properties.new, msg_size, IO::Memory.new("a" * msg_size))

      5.times { store.push(msg) }
      store.@segments.size.should eq 5
      store.close
      wait_for { store.closed }

      # Write ack files
      store.@segments.keys.each do |seg|
        break if seg == store.@segments.keys.last # don't ack the last segment
        path = File.join(dir, "acks." + seg.to_s.rjust(10, '0'))
        File.open(path, "w") do |f|
          f.write_bytes(4u32) # only one message per segment
        end
      end

      store = LavinMQ::MessageStore.new(dir, nil, durable: true)
      segment_files = Dir.glob(File.join(dir, "msgs.*")).count &.match(/msgs.\d{10}$/)
      store.@segments.size.should eq 1
      segment_files.should eq 1
    end
  end

  it "writes to a writable segment after a zero-filled last segment is dropped at load" do
    mktmpdir do |dir|
      store = LavinMQ::MessageStore.new(dir, nil)
      body = "x" * 1000
      (LavinMQ::Config.instance.segment_size * 5 // 2 // 1000).times { store.push(LavinMQ::Message.new("ex", "rk", body)) }
      store.close
      last = Dir.children(dir).select(&.starts_with?("msgs.")).max
      # A power loss after a rollover: the last segment lost its tail and meta
      # file, and the next one is at its full size but zero-filled
      File.delete?(File.join(dir, last.sub("msgs.", "meta.")))
      File.open(File.join(dir, last), "r+") do |f|
        f.seek(f.size // 2)
        f.write(Bytes.new(f.size - f.size // 2))
      end
      next_seg = File.join(dir, "msgs.#{(last[5..].to_u32 + 1).to_s.rjust(10, '0')}")
      File.open(next_seg, "w", &.truncate(LavinMQ::Config.instance.segment_size))

      store = LavinMQ::MessageStore.new(dir, nil)
      begin
        store.@wfile.path.should eq next_seg
        store.@wfile.@readonly.should be_false # a write to a read-only mapping segfaults
        sp = store.push(LavinMQ::Message.new("ex", "rk", "after restart"))
        String.new(store[sp].body).should eq "after restart"
      ensure
        store.close
      end
    end
  end

  it "counts a message written after a zero-filled last segment is dropped when the segment before it kept its meta file" do
    mktmpdir do |dir|
      store = LavinMQ::MessageStore.new(dir, nil)
      body = "x" * 1000
      (LavinMQ::Config.instance.segment_size * 5 // 2 // 1000).times { store.push(LavinMQ::Message.new("ex", "rk", body)) }
      store.close
      last = Dir.children(dir).select(&.starts_with?("msgs.")).max
      # The rollover reached the disk with the meta file, the new segment's header didn't
      File.delete(File.join(dir, last))
      File.open(File.join(dir, last), "w", &.truncate(LavinMQ::Config.instance.segment_size))

      store = LavinMQ::MessageStore.new(dir, nil)
      size = store.size
      store.push(LavinMQ::Message.new("ex", "rk", "after restart"))
      store.close

      store = LavinMQ::MessageStore.new(dir, nil)
      begin
        store.size.should eq size + 1
      ensure
        store.close
      end
    end
  end

  it "replicates a message written to a segment that was recreated at load" do
    replicator = LavinMQ::Clustering::Server.new(LavinMQ::Config.instance, NullCoordinator.new, 0)
    begin
      # A zero-filled only segment, a zero-filled last segment, and two zero-filled last segments
      many = LavinMQ::Config.instance.segment_size * 5 // 2 // 1000
      { {1, 1}, {many, 1}, {many, 2} }.each do |msgs, zero_filled|
        mktmpdir do |dir|
          store = LavinMQ::MessageStore.new(dir, nil)
          msgs.times { store.push(LavinMQ::Message.new("ex", "rk", "x" * 1000)) }
          segs = store.@segments.keys.last(zero_filled)
          store.close
          zero_fill_segments(dir, segs)

          store = LavinMQ::MessageStore.new(dir, replicator)
          begin
            store.@wfile.path.should eq File.join(dir, "msgs.#{segs.first.to_s.rjust(10, '0')}")
            sp = store.push(LavinMQ::Message.new("ex", "rk", "after restart"))
            String.new(store[sp].body).should eq "after restart"
          ensure
            store.close
          end
        end
      end
    ensure
      replicator.close
    end
  end

  it "keeps a stream's offsets after a zero-filled last segment is dropped when the first segment is gone" do
    mktmpdir do |dir|
      store = LavinMQ::AMQP::StreamMessageStore.new(dir, nil)
      body = "x" * 1000
      (LavinMQ::Config.instance.segment_size * 5 // 2 // 1000).times { store.push(LavinMQ::Message.new("ex", "rk", body)) }
      segs = store.@segments.keys
      middle = segs[-2]
      last_offset = store.@segment_first_offset[middle] + store.@segment_msg_count[middle] - 1
      store.close
      # Retention dropped the first segment, then a power loss zero-filled the last one
      File.delete(File.join(dir, "msgs.#{segs.first.to_s.rjust(10, '0')}"))
      File.delete(File.join(dir, "meta.#{segs.first.to_s.rjust(10, '0')}"))
      last = File.join(dir, "msgs.#{segs.last.to_s.rjust(10, '0')}")
      File.delete(last)
      File.open(last, "w", &.truncate(LavinMQ::Config.instance.segment_size))

      store = LavinMQ::AMQP::StreamMessageStore.new(dir, nil)
      store.last_offset.should eq last_offset
      store.push(LavinMQ::Message.new("ex", "rk", "after restart"))
      store.close

      store = LavinMQ::AMQP::StreamMessageStore.new(dir, nil)
      begin
        store.last_offset.should eq last_offset + 1
      ensure
        store.close
      end
    end
  end

  it "keeps a stream's offsets after two zero-filled last segments" do
    mktmpdir do |dir|
      store = LavinMQ::AMQP::StreamMessageStore.new(dir, nil)
      body = "x" * 1000
      (LavinMQ::Config.instance.segment_size * 5 // 2 // 1000).times { store.push(LavinMQ::Message.new("ex", "rk", body)) }
      segs = store.@segments.keys
      last_offset = store.@segment_first_offset[segs.first] + store.@segment_msg_count[segs.first] - 1
      store.close
      # A power loss soon after two rollovers: only the first segment reached the disk
      zero_fill_segments(dir, segs[1..])

      store = LavinMQ::AMQP::StreamMessageStore.new(dir, nil)
      store.last_offset.should eq last_offset
      store.push(LavinMQ::Message.new("ex", "rk", "after restart"))
      store.close

      store = LavinMQ::AMQP::StreamMessageStore.new(dir, nil)
      begin
        store.last_offset.should eq last_offset + 1
      ensure
        store.close
      end
    end
  end

  it "keeps a message written to a segment that got the id of a dropped segment with acks" do
    mktmpdir do |dir|
      store = LavinMQ::MessageStore.new(dir, nil)
      body = "x" * 1000
      sps = Array(LavinMQ::SegmentPosition).new
      (LavinMQ::Config.instance.segment_size * 5 // 2 // 1000).times { sps << store.push(LavinMQ::Message.new("ex", "rk", body)) }
      segs = store.@segments.keys
      size = store.@segment_msg_count[segs.first]
      store.delete(sps.find! { |sp| sp.segment == segs[1] })
      store.close
      zero_fill_segments(dir, segs[1..])

      store = LavinMQ::MessageStore.new(dir, nil)
      store.@segments.keys.should eq segs[0..1]
      store.size.should eq size
      store.push(LavinMQ::Message.new("ex", "rk", "after restart"))
      store.close

      store = LavinMQ::MessageStore.new(dir, nil)
      begin
        store.size.should eq size + 1
      ensure
        store.close
      end
    end
  end

  it "loads a store whose segments before the last one are empty files" do
    with_store do |store, dir|
      body = "x" * (LavinMQ::Config.instance.segment_size // 2)
      3.times { store.push(LavinMQ::Message.new("ex", "rk", body)) }
      store.@segments.size.should eq 3
      store.close
      # A crash can leave a segment created but not yet truncated to its size
      File.write(File.join(dir, "msgs.0000000001"), "")
      File.write(File.join(dir, "msgs.0000000002"), "")

      store = LavinMQ::MessageStore.new(dir, nil)
      store.closed.should be_false
      store.@segments.has_key?(2u32).should be_false
      File.exists?(File.join(dir, "msgs.0000000002")).should be_false
      store.size.should eq 1
      env = store.shift?.should_not be_nil
      env.message.bodysize.should eq body.bytesize
      store.close
    end
  end

  it "keeps a segment that lost its schema version but has messages, and closes the store" do
    with_store do |store, dir|
      body = "x" * (LavinMQ::Config.instance.segment_size // 2)
      3.times { store.push(LavinMQ::Message.new("ex", "rk", body)) }
      store.close
      segment = File.join(dir, "msgs.0000000002")
      size = File.size(segment)
      File.open(segment, "r+", &.write(Bytes.new(4)))

      store = LavinMQ::MessageStore.new(dir, nil)
      store.closed.should be_true
      File.size(segment).should eq size
    end
  end

  it "advances @rfile when delete_unused_segments removes the rfile's segment" do
    mktmpdir do |dir|
      msg_size = LavinMQ::Config.instance.segment_size.to_u64 // 2 + 1
      msg = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k",
        AMQ::Protocol::Properties.new, msg_size, IO::Memory.new("a" * msg_size))

      # Leave one segment on disk with all messages acked.
      store = LavinMQ::MessageStore.new(dir, nil, durable: true)
      store.push(msg)
      env = store.shift?.should_not be_nil
      store.delete(env.segment_position)
      store.close

      # Reopen. The leftover segment is kept at startup because it is
      # current_seg, so @rfile = @wfile points at it.
      store = LavinMQ::MessageStore.new(dir, nil, durable: true)

      # Pushing a message that needs to roll the segment runs
      # delete_unused_segments. The fix must advance @rfile before
      # delete_file closes the orphaned mfile, otherwise the next shift?
      # would raise IO::Error("Closed mfile").
      store.push(msg)
      env = store.shift?.should_not be_nil
      store.delete(env.segment_position)
      store.close
    end
  end

  #
  # Run all specs for both durable and non-durable stores
  #
  {false, true}.each do |durable|
    describe "when #{durable ? "" : "non-"}durable" do
      describe "#first?" do
        it "should return nil from empty segment" do
          mktmpdir do |dir|
            File.write(File.join(dir, "msgs.0000000001"), "\x04\x00\x00\x00")
            store = LavinMQ::MessageStore.new(dir, nil, durable)
            store.@segments.first_value.truncate(1000)
            store.first?.should be_nil
            store.close
          end
        end
      end

      describe "#shift?" do
        it "should return nil from empty segment" do
          mktmpdir do |dir|
            File.write(File.join(dir, "msgs.0000000001"), "\x04\x00\x00\x00")
            store = LavinMQ::MessageStore.new(dir, nil, durable)
            store.@segments.first_value.truncate(1000)
            store.shift?.should be_nil
            store.close
          end
        end
      end

      it "can ack messages after restart" do
        mktmpdir do |dir|
          File.write(File.join(dir, "msgs.0000000001"), "\x04\x00\x00\x00")
          File.write(File.join(dir, "acks.0000000001"), "")
          store = LavinMQ::MessageStore.new(dir, nil, durable)
          body_io = IO::Memory.new("hello")
          message = LavinMQ::Message.new(RoughTime.unix_ms, "test_exchange", "test_key", AMQ::Protocol::Properties.new, 5u64, body_io)
          store.push(message)
          env = store.shift?.should_not be_nil
          String.new(env.message.body).should eq "hello"
          store.delete(env.segment_position)
          store.close
        end
      end

      describe "#push" do
        it "should not raise when rolling over on new wfile" do
          with_store(durable: durable) do |store|
            msg_size = LavinMQ::Config.instance.segment_size.to_u64 // 2 + 1
            msg = LavinMQ::Message.new(
              RoughTime.unix_ms, "e", "k",
              AMQ::Protocol::Properties.new, msg_size, IO::Memory.new("a" * msg_size)
            )
            begin
              10.times do
                store.push msg
              end
            rescue ex
              fail ex.inspect_with_backtrace, line: (__LINE__ - 3) # -3 to get the push line
            end
          end
        end
      end

      describe "#empty?" do
        it "should be true for a fresh store" do
          with_store(durable: durable) do |store|
            store.empty?.should be_true
          end
        end

        it "should be false after push" do
          with_store(durable: durable) do |store|
            store.push LavinMQ::Message.new("ex", "rk", "body")
            store.empty?.should be_false
          end
        end

        it "should be true after all messages has been shifted" do
          with_store(durable: durable) do |store|
            5.times { store.push LavinMQ::Message.new("ex", "rk", "body") }

            while store.shift?
            end

            store.empty?.should be_true
          end
        end
      end

      describe "#empty" do
        it "should be true for a new store" do
          with_store(durable: durable) do |store|
            store.empty.should be_true
          end
        end

        it "should be true after all messages has been shifted" do
          with_store(durable: durable) do |store|
            5.times { store.push LavinMQ::Message.new("ex", "rk", "body") }

            while store.shift?
            end

            store.empty.should be_true
          end
        end

        it "should be false on after a push to a new store" do
          with_store(durable: durable) do |store|
            store.push LavinMQ::Message.new("ex", "rk", "body")

            store.empty.should be_false
          end
        end

        it "should be false after push to an empty store" do
          with_store(durable: durable) do |store|
            5.times { store.push LavinMQ::Message.new("ex", "rk", "body") }

            while store.shift?
            end

            5.times { store.push LavinMQ::Message.new("ex", "rk", "body") }

            store.empty.should be_false
          end
        end

        it "should be false after requeue" do
          with_store(durable: durable) do |store|
            store.push LavinMQ::Message.new("ex", "rk", "body")
            env = store.shift?.should_not be_nil
            store.empty.should be_true
            store.requeue env.segment_position
            store.empty.should be_false
          end
        end

        it "should be true after last message has been purged" do
          with_store(durable: durable) do |store|
            5.times { store.push LavinMQ::Message.new("ex", "rk", "body") }

            store.empty.should be_false
            store.purge(10)

            store.empty.should be_true
          end
        end

        it "should be true after purge_all" do
          with_store(durable: durable) do |store|
            5.times { store.push LavinMQ::Message.new("ex", "rk", "body") }

            store.empty.should be_false
            store.purge_all

            store.empty.should be_true
          end
        end
      end
    end
  end

  describe "#purge_all" do
    it "acks requeued messages on disk so they don't come back after restart" do
      mktmpdir do |dir|
        store = LavinMQ::MessageStore.new(dir, nil, durable: true)
        3.times { |i| store.push LavinMQ::Message.new("ex", "rk", "body#{i}") }
        env = store.shift?.should_not be_nil
        store.requeue env.segment_position
        store.size.should eq 3
        store.purge_all
        store.size.should eq 0
        store.close

        store = LavinMQ::MessageStore.new(dir, nil, durable: true)
        begin
          store.size.should eq 0
          store.shift?.should be_nil
        ensure
          store.close
        end
      end
    end

    it "purges msgs in a segment that was acked out of order before a restart" do
      mktmpdir do |dir|
        third_seg = LavinMQ::Config.instance.segment_size.to_u64 // 3 + 1
        big = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k",
          AMQ::Protocol::Properties.new, third_seg, IO::Memory.new("a" * third_seg))

        store = LavinMQ::MessageStore.new(dir, nil)
        6.times { store.push(big) } # seg 1 = [m1, m2], seg 2 = [m3, m4], seg 3 = [m5, m6]
        envs = Array(LavinMQ::Envelope).new
        4.times { envs << store.shift?.should_not be_nil }
        store.delete(envs[2].segment_position) # ack m3 only, seg 2 is partially acked
        store.close

        # A reopen resets @rfile_id to the first segment, so seg 2 counts as
        # unread, but @segment_msg_count still counts the acked m3 while @size
        # doesn't. purge_all must not subtract that ack from @size, or its
        # shift loop underflows and leaves the rest of the msgs on disk.
        store = LavinMQ::MessageStore.new(dir, nil)
        store.size.should eq 5
        store.purge_all
        store.size.should eq 0
        store.close

        store = LavinMQ::MessageStore.new(dir, nil)
        store.size.should eq 0
        store.close
      end
    end

    it "empties the store on disk when a segment's meta counts msgs the segment doesn't hold" do
      mktmpdir do |dir|
        sps = push_with_lost_tail(dir)

        # The lost msgs sit behind real ones, so the store loads fine
        store = LavinMQ::MessageStore.new(dir, nil, durable: true)
        store.size.should eq 12
        store.purge_all
        store.size.should eq 0
        store.close

        store = LavinMQ::MessageStore.new(dir, nil, durable: true)
        begin
          store.size.should eq 0
          store.first?.should be_nil
          File.exists?(File.join(dir, "msgs.#{sps.first.segment.to_s.rjust(10, '0')}")).should be_false
        ensure
          store.close
        end
      end
    end
  end

  describe "when a segment's meta counts msgs the segment doesn't hold" do
    it "counts the segment at load when the msgs left in it can't fit" do
      mktmpdir do |dir|
        sps = push_with_lost_tail(dir) do |store, envs|
          # Ack everything but the 3 msgs that are about to be lost
          envs.each_with_index { |env, i| store.delete(env.segment_position) unless 6 <= i < 9 }
        end
        seg1 = sps.first.segment.to_s.rjust(10, '0')

        store = LavinMQ::MessageStore.new(dir, nil, durable: true)
        begin
          store.size.should eq 0
          store.empty?.should be_true
          store.first?.should be_nil
          # Every msg left in seg 1 is acked, so the segment is gone
          File.exists?(File.join(dir, "msgs.#{seg1}")).should be_false
          File.exists?(File.join(dir, "meta.#{seg1}")).should be_false
        ensure
          store.close
        end

        store = LavinMQ::MessageStore.new(dir, nil, durable: true)
        begin
          store.size.should eq 0
          store.shift?.should be_nil
        ensure
          store.close
        end
      end
    end

    it "recounts when the msgs run out while still counted, and keeps working" do
      mktmpdir do |dir|
        sps = push_with_lost_tail(dir)
        seg1 = sps.first.segment.to_s.rjust(10, '0')

        # Msgs left in seg 1 hide the lost ones at load
        store = LavinMQ::MessageStore.new(dir, nil, durable: true)
        begin
          store.size.should eq 12
          count = 0
          while env = store.shift?
            store.delete(env.segment_position)
            count += 1
          end
          count.should eq 9 # 6 left in seg 1, 3 in seg 2
          store.size.should eq 0
          # Seg 1 is recounted, and all its msgs are acked, so it's gone
          File.exists?(File.join(dir, "msgs.#{seg1}")).should be_false
          # The recount leaves the read position where it was, so the next
          # shift? gets the new msg, not a redelivery of an old one
          store.push(LavinMQ::Message.new("ex", "rk", "after"))
          env = store.shift?.should_not be_nil
          String.new(env.message.body).should eq "after"
          store.shift?.should be_nil
        ensure
          store.close
        end
      end
    end
  end

  it "closes gracefully when segment has corrupt schema version with replicator", tags: "etcd" do
    with_etcd do
      mktmpdir do |dir|
        # Create a valid store with a message, then close it
        store = LavinMQ::MessageStore.new(dir, nil)
        store.push(LavinMQ::Message.new("ex", "rk", "body"))
        store.close

        # Corrupt the schema version at the start of the segment file
        seg_file = Dir.children(dir).find!(&.starts_with?("msgs."))
        File.open(File.join(dir, seg_file), "r+") { |f| f.write("abcd".to_slice) }

        # With a replicator (no followers), close spawns a fiber that races
        # with the constructor — this should close gracefully, not crash
        replicator = LavinMQ::Clustering::Server.new(LavinMQ::Config.instance, NullCoordinator.new, 0)
        begin
          store = LavinMQ::MessageStore.new(dir, replicator)
          store.closed.should be_true
        ensure
          replicator.close
        end
      end
    end
  end

  it "closes gracefully when a middle segment is corrupt with replicator", tags: "etcd" do
    with_etcd do
      mktmpdir do |dir|
        # Create a store with multiple segments (one message per segment)
        store = LavinMQ::MessageStore.new(dir, nil)
        msg_size = LavinMQ::Config.instance.segment_size.to_u64 - (LavinMQ::BytesMessage::MIN_BYTESIZE + 5)
        msg = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k", AMQ::Protocol::Properties.new, msg_size, IO::Memory.new("a" * msg_size))
        3.times { store.push(msg) }
        store.@segments.size.should eq 3
        store.close

        # Corrupt the schema version of the second segment
        seg_files = Dir.children(dir).select(&.starts_with?("msgs.")).sort!
        File.open(File.join(dir, seg_files[1]), "r+") { |f| f.write("abcd".to_slice) }

        # With a replicator (no followers), this should close gracefully
        # even though valid segments before the corrupt one were already loaded
        replicator = LavinMQ::Clustering::Server.new(LavinMQ::Config.instance, NullCoordinator.new, 0)
        begin
          store = LavinMQ::MessageStore.new(dir, replicator)
          store.closed.should be_true
        ensure
          replicator.close
        end
      end
    end
  end

  describe "replication" do
    it "sends the shortened segment to followers after dropping a torn trailing record" do
      mktmpdir do |dir|
        store = LavinMQ::MessageStore.new(dir, nil)
        2.times { store.push(LavinMQ::Message.new("ex", "rk", "a stored message")) }
        seg_path = store.@segments.last_value.path
        store.close

        # Tear the last record and remove the meta file, so produce_metadata
        # rebuilds the segment and resizes it past the incomplete record.
        File.open(seg_path, "r+") { |f| f.truncate(f.size - 3) }
        meta_path = seg_path.sub("msgs.", "meta.")
        File.delete(meta_path) if File.exists?(meta_path)

        replicator = SpyReplicator.new
        store = LavinMQ::MessageStore.new(dir, replicator)
        store.close
        replicator.replaced_files.should contain(seg_path)
      end
    end

    it "does not send intact segments to followers when it rebuilds metadata" do
      mktmpdir do |dir|
        store = LavinMQ::MessageStore.new(dir, nil)
        2.times { store.push(LavinMQ::Message.new("ex", "rk", "a stored message")) }
        seg_path = store.@segments.last_value.path
        store.close

        # Remove only the meta file. The segment itself is intact, so the
        # metadata rebuild must not re-replicate it.
        meta_path = seg_path.sub("msgs.", "meta.")
        File.delete(meta_path) if File.exists?(meta_path)

        replicator = SpyReplicator.new
        store = LavinMQ::MessageStore.new(dir, replicator)
        store.close
        replicator.replaced_files.should_not contain(seg_path)
      end
    end

    it "registers the initial segment file" do
      mktmpdir do |dir|
        replicator = SpyReplicator.new
        store = LavinMQ::MessageStore.new(dir, replicator)
        store.close
        replicator.registered_files.keys.map { |p| File.basename(p) }.should contain("msgs.0000000001")
      end
    end

    it "registers existing segment files on startup" do
      mktmpdir do |dir|
        File.write(File.join(dir, "msgs.0000000001"), "\x04\x00\x00\x00")
        replicator = SpyReplicator.new
        store = LavinMQ::MessageStore.new(dir, replicator)
        store.close
        replicator.registered_files.keys.map { |p| File.basename(p) }.should contain("msgs.0000000001")
      end
    end

    it "registers ack files on startup" do
      mktmpdir do |dir|
        File.write(File.join(dir, "msgs.0000000001"), "\x04\x00\x00\x00")
        File.write(File.join(dir, "acks.0000000001"), "")
        replicator = SpyReplicator.new
        store = LavinMQ::MessageStore.new(dir, replicator)
        store.close
        replicator.registered_files.keys.map { |p| File.basename(p) }.should contain("acks.0000000001")
      end
    end

    it "does not register orphaned ack files" do
      mktmpdir do |dir|
        File.write(File.join(dir, "msgs.0000000001"), "\x04\x00\x00\x00")
        File.write(File.join(dir, "acks.0000000002"), "")
        replicator = SpyReplicator.new
        store = LavinMQ::MessageStore.new(dir, replicator)
        store.close
        replicator.registered_files.keys.map { |p| File.basename(p) }.should_not contain("acks.0000000002")
      end
    end

    it "deletes orphaned ack files from the replicator on startup" do
      mktmpdir do |dir|
        File.write(File.join(dir, "msgs.0000000001"), "\x04\x00\x00\x00")
        orphan_path = File.join(dir, "acks.0000000002")
        File.write(orphan_path, "")
        replicator = SpyReplicator.new
        store = LavinMQ::MessageStore.new(dir, replicator)
        store.close
        replicator.deleted_files.should contain(orphan_path)
      end
    end

    it "deletes fully-acked segments from the replicator on startup" do
      mktmpdir do |dir|
        msg_size = LavinMQ::Config.instance.segment_size.to_u64 - (LavinMQ::BytesMessage::MIN_BYTESIZE + 5)
        msg = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k", AMQ::Protocol::Properties.new, msg_size, IO::Memory.new("a" * msg_size))

        store = LavinMQ::MessageStore.new(dir, nil, durable: true)
        2.times { store.push(msg) }
        store.close
        wait_for { store.closed }

        File.open(File.join(dir, "acks.0000000001"), "w") do |f|
          f.write_bytes(4u32)
        end

        replicator = SpyReplicator.new
        store = LavinMQ::MessageStore.new(dir, replicator, durable: true)
        store.close

        replicator.deleted_files.map { |p| File.basename(p) }.should contain("msgs.0000000001")
      end
    end

    it "re-registers files without an MFile reference when closed" do
      mktmpdir do |dir|
        replicator = SpyReplicator.new
        store = LavinMQ::MessageStore.new(dir, replicator)
        store.close
        sleep 1.millisecond
        file_registrations = replicator.registered_files.select { |_, t| t == :path }
        file_registrations.keys.map { |p| File.basename(p) }.should contain("msgs.0000000001")
      end
    end

    it "registers ack files from all segments on normal startup" do
      mktmpdir do |dir|
        store = LavinMQ::MessageStore.new(dir, nil, durable: true)
        msg_size = LavinMQ::Config.instance.segment_size.to_u64 - (LavinMQ::BytesMessage::MIN_BYTESIZE + 5)
        msg = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k", AMQ::Protocol::Properties.new, msg_size, IO::Memory.new("a" * msg_size))
        3.times { store.push(msg) }
        store.close
        wait_for { store.closed }

        seg_files = Dir.children(dir).select(&.starts_with?("msgs.")).sort!
        ack_files = seg_files.map(&.sub("msgs.", "acks."))
        ack_files.each { |f| File.open(File.join(dir, f), "w", &.write_bytes(4_u32)) }

        replicator = SpyReplicator.new
        store = LavinMQ::MessageStore.new(dir, replicator)
        store.close
        registered = replicator.registered_files.keys.map { |p| File.basename(p) }
        ack_files.each { |f| registered.should contain(f) }
      end
    end

    it "deletes orphaned ack file and registers valid ack files when a segment is corrupt" do
      mktmpdir do |dir|
        store = LavinMQ::MessageStore.new(dir, nil, durable: true)
        msg_size = LavinMQ::Config.instance.segment_size.to_u64 - (LavinMQ::BytesMessage::MIN_BYTESIZE + 5)
        msg = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k", AMQ::Protocol::Properties.new, msg_size, IO::Memory.new("a" * msg_size))
        3.times { store.push(msg) }
        store.close
        wait_for { store.closed }

        seg_files = Dir.children(dir).select(&.starts_with?("msgs.")).sort!
        ack_files = seg_files.map(&.sub("msgs.", "acks."))
        ack_files.each { |f| File.open(File.join(dir, f), "w", &.write_bytes(4_u32)) }
        orphan_ack = File.join(dir, "acks.0000000099")
        File.write(orphan_ack, "")
        File.open(File.join(dir, seg_files[0]), "r+") { |f| f.write("abcd".to_slice) }

        replicator = SpyReplicator.new
        store = LavinMQ::MessageStore.new(dir, replicator)
        sleep 1.millisecond
        store.closed.should be_true
        registered = replicator.registered_files.keys.map { |p| File.basename(p) }
        ack_files.each { |f| registered.should contain(f) }
        replicator.deleted_files.should contain(orphan_ack)
        File.exists?(orphan_ack).should be_false
      end
    end

    [
      {"first segment", 3, 0},
      {"middle segment", 4, 1},
      {"last segment", 3, -1},
    ].each do |desc, n_segments, corrupt_idx|
      it "registers all files when the #{desc} is corrupt" do
        mktmpdir do |dir|
          store = LavinMQ::MessageStore.new(dir, nil, durable: true)
          msg_size = LavinMQ::Config.instance.segment_size.to_u64 - (LavinMQ::BytesMessage::MIN_BYTESIZE + 5)
          msg = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k", AMQ::Protocol::Properties.new, msg_size, IO::Memory.new("a" * msg_size))
          n_segments.times { store.push(msg) }
          store.close
          wait_for { store.closed }

          seg_files = Dir.children(dir).select(&.starts_with?("msgs.")).sort!
          ack_files = seg_files.map(&.sub("msgs.", "acks."))
          ack_files.each { |f| File.open(File.join(dir, f), "w", &.write_bytes(4_u32)) }
          File.open(File.join(dir, seg_files[corrupt_idx]), "r+") { |f| f.write("abcd".to_slice) }

          replicator = SpyReplicator.new
          store = LavinMQ::MessageStore.new(dir, replicator)
          sleep 1.millisecond
          store.closed.should be_true
          registered = replicator.registered_files.keys.map { |p| File.basename(p) }
          (seg_files + ack_files).each { |f| registered.should contain(f) }
        end
      end
    end

    it "replicates the rewritten ack file after pruning orphans" do
      mktmpdir do |dir|
        setup_orphaned_ack_scenario(dir)

        replicator = SpyReplicator.new
        store = LavinMQ::MessageStore.new(dir, replicator, durable: true)
        store.close

        replicator.replaced_files.map { |p| File.basename(p) }.should contain("acks.0000000001")
        replicator.registered_files.keys.map { |p| File.basename(p) }.should contain("acks.0000000001")
      end
    end
  end

  # #1862 — on unclean shutdown, acks.* can end up with positions past the
  # corresponding msgs.* data end (orphaned acks), causing shift? to skip
  # newly-pushed messages and raise "EOF but @size=1".
  describe "after crash with fully acked segment" do
    # Simulates unclean shutdown where mmap msg writes were lost but ack writes survived:
    # the ack file references positions that don't exist in the msg file anymore.
    it "prunes orphaned acks across multiple segments when all positions are orphaned" do
      mktmpdir do |dir|
        # Two segments with only a schema header and an all-orphaned ack file
        # each — exercises the @deleted.delete(seg) branch for multiple segments.
        [1u32, 2u32].each do |seg|
          File.write(File.join(dir, "msgs.#{seg.to_s.rjust(10, '0')}"), "\x04\x00\x00\x00")
          File.open(File.join(dir, "acks.#{seg.to_s.rjust(10, '0')}"), "w") do |f|
            f.write_bytes(100u32, IO::ByteFormat::SystemEndian)
            f.write_bytes(200u32, IO::ByteFormat::SystemEndian)
          end
        end

        store = LavinMQ::MessageStore.new(dir, nil, durable: true)
        store.@deleted.empty?.should be_true
        store.close
      end
    end

    it "does not raise EOF when ack file has orphaned positions past data" do
      mktmpdir do |dir|
        setup_orphaned_ack_scenario(dir)

        # Reopen — prune_orphaned_acks should drop the 2 orphaned positions.
        store = LavinMQ::MessageStore.new(dir, nil, durable: true)
        store.@size.should eq 0
        store.@deleted[1]?.try(&.size).should eq 5
        store.@acks[1].size.should eq 5 * sizeof(UInt32)

        body = "a" * 1000
        store.push(LavinMQ::Message.new("ex", "rk", body))
        store.@size.should eq 1

        env = store.shift?.should_not be_nil
        String.new(env.message.body).should eq body
        store.@size.should eq 0
        store.close
      end
    end

    it "logs when pruning orphaned ack positions" do
      mktmpdir do |dir|
        setup_orphaned_ack_scenario(dir)
        Log.capture("lmq.*", :warn) do |log|
          store = LavinMQ::MessageStore.new(dir, nil, durable: true)
          store.close
          log.check(:warn, /Msgs\/acks files for segment 1 are out of sync.*Removing 2 orphaned ack position\(s\)/)
        end
      end
    end

    it "handles orphaned ack positions without crashing when opened as non-durable" do
      mktmpdir do |dir|
        setup_orphaned_ack_scenario(dir)

        # Non-durable reopens unlink the msg/ack files as they load, so the
        # ack file is detected as orphaned and @deleted never gets populated.
        # The important thing is that opening doesn't crash.
        store = LavinMQ::MessageStore.new(dir, nil, durable: false)
        (store.@deleted[1]?.nil? || store.@deleted[1].empty?).should be_true
        store.close
      end
    end

    it "deletes leftover tmp.acks.* files in the data dir" do
      mktmpdir do |dir|
        File.write(File.join(dir, "msgs.0000000001"), "\x04\x00\x00\x00")
        File.write(File.join(dir, "acks.0000000001"), "")
        orphan_tmp = File.join(dir, "tmp.acks.0000000001")
        File.write(orphan_tmp, "garbage-bytes")

        store = LavinMQ::MessageStore.new(dir, nil, durable: true)
        store.@acks.has_key?(1u32).should be_true
        File.exists?(orphan_tmp).should be_false
        store.close
      end
    end

    it "does not raise EOF when rfile.pos is at end when open_new_segment fires" do
      mktmpdir do |dir|
        body = "a" * 1000
        store = LavinMQ::MessageStore.new(dir, nil, durable: true)
        5.times { store.push(LavinMQ::Message.new("ex", "rk", body)) }
        while env = store.shift?
          store.delete(env.segment_position)
        end
        store.close
        wait_for { store.closed }

        store = LavinMQ::MessageStore.new(dir, nil, durable: true)
        store.@size.should eq 0

        # Push-shift-ack one small msg; rfile.pos is now at end of segment 1.
        store.push(LavinMQ::Message.new("ex", "rk", body))
        env = store.shift?.should_not be_nil
        store.delete(env.segment_position)
        store.empty?.should be_true

        # Invariant: rfile == wfile and rfile.pos == rfile.size (fully consumed).
        store.@rfile.pos.should eq store.@rfile.size

        # Now push a large message that forces open_new_segment.
        # open_new_segment adds segment 2 and delete_unused_segments deletes segment 1.
        # @rfile still points to orphan segment 1 with pos == size.
        half_seg = LavinMQ::Config.instance.segment_size.to_u64 // 2 + 1
        store.push(LavinMQ::Message.new(RoughTime.unix_ms, "e", "k",
          AMQ::Protocol::Properties.new, half_seg, IO::Memory.new("b" * half_seg)))
        store.@size.should eq 1

        env = store.shift?
        env.should_not be_nil
        store.close
      end
    end
  end

  describe "#purge_all" do
    it "leaves @size == 0 when deleted segments contain partial acks" do
      with_store do |store|
        # Fill several segments so purge_all has segments to delete beyond rfile/wfile.
        third_seg = LavinMQ::Config.instance.segment_size.to_u64 // 3 + 1
        big = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k",
          AMQ::Protocol::Properties.new, third_seg, IO::Memory.new("a" * third_seg))
        6.times { store.push(big) } # 3 segments, 2 msgs each
        store.@segments.size.should eq 3

        # Shift+ack m1 - leaves seg 1 partially acked (one ready msg, one ack).
        # purge_all keeps seg 1 (it's the rfile) and the shift loop finishes
        # draining it.
        env = store.shift?.should_not be_nil
        store.delete(env.segment_position)

        store.purge_all
        store.@size.should eq 0
        store.@bytesize.should eq 0
        store.empty?.should be_true
        store.empty.value.should be_true
      end
    end

    it "shift? from @requeued keeps @size consistent when the segment is gone" do
      with_store do |store|
        store.push(LavinMQ::Message.new("ex", "rk", "body"))
        env = store.shift?.should_not be_nil
        store.requeue(env.segment_position)
        store.@size.should eq 1

        # Simulate a race: the requeued sp's segment was deleted by another
        # purge before we got back to shift?. Without the fix, shift? bubbles
        # an exception while the requeued entry's accounting is left behind.
        store.@segments.delete(env.segment_position.segment)

        expect_raises(LavinMQ::MessageStore::Error) do
          store.shift?
        end
        store.@size.should eq 0
        store.@bytesize.should eq 0
      end
    end

    it "does not raise when @requeued sp points to a missing segment" do
      with_store do |store|
        store.push(LavinMQ::Message.new("ex", "rk", "body"))
        env = store.shift?.should_not be_nil
        store.requeue(env.segment_position)

        # Simulate a race where the requeued sp's segment was deleted before
        # purge_all ran. The @requeued drain in purge_all must not touch the
        # missing segment when decrementing @size/@bytesize.
        store.@segments.delete(env.segment_position.segment)

        store.purge_all
        store.@size.should eq 0
        store.@bytesize.should eq 0
        store.empty.value.should be_true
      end
    end

    it "does not raise when an older segment has in-flight messages" do
      with_store do |store|
        half_seg = LavinMQ::Config.instance.segment_size.to_u64 // 2 + 1
        big = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k",
          AMQ::Protocol::Properties.new, half_seg, IO::Memory.new("a" * half_seg))

        # One big msg per segment; second shift advances rfile to seg 2.
        store.push(big)
        store.push(big)
        store.shift?.should_not be_nil
        store.shift?.should_not be_nil

        store.@segments.keys.should contain(1u32)
        store.@rfile_id.should eq 2u32
        store.@size.should eq 0u32

        store.purge_all
        store.empty?.should be_true
      end
    end

    it "does not raise when @requeued points to a segment that gets deleted" do
      with_store do |store|
        half_seg = LavinMQ::Config.instance.segment_size.to_u64 // 2 + 1
        big = LavinMQ::Message.new(RoughTime.unix_ms, "e", "k",
          AMQ::Protocol::Properties.new, half_seg, IO::Memory.new("a" * half_seg))
        small = LavinMQ::Message.new("ex", "rk", "body")

        # Layout: seg 1 = [big], seg 2 = [big, small], seg 3 = [big].
        store.push(big)
        store.push(big)
        store.push(small)
        store.push(big)

        # Ack M1 -> seg 1 auto-deletes. Shift the rest; ack M4 (wfile, kept).
        env = store.shift?.should_not be_nil
        store.delete(env.segment_position)
        env_m2 = store.shift?.should_not be_nil
        env_m3 = store.shift?.should_not be_nil
        env_m4 = store.shift?.should_not be_nil
        store.delete(env_m4.segment_position)

        # Requeue m2/m3 -> @requeued holds sps to seg 2, no longer rfile/wfile.
        store.requeue(env_m2.segment_position)
        store.requeue(env_m3.segment_position)

        store.@segments.keys.should contain(2u32)
        store.@rfile_id.should eq 3u32

        store.purge_all
        store.empty?.should be_true
      end
    end
  end

  {% if flag?(:linux) %}
    describe "random access advice" do
      it "advises every segment but the write segment random access" do
        with_datadir do |dir|
          store = LavinMQ::MessageStore.new(dir, nil)
          vm_flags(store.@wfile.path).should_not contain "rr"
          large = "x" * (LavinMQ::Config.instance.segment_size // 2)
          3.times { store.push(LavinMQ::Message.new("", "rk", large)) }
          store.@wfile_id.should_not eq 1
          vm_flags(store.@wfile.path).should_not contain "rr"
          store.@segments.each_value { |s| vm_flags(s.path).should contain "rr" unless s == store.@wfile }
          store.close
          store = LavinMQ::MessageStore.new(dir, nil)
          vm_flags(store.@wfile.path).should_not contain "rr"
          store.@segments.each_value { |s| vm_flags(s.path).should contain "rr" unless s == store.@wfile }
          store.close
        end
      end

      it "advises the write segment random access once a publish to it is synced" do
        with_datadir do |dir|
          store = LavinMQ::MessageStore.new(dir, nil)
          store.push(synced_message("m"))
          vm_flags(store.@wfile.path).should contain "rr"
          large = "x" * (LavinMQ::Config.instance.segment_size // 2)
          3.times { store.push(LavinMQ::Message.new("", "rk", large)) }
          store.@wfile_id.should_not eq 1
          vm_flags(store.@wfile.path).should contain "rr"
          store.close
        end
      end

      it "keeps readahead on the write segment when sync is disabled" do
        LavinMQ::Config.instance.sync = false
        with_datadir do |dir|
          store = LavinMQ::MessageStore.new(dir, nil)
          store.push(synced_message("m"))
          vm_flags(store.@wfile.path).should_not contain "rr"
          store.close
        end
      end

      it "reads segments with readahead while loading them at startup" do
        with_datadir do |dir|
          store = LavinMQ::MessageStore.new(dir, nil)
          body = "x" * (LavinMQ::Config.instance.segment_size // 4)
          5.times { store.push(LavinMQ::Message.new("", "rk", body)) }
          env = store.shift?.should_not be_nil
          store.delete(env.segment_position) # acks to skip through on load
          store.@segments.size.should eq 2
          store.close
          AdviceOnLoadStore.advice_on_load.clear
          store = AdviceOnLoadStore.new(dir, nil)
          store.size.should eq 4
          loads = AdviceOnLoadStore.advice_on_load
          loads.map(&.first).should eq ["read_metadata_file", "produce_metadata"]
          # Skipping the acked message, and counting the messages of the write
          # segment, which has no meta file: what its readahead when opened
          # didn't fetch, on a compressing filesystem, is read ahead here
          loads.each do |_, flags|
            flags.should contain "sr"
            flags.should_not contain "rr"
          end
          store.@segments.each_value { |s| vm_flags(s.path).should contain "rr" unless s == store.@wfile }
          store.close
        end
      end

      it "fetches the last segment in one readahead before counting its messages" do
        with_datadir do |dir|
          store = LavinMQ::MessageStore.new(dir, nil)
          100.times { store.push(LavinMQ::Message.new("", "rk", "x" * 1000)) } # about 25 pages
          store.close
          evict_from_page_cache(Dir.glob(File.join(dir, "msgs.*")).first)
          AdviceOnLoadStore.cached_on_load.clear
          store = AdviceOnLoadStore.new(dir, nil)
          store.size.should eq 100
          # Without it, only the page the schema check faulted in
          AdviceOnLoadStore.cached_on_load.size.should eq 1
          AdviceOnLoadStore.cached_on_load.first.should be >= 20
          store.close
        end
      end

      it "recounts a segment with acks and a corrupt meta file with readahead, then random access" do
        with_datadir do |dir|
          store = LavinMQ::MessageStore.new(dir, nil)
          body = "x" * (LavinMQ::Config.instance.segment_size // 4)
          5.times { store.push(LavinMQ::Message.new("", "rk", body)) }
          env = store.shift?.should_not be_nil
          store.delete(env.segment_position) # acks to skip through on load
          store.close
          File.write(Dir.glob(File.join(dir, "meta.*")).sort.first, "x") # too short for its count
          AdviceOnLoadStore.advice_on_load.clear
          store = AdviceOnLoadStore.new(dir, nil)
          store.size.should eq 4
          loads = AdviceOnLoadStore.advice_on_load
          loads.map(&.first).should eq ["read_metadata_file", "produce_metadata", "produce_metadata"]
          loads.each { |_, flags| flags.should contain "sr" }
          store.@segments.each_value { |s| vm_flags(s.path).should contain "rr" unless s == store.@wfile }
          store.close
        end
      end

      it "loads a segment with acks and a corrupt record as closed instead of raising" do
        with_datadir do |dir|
          store = LavinMQ::MessageStore.new(dir, nil)
          body = "x" * (LavinMQ::Config.instance.segment_size // 4)
          5.times { store.push(LavinMQ::Message.new("", "rk", body)) }
          env = store.shift?.should_not be_nil
          store.delete(env.segment_position) # acks to skip through on load
          store.close
          first = Dir.glob(File.join(dir, "msgs.*")).sort.first
          # The first record's bodysize: after the schema version, timestamp,
          # exchange, routing key and properties
          bodysize_pos = 4 + 8 + 1 + 1 + "rk".bytesize + AMQ::Protocol::Properties.new.bytesize
          File.open(first, "r+") { |f| f.seek(bodysize_pos); f.write_bytes(UInt64::MAX) }
          store = LavinMQ::MessageStore.new(dir, nil)
          store.closed.should be_true
        end
      end

      it "reads only the allocated part of a last segment left at its capacity by a crash" do
        with_datadir do |dir|
          store = LavinMQ::MessageStore.new(dir, nil)
          store.push(LavinMQ::Message.new("ex", "rk", "body"))
          store.close
          path = Dir.glob(File.join(dir, "msgs.*")).first
          File.open(path, "r+", &.truncate(LavinMQ::Config.instance.segment_size)) # only a graceful close shrinks it
          store = LavinMQ::MessageStore.new(dir, nil)
          store.size.should eq 1
          cached_pages(path).should be < 64 # not the whole hole zero-filled, 128 pages in specs
          store.close
        end
      end

      it "advises the next full segment sequential for a reader that read the previous one fast" do
        with_datadir do |dir|
          store = LavinMQ::MessageStore.new(dir, nil)
          large = "x" * (LavinMQ::Config.instance.segment_size // 2)
          3.times { store.push(LavinMQ::Message.new("", "rk", large)) }
          first, second, third = store.@segments.values.map(&.path)
          3.times { store.shift?.should_not be_nil }
          vm_flags(first).should contain "rr" # no read before it to go by
          vm_flags(second).should_not contain "rr"
          vm_flags(second).should contain "sr"
          vm_flags(third).should_not contain "rr" # the write segment
          store.close
        end
      end

      it "keeps random access for a reader that read the previous segment slowly" do
        LavinMQ::Config.instance.segment_size = 64 * 1024
        with_datadir do |dir|
          store = LavinMQ::MessageStore.new(dir, nil)
          large = "x" * (LavinMQ::Config.instance.segment_size // 2)
          3.times { store.push(LavinMQ::Message.new("", "rk", large)) }
          second = store.@segments.values[1].path
          store.shift?.should_not be_nil
          sleep 200.milliseconds # 64 KiB in 200 ms is below 1 MiB/s
          store.shift?.should_not be_nil
          store.@rfile.path.should eq second
          vm_flags(second).should contain "rr"
          store.close
        end
      end

      it "advises ack files" do
        with_datadir do |dir|
          store = LavinMQ::MessageStore.new(dir, nil)
          2.times { |i| store.push(LavinMQ::Message.new("", "rk", "m#{i}")) }
          env = store.shift?.should_not be_nil
          store.delete(env.segment_position)
          vm_flags(store.@acks[env.segment_position.segment].path).should contain "rr"
          store.close
        end
      end
    end
  {% end %}
end
