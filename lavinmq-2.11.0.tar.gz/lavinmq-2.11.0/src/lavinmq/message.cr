require "amq-protocol"
require "./mfile"

module LavinMQ
  # Messages read from message store (mmap filed) and being delivered to consumers
  struct BytesMessage
    getter timestamp, exchange_name, routing_key, properties, bodysize, body

    def needs_sync? : Bool
      false
    end

    def synced_by_commit? : Bool
      false
    end

    def moved? : Bool
      false
    end

    MIN_BYTESIZE = 8 + 1 + 1 + 2 + 8 + 1

    def initialize(@timestamp : Int64, @exchange_name : String,
                   @routing_key : String, @properties : AMQ::Protocol::Properties,
                   @bodysize : UInt64, @body : Bytes)
    end

    def bytesize
      sizeof(Int64) + 1 + @exchange_name.bytesize + 1 + @routing_key.bytesize +
        @properties.bytesize + sizeof(UInt64) + @bodysize
    end

    def ttl
      @properties.expiration.try(&.to_i64?)
    end

    def dlx : String?
      @properties.headers.try(&.fetch("x-dead-letter-exchange", nil).as?(String))
    end

    def dlrk : String?
      @properties.headers.try(&.fetch("x-dead-letter-routing-key", nil).as?(String))
    end

    def to_io(io : IO, format = IO::ByteFormat::SystemEndian)
      io.write_bytes @timestamp, format
      io.write_bytes AMQ::Protocol::ShortString.new(@exchange_name), format
      io.write_bytes AMQ::Protocol::ShortString.new(@routing_key), format
      io.write_bytes @properties, format
      io.write_bytes @bodysize, format
      io.write @body
    end

    def self.skip(io, format = IO::ByteFormat::SystemEndian) : UInt64
      skipped = 0_u64
      skipped += io.skip(sizeof(UInt64))                             # ts
      skipped += 1 + io.skip(io.read_byte || raise IO::EOFError.new) # ex
      skipped += 1 + io.skip(io.read_byte || raise IO::EOFError.new) # rk
      skipped += AMQ::Protocol::Properties.skip(io, format)
      skipped += io.skip(UInt64.from_io io, format) + sizeof(UInt64)
      skipped
    end

    def self.from_bytes(bytes, format = IO::ByteFormat::SystemEndian) : self
      ts = format.decode(Int64, bytes[0, 8]); pos = 8
      ex = AMQ::Protocol::ShortString.from_bytes(bytes + pos); pos += 1 + ex.bytesize
      rk = AMQ::Protocol::ShortString.from_bytes(bytes + pos); pos += 1 + rk.bytesize
      pr = AMQ::Protocol::Properties.from_bytes(bytes + pos, format); pos += pr.bytesize
      sz = format.decode(UInt64, bytes[pos, 8]); pos += 8
      body = bytes[pos, sz]
      BytesMessage.new(ts, ex, rk, pr, sz, body)
    end
  end

  # Messages from publishers, read from socket and then written to mmap files
  struct Message
    property timestamp
    getter exchange_name, routing_key, properties, bodysize, body_io
    # Set for publishes that are confirmed (AMQP confirm mode, MQTT QoS 1), so
    # the segments they're written to are synced before the confirm
    property? needs_sync = false
    # Set for transactional publishes, the commit syncs the data dir
    property? synced_by_commit = false
    # Set for the copies the broker makes of another queue's messages, see
    # .moved_copy, so the segments they're written to are synced before the
    # segment they were moved out of is unlinked, see
    # Persister#unlink_after_sync
    property? moved = false

    def initialize(@timestamp : Int64, @exchange_name : String,
                   @routing_key : String, @properties : AMQ::Protocol::Properties,
                   @bodysize : UInt64, @body_io : IO)
    end

    def initialize(@exchange_name : String, @routing_key : String,
                   body : String, @properties = AMQ::Protocol::Properties.new)
      @timestamp = RoughTime.unix_ms
      @bodysize = body.bytesize.to_u64
      @body_io = IO::Memory.new(body)
    end

    # A copy of a stored message that the broker moves to another queue
    # (dead-lettered, delayed, retried). Build every such copy with this, so
    # it's marked moved.
    def self.moved_copy(msg : BytesMessage, *, timestamp = msg.timestamp,
                        exchange_name = msg.exchange_name, routing_key = msg.routing_key,
                        properties = msg.properties) : self
      copy = new(timestamp, exchange_name, routing_key, properties, msg.bodysize, IO::Memory.new(msg.body))
      copy.moved = true
      copy
    end

    def bytesize
      sizeof(Int64) + 1 + @exchange_name.bytesize + 1 + @routing_key.bytesize +
        @properties.bytesize + sizeof(UInt64) + @bodysize
    end

    def to_io(io : IO, format = IO::ByteFormat::SystemEndian)
      io.write_bytes @timestamp, format
      io.write_bytes AMQ::Protocol::ShortString.new(@exchange_name), format
      io.write_bytes AMQ::Protocol::ShortString.new(@routing_key), format
      io.write_bytes @properties, format
      io.write_bytes @bodysize, format
      if io_mem = @body_io.as?(IO::Memory)
        slice = io_mem.to_slice
        raise IO::Error.new("Unexpected body size: #{slice.bytesize} != #{@bodysize}") if slice.bytesize != @bodysize
        io.write(slice)
        io_mem.pos = @bodysize # necessary for rewinding in Vhost#publish
      else
        copied = IO.copy(@body_io, io, @bodysize)
        if copied != @bodysize
          raise IO::Error.new("Could only write #{copied} of #{@bodysize} bytes to message store")
        end
      end
    end
  end

  struct Envelope
    getter segment_position, message, redelivered

    # `segment` is the segment the message, body and headers both, is read from
    def initialize(@segment_position : SegmentPosition, @message : BytesMessage, *,
                   @segment : MFile, @redelivered = false)
    end

    # Keeps the segment mapped until #release, even if it's deleted or its
    # store closed meanwhile. Prefer the stores' *_with_lease? helpers, which
    # release when their block returns.
    protected def lease : self
      @segment.lease
      self
    end

    protected def release : Nil
      @segment.release_lease
    end

    # The same message flagged as redelivered, for a message that left the
    # queue and came back through another store, like the retry queue
    def as_redelivered : self
      Envelope.new(@segment_position, @message, segment: @segment, redelivered: true)
    end
  end
end
