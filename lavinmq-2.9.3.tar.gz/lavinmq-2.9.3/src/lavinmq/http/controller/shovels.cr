require "../controller.cr"
require "../stats_helper"

module LavinMQ
  module HTTP
    class ShovelsController < Controller
      include StatsHelpers

      private def register_routes
        get "/api/shovels" do |context, _params|
          refuse_unless_policymaker(context, user(context))
          arr = vhosts(user(context)).flat_map do |v|
            v.shovels.values
          end
          page(context, arr)
        end

        get "/api/shovels/:vhost" do |context, params|
          with_vhost(context, params) do |vhost|
            refuse_unless_policymaker(context, user(context), vhost)
            page(context, vhost.shovels.values)
          end
        end

        get "/api/shovels/:vhost/:name" do |context, params|
          with_vhost(context, params) do |vhost|
            refuse_unless_policymaker(context, user(context), vhost)
            shovel_name = params["name"]
            if shovel = vhost.shovels[shovel_name]?
              shovel.to_json(context.response)
            else
              context.response.status_code = 404
            end
          end
        end

        put "/api/shovels/:vhost/:name/pause" do |context, params|
          with_vhost(context, params) do |vhost|
            refuse_unless_policymaker(context, user(context), vhost)
            shovel_name = params["name"]
            if current_shovel = vhost.shovels[shovel_name]?
              if !current_shovel.running?
                context.response.status_code = 422
                next
              end
              current_shovel.pause
              context.response.status_code = 204
            else
              context.response.status_code = 404
            end
          end
        end

        put "/api/shovels/:vhost/:name/resume" do |context, params|
          with_vhost(context, params) do |vhost|
            refuse_unless_policymaker(context, user(context), vhost)
            shovel_name = params["name"]
            if current_shovel = vhost.shovels[shovel_name]?
              if !current_shovel.paused?
                context.response.status_code = 422
                next
              end
              current_shovel.resume
              context.response.status_code = 204
            else
              context.response.status_code = 404
            end
          end
        end
      end
    end
  end
end
