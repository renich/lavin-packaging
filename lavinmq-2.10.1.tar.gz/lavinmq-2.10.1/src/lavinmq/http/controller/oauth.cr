require "base64"
require "../controller"
require "../router"
require "../oauth2/pkce"
require "../oauth2/token_exchange"
require "../../auth/jwt/jwks_fetcher"

module LavinMQ
  module HTTP
    class OAuthController
      include Router

      Log = LavinMQ::Log.for "http.oauth"

      def initialize(@oauth_authenticator : Auth::OAuthAuthenticator)
        register_routes
      end

      def call(context)
        authenticate_jwt_cookie(context) if management_api_request?(context)
        super
      end

      # The oauth_token cookie is only consumed to authenticate management HTTP
      # API requests. Limiting the (relatively expensive) JWT verification to
      # the /api path keeps a forged cookie from forcing signature checks on
      # every unrelated request, e.g. static assets or the login page (GH #2077).
      private def management_api_request?(context) : Bool
        context.request.path.starts_with?("/api/")
      end

      private def authenticate_jwt_cookie(context)
        token = context.request.cookies["oauth_token"]?
        return if token.nil?

        if user = authenticate_token(token.value, context.request.remote_address)
          context.user = user
          return
        end

        # No JWKS keys yet means verification couldn't run; keep the session
        # cookies, the token may still be valid.
        return if @oauth_authenticator.token_verifier.fetcher.public_keys.empty?

        expire_cookie(context, "oauth_token", cookie_path)
        expire_cookie(context, "m", cookie_path)
      end

      private def authenticate_token(token, remote_address) : Auth::BaseUser?
        auth_context = Auth::Context.new("", token.to_slice, remote_address)
        user = @oauth_authenticator.authenticate(auth_context)
        return if user.nil? || user.tags.empty?
        user
      end

      private def register_routes
        get "/oauth/enabled" { |context, _params| handle_enabled(context) }
        get "/oauth/authorize" { |context, _params| handle_authorize(context) }
        get "/oauth/callback" { |context, _params| handle_callback(context) }
        get "/oauth/logout" { |context, _params| handle_logout(context) }
      end

      private def handle_enabled(context) : ::HTTP::Server::Context
        context.response.content_type = "application/json"
        {enabled: Config.instance.oauth_mgmt_ui_enabled?}.to_json(context.response)
        context
      end

      private def handle_authorize(context) : ::HTTP::Server::Context
        config = Config.instance
        oauth_error(context, 503, "OAuth not configured") unless config.oauth_mgmt_ui_enabled?
        client_id = config.oauth_client_id || oauth_error(context, 503, "OAuth not configured")

        auth_ep = oidc_config.authorization_endpoint || raise "OIDC missing authorization_endpoint"
        verifier, challenge = OAuth2::PKCE.generate
        state = Random::Secure.urlsafe_base64(32)

        set_cookie(context, "oauth_state", "#{state}:#{verifier}",
          path: cookie_path, http_only: true, max_age: 5.minutes)

        params = ::URI::Params.build do |p|
          p.add "client_id", client_id
          p.add "redirect_uri", build_redirect_uri
          p.add "response_type", "code"
          p.add "scope", config.oauth_mgmt_scopes
          p.add "code_challenge", challenge
          p.add "code_challenge_method", "S256"
          p.add "state", state
          # Some IdPs (e.g. Auth0) only issue JWT access tokens when an audience is requested
          if audience = config.oauth_audience
            p.add "audience", audience
          end
        end

        context.response.content_type = "application/json"
        {authorize_url: "#{auth_ep}?#{params}"}.to_json(context.response)
        context
      rescue OAuthError
        context
      rescue ex
        Log.error(exception: ex) { "OAuth authorize failed (#{ex.class})" }
        context.response.status_code = 502
        context.response.content_type = "application/json"
        {reason: "OAuth authorization failed"}.to_json(context.response)
        context
      end

      private def handle_callback(context) : ::HTTP::Server::Context
        code, code_verifier, client_id = validate_callback(context)

        token_ep = oidc_config.token_endpoint || raise "OIDC missing token_endpoint"
        token_response = OAuth2::TokenExchange.new(token_ep, client_id)
          .exchange(code, build_redirect_uri, code_verifier)

        user = authenticate_token(token_response.access_token, context.request.remote_address)
        oauth_redirect_error(context, "Token validation failed") if user.nil?

        max_age = token_response.expires_in.try { |e| Math.min(e, 8.hours.total_seconds.to_i64).seconds } || 8.hours

        set_cookie(context, "oauth_token", token_response.access_token,
          path: cookie_path, http_only: true, max_age: max_age)
        value = Base64.strict_encode("#{user.name}:")
        set_cookie(context, "m", "|oauth:#{URI.encode_path_segment(value)}",
          path: cookie_path, max_age: max_age)
        expire_cookie(context, "oauth_state", cookie_path)

        context.response.status = ::HTTP::Status::FOUND
        context.response.headers["Location"] = ".."
        context
      rescue OAuthError
        context
      rescue ex
        Log.error(exception: ex) { "OAuth callback failed (#{ex.class})" }
        context.response.status = ::HTTP::Status::FOUND
        context.response.headers["Location"] = "../login?error=#{URI.encode_path_segment("OAuth authentication failed")}"
        context
      end

      private def handle_logout(context) : ::HTTP::Server::Context
        expire_cookie(context, "oauth_token", cookie_path)
        expire_cookie(context, "m", cookie_path)
        context.response.status = ::HTTP::Status::FOUND
        context.response.headers["Location"] = "../login"
        context
      end

      private def validate_callback(context) : {String, String, String}
        config = Config.instance
        oauth_redirect_error(context, "OAuth not configured") unless config.oauth_mgmt_ui_enabled?
        client_id = config.oauth_client_id || oauth_redirect_error(context, "OAuth not configured")

        if error = context.request.query_params["error"]?
          description = context.request.query_params["error_description"]? || error
          oauth_redirect_error(context, description)
        end

        cookie_value = context.request.cookies["oauth_state"]?.try(&.value) || oauth_redirect_error(context, "Missing OAuth state")
        sep = cookie_value.index(':') || oauth_redirect_error(context, "Invalid OAuth state cookie")
        expected_state = cookie_value[0...sep]
        provided_state = context.request.query_params["state"]? || oauth_redirect_error(context, "State mismatch")
        oauth_redirect_error(context, "State mismatch") unless Crypto::Subtle.constant_time_compare(expected_state, provided_state)
        code = context.request.query_params["code"]? || oauth_redirect_error(context, "Missing authorization code")

        {code, cookie_value[sep + 1..], client_id}
      end

      # SameSite defaults to Lax: the OAuth callback arrives as a top-level
      # redirect from the IdP, where Strict cookies are not sent.
      private def set_cookie(context, name, value, path = "/", http_only = false,
                             samesite = ::HTTP::Cookie::SameSite::Lax,
                             max_age = 8.hours)
        context.response.cookies << ::HTTP::Cookie.new(
          name: name, value: value, path: path, http_only: http_only,
          secure: cookies_secure?, samesite: samesite, max_age: max_age)
      end

      # Cookies are marked Secure unless the management UI is served over plain
      # HTTP (only allowed for localhost), where Secure cookies are dropped by
      # some browsers and would break the login flow.
      private def cookies_secure? : Bool
        base_url = Config.instance.oauth_mgmt_base_url
        return true unless base_url
        base_url.scheme != "http"
      end

      private def expire_cookie(context, name, path)
        context.response.cookies << ::HTTP::Cookie.new(name: name, value: "", path: path, max_age: 0.seconds)
      end

      # Scope auth cookies to the path the UI is served under (the path of
      # oauth_mgmt_base_url, e.g. "/lavinmq" behind a proxy), defaulting to "/".
      private def cookie_path : String
        path = Config.instance.oauth_mgmt_base_url.try(&.path).to_s.chomp("/")
        path.empty? ? "/" : path
      end

      private def oauth_error(context, status_code, message) : NoReturn
        context.response.status_code = status_code
        context.response.content_type = "application/json"
        {reason: message}.to_json(context.response)
        raise OAuthError.new
      end

      private def oauth_redirect_error(context, message) : NoReturn
        context.response.status = ::HTTP::Status::FOUND
        context.response.headers["Location"] = "../login?error=#{URI.encode_path_segment(message)}"
        raise OAuthError.new
      end

      private def oidc_config : Auth::JWT::JWKSFetcher::OIDCConfiguration
        fetcher = @oauth_authenticator.token_verifier.fetcher
        fetcher.oidc_config || fetcher.fetch_oidc_config
      end

      private def build_redirect_uri : String
        base_url = Config.instance.oauth_mgmt_base_url || raise "oauth_mgmt_base_url must be configured when OAuth is enabled"
        "#{base_url.to_s.chomp("/")}/oauth/callback"
      end

      class OAuthError < Exception; end
    end
  end
end
