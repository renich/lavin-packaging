require "./spec_helper"
require "./../src/lavinmq/amqp/queue"

describe LavinMQ::Client::Channel::Consumer do
  describe "without x-priority" do
    it "should round-robin" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("consumer-priority")
          ch.prefetch 1
          msgs = Channel(Int32).new

          q.subscribe(no_ack: false) do |msg|
            msgs.send 1
            msg.ack
          end

          q.subscribe(no_ack: false) do |msg|
            msgs.send 2
            msg.ack
          end

          q.publish("priority")
          q.publish("priority")
          msgs.receive.should eq 1
          msgs.receive.should eq 2
        end
      end
    end

    it "should round-robin when all consumers have capacity" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("round-robin")
          got = Channel(Int32).new
          with_channel(s) do |ch1|
            with_channel(s) do |ch2|
              {ch1, ch2}.each_with_index do |consumer_ch, i|
                consumer_ch.prefetch 8 - 4 * i
                consumer_ch.basic_consume(q.name, no_ack: false) do |msg|
                  msg.ack
                  got.send i
                end
              end
              # The first message starts the deliver loops, which don't
              # race for it in line
              q.publish("m")
              got.receive
              # Publish one at a time, so both consumers are idle with free
              # capacity whenever a message arrives
              order = Array.new(20) do
                q.publish("m")
                got.receive
              end
              order.each_cons_pair { |a, b| a.should_not eq b }
            end
          end
        end
      end
    end

    it "should not stall other consumers when one consumer's client stops reading" do
      LavinMQ::Config.instance.tcp_send_timeout = 30
      LavinMQ::Config.instance.tcp_send_buffer_size = 4096
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("stalled-reader")
          queue = s.vhosts["/"].queue(q.name)
          # A no-ack consumer that never reads, with small buffers so they fill fast
          with_raw_amqp_connection(s) do |io, stream|
            io.recv_buffer_size = 4096
            io.write_bytes AMQ::Protocol::Frame::Channel::Open.new(1_u16), IO::ByteFormat::NetworkEndian
            io.flush
            stream.next_frame.as(AMQ::Protocol::Frame::Channel::OpenOk)
            io.write_bytes AMQ::Protocol::Frame::Basic::Consume.new(1_u16, 0_u16, q.name, "", false, true, false, false,
              AMQ::Protocol::Table.new), IO::ByteFormat::NetworkEndian
            io.flush
            stream.next_frame.as(AMQ::Protocol::Frame::Basic::ConsumeOk)
            with_channel(s) do |ch2|
              ch2.prefetch 10
              ch2.basic_consume(q.name, no_ack: false, &.ack)
              body = Bytes.new(8 * 1024)
              # One message at a time, so the queue is empty whenever the
              # stuck consumer flushes, and its flush blocks once its socket
              # is full. The other consumer must still get every message.
              200.times do
                q.publish_confirm body
                wait_for(3.seconds) { queue.message_count.zero? }
              end
            end
          end
        end
      end
    end
  end

  describe "with x-priority" do
    it "should respect priority" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("consumer-priority")
          ch.prefetch 1
          subscriber_args = AMQP::Client::Arguments.new({"x-priority" => 5})
          msgs = Channel(AMQP::Client::DeliverMessage?).new(1)

          q.subscribe(no_ack: false) do |_|
            msgs.send nil
          end

          q.subscribe(no_ack: false, args: subscriber_args) do |msg|
            msgs.send msg
          end

          q.publish_confirm("priority")
          m = msgs.receive
          m.should be_truthy
          if m.is_a?(AMQP::Client::DeliverMessage)
            m.ack
            m.body_io.to_s.should eq "priority"
          end
        end
      end
    end

    it "should send to prioritized consumer if ready" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("consumer-priority")
          ch.prefetch 1
          subscriber_args = AMQP::Client::Arguments.new({"x-priority" => 5})
          msgs = Channel(AMQP::Client::DeliverMessage?).new(1)

          q.subscribe(no_ack: false) do |_|
            msgs.send nil
          end

          q.subscribe(no_ack: false, args: subscriber_args) do |msg|
            msgs.send msg
          end

          q.publish_confirm("priority")
          m = msgs.receive
          m.should be_truthy
          if m.is_a?(AMQP::Client::DeliverMessage)
            m.ack
            m.body_io.to_s.should eq "priority"
          end

          q.publish_confirm("priority")
          m = msgs.receive
          m.should be_truthy
          if m.is_a?(AMQP::Client::DeliverMessage)
            m.ack
            m.body_io.to_s.should eq "priority"
          end
        end
      end
    end

    it "should round-robin to high priority consumers" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("consumer-priority")
          ch.prefetch 1
          subscriber_args = AMQP::Client::Arguments.new({"x-priority" => 5})

          msgs = Channel(Int32).new
          # This is a sync channel to make sure each consumer
          # is "working" long enough for the other consumer
          # to retrive a message...
          work = Channel(Bool).new
          q.subscribe(no_ack: false, args: subscriber_args) do |msg|
            msgs.send 1
            work.send true
            msg.ack
          end

          q.subscribe(no_ack: false, args: subscriber_args) do |msg|
            work.receive
            msgs.send 2
            msg.ack
          end

          100.times { q.publish("priority") }
          50.times do
            msgs.receive.should eq 1
            msgs.receive.should eq 2
          end
        end
      end
    end

    it "should accept any integer as x-priority" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue
          q.subscribe(args: AMQP::Client::Arguments.new({"x-priority": Int8::MIN})) { |_| }
          q.subscribe(args: AMQP::Client::Arguments.new({"x-priority": Int16::MAX})) { |_| }
          q.subscribe(args: AMQP::Client::Arguments.new({"x-priority": 1i64})) { |_| }
        end

        with_channel(s) do |ch|
          expect_raises(AMQP::Client::Channel::ClosedException, /out of bounds/) do
            q = ch.queue
            q.subscribe(args: AMQP::Client::Arguments.new({"x-priority": Int64::MAX})) { |_| }
          end
        end
      end
    end

    it "should not accept any thing but integers as x-priority" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          expect_raises(AMQP::Client::Channel::ClosedException, /must be an integer/) do
            q = ch.queue
            q.subscribe(args: AMQP::Client::Arguments.new({"x-priority": "a"})) { |_| }
          end
        end
      end

      with_amqp_server do |s|
        with_channel(s) do |ch|
          expect_raises(AMQP::Client::Channel::ClosedException, /must be an integer/) do
            q = ch.queue
            q.subscribe(args: AMQP::Client::Arguments.new({"x-priority": 0.1})) { |_| }
          end
        end
      end
    end

    it "should not strand a message when the channel closes during delivery" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("consumer-close-strand")
          999.times { q.publish("m") }
          q.publish_confirm("m")
          sq = s.vhosts["/"].queue("consumer-close-strand")
          subscriber_args = AMQP::Client::Arguments.new({"x-priority" => 1})
          20.times do
            with_channel(s) do |cch|
              cch.prefetch 100
              delivered = Channel(Nil).new(100)
              cch.queue("consumer-close-strand").subscribe(no_ack: false, args: subscriber_args) do |_|
                delivered.send nil
              end
              delivered.receive
            end
            # The deliver loop exits once it notices the closed channel
            sq.deliver_loop_wg.wait
            sq.consumers.should be_empty
            sq.unacked_count.should eq 0
            sq.message_count.should eq 1000
          end
        end
      end
    end

    it "should requeue a message shifted after the channel closed" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          # With no delivery attempt to spare, the message is dropped if the
          # delivery that never reached the client counts as one
          args = AMQP::Client::Arguments.new({"x-delivery-limit" => 0})
          q = ch.queue("consumer-close-shift", args: args)
          q.publish_confirm("m")
          sq = s.vhosts["/"].queue("consumer-close-shift")
          server_ch = s.connections.first.as(LavinMQ::AMQP::Client).channels.first.as(LavinMQ::AMQP::Channel)
          # Hold the queue's store lock, so that the deliver loop gets past its
          # closed checks and waits for the lock to shift the message, then
          # close the channel meanwhile, as the management API can
          sq.@msg_store_lock.synchronize do
            q.subscribe(no_ack: false) { |_| }
            wait_for { sq.consumers_size == 1 }
            Fiber.yield # Let the deliver loop reach the lock
            server_ch.close("closed during delivery")
          end
          # The deliver loop shifts the message, but the closed channel refuses
          # to record it as unacked, so the consumer has to requeue it
          wait_for { sq.message_count == 1 }
          sq.unacked_count.should eq 0
          sq.consumers.should be_empty
          sq.reject_count.should eq 0
        end
        with_channel(s) do |ch|
          msg = ch.basic_get("consumer-close-shift", no_ack: false).should_not be_nil
          # Redelivered, so it was shifted and requeued by the consumer rather
          # than stopped by the closed check before the shift, but it's still
          # on its first counted delivery
          msg.redelivered.should be_true
          msg.properties.headers.try(&.["x-delivery-count"]?).should be_nil
          msg.ack
        end
      end
    end

    it "should stop waiting for higher priority consumers when closed" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("prio-wait-close")
          sq = s.vhosts["/"].queue("prio-wait-close")
          # Without a prefetch limit this consumer never runs out of capacity
          high_prio = AMQP::Client::Arguments.new({"x-priority" => 10})
          q.subscribe(no_ack: false, args: high_prio) { |_| }
          low = with_channel(s) do |ch2|
            ch2.queue("prio-wait-close").subscribe(no_ack: false) { |_| }
            wait_for { sq.consumers_size == 2 }
            consumer = sq.consumers.find! { |c| c.priority == 0 }.as(LavinMQ::AMQP::Consumer)
            # Starts the deliver loops; the low priority one then waits for the
            # high priority consumer to run out of capacity, which it never does
            q.publish_confirm("m")
            wait_for { sq.unacked_count == 1 }
            consumer.@deliver_loop_running.get.should be_true
            consumer
          end
          # Closing the low priority consumer's channel must end that wait
          wait_for { !low.@deliver_loop_running.get }
        end
      end
    end
  end

  describe "on-demand deliver_loop" do
    it "delivers messages published after consumer connects to empty queue" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("on-demand-deliver-loop")
          msgs = Channel(String).new

          q.subscribe(no_ack: true) do |msg|
            msgs.send msg.body_io.to_s
          end

          q.publish("test1")
          q.publish("test2")

          msgs.receive.should eq "test1"
          msgs.receive.should eq "test2"
        end
      end
    end

    it "delivers messages already in queue when consumer connects" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("on-demand-deliver-loop-nonempty")
          q.publish("pre-existing")

          msgs = Channel(String).new
          q.subscribe(no_ack: true) do |msg|
            msgs.send msg.body_io.to_s
          end

          msgs.receive.should eq "pre-existing"
        end
      end
    end

    it "delivers requeued messages to consumers on empty queue" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          q = ch.queue("on-demand-deliver-loop-requeue")
          ch.prefetch 1
          msgs = Channel(AMQP::Client::DeliverMessage).new

          q.subscribe(no_ack: false) do |msg|
            msgs.send msg
          end

          q.publish("requeue-me")
          msg = msgs.receive
          msg.body_io.to_s.should eq "requeue-me"
          msg.reject(requeue: true)

          msg2 = msgs.receive
          msg2.body_io.to_s.should eq "requeue-me"
          msg2.ack
        end
      end
    end

    it "shuts down deliver_loop after idle timeout and respawns on next message" do
      config = LavinMQ::Config.new
      config.deliver_loop_idle_timeout = 100.milliseconds
      with_amqp_server(config: config) do |s|
        with_channel(s) do |ch|
          q = ch.queue("idle-respawn")
          msgs = Channel(String).new
          q.subscribe(no_ack: true) { |msg| msgs.send msg.body_io.to_s }

          q.publish "first"
          msgs.receive.should eq "first"

          # Wait for deliver_loop to idle out
          sleep 300.milliseconds

          q.publish "after-idle"
          select
          when msg = msgs.receive
            msg.should eq "after-idle"
          when timeout 500.milliseconds
            fail "deliver_loop did not respawn after idle timeout"
          end
        end
      end
    end

    it "respawns idle consumer's deliver loop when channel close requeues a message" do
      with_amqp_server do |s|
        with_channel(s) do |ch|
          conn = AMQP::Client.new(port: amqp_port(s)).connect
          msgs = Channel(AMQP::Client::DeliverMessage).new

          q = conn.channel.queue("respawn-on-reject")
          q.subscribe(no_ack: false) { |msg| msgs.send msg }
          q.publish "test-msg"
          msgs.receive

          # Subscribes to an empty queue, so its deliver_loop won't start
          ch.queue("respawn-on-reject").subscribe(no_ack: false) { |msg| msgs.send msg }

          # Closing connection requeues the unacked msg via reject;
          # The other consumers deliver_loop must respawn to consume it
          conn.close

          select
          when msg = msgs.receive
            msg.body_io.to_s.should eq "test-msg"
          when timeout 500.milliseconds
            fail "Consumer did not receive requeued message"
          end
        end
      end
    end
  end
end
