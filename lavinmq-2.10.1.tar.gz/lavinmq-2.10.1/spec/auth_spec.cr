require "./spec_helper"
require "../src/lavinmq/auth/chain"
require "../src/lavinmq/auth/authenticators/local"

class MockVerifier < LavinMQ::Auth::JWT::TokenVerifier
  def initialize(config : LavinMQ::Config, @username : String, @tags : Array(LavinMQ::Tag)?,
                 @permissions : Hash(String, LavinMQ::Auth::BaseUser::Permissions)?, @expires_at : Time)
    uri = config.oauth_issuer_url || URI.new
    jwks_fetcher = LavinMQ::Auth::JWT::JWKSFetcher.new(uri, config.oauth_jwks_cache_ttl)
    super(config, jwks_fetcher)
  end
end

class MockJWKSFetcher < LavinMQ::Auth::JWT::JWKSFetcher
  def initialize
    super(URI.new, 1.seconds)
  end

  def fetch_and_update
  end
end

class SimpleMockVerifier < LavinMQ::Auth::JWT::TokenVerifier
  def initialize(config : LavinMQ::Config = LavinMQ::Config.new)
    config.oauth_issuer_url = URI.new if config.oauth_issuer_url.nil?
    super(config, MockJWKSFetcher.new)
  end
end

# Returns the frame the server answers Connection.StartOk with: Tune if accepted, Close if refused
private def amqp_login(port : Int32, username : String, password : String, proxy_header : String? = nil)
  socket = TCPSocket.new("localhost", port)
  socket.read_timeout = 5.seconds
  socket.write proxy_header.to_slice if proxy_header
  socket.write LavinMQ::AMQP::PROTOCOL_START_0_9_1.to_slice
  socket.flush
  stream = AMQ::Protocol::Stream.new(socket)
  stream.next_frame.should be_a AMQ::Protocol::Frame::Connection::Start
  props = AMQ::Protocol::Table.new({capabilities: {authentication_failure_close: true}})
  start_ok = AMQ::Protocol::Frame::Connection::StartOk.new(props, "PLAIN", "\u0000#{username}\u0000#{password}", "en_US")
  socket.write_bytes start_ok, IO::ByteFormat::NetworkEndian
  socket.flush
  stream.next_frame
ensure
  socket.try &.close
end

describe LavinMQ::Auth::Chain do
  it "creates a default authentication chain if not configured" do
    with_amqp_server do |s|
      chain = LavinMQ::Auth::Chain.create(s.@config, s.@users)
      chain.@backends.should be_a Array(LavinMQ::Auth::Authenticator)
      chain.@backends.size.should eq 1
    end
  end

  it "successfully authenticates and returns a local user" do
    with_amqp_server do |s|
      chain = LavinMQ::Auth::Chain.create(s.@config, s.@users)
      ctx = LavinMQ::Auth::Context.new("guest", "guest".to_slice, loopback: true)
      user = chain.authenticate(ctx)
      user.should_not be_nil
    end
  end

  it "does not authenticate when given invalid credentials" do
    with_amqp_server do |s|
      s.@users.create("foo", "bar")
      chain = LavinMQ::Auth::Chain.create(s.@config, s.@users)
      ctx = LavinMQ::Auth::Context.new("bar", "baz".to_slice, loopback: true)
      user = chain.authenticate(ctx)
      user.should be_nil
    end
  end

  it "requires loopback if Config.#default_user_only_loopback? is true" do
    with_amqp_server do |s|
      LavinMQ::Config.instance.default_user_only_loopback = true
      # verifier = SimpleMockVerifier.new(s.@config)
      chain = LavinMQ::Auth::Chain.create(s.@config, s.@users)
      ctx = LavinMQ::Auth::Context.new("guest", "guest".to_slice, loopback: false)
      user = chain.authenticate(ctx)
      user.should be_nil
    end
  end

  describe "default user loopback gate with PROXY protocol" do
    it "rejects the default user when a PROXY header claims a loopback source" do
      with_amqp_server do |s|
        with_proxy_protocol do
          port = amqp_port(s)
          header = "PROXY TCP4 127.0.0.1 127.0.0.1 54321 #{port}\r\n"
          frame = amqp_login(port, "guest", "guest", header)
          frame.should be_a AMQ::Protocol::Frame::Connection::Close
          frame.as(AMQ::Protocol::Frame::Connection::Close).reply_code.should eq 403
        end
      end
    end

    it "accepts the default user from a real loopback connection without a PROXY header" do
      with_amqp_server do |s|
        with_proxy_protocol do
          frame = amqp_login(amqp_port(s), "guest", "guest")
          frame.should be_a AMQ::Protocol::Frame::Connection::Tune
        end
      end
    end

    it "rejects the default user when a listed proxy reports a loopback source" do
      with_amqp_server do |s|
        with_proxy_protocol([LavinMQ::IPMatcher.parse("127.0.0.1"), LavinMQ::IPMatcher.parse("::1")]) do
          port = amqp_port(s)
          header = "PROXY TCP4 127.0.0.1 127.0.0.1 54321 #{port}\r\n"
          frame = amqp_login(port, "guest", "guest", header)
          frame.should be_a AMQ::Protocol::Frame::Connection::Close
          frame.as(AMQ::Protocol::Frame::Connection::Close).reply_code.should eq 403
        end
      end
    end

    it "rejects the default user when a listed proxy reports a remote source" do
      with_amqp_server do |s|
        with_proxy_protocol([LavinMQ::IPMatcher.parse("127.0.0.1"), LavinMQ::IPMatcher.parse("::1")]) do
          port = amqp_port(s)
          header = "PROXY TCP4 10.1.2.3 127.0.0.1 54321 #{port}\r\n"
          frame = amqp_login(port, "guest", "guest", header)
          frame.should be_a AMQ::Protocol::Frame::Connection::Close
          frame.as(AMQ::Protocol::Frame::Connection::Close).reply_code.should eq 403
        end
      end
    end

    it "accepts a non-default user when a PROXY header claims a loopback source" do
      with_amqp_server do |s|
        with_proxy_protocol do
          s.@users.create("foo", "bar")
          port = amqp_port(s)
          header = "PROXY TCP4 127.0.0.1 127.0.0.1 54321 #{port}\r\n"
          frame = amqp_login(port, "foo", "bar", header)
          frame.should be_a AMQ::Protocol::Frame::Connection::Tune
        end
      end
    end
  end

  describe "auth backend configuration" do
    it "creates only local authenticator when backends is ['local']" do
      config = LavinMQ::Config.new
      config.auth_backends = ["local"]
      with_datadir do |data_dir|
        config.data_dir = data_dir
        users = LavinMQ::Auth::UserStore.new(data_dir, nil)
        # verifier = SimpleMockVerifier.new(config)
        chain = LavinMQ::Auth::Chain.create(config, users)
        chain.@backends.size.should eq 1
        chain.@backends[0].should be_a LavinMQ::Auth::LocalAuthenticator
      end
    end

    it "creates only oauth authenticator when backends is ['oauth']" do
      config = LavinMQ::Config.new
      config.auth_backends = ["oauth"]
      config.oauth_issuer_url = URI.parse("https://test-giant-beige-hawk.rmq7.cloudamqp.com/realms/lavinmq-dev/")
      config.oauth_preferred_username_claims = ["preferred_username"]
      with_datadir do |data_dir|
        config.data_dir = data_dir
        users = LavinMQ::Auth::UserStore.new(data_dir, nil)
        chain = LavinMQ::Auth::Chain.create(config, users)
        chain.@backends.size.should eq 1
        chain.@backends[0].should be_a LavinMQ::Auth::OAuthAuthenticator
      end
    end

    it "creates both authenticators when backends is ['local', 'oauth']" do
      config = LavinMQ::Config.new
      config.auth_backends = ["local", "oauth"]
      config.oauth_issuer_url = URI.parse("https://test-giant-beige-hawk.rmq7.cloudamqp.com/realms/lavinmq-dev/")
      config.oauth_preferred_username_claims = ["preferred_username"]
      with_datadir do |data_dir|
        config.data_dir = data_dir
        users = LavinMQ::Auth::UserStore.new(data_dir, nil)
        chain = LavinMQ::Auth::Chain.create(config, users)
        chain.@backends.size.should eq 2
        chain.@backends[0].should be_a LavinMQ::Auth::LocalAuthenticator
        chain.@backends[1].should be_a LavinMQ::Auth::OAuthAuthenticator
      end
    end

    it "creates authenticators in specified order ['oauth', 'local']" do
      config = LavinMQ::Config.new
      config.auth_backends = ["oauth", "local"]
      config.oauth_issuer_url = URI.parse("https://test-giant-beige-hawk.rmq7.cloudamqp.com/realms/lavinmq-dev/")
      config.oauth_preferred_username_claims = ["preferred_username"]
      with_datadir do |data_dir|
        config.data_dir = data_dir
        users = LavinMQ::Auth::UserStore.new(data_dir, nil)
        chain = LavinMQ::Auth::Chain.create(config, users)
        chain.@backends.size.should eq 2
        chain.@backends[0].should be_a LavinMQ::Auth::OAuthAuthenticator
        chain.@backends[1].should be_a LavinMQ::Auth::LocalAuthenticator
      end
    end

    it "raises error for unsupported backend" do
      config = LavinMQ::Config.new
      config.auth_backends = ["unsupported"]
      with_datadir do |data_dir|
        config.data_dir = data_dir
        users = LavinMQ::Auth::UserStore.new(data_dir, nil)
        expect_raises(Exception, /Unsupported authentication backend/) do
          LavinMQ::Auth::Chain.create(config, users)
        end
      end
    end

    it "raises error when invalid backend is mixed with valid ones" do
      config = LavinMQ::Config.new
      config.auth_backends = ["local", "invalid", "oauth"]
      config.oauth_issuer_url = URI.parse("https://auth.example.com")
      with_datadir do |data_dir|
        config.data_dir = data_dir
        users = LavinMQ::Auth::UserStore.new(data_dir, nil)
        expect_raises(Exception, /Unsupported authentication backend: invalid/) do
          LavinMQ::Auth::Chain.create(config, users)
        end
      end
    end
  end

  describe "auth chaining fallback behavior" do
    it "tries local first, then oauth when both configured" do
      config = LavinMQ::Config.new
      config.auth_backends = ["local", "oauth"]
      config.oauth_issuer_url = URI.parse("https://auth.example.com")
      config.oauth_preferred_username_claims = ["preferred_username"]

      with_datadir do |data_dir|
        config.data_dir = data_dir
        users = LavinMQ::Auth::UserStore.new(data_dir, nil)
        users.create("testuser", "localpass", [LavinMQ::Tag::Administrator])

        chain = LavinMQ::Auth::Chain.create(config, users)

        # Should authenticate with local backend
        ctx = LavinMQ::Auth::Context.new("testuser", "localpass".to_slice, loopback: true)
        user = chain.authenticate ctx
        user.should_not be_nil
        user.should be_a LavinMQ::Auth::User
        user.try(&.name).should eq "testuser"
      end
    end

    it "returns nil when all backends in chain fail" do
      config = LavinMQ::Config.new
      config.auth_backends = ["local", "oauth"]
      config.oauth_issuer_url = URI.parse("https://auth.example.com")
      config.oauth_preferred_username_claims = ["preferred_username"]

      with_datadir do |data_dir|
        config.data_dir = data_dir
        users = LavinMQ::Auth::UserStore.new(data_dir, nil)
        users.create("testuser", "correctpass", [LavinMQ::Tag::Administrator])

        chain = LavinMQ::Auth::Chain.create(config, users)

        # Wrong password for local user, not a JWT for oauth
        ctx = LavinMQ::Auth::Context.new("testuser", "wrongpass".to_slice, loopback: true)
        user = chain.authenticate ctx
        user.should be_nil
      end
    end
  end

  describe "OauthUser" do
    it "token_lifetime returns positive duration for non-expired token" do
      config = LavinMQ::Config.new
      config.oauth_issuer_url = URI.parse("https://auth.example.com")
      config.oauth_preferred_username_claims = ["preferred_username"]
      verifier = MockVerifier.new(config, "testuser", nil, nil, Time.utc + 1.hour)

      user = LavinMQ::Auth::OAuthUser.new(
        "testuser",
        [] of LavinMQ::Tag,
        {} of String => LavinMQ::Auth::BaseUser::Permissions,
        Time.utc + 1.hour,
        verifier
      )

      lifetime = user.token_lifetime
      lifetime.should be > 59.minutes
      lifetime.should be <= 1.hour + 1.second
    end

    it "token_lifetime returns negative duration for expired token" do
      config = LavinMQ::Config.new
      config.oauth_issuer_url = URI.parse("https://auth.example.com")
      config.oauth_preferred_username_claims = ["preferred_username"]
      verifier = MockVerifier.new(config, "testuser", nil, nil, Time.utc + 1.hour)

      user = LavinMQ::Auth::OAuthUser.new(
        "testuser",
        [] of LavinMQ::Tag,
        {} of String => LavinMQ::Auth::BaseUser::Permissions,
        Time.utc - 1.hour,
        verifier
      )

      lifetime = user.token_lifetime
      lifetime.should eq 0.seconds
    end

    describe "on_expiration" do
      it "calls the block when token expires" do
        config = LavinMQ::Config.new
        config.oauth_issuer_url = URI.parse("https://auth.example.com")
        config.oauth_preferred_username_claims = ["preferred_username"]
        verifier = MockVerifier.new(config, "testuser", nil, nil, Time.utc + 50.milliseconds)

        user = LavinMQ::Auth::OAuthUser.new(
          "testuser",
          [] of LavinMQ::Tag,
          {} of String => LavinMQ::Auth::BaseUser::Permissions,
          Time.utc + 50.milliseconds,
          verifier
        )

        callback_called = Channel(Nil).new

        user.on_expiration do
          callback_called.send nil
        end

        select
        when callback_called.receive
          # Expected behavior - callback was called
        when timeout(500.milliseconds)
          fail "Expected expiration callback to be called"
        end
      end

      it "does not call block before expiration" do
        config = LavinMQ::Config.new
        config.oauth_issuer_url = URI.parse("https://auth.example.com")
        config.oauth_preferred_username_claims = ["preferred_username"]
        verifier = MockVerifier.new(LavinMQ::Config.new, "testuser", nil, nil, Time.utc + 1.hour)

        user = LavinMQ::Auth::OAuthUser.new(
          "testuser",
          [] of LavinMQ::Tag,
          {} of String => LavinMQ::Auth::BaseUser::Permissions,
          Time.utc + 1.hour,
          verifier
        )

        callback_called = false

        user.on_expiration do
          callback_called = true
        end

        sleep 50.milliseconds
        callback_called.should be_false
      end
    end
  end

  describe "permissions_details" do
    it "returns correct permission details for local user" do
      with_datadir do |data_dir|
        users = LavinMQ::Auth::UserStore.new(data_dir, nil)
        user = users.create("testuser", "password", [LavinMQ::Tag::Administrator])
        user.permissions["/"] = {config: /.*/, read: /.*/, write: /.*/}

        details = user.permissions_details("/", user.permissions["/"])

        details[:user].should eq "testuser"
        details[:vhost].should eq "/"
        details[:configure].should eq /.*/
        details[:read].should eq /.*/
        details[:write].should eq /.*/
      end
    end

    it "returns correct permission details for OAuth user" do
      config = LavinMQ::Config.new
      config.oauth_issuer_url = URI.parse("https://auth.example.com")
      config.oauth_preferred_username_claims = ["preferred_username"]
      verifier = MockVerifier.new(config, "testuser", nil, nil, Time.utc + 1.hour)

      permissions = {"/" => {config: /^queue/, read: /.*/, write: /^exchange/}}
      user = LavinMQ::Auth::OAuthUser.new(
        "oauthuser",
        [] of LavinMQ::Tag,
        permissions,
        Time.utc + 1.hour,
        verifier
      )

      details = user.permissions_details("/", permissions["/"])

      details[:user].should eq "oauthuser"
      details[:vhost].should eq "/"
      details[:configure].should eq /^queue/
      details[:read].should eq /.*/
      details[:write].should eq /^exchange/
    end
  end
end
