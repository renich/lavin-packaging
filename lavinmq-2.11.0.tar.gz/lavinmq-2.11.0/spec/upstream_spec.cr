require "./spec_helper"
require "log/spec"
require "../src/lavinmq/federation/upstream"
require "../src/lavinmq/federation/upstream_store"

module UpstreamSpecHelpers
  def self.setup_qs(ch) : {AMQP::Client::Exchange, AMQP::Client::Queue}
    x = ch.exchange("", "direct", passive: true)
    ch.queue("federation_q1")
    q2 = ch.queue("federation_q2")
    {x, q2}
  end

  def self.setup_federation(s, upstream_name, exchange = nil, queue = nil, prefetch = 1000_u16, *,
                            reconnect_delay = 1.millisecond)
    cleanup_vhosts(s)
    upstream_vhost = s.vhosts.create("upstream")
    downstream_vhost = s.vhosts.create("downstream")
    upstream = LavinMQ::Federation::Upstream.new(
      downstream_vhost, upstream_name,
      "#{s.amqp_server.url}/upstream", exchange, queue,
      LavinMQ::Federation::AckMode::OnConfirm, expires: nil, max_hops: 1_i64,
      msg_ttl: nil, prefetch: prefetch, reconnect_delay: reconnect_delay
    )
    downstream_vhost.upstreams.add(upstream)
    {upstream, upstream_vhost, downstream_vhost}
  end

  # A TCP proxy to the AMQP server that holds accepted connections until the
  # gate is closed, to park a link in its upstream connect. `accepted` gets
  # a value for each accepted connection
  def self.with_gated_proxy(s, &)
    target = URI.parse(s.amqp_server.url)
    proxy = TCPServer.new("127.0.0.1", 0)
    accepted = Channel(Nil).new(16)
    gate = Channel(Nil).new
    spawn(name: "gated proxy") do
      while client = proxy.accept?
        select
        when accepted.send nil
        else
        end
        spawn forward_when_open(client, target, gate), name: "gated proxy connection"
      end
    end
    url = target.dup
    url.host = "127.0.0.1"
    url.port = proxy.local_address.port
    yield url, accepted, gate
  ensure
    gate.try &.close
    proxy.try &.close
  end

  private def self.forward_when_open(client : TCPSocket, target : URI, gate : Channel(Nil))
    gate.receive?
    forward(client, target)
  end

  # Connects `client` to `target` and copies both ways. A method of its own
  # so the copying fibers capture this connection's sockets: blocks spawned
  # in the accept loop would share its variables, which the next accept?
  # overwrites, with nil once the proxy closes.
  private def self.forward(client : TCPSocket, target : URI)
    server = TCPSocket.new(target.hostname.not_nil!("URI has no host"), target.port.not_nil!("URI has no port"))
    spawn { IO.copy(client, server) rescue nil; server.close rescue nil }
    spawn { IO.copy(server, client) rescue nil; client.close rescue nil }
  rescue IO::Error
    client.close
  end

  def self.start_link(upstream, pattern = "downstream_ex", applies_to = "exchanges")
    definitions = {"federation-upstream" => JSON::Any.new(upstream.name)} of String => JSON::Any
    upstream.vhost.add_policy("FE", pattern, applies_to, definitions, 12_i8)
  end

  def self.cleanup_vhost(s, vhost_name)
    v = s.vhosts[vhost_name]
    s.vhosts.delete(vhost_name)
    wait_for { !(Dir.exists?(v.data_dir)) }
  rescue KeyError
  end

  def self.cleanup_vhosts(s)
    cleanup_vhost(s, "upstream")
    cleanup_vhost(s, "downstream")
  end

  def self.with_fe_chain(s : LavinMQ::Server, chain_length = 10, max_hops = chain_length, &)
    url = URI.parse(s.amqp_server.url)
    # Create ten vhosts, each with an exchange "fe"
    # Setup a chain of exchange federation with v10 as downstream
    # and v1 as "top upstream"
    # Messages should travel
    # v1:fe -> v2:fe -> v3:fe -> ... -> v4:fe -> v10:fe
    vhosts = [] of LavinMQ::VHost
    upstreams = [] of LavinMQ::Federation::Upstream
    vhost1 = s.vhosts.create("v1")
    vhost1.declare_exchange("fe", "topic", durable: true, auto_delete: false)
    vhosts << vhost1
    vhost_prev = vhost1
    2.to(chain_length) do |i|
      vhost = s.vhosts.create("v#{i}")
      vhosts << vhost
      vhost.declare_exchange("fe", "topic", durable: true, auto_delete: false)
      url.path = vhost_prev.name
      upstream = LavinMQ::Federation::Upstream.new(vhost, "ef from #{vhost_prev.name}", url.to_s, exchange: nil, queue: nil, max_hops: max_hops)
      upstreams << upstream
      vhost.upstreams.add(upstream)
      link = upstream.link(vhost.exchange("fe"))
      wait_for { link.state.running? }
      vhost_prev = vhost
    end
    yield vhosts, upstreams
  ensure
    upstreams.try &.each &.close
  end
end

describe LavinMQ::Federation::Upstream do
  describe "Queue federation" do
    it "should use federated queue's name if @queue is empty" do
      with_amqp_server do |s|
        vhost_downstream = s.vhosts.create("/")
        vhost_upstream = s.vhosts.create("upstream")
        upstream = LavinMQ::Federation::Upstream.new(vhost_downstream, "qf test upstream", "#{s.amqp_server.url}/upstream", nil, "")

        with_channel(s) do |ch|
          ch.queue("federated_q")
          link = upstream.link(vhost_downstream.queue("federated_q"))
          link.name.should eq "federated_q"
          wait_for { link.state.running? }
          vhost_upstream.queue_exists?("federated_q").should be_true
        end
      ensure
        upstream.try &.close
      end
    end

    it "should federate queue" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        upstream = LavinMQ::Federation::Upstream.new(vhost, "qf test upstream", s.amqp_server.url, nil, "federation_q1")

        with_channel(s) do |ch|
          x, q2 = UpstreamSpecHelpers.setup_qs ch
          x.publish_confirm "federate me", "federation_q1"
          upstream.link(vhost.queue("federation_q2"))
          msgs = Channel(String).new
          q2.subscribe { |msg| msgs.send msg.body_io.to_s }
          msgs.should be_receiving "federate me"
          vhost.queue("federation_q1").message_count.should eq 0
        end
      ensure
        upstream.try &.close
      end
    end

    it "should not federate queue if no downstream consumer" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        upstream = LavinMQ::Federation::Upstream.new(vhost, "qf test upstream wo downstream", s.amqp_server.url, nil, "federation_q1")

        with_channel(s) do |ch|
          x = UpstreamSpecHelpers.setup_qs(ch).first
          x.publish_confirm "federate me", "federation_q1"
          link = upstream.link(vhost.queue("federation_q2"))
          wait_for { link.state.running? }
          vhost.queue("federation_q1").message_count.should eq 1
          vhost.queue("federation_q2").message_count.should eq 0
        end
      ensure
        upstream.try &.close
      end
    end

    it "should federate queue with ack mode no-ack" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        upstream = LavinMQ::Federation::Upstream.new(vhost, "qf test upstream no-ack", s.amqp_server.url, nil, "federation_q1",
          ack_mode: LavinMQ::Federation::AckMode::NoAck)

        with_channel(s) do |ch|
          x, q2 = UpstreamSpecHelpers.setup_qs ch
          x.publish_confirm "federate me", "federation_q1"
          upstream.link(vhost.queue("federation_q2"))
          msgs = Channel(String).new
          q2.subscribe { |msg| msgs.send msg.body_io.to_s }
          msgs.should be_receiving "federate me"
          vhost.queue("federation_q1").message_count.should eq 0
        end
      ensure
        upstream.try &.close
      end
    end

    it "should federate queue with ack mode on-publish" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        upstream = LavinMQ::Federation::Upstream.new(vhost, "qf test upstream on-publish", s.amqp_server.url, nil, "federation_q1",
          ack_mode: LavinMQ::Federation::AckMode::OnPublish)

        with_channel(s) do |ch|
          x, q2 = UpstreamSpecHelpers.setup_qs ch
          x.publish_confirm "federate me", "federation_q1"
          upstream.link(vhost.queue("federation_q2"))
          msgs = Channel(String).new
          q2.subscribe { |msg| msgs.send msg.body_io.to_s }
          msgs.should be_receiving "federate me"
          vhost.queue("federation_q1").message_count.should eq 0
        end
      ensure
        upstream.try &.close
      end
    end

    it "stops the link when the federated queue is deleted" do
      with_amqp_server do |s|
        upstream, _, downstream_vhost =
          UpstreamSpecHelpers.setup_federation(s, "qf delete queue", nil, "upstream_q")
        downstream_vhost.declare_queue("downstream_q", true, false)
        q = downstream_vhost.queue("downstream_q")
        link = upstream.link(q)

        q.delete

        upstream.links.should be_empty
        wait_for { link.state.terminated? }
      end
    end

    it "stops the link when the federated queue is closed" do
      with_amqp_server do |s|
        upstream, _, downstream_vhost =
          UpstreamSpecHelpers.setup_federation(s, "qf close queue", nil, "upstream_q")
        downstream_vhost.declare_queue("downstream_q", true, false)
        q = downstream_vhost.queue("downstream_q")
        link = upstream.link(q)

        q.close

        upstream.links.should be_empty
        wait_for { link.state.terminated? }
      end
    end

    it "stops the link before the closing queue is deleted" do
      with_amqp_server do |s|
        upstream, _, downstream_vhost =
          UpstreamSpecHelpers.setup_federation(s, "qf stop early", nil, "upstream_q")
        # Transient, so closing deletes it and frees the name for a redeclare
        downstream_vhost.declare_queue("downstream_q", false, false)
        q = downstream_vhost.queue("downstream_q")
        upstream.link(q)

        closed = Channel(Nil).new
        q.@msg_store_lock.synchronize do
          spawn { q.close; closed.close }
          # close is now parked on the lock, before it deletes the queue
          wait_for { q.closed? }
          upstream.links.should be_empty
        end
        closed.receive?
        downstream_vhost.queue?("downstream_q").should be_nil
      end
    end

    it "keeps the link of a queue redeclared under the same name" do
      with_amqp_server do |s|
        upstream, _, downstream_vhost =
          UpstreamSpecHelpers.setup_federation(s, "qf redeclare", nil, "upstream_q")
        downstream_vhost.declare_queue("downstream_q", false, false)
        old_q = downstream_vhost.queue("downstream_q")
        old_q.delete
        downstream_vhost.declare_queue("downstream_q", false, false)
        new_q = downstream_vhost.queue("downstream_q")
        link = upstream.link(new_q)

        # A late cleanup for the old queue must not take the new queue's link
        upstream.stop_link(old_q)

        upstream.links.should eq [link]
      ensure
        upstream.try &.close
      end
    end

    it "does not set up a queue link stopped while connecting" do
      with_amqp_server do |s|
        UpstreamSpecHelpers.cleanup_vhosts(s)
        upstream_vhost = s.vhosts.create("upstream")
        downstream_vhost = s.vhosts.create("downstream")
        UpstreamSpecHelpers.with_gated_proxy(s) do |url, accepted, gate|
          upstream = LavinMQ::Federation::Upstream.new(downstream_vhost,
            "qf stop while connecting", "#{url}/upstream", nil, "upstream_q")
          downstream_vhost.upstreams.add(upstream)
          downstream_vhost.declare_queue("downstream_q", true, false)
          q = downstream_vhost.queue("downstream_q")
          link = upstream.link(q)
          accepted.receive # the link is parked in its upstream connect

          q.delete
          upstream.links.should be_empty
          gate.close # let the connect complete

          wait_for { link.state.terminated? }
          # The stopped link must not have declared anything upstream
          upstream_vhost.queue?("upstream_q").should be_nil
        end
      end
    end

    it "should reconnect queue link after upstream disconnect" do
      with_amqp_server do |s|
        upstream, upstream_vhost, downstream_vhost = \
           UpstreamSpecHelpers.setup_federation(s, "ef test upstream restart",
            nil, "upstream_q")
        UpstreamSpecHelpers.start_link(upstream, "downstream_q", "queues")
        s.users.add_permission("guest", "upstream", /.*/, /.*/, /.*/)
        s.users.add_permission("guest", "downstream", /.*/, /.*/, /.*/)

        upstream_vhost.declare_exchange("upstream_ex", "topic", true, false)
        upstream_vhost.declare_queue("upstream_q", true, false)
        downstream_vhost.declare_exchange("downstream_ex", "topic", true, false)
        downstream_vhost.declare_queue("downstream_q", true, false)

        wait_for { downstream_vhost.queue("downstream_q").policy.try(&.name) == "FE" }
        wait_for { upstream.links.first?.try &.state.running? }

        # Disconnect the federation link
        conn_id = nil
        upstream_vhost.each_connection do |conn|
          next unless conn.client_name.starts_with?("Federation link")
          conn_id = conn.object_id
          conn.close
        end
        wait_for { upstream_vhost.connections_size == 0 }
        upstream.links.first.@state_changed.try_send nil
        wait_for { upstream_vhost.connections_size == 1 }
        conn = nil
        upstream_vhost.each_connection { |c| conn = c if c.name.starts_with?("Federation link") }
        # Verify that it's a new connection... Any better assertion that can be done?
        conn.object_id.should_not eq conn_id
      end
    end

    it "should resume federation after downstream reconnects" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        upstream = LavinMQ::Federation::Upstream.new(vhost, "qf test upstream reconnect", s.amqp_server.url, nil, "federation_q1")
        msgs = [] of AMQP::Client::DeliverMessage

        with_channel(s) do |ch|
          x, q2 = UpstreamSpecHelpers.setup_qs ch
          x.publish_confirm "federate me", "federation_q1"
          upstream.link(vhost.queue("federation_q2"))
          q2.subscribe do |msg|
            msgs << msg
          end
          wait_for { msgs.size == 1 }
          msgs.size.should eq 1
        end

        with_channel(s) do |ch|
          x, q2 = UpstreamSpecHelpers.setup_qs ch
          x.publish_confirm "federate me", "federation_q1"
          q2.subscribe do |msg|
            msgs << msg
          end
          wait_for { msgs.size == 2 }
          msgs.size.should eq 2
          wait_for { vhost.queue("federation_q1").message_count == 0 }
        end
      ensure
        upstream.try &.close
      end
    end

    it "should keep message properties" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        upstream = LavinMQ::Federation::Upstream.new(vhost, "qf test upstream props", s.amqp_server.url, nil, "federation_q1")

        with_channel(s) do |ch|
          x, q2 = UpstreamSpecHelpers.setup_qs ch
          x.publish_confirm "federate me", "federation_q1", props: AMQP::Client::Properties.new(content_type: "application/json")
          upstream.link(vhost.queue("federation_q2"))
          msgs = [] of AMQP::Client::DeliverMessage
          q2.subscribe { |msg| msgs << msg }
          wait_for { msgs.size == 1 }
          msgs.first.properties.content_type.should eq "application/json"
        end
      ensure
        upstream.try &.close
      end
    end

    it "should only transfer messages when downstream has consumer" do
      with_amqp_server do |s|
        ds_queue_name = Random::Secure.hex(10)
        us_queue_name = Random::Secure.hex(10)
        upstream, us_vhost, ds_vhost = UpstreamSpecHelpers.setup_federation(s, Random::Secure.hex(10), nil, us_queue_name)

        UpstreamSpecHelpers.start_link(upstream, ds_queue_name, "queues")
        s.users.add_permission("guest", us_vhost.name, /.*/, /.*/, /.*/)
        s.users.add_permission("guest", ds_vhost.name, /.*/, /.*/, /.*/)

        # publish 1 message
        with_channel(s, vhost: us_vhost.name) do |upstream_ch|
          upstream_q = upstream_ch.queue(us_queue_name)
          upstream_q.publish_confirm "msg1"
        end

        # consume 1 message
        with_channel(s, vhost: ds_vhost.name) do |downstream_ch|
          downstream_q = downstream_ch.queue(ds_queue_name)
          wait_for { ds_vhost.queue(ds_queue_name).policy.try(&.name) == "FE" }
          wait_for { upstream.links.first?.try &.state.running? }

          msgs = Channel(String).new
          downstream_q.subscribe do |msg|
            msgs.send msg.body_io.to_s
          end
          msgs.should be_receiving "msg1"
          wait_for { s.vhosts[ds_vhost.name].queue(ds_queue_name).message_count == 0 }
        end

        wait_for { s.vhosts[ds_vhost.name].queue(ds_queue_name).consumers_empty? }

        # publish another message
        with_channel(s, vhost: us_vhost.name) do |upstream_ch|
          upstream_q = upstream_ch.queue(us_queue_name)
          upstream_q.publish_confirm "msg2"
        end

        # resume consuming on downstream, should get 1 message
        with_channel(s, vhost: ds_vhost.name) do |downstream_ch|
          msgs = Channel(String).new
          downstream_ch.queue(ds_queue_name).subscribe do |msg|
            msgs.send msg.body_io.to_s
          end
          msgs.should be_receiving "msg2"
        end
      end
    end

    it "should stop transfering messages if downstream consumer disconnects" do
      with_amqp_server do |s|
        ds_queue_name = Random::Secure.hex(10)
        us_queue_name = Random::Secure.hex(10)
        upstream, us_vhost, ds_vhost = UpstreamSpecHelpers.setup_federation(s, Random::Secure.hex(10), nil, us_queue_name, 1_u16)
        UpstreamSpecHelpers.start_link(upstream, ds_queue_name, "queues")
        s.users.add_permission("guest", us_vhost.name, /.*/, /.*/, /.*/)
        s.users.add_permission("guest", ds_vhost.name, /.*/, /.*/, /.*/)
        message_count = 2

        ds_vhost.declare_queue(ds_queue_name, true, false)
        ds_queue = ds_vhost.queue(ds_queue_name).as(LavinMQ::AMQP::Queue)

        link = wait_for { upstream.links.first? }
        # Poll the state rather than waiting on @state_changed.receive: the link
        # may already have transitioned to running before we start receiving, in
        # which case that change is gone and the bare receive blocks forever.
        wait_for { link.state.running? }

        us_queue = us_vhost.queue(us_queue_name).as(LavinMQ::AMQP::Queue)

        # publish 2 messages to upstream queue
        with_channel(s, vhost: us_vhost.name) do |upstream_ch|
          upstream_q = upstream_ch.queue(us_queue_name)
          message_count.times do |i|
            upstream_q.publish_confirm "msg#{i}"
          end
        end

        wait_for { us_queue.message_count == message_count }

        # consume 1 message from downstream queue
        with_channel(s, vhost: ds_vhost.name) do |downstream_ch|
          downstream_ch.prefetch(1)
          downstream_q = downstream_ch.queue(ds_queue_name)
          downstream_q.subscribe(tag: "c", no_ack: false, block: true) do |msg|
            downstream_q.unsubscribe("c")
            msg.ack
          end
        end
        us_queue.consumers_empty.when_true.should be_receiving nil
        ds_queue.consumers_empty.when_true.should be_receiving nil

        ds_queue.empty.should be_true
        ds_queue.message_count.should eq 0

        # resume consuming on downstream, federation should start again
        with_channel(s, vhost: ds_vhost.name) do |downstream_ch|
          ch = Channel(Nil).new
          downstream_q = downstream_ch.queue(ds_queue_name)
          downstream_q.subscribe(tag: "c2", no_ack: false) do |msg|
            msg.ack
            downstream_q.unsubscribe("c2")
            ch.close
          end

          ds_queue.consumers_empty.when_true.should be_receiving nil
          us_queue.consumers_empty.when_true.should be_receiving nil

          select
          when ch.receive?
          when timeout 3.seconds
            fail "federation didn't resume? timeout waiting for message on downstream queue"
          end

          us_queue.empty.should be_true
          ds_queue.empty.should be_true
        end
      end
    end

    describe "when @queue is nil" do
      describe "#link(Queue)" do
        it "should create link that consumes upstream queue with same name as downstream queue" do
          with_amqp_server do |s|
            vhost = s.vhosts["/"]

            vhost.declare_queue("q1", true, false)
            vhost.declare_queue("q2", true, false)

            upstream = LavinMQ::Federation::Upstream.new(vhost, "test", "amqp://", nil, nil)
            link1 = upstream.link(vhost.queue("q1"))
            link2 = upstream.link(vhost.queue("q2"))

            link1.@upstream_q.should eq "q1"
            link2.@upstream_q.should eq "q2"
          ensure
            upstream.try &.close
          end
        end
      end
    end
  end

  describe "Exchange federation" do
    it "should federate exchange" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        upstream = LavinMQ::Federation::Upstream.new(vhost, "ef test upstream", s.amqp_server.url, "upstream_ex")

        with_channel(s) do |ch|
          downstream_ex = ch.exchange("downstream_ex", "topic")
          downstream_q = ch.queue("downstream_q")
          downstream_q.bind(downstream_ex.name, "#")
          link = upstream.link(vhost.exchange(downstream_ex.name))
          wait_for { link.state.running? }
          upstream_ex = ch.exchange("upstream_ex", "topic", passive: true)
          upstream_ex.publish "federate me", "rk"
          msgs = [] of AMQP::Client::DeliverMessage
          downstream_q.subscribe { |msg| msgs << msg }
          wait_for { msgs.size == 1 }
          msgs.size.should eq 1
        end
      ensure
        upstream.try &.close
      end
    end

    it "should federate exchange even with no downstream consumer" do
      with_amqp_server do |s|
        upstream, upstream_vhost, downstream_vhost = UpstreamSpecHelpers.setup_federation(s, "ef test upstream wo downstream", "upstream_ex")
        UpstreamSpecHelpers.start_link(upstream)
        s.users.add_permission("guest", "upstream", /.*/, /.*/, /.*/)
        s.users.add_permission("guest", "downstream", /.*/, /.*/, /.*/)
        with_channel(s, vhost: "upstream") do |upstream_ch|
          with_channel(s, vhost: "downstream") do |downstream_ch|
            upstream_ex = upstream_ch.exchange("upstream_ex", "topic")
            downstream_ch.exchange("downstream_ex", "topic")
            wait_for { downstream_vhost.exchange("downstream_ex").policy.try(&.name) == "FE" }
            # Assert setup is correct
            wait_for { upstream.links.first?.try &.state.running? }
            downstream_q = downstream_ch.queue("downstream_q")
            downstream_q.bind("downstream_ex", "#")
            upstream_ex.publish_confirm "federate me", "rk"
            wait_for { downstream_q.get }
            msgs = [] of AMQP::Client::DeliverMessage
            downstream_q.subscribe { |msg| msgs << msg }
            upstream_ex.publish_confirm "federate me", "rk"
            wait_for { msgs.size == 1 }
            msgs.first.body_io.to_s.should eq("federate me")
          end
        end
        upstream_vhost.queues.all?(&.empty).should be_true
      end
    end

    it "should continue after upstream restart", tags: "slow" do
      with_amqp_server do |s|
        # Use reconnect delay so we have time to see state being stopped
        # and that we can publish a message before it's reconnected
        upstream, upstream_vhost, _downstream_vhost = \
           UpstreamSpecHelpers.setup_federation(s, "ef test upstream restart",
            "upstream_ex",
            reconnect_delay: 1.second)
        UpstreamSpecHelpers.start_link(upstream)
        s.users.add_permission("guest", "upstream", /.*/, /.*/, /.*/)
        s.users.add_permission("guest", "downstream", /.*/, /.*/, /.*/)

        with_channel(s, vhost: "upstream") do |upstream_ch|
          with_channel(s, vhost: "downstream") do |downstream_ch|
            upstream_ex = upstream_ch.exchange("upstream_ex", "topic")
            downstream_ch.exchange("downstream_ex", "topic")
            # Assert setup is correct
            link = wait_for { upstream.links.first? }
            link = link.should be_a LavinMQ::Federation::Upstream::ExchangeLink
            # wait_for { upstream.links.first?.try &.state.running? }
            downstream_q = downstream_ch.queue("downstream_q")
            downstream_q.bind("downstream_ex", "#")

            msgs = Channel(String).new
            downstream_q.subscribe(block: false) do |msg|
              msgs.send msg.body_io.to_s
            end

            # When state is running everything should be setup in the upstream
            wait_for { link.state.running? }

            us_queue = upstream_vhost.queue(link.@upstream_q).should be_a LavinMQ::AMQP::Queue
            # Wait until the federation link is actually consuming from the
            # upstream queue (consumers_empty == false) before publishing, so
            # msg1 is federated. consumers_empty is true when there are no
            # consumers, so we wait on when_false. (Waiting on when_true here
            # only ever returned immediately by racing the consumer attach —
            # which hung indefinitely when the consumer attached first.)
            us_queue.consumers_empty.when_false.should be_receiving nil

            upstream_ex.publish_confirm "msg1", "rk1"
            msgs.should be_receiving "msg1"

            upstream_vhost.each_connection do |conn|
              next unless conn.client_name.starts_with?("Federation link")
              conn.close
            end

            # it should be in "stopped" state while waiting for reconnect delay
            wait_for { link.state.stopped? }
            # publish before reconnect
            upstream_ex.publish_confirm "msg2", "rk2"

            # we can make it connect instantly (to speed up specs)
            # this is because we know the internals of the link and that
            # a timeout in a select is used together with the event channel
            link.@state_changed.try_send nil

            upstream_ex.publish_confirm "msg3", "rk3"
            msgs.should be_receiving "msg2"
            msgs.should be_receiving "msg3"
          ensure
            msgs.try &.close
          end
        end
        upstream_vhost.queues.all?(&.empty).should be_true
      end
    end

    it "should delete internal exchange and queue after deleting a federation link" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        upstream, upstream_vhost = UpstreamSpecHelpers.setup_federation(s, "qf test upstream delete", "upstream_ex", "upstream_q")
        federation_name = "federation: upstream_ex -> #{System.hostname}:downstream:downstream_ex"

        with_channel(s) do |ch|
          downstream_ex = ch.exchange("downstream_ex", "topic")
          link = upstream.link(vhost.exchange(downstream_ex.name))
          wait_for { link.state.running? }
          upstream_vhost.queue_exists?(federation_name).should be_true
          upstream_vhost.exchange_exists?(federation_name).should be_true
          link.delete
          upstream_vhost.queue_exists?(federation_name).should be_false
          upstream_vhost.exchange_exists?(federation_name).should be_false
        end
      end
    end

    it "should keep internal exchange and queue after broker shutdown" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        upstream, upstream_vhost = UpstreamSpecHelpers.setup_federation(s, "qf test upstream shutdown", "upstream_ex", "upstream_q")
        federation_name = "federation: upstream_ex -> #{System.hostname}:downstream:downstream_ex"

        with_channel(s) do |ch|
          downstream_ex = ch.exchange("downstream_ex", "topic")
          link = upstream.link(vhost.exchange(downstream_ex.name))
          wait_for { link.state.running? }
          upstream_vhost.queue_exists?(federation_name).should be_true
          upstream_vhost.exchange_exists?(federation_name).should be_true
          upstream.close # broker shutdown path — must not delete upstream resources
          upstream_vhost.queue_exists?(federation_name).should be_true
          upstream_vhost.exchange_exists?(federation_name).should be_true
        end
      end
    end

    it "keeps the link and upstream resources when vhost policies are re-applied" do
      with_amqp_server do |s|
        upstream, upstream_vhost, downstream_vhost =
          UpstreamSpecHelpers.setup_federation(s, "ef policy reapply", "upstream_ex")
        downstream_vhost.declare_exchange("downstream_ex", "topic", true, false)
        UpstreamSpecHelpers.start_link(upstream)
        link = wait_for { upstream.links.first? }
        wait_for { link.state.running? }
        federation_name = "federation: upstream_ex -> #{System.hostname}:downstream:downstream_ex"
        us_q = upstream_vhost.queue(federation_name)

        # Any policy or parameter change in the vhost re-applies all policies.
        # The unchanged federation policy must not restart the link, and must
        # not delete the upstream queue with its buffered messages.
        downstream_vhost.apply_policies

        upstream.links.first?.should be link
        link.state.running?.should be_true
        upstream_vhost.queue?(federation_name).should be us_q
      end
    end

    it "does not deadlock two-way federation with max-hops 3 or more" do
      with_amqp_server do |s|
        va = s.vhosts.create("fed_a")
        vb = s.vhosts.create("fed_b")
        va.declare_exchange("fe", "topic", true, false)
        vb.declare_exchange("fe", "topic", true, false)
        url_a = URI.parse(s.amqp_server.url)
        url_a.path = va.name
        url_b = URI.parse(s.amqp_server.url)
        url_b.path = vb.name
        up_a = LavinMQ::Federation::Upstream.new(va, "ef two-way from b", url_b.to_s,
          exchange: "fe", queue: nil, max_hops: 3_i64)
        va.upstreams.add(up_a)
        up_b = LavinMQ::Federation::Upstream.new(vb, "ef two-way from a", url_a.to_s,
          exchange: "fe", queue: nil, max_hops: 3_i64)
        vb.upstreams.add(up_b)
        link_a = up_a.link(va.exchange("fe").as(LavinMQ::AMQP::Exchange))
        link_b = up_b.link(vb.exchange("fe").as(LavinMQ::AMQP::Exchange))
        wait_for { link_a.state.running? && link_b.state.running? }

        va.declare_queue("q", true, false)
        q = va.queue("q")
        bound = Channel(Nil).new
        spawn do
          va.exchange("fe").bind(q, "rk")
          bound.close
        end
        # The links propagate the binding a -> b -> a -> b. Each hop used to
        # wait for its bind-ok inside the fiber that processes the previous
        # bind, so the chain deadlocked once it revisited a busy connection.
        select
        when bound.receive?
        when timeout 5.seconds
          fail "two-way binding propagation deadlocked"
        end
        # The propagation must stop by hop count, not run forever
        wait_for { vb.exchange("fe").bindings_details.size == 2 }
        wait_for { va.exchange("fe").bindings_details.size == 2 }
        # Give a wrongly forwarded extra hop time to arrive, then check the
        # counts stayed put
        sleep 100.milliseconds
        vb.exchange("fe").bindings_details.size.should eq 2
        va.exchange("fe").bindings_details.size.should eq 2
      ensure
        up_a.try &.close
        up_b.try &.close
      end
    end

    {% for descr, v in {nil: nil, empty: ""} %}
    describe "when @exchange is {{ descr }}" do
      it "should use downstream exchange name as upstream exchange" do
        with_amqp_server do |s|
          vhost = s.vhosts["/"]

          vhost.declare_exchange("ex1", "topic", true, false)

          upstream = LavinMQ::Federation::Upstream.new(vhost, "test", "amqp://", {{ v }})
          link1 = upstream.link(vhost.exchange("ex1"))

          link1.@upstream_exchange.should eq "ex1"
        end
      end
    end
  {% end %}
  end

  describe "QueueLink" do
    it "set x-received-from" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        upstream = LavinMQ::Federation::Upstream.new(vhost, "qf x-received-from", s.amqp_server.url, exchange: nil, queue: "federation_q1")

        with_channel(s) do |ch|
          x, q2 = UpstreamSpecHelpers.setup_qs ch
          x.publish "foo", "federation_q1"
          upstream.link(vhost.queue("federation_q2"))
          msgs = [] of AMQP::Client::DeliverMessage
          wg = WaitGroup.new(1)
          q2.subscribe do |msg|
            msgs << msg
            wg.done
          end
          wg.wait
          headers = msgs.first.properties.headers.should_not be_nil
          headers["x-received-from"].as(Array(AMQ::Protocol::Field)).should_not be_nil
        end
      ensure
        upstream.try &.close
      end
    end

    it "append to x-received-from" do
      # Sets up a "federation chain"
      with_amqp_server do |s|
        vhost1 = s.vhosts.create("one")
        vhost2 = s.vhosts.create("two")
        vhost3 = s.vhosts.create("three")

        vhost1.declare_queue("q1", durable: true, auto_delete: false)
        vhost2.declare_queue("q2", durable: true, auto_delete: false)
        vhost3.declare_queue("q3", durable: true, auto_delete: false)

        vhost1.queue("q1")
        q2 = vhost2.queue("q2")
        q3 = vhost3.queue("q3")

        url = URI.parse(s.amqp_server.url)

        vhost1_url = url.dup
        vhost1_url.path = vhost1.name
        upstream_q1_to_q2 = LavinMQ::Federation::Upstream.new(
          vhost2, "upstream q1 to q2", vhost1_url.to_s,
          exchange: nil, queue: "q1", max_hops: 100i64)
        link_q2 = upstream_q1_to_q2.link(q2)

        vhost2_url = url.dup
        vhost2_url.path = vhost2.name
        upstream_q2_to_q3 = LavinMQ::Federation::Upstream.new(
          vhost3, "upstream q2 to q3", vhost2_url.to_s,
          exchange: nil, queue: "q2", max_hops: 100i64)
        link_q3 = upstream_q2_to_q3.link(q3)

        wait_for { link_q2.state.running? && link_q3.state.running? }

        with_channel(s, vhost: "three") do |ch|
          ch_q3 = ch.queue("q3")

          wg = WaitGroup.new(1)
          ch_q3.subscribe do |msg|
            wg.done
            headers = msg.properties.headers.should_not be_nil
            x_received_from = headers["x-received-from"].should be_a Array(AMQ::Protocol::Field)
            x_received_from.size.should eq 2
          end

          with_channel(s, vhost: "one") do |ch_pub|
            ch_pub.queue("q1").publish "foo"
          end

          wg.wait
        end
      ensure
        upstream_q1_to_q2.try &.close
        upstream_q2_to_q3.try &.close
      end
    end
  end

  describe "ExchangeLink" do
    it "should reflect all bindings to upstream exchange" do
      with_amqp_server do |s|
        upstream, upstream_vhost, _ = UpstreamSpecHelpers.setup_federation(s, "ef test bindings", "upstream_ex")
        with_channel(s, vhost: "downstream") do |downstream_ch|
          downstream_ch.exchange("downstream_ex", "topic")
          queues = [] of AMQP::Client::Queue
          10.times do |i|
            downstream_q = downstream_ch.queue("")
            downstream_q.bind("downstream_ex", "before.link.#{i}")
            queues << downstream_q
          end

          UpstreamSpecHelpers.start_link(upstream)
          wait_for { upstream.links.first?.try &.state.running? }

          upstream_ex = upstream_vhost.exchange("upstream_ex").as(LavinMQ::AMQP::Exchange)
          upstream_ex.bindings_details.size.should eq queues.size

          10.times do |i|
            downstream_q = downstream_ch.queue("")
            downstream_q.bind("downstream_ex", "after.link.#{i}")
            queues << downstream_q
          end

          # Binds are forwarded without waiting for the upstream's reply, so
          # a client bind returns before the forward lands; use the default
          # wait_for timeout
          wait_for { upstream_ex.bindings_details.size == queues.size }
          queues.each &.delete
          wait_for { upstream_ex.bindings_details.empty? }
        end
      end
    end

    it "should reflect bindings made after the link reconnects" do
      with_amqp_server do |s|
        upstream, upstream_vhost, _ = UpstreamSpecHelpers.setup_federation(s, "ef test bindings reconnect", "upstream_ex")
        with_channel(s, vhost: "downstream") do |downstream_ch|
          downstream_ch.exchange("downstream_ex", "topic")
          UpstreamSpecHelpers.start_link(upstream)
          link = wait_for { upstream.links.first?.try { |l| l if l.state.running? } }

          upstream_vhost.each_connection do |conn|
            conn.close if conn.client_name.starts_with?("Federation link")
          end
          wait_for { !link.state.running? }
          wait_for { link.state.running? }

          upstream_ex = upstream_vhost.exchange("upstream_ex").as(LavinMQ::AMQP::Exchange)
          downstream_q = downstream_ch.queue("")
          downstream_q.bind("downstream_ex", "after.reconnect")
          wait_for { upstream_ex.bindings_details.size == 1 }
          downstream_q.unbind("downstream_ex", "after.reconnect")
          wait_for { upstream_ex.bindings_details.empty? }
        end
      end
    end

    it "stops the link when the federated exchange is deleted" do
      with_amqp_server do |s|
        upstream, _, downstream_vhost =
          UpstreamSpecHelpers.setup_federation(s, "ef delete exchange", "upstream_ex")
        downstream_vhost.declare_exchange("downstream_ex", "topic", true, false)
        link = upstream.link(downstream_vhost.exchange("downstream_ex").as(LavinMQ::AMQP::Exchange))

        downstream_vhost.delete_exchange("downstream_ex")

        upstream.links.should be_empty
        wait_for { link.state.terminated? }
      end
    end

    it "keeps the link of an exchange redeclared under the same name" do
      with_amqp_server do |s|
        upstream, _, downstream_vhost =
          UpstreamSpecHelpers.setup_federation(s, "ef redeclare", "upstream_ex")
        downstream_vhost.declare_exchange("downstream_ex", "topic", true, false)
        old_ex = downstream_vhost.exchange("downstream_ex").as(LavinMQ::AMQP::Exchange)
        downstream_vhost.delete_exchange("downstream_ex")
        downstream_vhost.declare_exchange("downstream_ex", "topic", true, false)
        new_ex = downstream_vhost.exchange("downstream_ex").as(LavinMQ::AMQP::Exchange)
        link = upstream.link(new_ex)

        # A late cleanup for the old exchange must not take the new one's link
        upstream.stop_link(old_ex)

        upstream.links.should eq [link]
        # Closing the link closes its connection only once it has one. A link
        # still connecting would connect to a server already shutting down,
        # and its client would log the forced close during a later spec.
        wait_for { link.state.running? }
      ensure
        upstream.try &.close
      end
    end

    it "should reflect bindings made while link is starting" do
      with_amqp_server do |s|
        upstream, upstream_vhost, _ =
          UpstreamSpecHelpers.setup_federation(s, "ef test bindings during start", "upstream_ex")
        with_channel(s, vhost: "downstream") do |downstream_ch|
          downstream_ch.exchange("downstream_ex", "topic")
          downstream_q = downstream_ch.queue("downstream_q")
          # Pre-existing bindings stretch the binding replay the link does
          # during startup, so that the binds below land mid-replay.
          before = 200
          before.times { |i| downstream_q.bind("downstream_ex", "before.link.#{i}") }

          UpstreamSpecHelpers.start_link(upstream)
          link = wait_for { upstream.links.first? }.as(LavinMQ::Federation::Upstream::ExchangeLink)
          # The link starts forwarding binds to the upstream while it is
          # still replaying the bindings above to the upstream exchange.
          wait_for { link.@consumer_ex }
          # Binds made during startup must also be reflected upstream.
          # (Regression: they were dropped if made before the link had
          # an upstream channel.)
          during = 10
          during.times { |i| downstream_q.bind("downstream_ex", "during.link.#{i}") }

          upstream_ex = wait_for { upstream_vhost.exchange?("upstream_ex") }
          upstream_ex = upstream_ex.as(LavinMQ::AMQP::Exchange)
          wait_for { upstream_ex.bindings_details.size == before + during }
        end
      end
    end

    it "drops the link when deleted during link startup" do
      with_amqp_server do |s|
        upstream, _, downstream_vhost =
          UpstreamSpecHelpers.setup_federation(s, "ef delete during start", "upstream_ex")
        downstream_vhost.declare_exchange("downstream_ex", "topic", true, false)
        downstream_ex = downstream_vhost.exchange("downstream_ex").as(LavinMQ::AMQP::Exchange)

        link = upstream.link(downstream_ex)
        # Delete while the link is parked on the upstream connect
        upstream.delete
        wait_for { link.state.terminated? }

        upstream.links.should be_empty
      end
    end

    it "set x-received-from" do
      with_amqp_server do |s|
        vhost1 = s.vhosts.create("one")
        vhost2 = s.vhosts.create("two")

        vhost1.declare_exchange("upstream_ex", "topic", durable: true, auto_delete: false)
        vhost2.declare_exchange("downstream_ex", "topic", durable: true, auto_delete: false)
        vhost2.declare_queue("downstream_q", durable: true, auto_delete: false)

        downstream_ex = vhost2.exchange("downstream_ex")
        downstream_q = vhost2.queue("downstream_q")
        downstream_ex.bind(downstream_q, "#")

        url = URI.parse(s.amqp_server.url)
        url.path = vhost1.name
        upstream = LavinMQ::Federation::Upstream.new(vhost2, "ef x-received-from", url.to_s, exchange: "upstream_ex", queue: nil)

        with_channel(s, vhost: "two") do |ch|
          link = upstream.link(downstream_ex)

          wait_for { link.state.running? }

          wg = WaitGroup.new(1)
          q = ch.queue("downstream_q", passive: true)
          q.subscribe(tag: "downstream_q_consumer") do |msg|
            headers = msg.properties.headers.should_not be_nil
            headers["x-received-from"].as(Array(AMQ::Protocol::Field)).should_not be_nil
            wg.done
          end

          with_channel(s, vhost: "one") do |ch_pub|
            ch_pub.exchange("upstream_ex", "topic").publish "foo", "routing.key"
          end

          wg.wait
        end
      ensure
        upstream.try &.close
      end
    end

    it "append to x-received-from" do
      # Sets up a "federation chain"
      with_amqp_server do |s|
        vhost1 = s.vhosts.create("one")
        vhost2 = s.vhosts.create("two")
        vhost3 = s.vhosts.create("three")

        vhost1.declare_exchange("ex1", "topic", durable: true, auto_delete: false)
        vhost2.declare_exchange("ex2", "topic", durable: true, auto_delete: false)
        vhost3.declare_exchange("ex3", "topic", durable: true, auto_delete: false)

        ex1 = vhost1.exchange("ex1")
        ex2 = vhost2.exchange("ex2")
        ex3 = vhost3.exchange("ex3")

        vhost3.declare_queue("q3", durable: true, auto_delete: false)
        downstream_q = vhost3.queue("q3")
        downstream_ex = vhost3.exchange("ex3")

        url = URI.parse(s.amqp_server.url)

        vhost1_url = url.dup
        vhost1_url.path = vhost1.name
        upstream_ex1_to_ex2 = LavinMQ::Federation::Upstream.new(
          vhost2, "upstream ex1 to ex2", vhost1_url.to_s,
          exchange: "ex1", queue: nil, max_hops: 100i64)
        vhost2.upstreams.add(upstream_ex1_to_ex2)

        vhost2_url = url.dup
        vhost2_url.path = vhost2.name
        upstream_ex2_to_ex3 = LavinMQ::Federation::Upstream.new(
          vhost3, "upstream ex2 to ex3", vhost2_url.to_s,
          exchange: "ex2", queue: nil, max_hops: 100i64)
        vhost3.upstreams.add(upstream_ex2_to_ex3)

        link_ex3 = upstream_ex2_to_ex3.link(ex3)
        link_ex2 = upstream_ex1_to_ex2.link(ex2)
        wait_for { link_ex2.state.running? && link_ex3.state.running? }

        downstream_ex.bind(downstream_q, "#")
        with_channel(s, vhost: "three") do |ch|
          ch_q3 = ch.queue("q3")

          wg = WaitGroup.new(1)
          ch_q3.subscribe do |msg|
            wg.done
            headers = msg.properties.headers.should_not be_nil
            x_received_from = headers["x-received-from"].should be_a Array(AMQ::Protocol::Field)
            x_received_from.size.should eq 2
          end

          with_channel(s, vhost: "one") do |ch_pub|
            ch_pub.exchange("ex1", "topic").publish "foo", "routing.key"
          end

          wg.wait
        end
      ensure
        upstream_ex1_to_ex2.try &.close
        upstream_ex2_to_ex3.try &.close
      end
    end

    it "set x-bound-from" do
      with_http_server do |_http, s|
        vhost1 = s.vhosts.create("one")
        vhost2 = s.vhosts.create("two")

        vhost1.declare_exchange("upstream_ex", "topic", durable: true, auto_delete: false)
        vhost2.declare_exchange("downstream_ex", "topic", durable: true, auto_delete: false)
        vhost2.declare_queue("downstream_q", durable: true, auto_delete: false)

        downstream_ex = vhost2.exchange("downstream_ex")
        downstream_q = vhost2.queue("downstream_q")
        downstream_ex.bind(downstream_q, "federation.link.rk")

        upstream_ex = vhost1.exchange("upstream_ex")

        url = URI.parse(s.amqp_server.url)
        url.path = vhost1.name
        upstream = LavinMQ::Federation::Upstream.new(vhost2, "ef x-bound-from", url.to_s, exchange: "upstream_ex", queue: nil)

        link = upstream.link(downstream_ex)

        wait_for { link.state.running? }
        wait_for { upstream_ex.bindings_details.size == 1 }

        binding_details = upstream_ex.bindings_details.find { |x| x.routing_key == "federation.link.rk" }.should_not be_nil
        arguments = binding_details.arguments.should_not be_nil
        x_bound_from = arguments["x-bound-from"].should be_a Array(AMQ::Protocol::Field)
        x_bound_from.size.should eq 1
      ensure
        upstream.try &.close
      end
    end

    describe "exchange federation chain", tags: "slow" do
      it "append to x-bound-from" do
        with_http_server do |_http, s|
          UpstreamSpecHelpers.with_fe_chain(s, chain_length: 10) do
            downstream_vhost = s.vhosts["v10"]
            downstream_ex = downstream_vhost.exchange("fe")
            downstream_vhost.declare_queue("q", durable: true, auto_delete: false)
            q = downstream_vhost.queue("q")
            # This binding should be propagated all the way to "fe" in "v1"
            # For each hop x-bound-from should be extended with one new entry
            downstream_ex.bind(q, "spec.routing.key")

            # Verify bindings on exchange "fe" from vhost v1 to
            # vhost v9. The links forward bindings without waiting for the
            # upstream's reply, so wait for each binding to arrive.
            1.to(9) do |i|
              fe = s.vhosts["v#{i}"].exchange("fe")
              wait_for { fe.bindings_details.size == 1 }
              fe_bk = fe.bindings_details.first.binding_key
              args = fe_bk.arguments.should_not be_nil
              x_bound_from = args["x-bound-from"].should be_a(Array(AMQ::Protocol::Field))
              # in v1 there should be 9 entries
              # in v2 there should be 8 entries etc
              x_bound_from.size.should eq(9 - i + 1)
              first_bound_from = x_bound_from.first.should be_a(AMQ::Protocol::Table)
              # The first (last appended) x-bound-from should be the previous vhost (v2 is prev to v1 etc)
              first_bound_from["vhost"].should eq "v#{i + 1}"
              # The first (last appended) x-bound-from should always be the downstream (v10)
              last_bound_from = x_bound_from.last.should be_a(AMQ::Protocol::Table)
              last_bound_from["vhost"].should eq "v10"
            end
          end
        end
      end

      it "binding forwarding respects lower maxhops on exchange" do
        # This spec verifies that even though "hops" in x-bound-from allows the
        # binding to be propagated to the next vhost, the max_hops of the current
        # exchange is lower and takes precedence preventing the binding from
        # traveling further.
        with_http_server do |_http, s|
          UpstreamSpecHelpers.with_fe_chain(s, chain_length: 10) do |_, upstreams|
            # By setting max_hops to 1 on v5, bindings should reach v4 but no further
            us = upstreams.find { |u| u.vhost.name == "v5" }.should_not be_nil
            us.max_hops = 1

            downstream_vhost = s.vhosts["v10"]
            downstream_ex = downstream_vhost.exchange("fe")
            downstream_vhost.declare_queue("q", durable: true, auto_delete: false)
            q = downstream_vhost.queue("q")
            # This binding should only be propagated to "fe" in "v4", because
            # max_hops on v5 is 1.
            downstream_ex.bind(q, "spec.routing.key")

            # Verify bindings on exchange "fe" from vhost v4 to
            # vhost v9. Binding forwarding is asynchronous, so wait for the
            # bindings to arrive before checking where they must not reach.
            4.to(9) do |i|
              fe = s.vhosts["v#{i}"].exchange("fe")
              wait_for { fe.bindings_details.size == 1 }
              fe_bk = fe.bindings_details.first.binding_key
              args = fe_bk.arguments.should_not be_nil
              x_bound_from = args["x-bound-from"].should be_a(Array(AMQ::Protocol::Field))
              # in v4 there should be 6 entries
              # in v5 there should be 5 entries etc
              x_bound_from.size.should eq(9 - i + 1), "Expected #{9 - i + 1} entries in v#{i} but got #{x_bound_from.size}"
              first_bound_from = x_bound_from.first.should be_a(AMQ::Protocol::Table)
              # The first (last appended) x-bound-from should be the previous vhost (v2 is prev to v1 etc)
              first_bound_from["vhost"].should eq "v#{i + 1}"
              # The first (last appended) x-bound-from should always be the downstream (v10)
              last_bound_from = x_bound_from.last.should be_a(AMQ::Protocol::Table)
              last_bound_from["vhost"].should eq "v10"
            end

            # v5's max_hops of 1 stops the binding at v4; v1 to v3 stay empty.
            # Forwarding is asynchronous, so give a wrongly forwarded extra
            # hop time to arrive before checking.
            sleep 100.milliseconds
            1.to(3) do |i|
              fe = s.vhosts["v#{i}"].exchange("fe")
              fe.bindings_details.size.should eq 0
            end
          end
        end
      end

      it "binding forwarding respects lower maxhops in binding argument" do
        # This spec verifies that even though max_hops of the current exchange allows the
        # binding to be propagated to the next vhost, the current "hops" value in x-bound-from
        # is lower and takes precedence preventing the binding from traveling further.
        with_http_server do |_http, s|
          UpstreamSpecHelpers.with_fe_chain(s, chain_length: 10) do |_, upstreams|
            # By setting max_hops to 3 on v10, bindings should reach v7 but no further
            us = upstreams.find { |u| u.vhost.name == "v10" }.should_not be_nil
            us.max_hops = 3

            downstream_vhost = s.vhosts["v10"]
            downstream_ex = downstream_vhost.exchange("fe")
            downstream_vhost.declare_queue("q", durable: true, auto_delete: false)
            q = downstream_vhost.queue("q")
            # This binding should only be propagated to "fe" in "v4", because
            # max_hops on v5 is 1.
            downstream_ex.bind(q, "spec.routing.key")

            # Verify bindings on exchange "fe" from vhost v7 to
            # vhost v9. Binding forwarding is asynchronous, so wait for the
            # bindings to arrive before checking where they must not reach.
            7.to(9) do |i|
              fe = s.vhosts["v#{i}"].exchange("fe")
              wait_for { fe.bindings_details.size == 1 }
              fe_bk = fe.bindings_details.first.binding_key
              args = fe_bk.arguments.should_not be_nil
              x_bound_from = args["x-bound-from"].should be_a(Array(AMQ::Protocol::Field))
              x_bound_from.size.should eq(9 - i + 1), "Expected #{6 - i + 1} entries in v#{i} but got #{x_bound_from.size}"
              first_bound_from = x_bound_from.first.should be_a(AMQ::Protocol::Table)
              # The first (last appended) x-bound-from should be the previous vhost (v2 is prev to v1 etc)
              first_bound_from["vhost"].should eq "v#{i + 1}"
              # The first (last appended) x-bound-from should always be the downstream (v10)
              last_bound_from = x_bound_from.last.should be_a(AMQ::Protocol::Table)
              last_bound_from["vhost"].should eq "v10"
            end

            # The hops value in the binding stops it at v7; v1 to v6 stay
            # empty. Forwarding is asynchronous, so give a wrongly forwarded
            # extra hop time to arrive before checking.
            sleep 100.milliseconds
            1.to(6) do |i|
              fe = s.vhosts["v#{i}"].exchange("fe")
              fe.bindings_details.size.should eq 0
            end
          end
        end
      end

      it "message forwarding respects max-hops" do
        # Verify that a message that has been forwarded twice (two x-received-from entries)
        # will only be forwarded once when published to a federated exchange with max-hops 3.
        with_http_server do |_http, s|
          UpstreamSpecHelpers.with_fe_chain(s, chain_length: 3) do
            downstream_vhost = s.vhosts["v3"]
            downstream_ex = downstream_vhost.exchange("fe")
            downstream_vhost.declare_queue("q", durable: true, auto_delete: false)
            q = downstream_vhost.queue("q")
            downstream_ex.bind(q, "spec.routing.key")

            with_channel(s, vhost: "v1") do |ch|
              # By addign two entries in x-received-from the message should
              # only be forwarded once (from fe in v1 to fe in v2)
              props = AMQ::Protocol::Properties.new(
                headers: AMQ::Protocol::Table.new({
                  "x-received-from": Array(AMQ::Protocol::Table){
                    AMQ::Protocol::Table.new({"exchange": "foo"}),
                    AMQ::Protocol::Table.new({"exchange": "bar"}),
                  },
                }),
              )
              ch.exchange("fe", "topic").publish_confirm "foo", "spec.routing.key", props: props
            end

            v1fe = s.vhosts["v1"].exchange("fe")
            v2fe = s.vhosts["v2"].exchange("fe")
            v3fe = s.vhosts["v3"].exchange("fe")

            # We have no good synchronization point, so we yield a few times (instead of sleep)
            # to make sure the message has been processed all the way
            10.times { Fiber.yield }

            v1fe.publish_in_count.should eq 1
            v2fe.publish_in_count.should eq 1
            v3fe.publish_in_count.should eq 0
          end
        end
      end
    end
  end

  describe LavinMQ::Federation::UpstreamStore do
    it "removes a deleted upstream from sets even when a non-matching entry comes first" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}"})))
        store.create_upstream("b", JSON.parse(%({"uri": "#{s.amqp_server.url}"})))
        # The set lists a non-matching upstream ("a") before the one we
        # delete ("b"). The bare `return` in do_delete_upstream used to abort
        # the reject! on the first non-matching entry, leaving the deleted "b"
        # lingering in the set: it showed up as a phantom in federation status
        # and could be re-linked (revived) on the next link_set.
        store.create_upstream_set("set1", JSON.parse(%([{"upstream": "a"}, {"upstream": "b"}])))

        store.delete_upstream("b")

        store.get_set?("set1").should_not(be_nil).map(&.name).should eq ["a"]
      end
    end

    it "dups the upstream and applies per-entry overrides without sharing state" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}", "prefetch-count": 10})))
        # A set entry with more than the "upstream" key dups the upstream and
        # applies the overrides to the copy. This used to crash by reading the
        # override values off the whole set array instead of the entry, and the
        # shallow dup shared its link tables with the original.
        store.create_upstream_set("set1",
          JSON.parse(%([{"upstream": "a", "uri": "#{s.amqp_server.url}", "prefetch-count": 99}])))

        original = store.get_set?("all").should_not(be_nil).find! { |u| u.name == "a" }
        member = store.get_set?("set1").should_not(be_nil).first

        member.should_not be original
        member.prefetch.should eq 99_u16
        original.prefetch.should eq 10_u16

        # Linking the dup must not touch the original's links (separate tables).
        vhost.declare_queue("q", false, false)
        member.link(vhost.queue("q"))
        member.links.size.should eq 1
        original.links.size.should eq 0
      ensure
        store.try &.stop_all
      end
    end

    it "stops links owned by a set member with overrides" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}"})))
        store.create_upstream_set("set1",
          JSON.parse(%([{"upstream": "a", "prefetch-count": 99}])))
        member = store.get_set?("set1").should_not(be_nil).first

        vhost.declare_queue("q", false, false)
        q = vhost.queue("q")
        member.link(q)
        # Removing the policy calls UpstreamStore#stop_link, which used to only
        # reach the named upstreams and not the set's dup
        store.stop_link(q)
        member.links.should be_empty

        vhost.declare_exchange("ex", "topic", false, false)
        member.link(vhost.exchange("ex"))
        vhost.delete_exchange("ex")
        member.links.should be_empty
      ensure
        store.try &.stop_all
      end
    end

    it "stops links of set entries with overrides when the queue is deleted" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}"})))
        store.create_upstream_set("set1",
          JSON.parse(%([{"upstream": "a", "prefetch-count": 99}])))
        member = store.get_set?("set1").should_not(be_nil).first
        vhost.declare_queue("q", true, false)
        q = vhost.queue("q")
        link = member.link(q)

        q.delete

        member.links.should be_empty
        wait_for { link.state.terminated? }
      ensure
        store.try &.stop_all
      end
    end

    it "keeps upstream resources when an upstream parameter is re-created" do
      with_amqp_server do |s|
        UpstreamSpecHelpers.cleanup_vhosts(s)
        upstream_vhost = s.vhosts.create("upstream")
        downstream_vhost = s.vhosts.create("downstream")
        store = downstream_vhost.upstreams
        config = JSON.parse(%({"uri": "#{s.amqp_server.url}/upstream", "exchange": "upstream_ex"}))
        upstream = store.create_upstream("a", config)
        downstream_vhost.declare_exchange("downstream_ex", "topic", true, false)
        ex = downstream_vhost.exchange("downstream_ex").as(LavinMQ::AMQP::Exchange)
        link = upstream.link(ex)
        wait_for { link.state.running? }
        federation_name = "federation: upstream_ex -> #{System.hostname}:downstream:downstream_ex"
        upstream_vhost.queue_exists?(federation_name).should be_true

        # A re-PUT of the parameter replaces the upstream and restarts its
        # links. The resources on the upstream broker hold buffered messages
        # and must survive for the new links to reuse.
        store.create_upstream("a", config)

        wait_for { link.state.terminated? }
        upstream_vhost.queue_exists?(federation_name).should be_true
        upstream_vhost.exchange_exists?(federation_name).should be_true
      ensure
        store.try &.stop_all
      end
    end

    it "keeps upstream resources when a re-created parameter only changes credentials" do
      with_amqp_server do |s|
        UpstreamSpecHelpers.cleanup_vhosts(s)
        upstream_vhost = s.vhosts.create("upstream")
        downstream_vhost = s.vhosts.create("downstream")
        store = downstream_vhost.upstreams
        config = JSON.parse(%({"uri": "#{s.amqp_server.url}/upstream", "exchange": "upstream_ex"}))
        upstream = store.create_upstream("a", config)
        downstream_vhost.declare_exchange("downstream_ex", "topic", true, false)
        ex = downstream_vhost.exchange("downstream_ex").as(LavinMQ::AMQP::Exchange)
        link = upstream.link(ex)
        wait_for { link.state.running? }
        federation_name = "federation: upstream_ex -> #{System.hostname}:downstream:downstream_ex"
        upstream_vhost.queue_exists?(federation_name).should be_true

        # Credentials and query options don't change which resources the links
        # declare, so a rotated password must not delete the buffered queue
        with_creds = s.amqp_server.url.sub("amqp://", "amqp://guest:guest@")
        config2 = JSON.parse(%({"uri": "#{with_creds}/upstream?heartbeat=10", "exchange": "upstream_ex"}))
        store.create_upstream("a", config2)

        wait_for { link.state.terminated? }
        upstream_vhost.queue_exists?(federation_name).should be_true
        upstream_vhost.exchange_exists?(federation_name).should be_true
      ensure
        store.try &.stop_all
      end
    end

    it "deletes the old upstream resources when a re-created parameter changes the exchange" do
      with_amqp_server do |s|
        UpstreamSpecHelpers.cleanup_vhosts(s)
        upstream_vhost = s.vhosts.create("upstream")
        downstream_vhost = s.vhosts.create("downstream")
        store = downstream_vhost.upstreams
        config = JSON.parse(%({"uri": "#{s.amqp_server.url}/upstream", "exchange": "upstream_ex"}))
        upstream = store.create_upstream("a", config)
        downstream_vhost.declare_exchange("downstream_ex", "topic", true, false)
        ex = downstream_vhost.exchange("downstream_ex").as(LavinMQ::AMQP::Exchange)
        link = upstream.link(ex)
        wait_for { link.state.running? }
        federation_name = "federation: upstream_ex -> #{System.hostname}:downstream:downstream_ex"
        upstream_vhost.queue_exists?(federation_name).should be_true

        # The new links declare resources named after the new exchange, so a
        # kept queue would stay bound to upstream_ex, filling up with nothing
        # consuming it
        config2 = JSON.parse(%({"uri": "#{s.amqp_server.url}/upstream", "exchange": "upstream_ex2"}))
        store.create_upstream("a", config2)

        wait_for { !upstream_vhost.queue_exists?(federation_name) }
        wait_for { !upstream_vhost.exchange_exists?(federation_name) }
      ensure
        store.try &.stop_all
      end
    end

    it "applies a changed expires when an upstream parameter is re-created" do
      with_amqp_server do |s|
        UpstreamSpecHelpers.cleanup_vhosts(s)
        upstream_vhost = s.vhosts.create("upstream")
        downstream_vhost = s.vhosts.create("downstream")
        store = downstream_vhost.upstreams
        config = JSON.parse(%({"uri": "#{s.amqp_server.url}/upstream", "exchange": "upstream_ex"}))
        upstream = store.create_upstream("a", config)
        downstream_vhost.declare_exchange("downstream_ex", "topic", true, false)
        ex = downstream_vhost.exchange("downstream_ex").as(LavinMQ::AMQP::Exchange)
        link = upstream.link(ex)
        wait_for { link.state.running? }
        federation_name = "federation: upstream_ex -> #{System.hostname}:downstream:downstream_ex"
        upstream_vhost.queue_exists?(federation_name).should be_true

        # The link declares the upstream queue passively when it exists, so a
        # changed x-expires only lands when the old queue is removed first
        config2 = JSON.parse(%({"uri": "#{s.amqp_server.url}/upstream", "exchange": "upstream_ex", "expires": 60000}))
        upstream2 = store.create_upstream("a", config2)
        link2 = upstream2.link(ex)
        wait_for { link2.state.running? }

        q = upstream_vhost.queue?(federation_name).should_not be_nil
        q.details_tuple[:arguments]["x-expires"]?.should eq 60_000
      ensure
        store.try &.stop_all
      end
    end

    it "relinks a named set and reuses its resources when an upstream parameter is re-created" do
      with_amqp_server do |s|
        UpstreamSpecHelpers.cleanup_vhosts(s)
        upstream_vhost = s.vhosts.create("upstream")
        downstream_vhost = s.vhosts.create("downstream")
        store = downstream_vhost.upstreams
        config = JSON.parse(%({"uri": "#{s.amqp_server.url}/upstream", "exchange": "upstream_ex"}))
        store.create_upstream("a", config)
        store.create_upstream_set("s1", JSON.parse(%([{"upstream": "a"}])))
        downstream_vhost.declare_exchange("downstream_ex", "topic", true, false)
        ex = downstream_vhost.exchange("downstream_ex").as(LavinMQ::AMQP::Exchange)
        store.reconcile_link(ex, nil, "s1")
        link = store.get_set?("s1").should_not(be_nil).first.links.first
        wait_for { link.state.running? }
        federation_name = "federation: upstream_ex -> #{System.hostname}:downstream:downstream_ex"
        us_q = upstream_vhost.queue?(federation_name).should_not be_nil

        # An identical re-PUT keeps the upstream resources for the new links
        # to reuse, but it also drops the set entries named after the
        # upstream. Without the replacement put back, the policy re-apply
        # reconciles against an empty set and links nothing, orphaning the
        # kept queue on the upstream broker.
        store.create_upstream("a", config)
        store.get_set?("s1").should_not(be_nil).map(&.name).should eq ["a"]
        store.reconcile_link(ex, nil, "s1")

        link2 = store.get_set?("s1").should_not(be_nil).first.links.first
        wait_for { link2.state.running? }
        upstream_vhost.queue?(federation_name).should be us_q
      ensure
        store.try &.stop_all
      end
    end

    it "rebuilds every set that names a re-created upstream" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        config = JSON.parse(%({"uri": "#{s.amqp_server.url}"}))
        store.create_upstream("a", config)
        sets = ["s1", "s2", "s3"]
        sets.each { |name| store.create_upstream_set(name, JSON.parse(%([{"upstream": "a"}]))) }

        # create_upstream_set deletes and re-inserts the set's config, so the
        # rebuild must iterate a snapshot: a mid-iteration hash compaction
        # skips a set, leaving it empty and its policy without links
        store.create_upstream("a", config)

        sets.each do |name|
          store.get_set?(name).should_not(be_nil).map(&.name).should eq ["a"]
        end
      ensure
        store.try &.stop_all
      end
    end

    it "keeps accepting upstream parameters after a malformed set is rejected" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}"})))
        # The rejected config must leave no stored state behind that a later
        # upstream PUT trips over in the set rebuild
        expect_raises(TypeCastError) do
          store.create_upstream_set("bad", JSON.parse(%([{"upstream": 1}])))
        end
        store.create_upstream("b", JSON.parse(%({"uri": "#{s.amqp_server.url}"})))
        store.map(&.name).sort!.should eq ["a", "b"]
      ensure
        store.try &.stop_all
      end
    end

    it "deletes the upstream resources of an override entry that is removed from the set" do
      with_amqp_server do |s|
        upstream_vhost = s.vhosts.create("upstream")
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}/upstream"})))
        store.create_upstream_set("set1",
          JSON.parse(%([{"upstream": "a", "exchange": "upstream_ex"}])))
        vhost.declare_exchange("downstream_ex", "topic", false, false)
        member = store.get_set?("set1").should_not(be_nil).first
        link = member.link(vhost.exchange("downstream_ex"))
        wait_for { link.state.running? }
        federation_name = "federation: upstream_ex -> #{System.hostname}:/:downstream_ex"
        upstream_vhost.queue_exists?(federation_name).should be_true
        upstream_vhost.exchange_exists?(federation_name).should be_true

        store.create_upstream_set("set1", JSON.parse("[]"))

        wait_for { !upstream_vhost.queue_exists?(federation_name) }
        wait_for { !upstream_vhost.exchange_exists?(federation_name) }
      ensure
        store.try &.stop_all
      end
    end

    it "deletes the upstream resources of override entries when the set is deleted" do
      with_amqp_server do |s|
        upstream_vhost = s.vhosts.create("upstream")
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}/upstream"})))
        store.create_upstream_set("set1",
          JSON.parse(%([{"upstream": "a", "exchange": "upstream_ex"}])))
        vhost.declare_exchange("downstream_ex", "topic", false, false)
        member = store.get_set?("set1").should_not(be_nil).first
        link = member.link(vhost.exchange("downstream_ex"))
        wait_for { link.state.running? }
        federation_name = "federation: upstream_ex -> #{System.hostname}:/:downstream_ex"
        upstream_vhost.queue_exists?(federation_name).should be_true

        store.delete_upstream_set("set1")

        wait_for { !upstream_vhost.queue_exists?(federation_name) }
        wait_for { !upstream_vhost.exchange_exists?(federation_name) }
      ensure
        store.try &.stop_all
      end
    end

    it "keeps the upstream resources of an override entry that stays in the set" do
      with_amqp_server do |s|
        upstream_vhost = s.vhosts.create("upstream")
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}/upstream"})))
        set_config = JSON.parse(%([{"upstream": "a", "exchange": "upstream_ex"}]))
        store.create_upstream_set("set1", set_config)
        vhost.declare_exchange("downstream_ex", "topic", false, false)
        member = store.get_set?("set1").should_not(be_nil).first
        link = member.link(vhost.exchange("downstream_ex"))
        wait_for { link.state.running? }
        federation_name = "federation: upstream_ex -> #{System.hostname}:/:downstream_ex"
        upstream_vhost.queue_exists?(federation_name).should be_true

        # The same entry must reuse the resources, so buffered messages survive
        store.create_upstream_set("set1", set_config)

        store.await_pending_deletes(member.uri, federation_name)
        upstream_vhost.queue_exists?(federation_name).should be_true
        upstream_vhost.exchange_exists?(federation_name).should be_true
      ensure
        store.try &.stop_all
      end
    end

    it "keeps the upstream resources when an entry's implicit exchange is made explicit" do
      with_amqp_server do |s|
        upstream_vhost = s.vhosts.create("upstream")
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}/upstream"})))
        store.create_upstream_set("set1",
          JSON.parse(%([{"upstream": "a", "prefetch-count": 99}])))
        vhost.declare_exchange("downstream_ex", "topic", false, false)
        member = store.get_set?("set1").should_not(be_nil).first
        link = member.link(vhost.exchange("downstream_ex"))
        wait_for { link.state.running? }
        federation_name = "federation: downstream_ex -> #{System.hostname}:/:downstream_ex"
        upstream_vhost.queue_exists?(federation_name).should be_true

        # Spelling out the implicit exchange name must not delete the resources
        store.create_upstream_set("set1",
          JSON.parse(%([{"upstream": "a", "exchange": "downstream_ex"}])))

        store.await_pending_deletes(member.uri, federation_name)
        upstream_vhost.queue_exists?(federation_name).should be_true
        upstream_vhost.exchange_exists?(federation_name).should be_true
      ensure
        store.try &.stop_all
      end
    end

    it "keeps the upstream resources when only the uri query of an entry changes" do
      with_amqp_server do |s|
        upstream_vhost = s.vhosts.create("upstream")
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}/upstream"})))
        store.create_upstream_set("set1",
          JSON.parse(%([{"upstream": "a", "exchange": "upstream_ex", "uri": "#{s.amqp_server.url}/upstream"}])))
        vhost.declare_exchange("downstream_ex", "topic", false, false)
        member = store.get_set?("set1").should_not(be_nil).first
        link = member.link(vhost.exchange("downstream_ex"))
        wait_for { link.state.running? }
        federation_name = "federation: upstream_ex -> #{System.hostname}:/:downstream_ex"
        upstream_vhost.queue_exists?(federation_name).should be_true

        store.create_upstream_set("set1",
          JSON.parse(%([{"upstream": "a", "exchange": "upstream_ex", "uri": "#{s.amqp_server.url}/upstream?heartbeat=10"}])))

        store.await_pending_deletes(member.uri, federation_name)
        upstream_vhost.queue_exists?(federation_name).should be_true
        upstream_vhost.exchange_exists?(federation_name).should be_true
      ensure
        store.try &.stop_all
      end
    end

    it "keeps the exchange federation resources when only the queue override changes" do
      with_amqp_server do |s|
        upstream_vhost = s.vhosts.create("upstream")
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}/upstream"})))
        store.create_upstream_set("set1",
          JSON.parse(%([{"upstream": "a", "exchange": "upstream_ex", "queue": "q1"}])))
        vhost.declare_exchange("downstream_ex", "topic", false, false)
        member = store.get_set?("set1").should_not(be_nil).first
        link = member.link(vhost.exchange("downstream_ex"))
        wait_for { link.state.running? }
        federation_name = "federation: upstream_ex -> #{System.hostname}:/:downstream_ex"
        upstream_vhost.queue_exists?(federation_name).should be_true

        # Queue links create nothing upstream, so this must not delete the
        # exchange link's resources
        store.create_upstream_set("set1",
          JSON.parse(%([{"upstream": "a", "exchange": "upstream_ex", "queue": "q2"}])))

        store.await_pending_deletes(member.uri, federation_name)
        upstream_vhost.queue_exists?(federation_name).should be_true
        upstream_vhost.exchange_exists?(federation_name).should be_true
      ensure
        store.try &.stop_all
      end
    end

    it "keeps the upstream resources when the uri changes only by a trailing slash" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}"})))
        store.create_upstream_set("set1",
          JSON.parse(%([{"upstream": "a", "exchange": "upstream_ex", "uri": "#{s.amqp_server.url}"}])))
        vhost.declare_exchange("downstream_ex", "topic", false, false)
        member = store.get_set?("set1").should_not(be_nil).first
        link = member.link(vhost.exchange("downstream_ex"))
        wait_for { link.state.running? }
        federation_name = "federation: upstream_ex -> #{System.hostname}:/:downstream_ex"
        vhost.queue_exists?(federation_name).should be_true

        # An empty path and "/" both mean the default vhost
        store.create_upstream_set("set1",
          JSON.parse(%([{"upstream": "a", "exchange": "upstream_ex", "uri": "#{s.amqp_server.url}/"}])))

        store.await_pending_deletes(member.uri, federation_name)
        vhost.queue_exists?(federation_name).should be_true
        vhost.exchange_exists?(federation_name).should be_true
      ensure
        store.try &.stop_all
      end
    end

    it "redeclares the queue with the new arguments when an entry keeps its name" do
      with_amqp_server do |s|
        upstream_vhost = s.vhosts.create("upstream")
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}/upstream"})))
        store.create_upstream_set("set1",
          JSON.parse(%([{"upstream": "a", "exchange": "upstream_ex", "expires": 60000}])))
        vhost.declare_exchange("downstream_ex", "topic", false, false)
        member = store.get_set?("set1").should_not(be_nil).first
        link = member.link(vhost.exchange("downstream_ex"))
        wait_for { link.state.running? }
        federation_name = "federation: upstream_ex -> #{System.hostname}:/:downstream_ex"
        old_q = upstream_vhost.queue?(federation_name).should_not be_nil

        # A passive re-declare of the old queue would keep the old x-expires
        store.create_upstream_set("set1",
          JSON.parse(%([{"upstream": "a", "exchange": "upstream_ex", "expires": 120000}])))
        new_link = store.get_set?("set1").should_not(be_nil).first.link(vhost.exchange("downstream_ex"))
        wait_for { new_link.state.running? }

        q = upstream_vhost.queue?(federation_name).should_not be_nil
        q.should_not be old_q
        q.details_tuple[:arguments]["x-expires"]?.should eq 120_000
      ensure
        store.try &.stop_all
      end
    end

    it "finishes pending deletes before a re-created set reuses the queue names" do
      with_amqp_server do |s|
        upstream_vhost = s.vhosts.create("upstream")
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}/upstream"})))
        set_config = JSON.parse(%([{"upstream": "a", "exchange": "upstream_ex"}]))
        store.create_upstream_set("set1", set_config)
        vhost.declare_exchange("downstream_ex", "topic", false, false)
        member = store.get_set?("set1").should_not(be_nil).first
        link = member.link(vhost.exchange("downstream_ex"))
        wait_for { link.state.running? }
        federation_name = "federation: upstream_ex -> #{System.hostname}:/:downstream_ex"
        upstream_vhost.queue_exists?(federation_name).should be_true

        # The delete must not outlive a re-created set that reuses the name
        store.delete_upstream_set("set1")
        store.create_upstream_set("set1", set_config)

        member2 = store.get_set?("set1").should_not(be_nil).first
        link2 = member2.link(vhost.exchange("downstream_ex"))
        wait_for { link2.state.running? }
        upstream_vhost.queue_exists?(federation_name).should be_true
        25.times { Fiber.yield; sleep 2.milliseconds }
        upstream_vhost.queue_exists?(federation_name).should be_true
      ensure
        store.try &.stop_all
      end
    end

    it "doesn't hold declares or later set changes behind a delete in flight" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        UpstreamSpecHelpers.with_gated_proxy(s) do |proxy_url, accepted, _gate|
          # "a" federates from the same vhost, so its delete needs the
          # definitions lock that a declare waiting on the store would hold
          store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}"})))
          store.create_upstream("hung", JSON.parse(%({"uri": "#{proxy_url}"})))
          store.create_upstream_set("set1",
            JSON.parse(%([{"upstream": "hung", "exchange": "hung_ex"}, {"upstream": "a", "exchange": "src_ex"}])))
          vhost.declare_exchange("src_ex", "topic", false, false)
          vhost.declare_exchange("downstream_ex", "topic", false, false)
          hung_member, local_member = store.get_set?("set1").should_not(be_nil)
          hung_member.link(vhost.exchange("downstream_ex"))
          accepted.receive # the hung member's link is parked in its connect
          local_link = local_member.link(vhost.exchange("downstream_ex"))
          wait_for { local_link.state.running? }
          local_q = "federation: src_ex -> #{System.hostname}:/:downstream_ex"

          spawn { store.create_upstream_set("set1", JSON.parse("[]")) }
          accepted.receive # the hung member's delete is parked in its connect
          done = Channel(Nil).new
          spawn do
            vhost.declare_queue("q_during_delete", false, false)
            store.create_upstream_set("set1", JSON.parse(%([{"upstream": "a", "exchange": "ex2"}])))
            done.close
          end
          select
          when done.receive?
          when timeout(5.seconds)
            fail "a declare or set change waited for the delete in flight"
          end

          store.get_set?("set1").should_not(be_nil).first.exchange.should eq "ex2"
          wait_for { !vhost.queue_exists?(local_q) }
        end
      ensure
        store.try &.stop_all
      end
    end

    it "makes a link wait for a delete of its queue that is still in flight" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        UpstreamSpecHelpers.with_gated_proxy(s) do |proxy_url, accepted, gate|
          store.create_upstream("a", JSON.parse(%({"uri": "#{proxy_url}"})))
          store.create_upstream_set("set1",
            JSON.parse(%([{"upstream": "a", "exchange": "upstream_ex", "expires": 60000}])))
          vhost.declare_exchange("downstream_ex", "topic", false, false)
          store.get_set?("set1").should_not(be_nil).first.link(vhost.exchange("downstream_ex"))
          accepted.receive # the old link is parked in its connect

          # Same queue name with new arguments: the old queue is deleted, and
          # the new link must not declare until that delete is done
          store.create_upstream_set("set1",
            JSON.parse(%([{"upstream": "a", "exchange": "upstream_ex", "expires": 120000}])))
          accepted.receive # the delete is parked in its connect
          link = store.get_set?("set1").should_not(be_nil).first.link(vhost.exchange("downstream_ex"))
          sleep 100.milliseconds
          select
          when accepted.receive
            fail "the new link connected while the delete was in flight"
          else
          end

          gate.close
          wait_for { link.state.running? }
        end
      ensure
        store.try &.stop_all
      end
    end

    it "keeps the previous parameter and the running set when a set update is rejected" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        vhost.add_parameter(LavinMQ::Parameter.new("federation-upstream", "a",
          JSON.parse(%({"uri": "#{s.amqp_server.url}"}))))
        good = JSON.parse(%([{"upstream": "a", "exchange": "upstream_ex"}]))
        vhost.add_parameter(LavinMQ::Parameter.new("federation-upstream-set", "set1", good))
        member = store.get_set?("set1").should_not(be_nil).first

        # The store and the running set must agree on the old config
        expect_raises(KeyError) do
          vhost.add_parameter(LavinMQ::Parameter.new("federation-upstream-set", "set1",
            JSON.parse(%([{"exchange": "upstream_ex"}]))))
        end

        param = vhost.parameters[{"federation-upstream-set", "set1"}]?.should_not be_nil
        param.value.should eq good
        store.get_set?("set1").should_not(be_nil).first.should be member
      ensure
        store.try &.stop_all
      end
    end

    it "leaves the old set and its links untouched when the new set config is malformed" do
      with_amqp_server do |s|
        s.vhosts.create("upstream")
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}/upstream"})))
        store.create_upstream_set("set1",
          JSON.parse(%([{"upstream": "a", "exchange": "upstream_ex"}])))
        vhost.declare_exchange("downstream_ex", "topic", false, false)
        member = store.get_set?("set1").should_not(be_nil).first
        link = member.link(vhost.exchange("downstream_ex"))
        wait_for { link.state.running? }

        expect_raises(KeyError) do
          store.create_upstream_set("set1", JSON.parse(%([{"exchange": "upstream_ex"}])))
        end

        store.get_set?("set1").should_not(be_nil).first.should be member
        link.state.running?.should be_true
      ensure
        store.try &.stop_all
      end
    end

    it "stops the links of a set member with overrides when the set is replaced or deleted" do
      with_amqp_server do |s|
        vhost = s.vhosts["/"]
        store = vhost.upstreams
        store.create_upstream("a", JSON.parse(%({"uri": "#{s.amqp_server.url}"})))
        set_config = JSON.parse(%([{"upstream": "a", "prefetch-count": 99}]))
        vhost.declare_exchange("ex", "topic", false, false)
        ex = vhost.exchange("ex")

        store.create_upstream_set("set1", set_config)
        replaced = store.get_set?("set1").should_not(be_nil).first
        replaced_link = replaced.link(ex)
        # Once replaced the copy is out of the store's reach, so its link
        # would no longer follow bindings or deletes of the exchange
        store.create_upstream_set("set1", set_config)
        replaced.links.should be_empty
        wait_for { replaced_link.state.terminated? }

        deleted = store.get_set?("set1").should_not(be_nil).first
        deleted_link = deleted.link(ex)
        store.delete_upstream_set("set1")
        deleted.links.should be_empty
        wait_for { deleted_link.state.terminated? }
      ensure
        store.try &.stop_all
      end
    end
  end

  describe "shutdown" do
    it "closes federation links without logging unexpected-close errors" do
      # A federation link's upstream connection lives on another vhost. On
      # broker shutdown every link must be stopped first (cleanly closing those
      # connections against still-live peers); otherwise a peer vhost can
      # force-close the link's socket mid-flight and the amqp-client read loop
      # logs "connection closed unexpectedly" / "Couldn't write CloseOk frame".
      Log.capture("amqp.client.connection", :error) do |logs|
        with_amqp_server do |s|
          upstream, up, down = UpstreamSpecHelpers.setup_federation(s, "shutdown-test", nil, "uq")
          up.declare_queue("uq", false, false)
          down.declare_queue("dq", false, false)
          link = upstream.link(down.queue("dq"))
          wait_for { link.state.running? }
        end
        # with_amqp_server's teardown has now run s.close (the broker shutdown).
        logs.empty
      end
    end
  end
end
