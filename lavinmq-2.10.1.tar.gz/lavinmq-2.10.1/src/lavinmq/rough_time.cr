module RoughTime
  @@utc = Time.utc
  @@unix_ms : Int64 = @@utc.to_unix_ms // 100 * 100
  @@instant = Time.instant

  Fiber::ExecutionContext::Isolated.new("RoughTime") do
    loop do
      sleep 0.1.seconds
      @@utc = Time.utc
      @@unix_ms = @@utc.to_unix_ms // 100 * 100
      @@instant = Time.instant
    end
  end

  def self.utc : Time
    @@utc
  end

  def self.unix_ms : Int64
    @@unix_ms
  end

  def self.instant : Time::Instant
    @@instant
  end
end
