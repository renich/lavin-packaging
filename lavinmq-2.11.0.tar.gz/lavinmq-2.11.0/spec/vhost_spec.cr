require "./spec_helper"

describe LavinMQ::VHost do
  it "should be able to create vhosts" do
    with_amqp_server do |s|
      s.vhosts.create("test")
      s.vhosts["test"]?.should_not be_nil
    end
  end

  it "should be able to delete vhosts" do
    with_amqp_server do |s|
      s.vhosts.create("test")
      s.vhosts.delete("test")
      s.vhosts["test"]?.should be_nil
    end
  end

  it "should be able to persist vhosts" do
    with_amqp_server do |s|
      s.vhosts.create("test")
      restart_server(s)
      s.vhosts["test"]?.should_not be_nil
    end
  end

  it "saves the MQTT default group when the vhost is created" do
    with_amqp_server do |s|
      vhost = s.vhosts.create("test")
      path = File.join(vhost.data_dir, "mqtt_permissions.json")
      original = vhost.mqtt_permission_service.to_json
      JSON.parse(File.read(path)).should eq JSON.parse(original)

      restart_server(s)

      s.vhosts["test"].mqtt_permission_service.to_json.should eq original
    end
  end

  it "keeps a deleted MQTT default group deleted after close and restart" do
    with_amqp_server do |s|
      vhost = s.vhosts.create("test")
      path = File.join(vhost.data_dir, "mqtt_permissions.json")
      vhost.mqtt_permission_service.delete("default")

      restart_server(s)

      JSON.parse(File.read(path)).as_a.should be_empty
      service = s.vhosts["test"].mqtt_permission_service
      service.size.should eq 0
      context = LavinMQ::MQTT::PermissionService::Context.new("guest", "dev")
      service.can_read?(context, "anything").should be_false
      service.can_write?(context, "anything").should be_false
    end
  end

  it "should be able to persist durable exchanges" do
    with_amqp_server do |s|
      s.vhosts.create("test")
      v = s.vhosts["test"]
      v.declare_exchange("e", "direct", true, false)
      restart_server(s)
      s.vhosts["test"].exchange("e").should_not be_nil
    end
  end

  it "should be able to persist durable delayed exchanges when type = x-delayed-message" do
    config = LavinMQ::Config.new
    with_amqp_server do |s|
      # This spec is to verify a fix where a server couldn't start again after a crash if
      # an delayed exchange had been declared by specifiying the type as "x-delayed-message".
      s.vhosts.create("test")
      v = s.vhosts["test"]
      arguments = AMQ::Protocol::Table.new({"x-delayed-type": "direct"})
      v.declare_exchange("e", "x-delayed-message", true, false, arguments: arguments)

      # Start a new server with the same data dir as `Server` without stopping
      # `Server` first, because stopping would compact definitions and therefore "rewrite"
      config.data_dir = s.data_dir
    end
    # the definitions file. This is to simulate a start after a "crash".
    # If this succeeds we assume it worked...?
    LavinMQ::Server.new(config)
  end

  it "should be able to persist durable queues" do
    with_amqp_server do |s|
      s.vhosts.create("test")
      v = s.vhosts["test"]
      v.declare_queue("q", true, false)
      restart_server(s)
      s.vhosts["test"].queue("q").should_not be_nil
    end
  end

  it "should be able to persist bindings" do
    with_amqp_server do |s|
      s.vhosts.create("test")
      v = s.vhosts["test"]
      v.declare_exchange("e", "direct", true, false)
      v.declare_queue("q", true, false)
      s.vhosts["test"].bind_queue("q", "e", "q")
      restart_server(s)
      s.vhosts["test"].exchange("e").bindings_details.first.destination.name.should eq "q"
    end
  end

  it "should not write bind frame to definition file for existing binding" do
    with_amqp_server do |s|
      s.vhosts.create("test")
      v = s.vhosts["test"]
      v.declare_exchange("e", "direct", true, false)
      v.declare_queue("q", true, false)
      s.vhosts["test"].bind_queue("q", "e", "q")
      pos = v.@definitions.not_nil!("definitions not initialized").@definitions_file.pos
      s.vhosts["test"].bind_queue("q", "e", "q")
      v.@definitions.not_nil!("definitions not initialized").@definitions_file.pos.should eq pos
    end
  end

  it "should not write unbind frame to definition file for non-existing binding" do
    with_amqp_server do |s|
      s.vhosts.create("test")
      v = s.vhosts["test"]
      v.declare_exchange("e", "direct", true, false)
      v.declare_queue("q", true, false)
      s.vhosts["test"].bind_queue("q", "e", "q")
      s.vhosts["test"].unbind_queue("q", "e", "q")
      pos = v.@definitions.not_nil!("definitions not initialized").@definitions_file.pos
      s.vhosts["test"].unbind_queue("q", "e", "q")
      v.@definitions.not_nil!("definitions not initialized").@definitions_file.pos.should eq pos
    end
  end

  it "should compact definitions during runtime" do
    with_amqp_server do |s|
      LavinMQ::Config.instance.max_deleted_definitions = 8
      v = s.vhosts.create("test")
      (LavinMQ::Config.instance.max_deleted_definitions - 1).times do
        v.declare_queue("q", true, false)
        v.delete_queue("q")
      end
      file_size = v.@definitions.not_nil!("definitions not initialized").@definitions_file.size
      v.declare_queue("q", true, false)
      v.delete_queue("q")
      v.@definitions.not_nil!("definitions not initialized").@definitions_file.size.should be < file_size
    end
  end

  it "should keep durable mqtt sessions after compaction and restart" do
    with_amqp_server do |s|
      LavinMQ::Config.instance.max_deleted_definitions = 8
      v = s.vhosts["/"]
      v.declare_queue("mqtt.persist", true, false, LavinMQ::AMQP::Table.new({"x-queue-type" => "mqtt"}))
      LavinMQ::Config.instance.max_deleted_definitions.times do
        v.declare_queue("q", true, false)
        v.delete_queue("q")
      end
      restart_server(s)
      session = s.vhosts["/"].session?("mqtt.persist")
      session.should_not be_nil
      s.vhosts["/"].queue?("mqtt.persist").should be_nil
    end
  end

  it "should keep durable mqtt session bindings after compaction and restart" do
    with_amqp_server do |s|
      LavinMQ::Config.instance.max_deleted_definitions = 8
      v = s.vhosts["/"]
      v.declare_queue("mqtt.persist", true, false, LavinMQ::AMQP::Table.new({"x-queue-type" => "mqtt"}))
      v.bind_queue("mqtt.persist", LavinMQ::MQTT::EXCHANGE, "a/b",
        LavinMQ::AMQP::Table.new({LavinMQ::MQTT::QOS_HEADER => 1u8}))
      LavinMQ::Config.instance.max_deleted_definitions.times do
        v.declare_queue("q", true, false)
        v.delete_queue("q")
      end
      restart_server(s)
      bindings = s.vhosts["/"].mqtt_exchange.bindings_details
      bindings.map(&.binding_key.routing_key).should eq ["a/b"]
      bindings.first.arguments.try &.[](LavinMQ::MQTT::QOS_HEADER).should eq 1u8
    end
  end

  describe "auto add permissions" do
    it "should add permission to the user creating the vhost" do
      with_amqp_server do |s|
        username = "test-user"
        user = s.users.create(username, "password", [LavinMQ::Tag::Administrator])
        vhost = "test-vhost"
        s.vhosts.create(vhost, user)
        p = user.permissions[vhost]
        p[:config].should eq /.*/
        p[:read].should eq /.*/
        p[:write].should eq /.*/
      end
    end

    it "should auto add permission to the default user" do
      with_amqp_server do |s|
        vhost = "test-vhost"
        s.vhosts.create(vhost)
        user = s.users.default_user
        p = user.permissions[vhost]
        p[:config].should eq /.*/
        p[:read].should eq /.*/
        p[:write].should eq /.*/
      end
    end
  end

  it "can limit queues" do
    with_amqp_server do |s|
      vhost = s.vhosts["/"]
      vhost.max_queues = 1
      with_channel(s) do |ch|
        ch.queue
        expect_raises(AMQP::Client::Channel::ClosedException, /queue limit/) do
          ch.queue
        end
      end
      vhost.max_queues = -1
      with_channel(s) do |ch|
        ch.queue
      end
    end
  end

  it "can limit connections" do
    with_amqp_server do |s|
      vhost = s.vhosts["/"]
      vhost.max_connections = 1
      with_channel(s) do |_ch|
        expect_raises(AMQP::Client::Connection::ClosedException, /connection limit/) do
          with_channel(s) do |_ch2|
          end
        end
        vhost.max_connections = -1
        with_channel(s) do |_ch3|
        end
      end
    end
  end

  # A closed connection removes itself from the vhost, which must not make
  # the close skip the next one: that one would be served by a closed vhost
  it "closes every connection, also when they're removed while closing" do
    with_amqp_server do |s|
      vhost = s.vhosts["/"]
      conns = Array.new(3) { AMQP::Client.new(port: amqp_port(s)).connect }
      begin
        wait_for { vhost.connections_size == conns.size }
        clients = vhost.connections.map(&.as(LavinMQ::AMQP::Client))
        # Runs when closing yields, like the first one's read loop ending
        spawn { vhost.rm_connection(clients.first) }
        vhost.@connections.close_all("Broker shutdown", vhost.@log)
        clients.reject(&.closed?).map(&.name).should be_empty
      ensure
        conns.each { |c| c.close rescue nil }
      end
    end
  end

  it "closes a connection that's added once it's closed" do
    with_amqp_server do |s|
      with_channel(s) do |_ch|
        client = s.vhosts["/"].connections.first.as(LavinMQ::AMQP::Client)
        closed_vhost = s.vhosts.create("closed")
        closed_vhost.close
        closed_vhost.add_connection(client)
        client.closed?.should be_true
      end
    end
  end

  it "serializes concurrent saves so they don't race on the tmp file" do
    with_amqp_server do |s|
      store = s.vhosts
      # Concurrent vhost create/delete (e.g. under churn) all call save!, which
      # shares one vhosts.json.tmp path. Without serialization two saves race
      # and one's rename finds the tmp already moved by the other.
      failures = Atomic(Int32).new(0)
      WaitGroup.wait do |wg|
        40.times do
          wg.spawn do
            store.save!
          rescue
            failures.add(1)
          end
        end
      end
      failures.get.should eq 0
    end
  end
end
