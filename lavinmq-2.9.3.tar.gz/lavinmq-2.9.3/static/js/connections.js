import * as HTTP from './http.js'
import * as Table from './table.js'

const vhost = window.sessionStorage.getItem('vhost')
const numFormatter = new Intl.NumberFormat()
let url = 'api/connections'
if (vhost && vhost !== '_all') {
  url = HTTP.url`api/vhosts/${vhost}/connections`
}
const tableOptions = {
  url,
  keyColumns: ['name'],
  pagination: true,
  columnSelector: true,
  search: true
}

Table.renderTable('table', tableOptions, function (tr, item, all) {
  if (all) {
    const connectionLink = document.createElement('a')
    connectionLink.href = HTTP.url`connection#name=${item.name}`
    connectionLink.appendChild(document.createElement('span')).textContent = item.name
    connectionLink.appendChild(document.createElement('br'))
    // Show connection_name for AMQP, client_id for MQTT
    const clientIdentifier = item.protocol && item.protocol.includes('AMQP')
      ? item.client_properties.connection_name
      : item.client_id
    connectionLink.appendChild(document.createElement('small')).textContent = clientIdentifier
    Table.renderCell(tr, 0, item.vhost)
    Table.renderCell(tr, 1, connectionLink)
    Table.renderCell(tr, 2, item.user)
    Table.renderCell(tr, 4, item.ssl ? '🔒' : '', 'center')
    Table.renderCell(tr, 5, item.tls_version, 'center')
    Table.renderCell(tr, 6, item.cipher, 'center')
    Table.renderCell(tr, 7, item.protocol, 'center')
    Table.renderCell(tr, 8, item.auth_mechanism)
    Table.renderCell(tr, 9, item.channel_max, 'right')
    Table.renderCell(tr, 10, item.timeout, 'right')
    const clientDiv = document.createElement('span')
    if (item.client_properties.product) {
      clientDiv.textContent = `${item.client_properties.product || ''} / ${item.client_properties.platform || ''}`
    } else {
      clientDiv.textContent = item.client_properties.platform || ''
    }
    clientDiv.appendChild(document.createElement('br'))
    clientDiv.appendChild(document.createElement('small')).textContent = item.client_properties.version
    Table.renderCell(tr, 11, clientDiv)
    Table.renderCell(tr, 12, new Date(item.connected_at).toLocaleString(), 'center')
  }
  Table.renderCell(tr, 3, null, `center state-${item.state}`)
  Table.renderCell(tr, 8, item.channels, 'right')
  Table.renderCell(tr, 13, numFormatter.format(item.recv_oct), 'right')
  Table.renderCell(tr, 14, numFormatter.format(item.send_oct), 'right')
})
