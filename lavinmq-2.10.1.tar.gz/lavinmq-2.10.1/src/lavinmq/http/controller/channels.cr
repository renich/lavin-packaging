require "uri"
require "../controller"
require "./connections"

module LavinMQ
  module HTTP
    class ChannelsController < Controller
      include ConnectionsHelper

      private def register_routes
        get "/api/channels" do |context, _params|
          page(context, all_channels(user(context)))
        end

        get "/api/vhosts/:vhost/channels" do |context, params|
          with_vhost(context, params) do |vhost|
            refuse_unless_management(context, user(context), vhost)
            channels = vhost.connections.flat_map(&.channels)
            page(context, channels)
          end
        end

        get "/api/channels/:name" do |context, params|
          with_channel(context, params) do |channel|
            channel.to_json(context.response)
          end
        end

        delete "/api/channels/:name" do |context, params|
          with_channel(context, params) do |channel|
            access_refused(context) unless can_access_connection?(channel.client, user(context))
            reason = context.request.headers["X-Reason"]? || "Closed via management plugin"
            channel.close(reason)
            context.response.status_code = 204
          end
        end

        put "/api/channels/:name" do |context, params|
          with_channel(context, params) do |channel|
            body = parse_body(context)
            if prefetch = body["prefetch"]?.try(&.as_i?)
              unless 0 <= prefetch <= UInt16::MAX
                bad_request(context, "prefetch must be between 0 and #{UInt16::MAX}")
              end
              channel.prefetch_count = prefetch.to_u16
            end
            context.response.status_code = 204
          end
        end
      end

      private def all_channels(user) : Array(Client::Channel)
        connections(user).flat_map(&.channels)
      end

      private def with_channel(context, params, &)
        name = params["name"]
        channel = all_channels(user(context)).find { |c| c.name == name }
        not_found(context, "Channel #{name} does not exist") unless channel
        yield channel
        context
      end
    end
  end
end
